# TGP Chat v0.6: Rust and TypeScript Technical Specification

This volume describes how every non-financial feature in the catalog is intended to operate, including trust boundaries, state machines, persistence, failure handling, and implementation acceptance. The financial subsystem receives its own volume because mixing wallet authority into a general chat architecture would obscure the highest-consequence boundaries.

## Architecture overview

### Logical component graph

```text
TypeScript UI
  | typed, capability-scoped commands and read models
  v
Rust application facade
  +-- profile/contact/verification state
  +-- direct-session engine --> independent endpoint sessions
  +-- group engine ---------> separate MLS leaf per endpoint
  +-- admission/authority --> explicit reviewed scope transitions
  +-- vault/storage -------> protected local records and local search
  +-- archive/sync --------> selected content, never live-state cloning
  +-- media worker --------> bounded sanitization/decoding/capture
  +-- network broker ------> Tor --> ingress relay --> destination relay
  +-- platform adapters ---> OS key protection / notifications / files
  +-- payment bridge ------> isolated Rust wallet runtime

Rust services, separately deployable:
  relay | rendezvous | signed directory | optional blob experiment
  optional platform wake adapter, independent of message content

No TGP account database. No global profile key visible to every peer.
No server-side contact directory. No server-side wallet API.
```

The graph defines responsibilities, not proven process isolation. Desktop, Android, and iOS need separate realizations; a box in a diagram is not a security boundary until access, IPC, memory, sockets, files, and failure behavior are tested.

### Proposed source layout

| Area | Rust crate or TypeScript package | Responsibility and restrictions |
|---|---|---|
| Domain types | `tgp-types` | Versioned event IDs, bounded values, typed identifiers; no sockets or key storage |
| Application facade | `tgp-app` | Command authorization, cancellation, idempotency, UI read models |
| Identity | `tgp-identity` | Scope-local identity objects, continuity, verified key records |
| Direct crypto | `tgp-direct` | Narrow maintained protocol adapter; no UI-defined crypto choices |
| Invitations | `tgp-invite` | Ceremony orchestration, one-use lifecycle, reviewed PAKE adapter |
| Groups | `tgp-groups` | MLS adapter, policy, membership/ordering/fork handling |
| Authority | `tgp-authority` | Grants, migrations, revocations, distinct role checks |
| Storage | `tgp-store` | Encrypted records, transactions, migration, outbox, tombstones |
| Vault | `tgp-vault` | Unlock leases, key wrapping, per-scope key availability |
| Sync/archive | `tgp-sync`, `tgp-archive` | Selected data transport, eligible-history containers, no live state |
| Network | `tgp-net` | Only approved socket ownership, destination policy, transport lifecycle |
| Delivery | `tgp-delivery` | Envelopes, queue capabilities, receipt and retry state |
| Media | `tgp-media` | Bounded worker, safe formats, metadata removal, encrypted staging |
| Calls | `tgp-call` | Experimental admission/capture/key-state controller |
| Notifications | `tgp-notify` | Minimal wake adapters with no message database access |
| Wallet facade | `tgp-wallet` | Separate runtime facade; excluded from chat-only build |
| Bridge | `tgp-pay-bridge` | Narrow request intents and result handles; no raw seed API |
| Diagnostics | `tgp-diagnostics` | Local checks, bounded redaction, user-reviewed export |
| Updates | `tgp-release` | Signed metadata, compatibility, rollback decisions |
| Relay | `tgp-relayd` | Opaque capability queues, quotas, TTL, no content keys |
| Rendezvous | `tgp-rendezvousd` | Expiring invitation mailbox, no person directory |
| Directory | `tgp-directory` | Signed infrastructure manifests and operator declarations |
| Blob experiment | `tgp-blobd` | Default-disabled ciphertext-only attachment experiment |
| Mobile shell | `apps/mobile` | React Native TypeScript; native UI/key/permission adapters |
| Desktop shell | `apps/desktop` | Tauri 2 TypeScript UI; explicit command permissions |
| Shared UI | `packages/tokens`, `packages/components` | Visual tokens, accessible components, no transport |
| View models | `packages/view-models` | Derived presentation only, not security authority |
| Bridge types | `packages/core-api` | Generated bounded command/result types |
| Copy | `packages/copy` | Localized exact language, separate from protocol reason codes |
| Test vectors | `fixtures/protocol`, `fixtures/ux` | Synthetic contacts/funds only; never production secrets |

### Process realization

| Platform | Proposed realization | Required limitation |
|---|---|---|
| Desktop | Sandboxed webview, Rust app process, separately sandboxed wallet/media workers, network broker | Tauri is not automatically a wallet process sandbox; OS-specific policies required |
| Android | RN UI/native facade; isolated media worker; separately permissioned wallet service where feasible; controlled network service | Shared UID/files/process permissions must be measured, not assumed isolated because different services |
| iOS | RN UI and Rust libraries in app sandbox; restricted extensions; wallet keys separately protected; separate install if strict process boundary cannot be met | Arbitrary persistent child processes cannot be assumed; in-process modules are not equivalent to independent OS sandboxes |
| Servers | Separate deployments, credentials, service roles, no shared relationship logs | Separate hostnames under one operator do not prove operator independence |

If the financial isolation requirement cannot be established on a platform, its integrated wallet stays disabled and the separately installed-wallet/export option is evaluated. This is an explicit platform gate, not permission to weaken INV-14.

React Native UniFFI bindings can generate TypeScript and JSI/C++ integration from Rust annotations, but the project is an integration dependency rather than a proof of secret isolation ([UniFFI React Native bindings](https://github.com/jhugman/uniffi-bindgen-react-native)). Tauri capabilities need explicit review of custom commands and merged window permissions; its documentation notes that registered commands can otherwise be available broadly ([Tauri capabilities](https://v2.tauri.app/security/capabilities/)).

## Cryptographic specification and qualification

### Profile register

| Surface | Preferred candidate | Mandatory condition | Prohibited shortcut |
|---|---|---|---|
| Direct handshake | libsignal-supported PQXDH profile | Pin exact implementation/profile; review scoped identity and prekey publication | Describe a generic KEM plus X25519 as “Signal” |
| Direct message evolution | Maintained libsignal Double Ratchet plus supported SPQR/Triple Ratchet | Require selected profile; no first-message compatibility downgrade in TGP production profile | Claim initial PQ handshake provides continuing PQ recovery |
| Group messaging | OpenMLS using approved hybrid PQ suite | Actual suite, codepoint, implementation, dependency fixes, interoperability, composition review | Production classical-only fallback to meet schedule |
| Low-entropy invitation | Reviewed PAKE implementation; CPace is a candidate | Full invitation composition review, one-use failure policy, transcript binding, PQ requirement analysis | Handwritten CPace-plus-KEM combiner |
| High-entropy invitation | Reviewed authenticated encrypted channel anchored in one-use QR secret | Mutual binding of scope keys, fresh endpoint keys, expiry, and capabilities | Treat a public link as a secret |
| Pairing | Reviewed compared-transcript secure channel | Fresh keys on new device; confirm both devices | Copy live session database |
| Local database | SQLCipher-class reviewed implementation | Exact configuration, database/WAL/temp behavior, per-chat separation | Assume one encrypted DB protects chats from other unlocked chats |
| Passphrase derivation | Argon2id | Benchmark and pin minimum parameters per supported device class | Fast hash or silent low-memory downgrade |
| Attachment/archive encryption | Maintained streaming/container construction | Unique key/nonces, chunk authentication, manifest binding, truncation/order checks | Assemble a novel AEAD stream by concatenation |
| Directory/releases | Maintained signature scheme/profile with threshold/offline release governance as reviewed | Signed version/expiry, rollback checks, rotation, transparent evidence | One online signing key as sole update authority |
| Call frames | Reviewed SFrame-compatible candidate plus independent call admission | Full sender authenticity, replay, counters, rekey, transport profile | “Uses SFrame” as complete call security |
| Wallet signing | Chain/hardware-supported protocols | Exact device/firmware/application matrix | Reuse messaging identity as payment signing key |

Signal describes SPQR as an ongoing post-quantum ratchet combined with the Double Ratchet to form the Triple Ratchet; its rollout logic includes a compatibility phase that is not automatically suitable for TGP's strict profile ([Signal SPQR](https://signal.org/blog/spqr/)). PQXDH's documented authentication and deniability limits must remain in TGP's claims rather than being replaced by “fully post-quantum anonymous messaging” ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/)).

OpenMLS's historical X-Wing experiment uses a draft suite without a standard IANA assignment, and the current IETF PQ suite work is still described as an Internet-Draft in the fetched material ([OpenMLS PQ experiment](https://blog.openmls.tech/posts/2024-04-11-pq-openmls/), [MLS PQ ciphersuites draft](https://datatracker.ietf.org/doc/html/draft-ietf-mls-pq-ciphersuites-06)). Therefore the production group profile remains a blocking ADR, not a solved checklist item.

### Dependency governance

libsignal is AGPLv3, describes use outside Signal as unsupported, and exposes APIs that may change; adopting it requires a maintained compatibility strategy and license/distribution review ([libsignal repository](https://github.com/signalapp/libsignal)). SQLCipher Community Edition has attribution and license-notice requirements that must appear in the application and release materials ([SQLCipher licensing](https://www.zetetic.net/sqlcipher/license/)).

An upstream audit does not validate TGP composition. OpenMLS reports an independent SRLabs assessment with remediations in identified releases and a remaining low-severity item, while a libcrux dependency advisory identifies an AArch64 constant-time select/swap issue and patched versions ([OpenMLS audit report announcement](https://blog.phnx.im/openmls-independent-security-audit/), [RustSec advisory RUSTSEC-2026-0212](https://rustsec.org/advisories/RUSTSEC-2026-0212.html)).

The build gate MUST consume current advisories, exact lockfiles, compiler flags, architecture-specific tests, and license inventory. No dependency version in this proposal is a timeless safe-version declaration.

### Key hierarchy and secret lifecycle

```text
OS random source
  +--> device wrapping/gating key (non-synchronizing where supported)
  +--> local app settings/store key
  +--> per-conversation vault keys
  +--> independent relationship identity and endpoint state
  +--> independent group credentials and MLS leaf state
  +--> independent pairing ephemeral state
  +--> independent archive encryption material
  +--> wallet runtime randomness --> separate per-wallet recovery/signing roots

No arrow from messaging root to wallet root.
No universal externally visible device certificate across relationships.
No reuse of a running ratchet or MLS sending leaf across installations.
```

Scope-local credentials may be managed under local organizational authority, but the exported credentials MUST NOT expose a universal root/certificate. This requires protocol review; it is not achieved by displaying different avatars.

Key access is expressed as bounded unlock leases. Background queues may accept/store ciphertext under a low-privilege spool key if reviewed, but locked content keys and wallet spending keys stay unavailable. UI state, biometric success, and a cached route status are not interchangeable with authority to use a key.

Secret erasure is best-effort memory hygiene plus explicit storage lifecycle; the OS, allocator, flash, snapshots, and recipient copies constrain absolute claims. Crash tests must establish that send-state persistence never moves backward into nonce/key reuse.

## Common application contracts

### Typed command boundary

The frontend sends intent, never raw protocol state. Rust checks current authority, vault state, version, bounds, capability, and expected revision before causing an effect.

```typescript
type CommandEnvelope<T> = {
  apiVersion: 1;
  commandId: string;           // locally unique, not a provider account ID
  expectedRevision?: string;   // optimistic concurrency, not wall-clock authority
  intent: T;
};

type SendTextIntent = {
  kind: "send_text";
  localConversationHandle: string;
  draftHandle: string;         // core-owned text, with bounded input API
  replyToLocalEvent?: string;
};

type LinkScopeIntent = {
  kind: "approve_device_scopes";
  pairingHandle: string;
  selectedScopes: string[];
  historyPlanHandle: string;   // reviewed separately, defaults to none
};
```

These are application schemas, not a custom cryptographic wire protocol. Generated types help prevent accidental misuse but Rust authorization remains mandatory for hostile or compromised frontend inputs.

Commands return `accepted`, `requires_review`, `blocked`, `conflict`, or `failed`, plus machine reason code and safe localized-copy key. Long tasks emit a capability-scoped progress stream that is cancelled/purged on lock; a late callback cannot resurrect an obsolete screen or grant.

### Encrypted event classes

| Class | Examples | Authorization |
|---|---|---|
| Content | Text, attachment descriptor, voice note | Admitted sender in current permitted state |
| Content mutation | Edit, reaction, deletion request | Author/policy check, target in same scope |
| Relationship | Endpoint proposal, admission, key change | Relationship continuity policy |
| Group control | Proposal, commit, role/policy change | MLS validity plus application authority and consent |
| Own-device sync | Allowed local preference or selected archive manifest | Explicit grant; cannot expand authority |
| Financial request | One-to-one bounded payment intent | Display only until local wallet review |
| Call control | Invite, accept, endpoint change | Call-specific admission, not chat membership alone |

Every event binds protocol version, scope, sender endpoint, event type, replay identity, parent/context where applicable, bounded payload length, and expiry semantics. Unknown authority-bearing versions stop the affected operation; unknown non-authority content may show “Unsupported message” without granting anything.

### Common limits

These are proposed initial hard limits to be reduced if tests require, not measured capacity. Security-sensitive limits are authenticated or locally enforced and cannot be changed by a remote feature flag.

| Object | Initial proposal | Failure behavior |
|---|---|---|
| Text event | 16 KiB UTF-8 content before envelope overhead | Composer explains limit; no truncation that changes meaning silently |
| Normal control object | 64 KiB decoded application object, except approved crypto profile payloads | Reject before unbounded allocation |
| Local decrypted text page | 100 events / bounded bytes | Pagination, cancellable search |
| Image send copy | 12 MP and 10 MiB after conversion | Resize locally or cancel |
| General attachment | 25 MiB endpoint-transfer pilot | Show unavailable above limit |
| Voice note | 5 minutes / 10 MiB | Stop with visible limit; no background recording |
| Video file | 30 seconds / 20 MiB pilot | Local compression or cancel |
| QR/file import | Typed per-format limit; no unbounded decompression | Reject hostile nesting, duplicate chunks, oversize |
| Relay ciphertext | Approved padded-cell profile and per-capability quota | Explicit rejection/backpressure |
| Archive | Streaming parser, bounded per-record and total declared size | Validate capacity before commit |
| Future/stale protocol buffering | Exact library/profile limits set in release manifest | Stop affected scope and request reviewed recovery |

The raw maxima do not override library protocol constraints. Benchmarks and review must establish viable values before production.

## Technical feature sheets

### T-01: Local identity, setup, and profile

**Covers:** F-001 through F-004, F-011, F-015. The local profile is an organizer of independent relationships, not a provider account.

- **Creation:** First launch checks OS entropy, creates protected local storage and independent profile settings, then begins the approved Tor bootstrap. Cryptographic identity generation may run in parallel with name entry only when all required hardware/protection prerequisites are satisfied.
- **Name semantics:** “What should this contact call you?” is optional. No uniqueness check, availability request, public search, email lookup, or directory write occurs. Default name may be “You” locally until deliberately shared.
- **Presentation:** Per-contact name/avatar disclosure is inside that relationship's E2EE channel. Reusing a photo/name across contexts is warned as a human linkage choice, not forbidden.
- **Permissions:** No contacts, precise location, microphone, camera, notification, or full-photo-library permission at launch. Request a narrow permission only at its first useful action.
- **Tutorial:** Local checklist state is ordinary protected local preference data. Dismiss/reset works offline, does not contact analytics, and cannot mutate security policy.
- **Failure:** Entropy/key-store failure prevents creation with actionable copy. A route failure does not prevent local profile editing or cause registration fallback. Interrupted setup resumes from an authenticated local checkpoint, never regenerating identity silently.
- **Acceptance:** Given two fresh unrelated relationships, when packets and exported credentials are compared, then no mandatory global profile credential links them. Given an empty name, then Connect still works and no remote availability lookup occurs.

### T-02: Invitations, comparison, contact lifecycle

**Covers:** F-005 through F-014. A connection ceremony must bind the intended peer, scoped keys, fresh endpoint keys, routing capabilities, protocol profile, nonce, and expiry.

| Invite state | Allowed action | Terminal rule |
|---|---|---|
| Draft | Edit local label, choose QR or remote ceremony | No remote authority |
| Published | Present one-use material; wait; cancel | Ten-minute proposed lifetime |
| Claimed | Bind candidate peer transcript; stop parallel claims | No content grant yet |
| Comparing | Show canonical comparison/provenance | Mismatch cancels and destroys attempt |
| Established | Persist new relationship/session atomically | Invite cannot be reused |
| Burned / expired / cancelled | Create a fresh invite only | Old material cannot reactivate |

The one-wrong-guess policy limits successful malicious contact but also permits invitation denial of service. Malicious rendezvous infrastructure cannot be trusted to enforce attempts: the inviter must persist its own accepted/burned state and reject concurrent transcripts. Offline guessing resistance and online races require a reviewed protocol, not only a server counter.

CPace is a candidate PAKE, not described here as an already-final deployed TGP standard; the fetched history places the draft in the RFC Editor process ([CPace publication history](https://datatracker.ietf.org/doc/draft-irtf-cfrg-cpace/history/)). Magic-Wormhole's one-time-code design is relevant prior art but not permission to copy incomplete protocol pieces ([Magic-Wormhole protocol security](https://github.com/magic-wormhole/magic-wormhole-protocols/security)).

For an in-person QR, scan authenticates possession of the displayed secret and binds the displayed key, not a person's civil identity. “Compared from this QR in person” is available only after the scanner explicitly confirms physical provenance and the peer ceremony completes. Remote QR/link arrival remains “Encrypted; identity not independently compared.”

Safety representations use the selected protocol's canonical encoding. Do not invent a short visually pleasing fingerprint. A local comparison record stores key fingerprint, scope, method, date, and optional local note; transferred verification shows its origin.

Optional signed contact cards deliberately create portable signature evidence, so they remain advanced, carry explicit fields, exclude wallet/contact mapping, and cannot become the default payment identity credential. Reusable links are disabled until capability enumeration, spam, revocation, persistence, and cross-context linkage are reviewed.

Blocking a peer stops local sends and active receipt subscriptions, rotates/revokes applicable queue capabilities, purges pending unsolicited payloads under policy, and offers separate local-history deletion. It cannot erase the peer's archive or prevent the peer generating a new unrelated invitation.

### T-03: Direct messaging, event mutation, queues, and search

**Covers:** F-016 through F-030. A direct relationship contains separately authorized endpoints, each with independent sessions; multi-device delivery must not turn into one cloned sender state.

| Send state | Evidence | Permitted UI |
|---|---|---|
| Draft | Local encrypted draft only | Unsent draft |
| Queued | Crash-consistent local outbox record and required state | Queued on this device |
| Relay accepted | Authenticated acknowledgment of queue acceptance | Accepted by relay |
| Endpoint received | Authenticated application receipt from identified endpoint | Received by an authorized endpoint |
| Partial | Some, not all, required endpoints acknowledged | Partially received |
| Failed | Rejection, incompatibility, expiry, resource failure | Failed with reason and safe retry |
| Expired | Policy expiry before successful receipt | Expired before receipt |

Prepare outbound message and persist ratchet advance/outbox transaction under reviewed crash-consistency semantics before network emission. Retry stable application event identity through approved protocol retransmission; do not re-encrypt using stale send keys after a crash. Exactly-once display is achieved by bounded deduplication, not a claim of exactly-once network transport.

Delivery receipts disclose availability and device participation even when they do not disclose reading. Existing v0.5 receipt semantics remain the baseline; additional per-person/group receipt details require a metadata delta review. Typing, last-online, and read receipts stay off and are not silently enabled by a new UI.

Replies refer to scoped event IDs. Render a quote only if the original is locally available and permitted; expired/deleted/locked source becomes “Original message unavailable.” Edits are authenticated author mutations with a bounded proposed 15-minute window, visible “Edited,” and deterministic per-author revision ordering; security/control events are never editable content. Conflicting authorized edits show a local conflict if they cannot be safely ordered.

Reactions are scoped add/remove operations with stable actor and event identity inside E2EE. Pin/archive/mute are local unless a separate group policy explicitly authorizes a visible group pin. Swipe shortcuts only perform reversible local actions; delete/export/spend require explicit controls.

Default history retention is Keep. Optional disappearing policy uses a validated bounded sender timestamp and authenticated policy revision; offline delay, clock uncertainty, copied archives, and modified recipients remain explicit. Timer changes are prospective. Locked-chat indexing uses per-chat protection and is removed from active memory/results on relock; no global plaintext FTS database.

External URLs are inert text until tapped. Render scheme/host, ask before opening another app, and never fetch tracking pixels or preview thumbnails automatically. Link parsing cannot invoke native commands, wallet sign, invitation acceptance, or shell execution.

**Acceptance:** Inject duplicate, stale, malformed, future-version, edit-by-other-author, cross-scope reply, expired target, and lock-during-search events. Each must produce a bounded truthful result without unauthorized action or plaintext residue in global search.

### T-04: Tor, relays, decentralization, and resilience

**Covers:** F-056 through F-064, F-098. A reviewed network broker owns app-managed online networking, including node, update, rate, diagnostic, attachment, and media requests.

Arti is the preferred Rust integration candidate, but the target platform must demonstrate all required lifecycle and transport functions. The fetched Arti release notes include security fixes and recommend upgrading; they do not establish every mobile transport feature ([Arti release notes](https://blog.torproject.org/arti_2_7_0_released/)). Current Tor anti-censorship work includes multiple transports, but none proves universal unblockability ([Tor anti-censorship review](https://blog.torproject.org/staying-ahead-of-censors-2025/)).

| Boundary | Requirement |
|---|---|
| Socket ownership | Messaging/wallet libraries receive a broker interface, not arbitrary network clients |
| Name resolution | Approved path only; test IPv4, IPv6, DNS, redirects, proxy bypass, localhost exceptions |
| Bootstrap exception | Tor/bridge/PT setup is documented transport traffic, not application direct fallback |
| Context separation | Distinct broker identities for unrelated chats, wallet accounts, updates, diagnostics |
| No hidden client | Disable dependency telemetry, HTTP fallbacks, remote fonts, crash clients, STUN and vendor checks |
| Route failure | Pause network effect; local queues remain protected; no weaker retry path |
| Endpoint change | Parse and show type/operator/address before saving; no auto-import from arbitrary QR |

Proposed message path: sender through Tor to ingress relay A; A forwards an opaque nested envelope to destination relay B; recipient retrieves from B through its own protected path. A may learn the chosen destination relay and traffic patterns; B sees mailbox activity, timing, and retrieval patterns. Relays must not receive civil identity, plaintext contact list, or universal sender credential. Collusion and timing remain review questions.

Queue creation uses random bearer capabilities with separated send/receive/admin authority and bounded quotas. Capability rotation must prevent old senders or revoked devices continuing delivery where protocol design allows; compromised capabilities still permit traffic observation or disruption within their scope.

Directory manifests contain relay onion address, supported protocol/security profile, operator declaration, expiry, capacity class, and signing metadata. Client verifies signatures/version/freshness; the directory is a discovery aid, not identity authority. BYO configuration remains available with equivalent protocol requirements. Different declared operators are a selection rule, not proof of independence.

Relays keep undelivered ciphertext in memory with seven days as an upper bound, not a durability promise. Restart may lose accepted packets; the sender retains protected retry sources. Disable swap/core dumps/snapshots/backups where possible and test actual hosting behavior; “RAM only” is not proved by application intent.

Aggregate operational counts may include process liveness and coarse resource/error classes. Exclude queue ID histories, source/destination pair logs, contact-level counters, per-user analytics, and persistent request traces. Rate limiting uses narrow capabilities, bounded resource budgets, and reviewed onion-service anti-DoS tools, not phone verification.

Cover traffic, volunteer Snowflake proxy, device-wide VPN, and nearby radio are separate experiments. They cannot be defaulted on as unexplained “more privacy,” because each changes bandwidth, observability, battery, permissions, and the threat model.

**Acceptance:** Kill Tor during every network-capable feature and inspect device/relay captures. A UI error is not sufficient; one direct escape fails the build.

### T-05: Storage, vaults, local lock, and deletion

**Covers:** F-065 through F-071, F-103. Global app lock, chat vault lock, wallet unlock, screen lock, and decoy state are separate state machines.

| Store | Content | Protection |
|---|---|---|
| App settings | Local preferences, non-sensitive UI state | Device-bound app-store encryption |
| Relationship vault | Content, labels, comparison records, local index | Separate per-chat vault key and lease |
| Crypto state | Independent sessions, prekeys, MLS state | Protected security store, transactional semantics |
| Ciphertext spool | Unopened envelopes and bounded routing data | Low-privilege encrypted spool; no content key |
| Media cache | Encrypted staged/original received bodies | Scope-local keys, TTL and size quotas |
| Wallet | Seeds, descriptors, outputs, account history | Separate runtime/storage hierarchy |
| Payment associations | Locally approved minimal contact/payment map | Separate bridge protection and clear retention |

A per-chat passphrase wraps the relevant chat key using a reviewed construction and Argon2id profile; it must not simply hide a row in a globally unlocked database. Hardware wrapping is used where supported but does not imply every key type lives inside secure hardware.

On lock: cancel plaintext streams; clear composer/search/view caches; close relevant database/key leases; replace thumbnails; suppress notification details; terminate or pause capture according to explicit call policy. Incoming ciphertext may queue without decrypting locked content. The keyboard, clipboard, OS histories, accessibility services, and compromised OS remain residual boundaries.

Panic lock is one local action with no remote trigger. It stops capture and locks sensitive views; destructive erasure is a separate experimental action with prior configuration and deliberate confirmation. Cryptographic key destruction is not a claim of physical overwrite of all flash blocks or backups.

Decoy/disguise and dead-man auto-wipe stay experimental; no marketing claims of forensic invisibility or guaranteed plausible deniability. Auto-lock is the safe inactivity behavior.

Delete local profile requires review of affected local chats, keys, archives, and wallets. A messaging reset MUST NOT silently destroy an activated wallet; wallet removal has a separate recovery check and confirmation. Existing recipient copies, external exports, and public-chain records remain outside local deletion authority.

### T-06: Attachments, voice notes, and multimedia

**Covers:** F-028, F-031 through F-036, F-049. Importing media is an untrusted parser operation and a potential metadata disclosure, not just selecting a file.

1. Obtain a narrow OS picker handle; do not request whole-library access unnecessarily.
2. Copy bytes into protected staging with size checks before decode.
3. Detect actual type and reject ambiguous/polyglot formats where unsupported.
4. Run a bounded sandboxed decode/sanitize pipeline.
5. Normalize image orientation and strip supported metadata from the send copy.
6. Re-encode supported audio/video locally; cap duration, dimensions, decoded memory, and CPU.
7. Show preview and whether sanitization succeeded, was partial, or is unsupported.
8. Bind descriptor, encrypted body manifest, type, length buckets, and integrity data.
9. Deliver through permitted protected transfer only.
10. Delete staging according to scope policy, including interruption and disk-full cleanup.

Documents cannot all be truthfully labeled “metadata removed.” Offer “Send original file” with a specific warning or cancel when safe normalization is unavailable. Do not silently mutate professional/evidentiary originals.

Default attachment delivery is endpoint-originated protected chunk transfer within the approved retention baseline. External ciphertext storage is a separate disabled experiment because even unreadable blobs introduce a new observer and persistence. Its candidate design uses random blob IDs, separate keys inside E2EE messages, padded authenticated chunks, fetch capability separation, and capped TTL; these do not themselves establish no regression.

One-time fetch tokens do not automatically support offline recipients, retries, linked devices, and multiple group members. The ADR must specify per-endpoint capability issuance, retry/resume, consumed-token races, revocation, relay failover, and leakable object equality before enabling storage.

Voice notes start only after visible user action and microphone permission. Cancel deletes the unsent recording; app lock/process interruption stops capture and preserves only a deliberately recoverable encrypted draft if policy permits. A call failure cannot silently become a recording.

View-once removes compliant in-app access after the defined opening event, but must retain sufficient bounded replay state to avoid reopening from duplicate delivery. It cannot prevent recording by a recipient or another device.

**Acceptance:** Fuzz malformed headers, decompression bombs, truncated chunks, duplicate/reordered chunks, wrong manifest, metadata fixtures, huge image dimensions, worker crashes, and relock during preview. No media worker receives wallet or authority keys.

### T-07: Groups, large groups, and communities

**Covers:** F-037 through F-044. The preferred group foundation is MLS with encrypted group operations, application-level consent/role policy, and independent endpoint leaves.

RFC 9750 warns that delivery infrastructure may learn membership and that anonymous credentials alone do not establish metadata privacy; it recommends encrypted group operation messages where possible ([MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)). TGP therefore does not treat “MLS + rotating mailbox” as a demonstrated no-regression scaling solution.

| Tier | Design target, not supported claim | Current disposition |
|---|---|---|
| Private group pilot | Up to 32 people / 128 endpoints, inherited envelope | Must pass crypto/authority/metadata gates |
| Expanded private group | Up to 64 people with explicit endpoint cap | Same client-fanout model; benchmark first |
| Large group experiment | 256 people and a separately measured endpoint cap | Disabled; no production shared mailbox |
| Community experiment | Invite-only collection of independent groups | Disabled until directory/admin linkage review |

Group creation: select existing relationship contacts; create local draft; review title/roster/policy; send encrypted invitations; receive acceptance; obtain fresh group-scoped credential/key package; validate consent/current policy; authorize proposal; serialize valid transition; persist MLS state; mark membership active only after admission.

Creator starts as administrator and explicit transition coordinator. Administrator authority permits policy-approved admission/removal, not decrypting absent content, exporting another vault, or spending group funds. Coordinator orders valid transitions, not authorizing otherwise invalid ones.

Each group endpoint uses a separate group-scoped signing credential. A person's mapping to that credential is disclosed to admitted group participants through reviewed authenticated channels, not a global TGP identity service. This may affect deniability, but no group-deniability claim is approved without independent analysis.

Client fanout wraps each recipient's outer delivery separately so identical inner MLS ciphertext is not trivially equal at different queues. Actual padding/traffic equivalence remains measured. Server fanout, shared mailbox IDs, Privacy Pass credentials, or rendezvous optimizations are separate ADRs because they can join readers/writers even if IDs rotate.

Only explicit call-to-one-to-one actions may initiate payments from group context. Application-generated payment requests, addresses, TXIDs, swap offers, and proofs are not group event types. Users can still manually type financial data into text; UI cannot promise universal content detection without prohibited content inspection.

Removal has local stop, authorized proposal, committed transition, per-endpoint receipt, and unconfirmed states. Remove person targets all represented endpoints. Removed members retain old keys/content; offline senders may not know removal yet. Strict freshness blocks affected sends when the client lacks required current-state evidence.

Conflicting authenticated child states stop affected application sends. Recover through authenticated missing-transition retrieval or a reviewed fresh admission; do not choose state by latest timestamp, silently elect a coordinator, or restore cloned MLS state. If safe continuity is unavailable after coordinator loss, create a successor group explicitly.

### T-08: Devices, selective sync, migration, and loss

**Covers:** F-050 through F-055, F-044. Controller is a local authority role, companion is an independently operating endpoint with explicit grants.

Pairing generates fresh new-device keys and a one-use ten-minute candidate invitation, creates a compared secure channel, requires confirmation on both devices, selects zero scopes initially, selects no history initially, reviews access once, then performs peer/group admission per scope. Pairing success is not conversation authorization.

| Data or power | Companion default |
|---|---|
| Selected new messages | Only after scope admission |
| Unselected/future conversations | None |
| Old content | None until separate range review |
| Attachments | On request and authorized |
| Local nicknames and private notes | Not copied |
| Verification | May transfer only with explicit provenance |
| Wallet seed, balance, view key, payment labels | Never through chat pairing |
| Enrollment/controller power | None |
| Group administrator power | Not inherited |
| Calls | Off until separately enabled and admitted |

Selected history becomes an encrypted archive of eligible content, not ratchets/group leaves. Transfer is resumable/cancellable; recipient sees which content is historical/imported. Expired/deleted content is excluded under current policy; reading/importing does not restart expiry.

Revocation immediately stops local new fanout, rotates capabilities where applicable, emits authenticated scoped changes, and triggers group rekey. UI tracks “Applied here,” “Awaiting peer/group update,” “Acknowledged,” and “Unconfirmed.” Offline participants can remain stale; no global instant-revocation claim.

Controller migration is an explicit authority transfer using compared transcript and fresh endpoint state. Transfer only chosen continuity authority, publish scoped successor events, retire old enrollment power after reviewed completion, and show partial progress. Concurrent successor claims pause automatic acceptance.

Controller loss does not promote a companion. Without separately approved continuity recovery, keep surviving readable history but re-establish identity/grants through fresh ceremonies. Old controller presence cannot be disproved by importing an archive.

### T-09: Experimental voice/video

**Covers:** F-045 through F-049. Asynchronous voice notes are the supported fallback capability; live calls qualify independently.

Tor's SOCKS interface does not support the usual UDP ASSOCIATE operation, so a generic UDP-first call stack cannot be assumed to work safely ([Tor SOCKS extensions](https://spec.torproject.org/socks-extensions.html)). The media profile must prove a maintained Tor-compatible transport, no STUN/direct candidate leaks, bounded latency/memory, and safe capture state.

| Call state | Capture | Key access | UI |
|---|---|---|---|
| Preparing / inviting | Off | Signaling only | Preparing protected call |
| Ringing | Off | No media grant yet | Incoming call |
| Connecting | Permission/preview only as explicitly chosen | Call-specific admission in progress | Setting up encrypted media |
| Live | Explicitly enabled microphone/camera | Only admitted endpoints | Actual participant list |
| Reconnecting | Paused by default | Current keys retained only under policy | Reconnecting; no weaker route |
| Security update | Paused | Rekey/admission pending | Paused for security update |
| Ended / failed | Off | Session secrets erased under profile | End reason; separate voice-note action |

Chat membership does not confer call decryption. Use a separately reviewed call subgroup or equivalent so nonparticipating members lack media secrets. New endpoint admission, leave, handoff, and multiple-device answers must rekey and keep only the selected active endpoint.

SFrame is a frame-protection candidate, not complete signaling, admission, key management, or transport ([SFrame RFC 9605](https://www.rfc-editor.org/rfc/rfc9605.html)). The application must solve sender authenticity, replay, counter uniqueness, rotations, malicious participants, call/endpoint binding, and bounded out-of-order buffering.

Media infrastructure may observe session duration, traffic, and associations. That new exposure blocks production under the strict no-regression rule until equivalent protection is demonstrated; opt-in calling is not an automatic exception.

### T-11: Platform, notifications, and frontend hardening

**Covers:** F-072, F-073, all platform realizations. Rust owns security decisions; TypeScript receives only currently permitted plaintext/read models.

Desktop Tauri configuration MUST explicitly enumerate enabled capabilities and custom-command permissions, deny remote content/remote command access, avoid shell and arbitrary filesystem APIs, restrict window creation, use a strict CSP, and load only signed bundled UI. Tauri's Isolation pattern can filter IPC but does not replace Rust validation or OS-level wallet/media isolation ([Tauri capabilities](https://v2.tauri.app/security/capabilities/), [Tauri Isolation pattern](https://v2.tauri.app/concept/inter-process-communication/isolation/)).

RN bridges MUST avoid serializing seeds, private protocol keys, or universal authority objects into JavaScript. Even necessary message plaintext in the UI remains a JS-memory exposure; lock/cancellation/redaction tests are required. No over-the-air arbitrary JavaScript update channel.

Android background availability needs real-device tests for Doze, force-stop, reboot, permission denial, foreground-service limits, and battery restrictions. Foreground-service rules vary by platform version and service type, so permanent operation is not a valid assumption ([Android foreground-service changes](https://developer.android.com/develop/background-work/services/fgs/changes)).

iOS default is app-open delivery. Optional minimal platform notifications preserve the v0.5 exception only after token/wake linkage review; no preview, sender, title, amount, balance, or content key. Disable registration when user turns it off, with explicit deletion/expiry semantics.

UnifiedPush remains a separately reviewed option: the distributor and its server are real infrastructure actors, not a serverless guarantee ([UnifiedPush FAQ](https://unifiedpush.org/users/faq/)). All notification modes must explain availability separately from content confidentiality.

Desktop locks on OS session lock/user switch/sleep policy, uses generic notifications, disables OS search indexing and plaintext recent-file previews, and separates closing a window from locking the app. Each OS needs its own signed update/storage/file-picker/keyboard/accessibility tests.

### T-12: Backup and recovery

**Covers:** F-092 through F-095. There are three distinct recoveries: content archive, identity continuity, and wallet funds; none implies the others.

| Archive class | Included | Excluded |
|---|---|---|
| Chat history | Selected eligible messages, explicitly selected local metadata, manifest | Seeds, live ratchets, MLS sending leaves, media session state, implicit controller authority |
| Continuity candidate | Explicit chosen scoped recovery credentials under separate protection | Proof original device is gone; automatic group readmission |
| Wallet backup | Chain-specific seed/passphrase/descriptor/restore data under explicit wallet ceremony | Chat history and universal contact mapping by default |

Container parser validates version, authenticated manifest, declared limits, record count, chunk/order integrity, expiry eligibility, destination capacity, and compatibility before committing. Stream into protected storage; no plaintext temporary directory. Password failure cannot distinguish secret content or permit reduced KDF work silently.

Recovery drills restore into a temporary non-authoritative local context, verify content/fund derivation without spending, and destroy temporary secrets. A chat drill cannot activate old endpoints; a wallet drill cannot broadcast or transfer funds.

Social recovery, generic seed splitting, and Bitcoin multisig remain separate studies. SLIP-39 compatibility must be checked against the exact wallet/hardware format rather than assuming arbitrary BIP39 seeds, Monero mnemonics, and all devices are interchangeable. Never route recovery shares automatically through the same profile being recovered.

### T-13: Offline transfer and nearby experiments

**Covers:** F-064, F-096. Offline QR/file transfer uses explicit type markers, version, bounds, sequence/integrity checks, destination/network review, and no private-key export.

Transaction signing QR, receive-address QR, contact invitation QR, verification QR, device pairing QR, and configuration QR are different types. A generic scanner routes to preview only; scanning cannot sign, broadcast, enroll, grant, or replace settings.

Nearby radio requires separate consent, authenticated known peers, local-radio metadata disclosure, replay/expiry limits, and no automatic internet bypass. Initial mesh is at most a text-only prototype with no wallet synchronization or promised settlement.

### T-14: Diagnostics, support, abuse, funding

**Covers:** F-060, F-097, F-098, F-100. Diagnostics are local, bounded, and opt-in to export.

Allowed local evidence includes tested route, app version, error category, coarse resource readings, and relevant configuration fields after redaction. Exclude content, keys, seed fragments, address/contact maps, complete device/roster inventories, public IP tests without consent, and automatic crash dumps.

Before export show exact fields and recipient/retention policy. Support cannot look up a person's chats or recover secrets. User abuse reporting previews exactly selected content leaving protected storage; there is no universal server decryption or content scanning.

Chat, verification, revocation, updates, and baseline security remain free. Any separately billed support/capacity service must not share a reusable entitlement identifier with unrelated relationships. No payment skim or privacy-reducing analytics to prove revenue.

### T-15: Distribution, updates, and incidents

**Covers:** F-005, F-099, F-104. Release records include source revision, artifact digest/signature, platform, security profile, dependency lock/SBOM, build recipe, license notices, independent rebuild result, known findings, compatibility, and rollback instructions.

Update checks are opt-in and use approved transport. Store/OS delivery is a separately disclosed platform service; neither artifact signing nor in-app digest comparison proves runtime OS integrity. Security updates are never paywalled.

Incident response protects release authority first, disables affected new actions without destroying user funds/recovery access, communicates scoped impact, obtains remediation/retest, and publishes updated evidence. An emergency switch must not strand an in-flight swap, erase keys, unlock vaults, or weaken routing.

### T-16: UX infrastructure, accessibility, and measurement

**Covers:** F-015, F-101, F-102. Shared TS components render independent trust/route/authority/availability states from core-owned data.

Use system text scaling, screen-reader order and provenance, keyboard navigation, visible focus, reduced motion, non-color status, and accessible non-camera alternatives. Critical warnings and exact amounts never appear only in captions, tooltips, or truncating banners.

Local responsiveness is measured separately from relay delivery and settlement. Laboratory packet captures and consented research cohorts provide evidence; production engagement tracking, social-graph collection, or universal device IDs are not added for convenience.

## Security-relevant error contract

| Reason code | User-facing direction | Safe action |
|---|---|---|
| `ROUTE_UNAVAILABLE` | Protected connection unavailable; nothing was sent directly | Keep queued; retry or inspect connection |
| `IDENTITY_CHANGED` | This contact's key changed; review before sending | Pause affected sends; compare |
| `ENDPOINT_PENDING` | A new device is awaiting approval | Review scoped recipient change |
| `GROUP_CONFLICT` | Group state needs review | Pause affected sends; authenticated recovery |
| `PROFILE_UNSUPPORTED` | This version cannot use the required security profile | Update or leave action unavailable |
| `VAULT_LOCKED` | Unlock this chat to continue | No preview or auto-unlock |
| `STORAGE_FULL` | Not enough protected storage; no plaintext fallback | Cancel/retry after explicit cleanup |
| `INVITE_INVALID` | Invitation expired, used, or cancelled | Create new invitation |
| `MEDIA_UNSAFE` | This file cannot be safely prepared | Cancel or explicitly reviewed original-file option |
| `WALLET_POLICY_BLOCK` | Contact payment unavailable from this wallet under current policy | Keep management-only; no weaker override |
| `DEADLINE_COVERAGE_MISSING` | This device cannot safely start this swap | No funding; review supported external tool |
| `AUTHORITY_CONFLICT` | Competing authority changes require review | No automatic successor selection |

Reason codes must not expose unrelated contact names, account addresses, seeds, or internal secret data in notifications or logs. All retry controls revalidate current policy rather than replaying a previously approved authority action blindly.
