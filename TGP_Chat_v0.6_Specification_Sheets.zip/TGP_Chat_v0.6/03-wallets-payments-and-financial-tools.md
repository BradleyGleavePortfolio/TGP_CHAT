# TGP Chat v0.6: Wallets, Payments, and Independent Financial Tools

This volume specifies a non-custodial financial subsystem that does not become a messaging identity system. It explicitly separates managing existing BTC/ETH from proving that a contact payment is unlinkable, because a local software boundary cannot erase public-chain history or information already known to an exchange, provider, counterparty, or compromised endpoint.

## Financial product contract

### What TGP can and cannot promise

- **Can design for:** No TGP-held seed, spend key, private view key, plaintext contact/payment ledger, universal wallet/chat identifier, hosted transaction signer, or server-side wallet account.
- **Can test:** Wallet/chat IPC permissions, separate key roots/stores, no forbidden fields to nodes, no direct network escape, no address/xpub upload in approved BTC mode, chain-specific state accuracy, explicit sign/export/broadcast authorization.
- **Cannot promise:** Existing KYC history disappears, a public-chain transaction is unobservable, Tor makes an RPC query's address invisible to its recipient, counterparties cannot preserve evidence, or an atomic swap is a privacy certificate.
- **Must withhold:** Contact-spending capability when its known disclosure exceeds the applicable baseline or a required isolation/cryptographic/legal gate is unresolved.

Ethereum's wallet-privacy discussion identifies address/RPC, IP, timing, portfolio grouping, analytics, and public-chain relationships as distinct exposures ([Ethereum wallet privacy](https://ethereum.org/latest/next-great-wallet-private/)). Bitcoin compact filter integration provides client-side filter processing, but that does not establish that all subsequent block fetching or broadcasting is unobservable ([BDK-Kyoto documentation](https://docs.rs/bdk_kyoto/latest/bdk_kyoto/)).

### Wallet activation is not chat enrollment

Wallet activation is optional, device-specific, and reversible without breaking messaging. A linked chat device receives no wallet seed, address list, balance, transaction history, private view key, source labels, or spending permission.

No financial vocabulary appears in first-run chat setup. An incoming request can be viewed without activating a wallet, but viewing cannot install a provider, register an account, sign, broadcast, or authorize a later payment.

### Capability tiers

| Tier | Capability | Default and restrictions |
|---|---|---|
| W0 Disabled | No wallet runtime loaded | Initial state; chat-only build supported |
| W1 Watch-only | Inspect approved descriptor/address data locally | No signing; imported history labeled identity-linkage unknown/known |
| W2 Hardware connected | Prepare intent, obtain external signature | Seed never requested; exact device/firmware/chain matrix |
| W3 Local software signer | Separately protected chain-specific keys | Explicit restore/create ceremony, isolated runtime, separate backup |
| W4 Contact payment eligible | Typed one-to-one requests and authorized send | Only if applicable no-regression and chain gates pass |
| W5 Advanced external tools | Export/import into user-chosen independent software | Separate disclosure and legal gate; no automatic privacy upgrade |
| W6 Experimental swap | Reviewed engine with proven deadline coverage | Disabled by default; mainnet unavailable until all gates pass |

A wallet may remain W1 or W2 indefinitely. UI must not imply that connecting funds makes them suitable for private contact payments.

## T-10: Financial architecture

### Runtime separation

```text
Chat runtime                         Wallet runtime
  local relationship handle            independent wallet handle
  encrypted request card                chain account/descriptor/output state
  minimal local status                  separate signing/recovery keys
  no seed or full wallet history        no contact roster or message history
           |                           |
           +-- typed local bridge -----+
                one-use operation handles
                bounded intents/results
                separate local authorization

Wallet network API --> network broker (wallet-specific isolation context)
                   --> own node / approved chain peer / reviewed provider

Nothing above requires a TGP-hosted wallet server.
```

On desktop the intended boundary is an OS-sandboxed wallet worker with separate filesystem access and narrow IPC. On mobile, same-process library separation does not meet the same guarantee; if the required boundary cannot be demonstrated, use management-only or separate-wallet software rather than claiming equivalence.

Wallet UI presents a local contact label only through a core-owned transient review model. It must not send that label to a chain adapter, node, hardware vendor server, analytics provider, or external tool unless an explicit export includes it.

### Keys and databases

| Material | Location | Export rule |
|---|---|---|
| XMR spend/recovery secret | Wallet-only protected store or hardware | Explicit protected backup/restore only |
| XMR private view key | Wallet-only scan context | Never remote/light-wallet upload in approved baseline |
| BTC descriptor/xpub | Local wallet protected store | Sensitive portfolio information; hardware/backup export only as reviewed |
| BTC private signing keys | Hardware or wallet signer | Never chat bridge or general diagnostics |
| ETH signing key | Hardware or wallet signer | No arbitrary dapp access, personal-sign, or account enumeration by chat |
| Chain state | Wallet database | No chat IDs/names in adapter-owned records |
| Payment/contact association | Separately protected local bridge map | Minimal purpose/retention; never default chat sync |
| External tool operation state | Adapter-local encrypted store | Exact manifest/export and recovery rules |
| Swap recovery journal | Isolated encrypted recovery store | High-consequence backup, no default contact association |

Creating keys independently is necessary but not sufficient. Shared timestamps, device compromise, broker identifiers, backup names, logs, provider batching, and clipboard/export fields can still join contexts.

### Typed bridge schema

```typescript
type Chain = "xmr-mainnet" | "btc-mainnet" | "eth-mainnet";

type PaymentRequestV1 = {
  version: 1;
  kind: "payment_request";
  requestNonce: string;       // random, scoped to one request
  chain: Chain;
  recipientAddress: string;
  amountAtomic?: string;     // integer string; no floating point
  memo?: string;             // bounded, encrypted, not a node field
  expiresAt: string;
};

type PreparePayment = {
  kind: "prepare_payment";
  localRequestHandle: string;
  selectedWalletHandle: string;
  amountAtomic: string;
  sourcePolicyHandle: string;
};

type ReviewedPayment = {
  reviewHandle: string;
  revision: string;
  chain: Chain;
  destinationDisplay: string;
  amountAtomic: string;
  feeCapAtomic: string;
  riskClass: "baseline-eligible" | "management-only" | "blocked";
  expiresAt: string;
};

type AuthorizePayment = {
  kind: "authorize_payment";
  reviewHandle: string;
  expectedRevision: string;
  localAuthorizationHandle: string;
};
```

The encrypted chat transport binds the request to its relationship context; a global contact ID does not enter the wire payload or chain adapter. Review handles are local, short-lived, non-reusable authorization references, not transferable bearer tokens that permit an external message to sign.

Required validation: payload version/type/length; chain/network; address checksum/encoding; amount range; asset precision; request nonce duplication; expiry/skew; destination substitution; currently admitted sender; wallet capability; local vault state; source policy; fees; and review revision. Unknown network/contract calls fail closed.

The bridge does not expose arbitrary transaction signing, arbitrary Ethereum calldata, seed export, unrestricted filesystem, external URL fetch, or “mark transaction paid” as trusted facts. A peer can send a payment claim; the wallet independently determines what it can verify.

## Connecting existing BTC/ETH safely

### Connection journey

1. User opens You → Wallet → Activate.
2. User sees that wallet recovery is separate from chat recovery.
3. User chooses Connect existing, Create new, or Restore from recovery.
4. Connect existing offers Hardware or Watch-only first; it never asks for a seed.
5. User selects chain and supported device/format.
6. App previews requested public data and its privacy implications.
7. Local parser validates network, descriptor/address syntax, derivation/policy, and ownership proof only where the protocol requires it.
8. No network request is made until the user reviews the node/peer profile.
9. Wallet sync runs through its own broker context, with no contact metadata.
10. Wallet receives a provenance label and management-only status.
11. Contact payment eligibility remains blocked unless separately established.
12. User may disconnect, remove imported public data, or inspect source/exposure details without sending funds.

“Restore from recovery” is intentionally a different path. It means introducing spend-capable secrets into the device and must not be hidden behind the harmless-sounding word “Connect.”

### Quarantine is a safety policy, not a cleansing mechanism

| Local provenance label | Meaning | Permitted behavior |
|---|---|---|
| Externally linked | User/import evidence indicates exchange/KYC/public identity association | Management-only; no contact payment |
| History unknown | TGP cannot determine prior linkage | Conservative management-only default |
| New local wallet | Keys generated locally with no imported history | Not proof of anonymity; evaluate funding and future activity |
| Reviewed protocol output | An approved tool produced an output under a recorded profile | Preserve source ancestry; no automatic unlinkability label |
| Contact-associated | User deliberately linked a local payment to a relationship | Protect local map; no sync/export by default |
| Mixed-source selection | Spend combines inputs/accounts with different local provenance | Block automatic merge; explicit advanced review still cannot waive baseline |

Source labels are local policy metadata. They are not factual assertions about ownership, legality, sanctions status, or whether a blockchain analyst can make a link.

The app MUST NOT offer “remove KYC history,” “clean coins,” “guaranteed private hop,” or a BTC→XMR→BTC recipe as a privacy guarantee. Swaps, CoinJoin, pools, delays, fresh addresses, and separate circuits may change some observations but cannot establish that no identity link remains.

### Key distinctions the UI must teach

- **Wallet connection:** Imports public monitoring data or associates a hardware signer locally.
- **Wallet restore:** Introduces recovery/spending capability into this device.
- **Blockchain privacy:** Concerns what ledger observers can infer, independently of TGP.
- **Network privacy:** Concerns what nodes/providers and network observers see.
- **Local association privacy:** Concerns the protected contact/payment map on the endpoint.
- **Counterparty knowledge:** The intended payment peer knows the request and interaction.
- **Provider confidentiality:** TGP infrastructure does not receive decryptable financial contents, while traffic correlation remains a separate question.

## Monero specification

### Node and scanning model

Run wallet scanning locally, keep private view/spend keys on-device or hardware, and reach own/approved remote node through the broker. Do not introduce a hosted light-wallet server that receives private view keys merely to improve speed.

Monero documentation distinguishes local scanning from remote-node observations and warns that malicious nodes can bias or withhold data; it also distinguishes own-node operation from protected transaction propagation ([Monero remote nodes and privacy](https://docs.getmonero.org/interacting/remote-nodes/)). TGP must therefore test the exact RPC pattern, trusted-node flags, decoy selection, fee validation, output queries, and broadcast path rather than saying “Tor makes any node safe.”

Rust wallet library selection must cover complete wallet policy, not only transaction construction. The fetched `monero-wallet` documentation explicitly says it is not a complete wallet and does not itself maintain state, select outputs, or run background work ([monero-wallet documentation](https://docs.rs/monero-wallet/0.2.0/monero_wallet/)).

### Receive, send, and recovery

Generate fresh receive subaddresses per request/context, store contact mapping locally, and avoid displaying balance/address until requested. A new subaddress does not hide a user's identity from a person to whom they deliberately identify themselves.

Send review shows exact XMR amount, recipient comparison state, address, network, wallet/source policy, estimated fee, delay policy, and optional guardrail. Coin-control capability is only exposed if the maintained wallet stack supports it safely; UI calls them wallet outputs rather than applying BTC terminology indiscriminately.

Settlement UI uses observed transaction state, confirmations, and actual unlocked/spendable status. It must not hard-code one universal “safe after N confirmations” promise or equate a chat receipt with chain finality.

Mnemonic/restore format is pinned to a supported wallet matrix. Polyseed encodes creation-date information and has feature/compatibility distinctions that cannot be replaced by a generic seed screen ([Polyseed specification](https://docs.getmonero.org/mnemonics/polyseed/)).

Future protocol upgrades, including FCMP++/new addressing, are disabled until official activation, maintained libraries, interoperability, hardware support, and recovery tests are confirmed. This spec does not rely on an estimated activation date from secondary coverage.

## Bitcoin specification

### Wallet model

Preferred candidate: maintained BDK descriptor wallet with separately selected signer, local filter matching through a Kyoto-compatible BIP157/158 client or own-node mode, and explicit PSBT workflows. BDK-Kyoto documents block-header/filter/block processing but does not establish built-in Tor support in the fetched page, so broker integration is a blocking test rather than an assumed capability ([BDK-Kyoto documentation](https://docs.rs/bdk_kyoto/latest/bdk_kyoto/)).

| Concern | Requirement |
|---|---|
| Address reuse | Fresh address per request; warn before deliberate reuse |
| Portfolio disclosure | No xpub/descriptor upload to a public service |
| Filter privacy | Local matching, review block-fetch patterns and peer correlation |
| Coin selection | Conservative source-label boundaries; change handling; fee calculation locally |
| Signing | Hardware/air-gapped PSBT first; never unrestricted raw-sign request |
| Broadcast | Approved protected peer path/own-node integration; no direct fallback |
| Fee bump | Chain-specific reviewed RBF/CPFP workflow; no silent extra signing |
| Reorg | Confirmed state can move backward; show chain uncertainty |
| Backup | Descriptor/policy/network/origin/derivation and signer recovery requirements |
| Multisig | Deferred until descriptor recovery and hardware policy registration qualify |

Bitcoin Core release notes describe a private-broadcast option, but TGP cannot claim to inherit its protection merely by naming the option ([Bitcoin Core release notes](https://bitcoin.org/en/releases/31.0/)). Actual node version, configuration, dependencies, network behavior, and current advisories must be qualified independently.

### PSBT workflow

Prepare a bounded PSBT locally, review destination/amount/fees/change/policy, transfer only required signing material, verify the signer-returned transaction matches the reviewed intent, validate signature/sighash/network/fee bounds, then separately authorize broadcast. Unknown/proprietary fields are bounded and rejected or stripped under reviewed policy.

Hardware compatibility means exact model, firmware, chain application, transport, descriptor policy, address types, PSBT variants, and recovery behavior. A hardware abstraction crate is an integration candidate, not a promise that all listed hardware works on all TGP platforms ([async-hwi documentation](https://docs.rs/async-hwi/0.0.34/async_hwi/)).

### Payjoin

Payjoin can improve some transaction-structure privacy properties but cannot erase all public-chain, participant, timing, or source-history information. It does not satisfy the strict contact-payment requirement automatically.

BIP77 uses encrypted asynchronous proposals and OHTTP-supported directory communication in its documented design ([Payjoin BIP77](https://payjoin.org/docs/how-it-works/payjoin-v2-bip-77/)). A TGP-specific chat transport for proposal payloads must be reviewed for protocol equivalence and cannot be marketed as interoperable BIP77 solely because it carries a PSBT.

Requirements: validate receiver contribution and ownership assumptions; bound additional fee; preserve intended recipient amount; reject malicious substitutions; handle conflicting spends; keep change policy; time out safely; retain recovery state; never silently fall back to an ordinary payment after a Payjoin failure. A failed negotiation cannot move funds without fresh ordinary-payment review, and a baseline-blocked contact payment has no fallback.

### Silent payments

Silent-payment receiving stays experimental until scanning, light-client data, restore performance, hardware support, and amount/source correlation are reviewed. Fresh addresses are not a claim that the source wallet is unlinkable.

## Ethereum specification

### Scope

Initial design scope is native ETH management with explicit own-node/provider configuration. ERC-20 breadth, arbitrary dapps, WalletConnect, ENS reverse lookups, NFT previews, DeFi approvals, account-abstraction sponsorship, and bridge integrations are not silently included.

Use maintained Rust transaction primitives such as an alloy-class adapter, explicit chain ID, integer amounts, bounded fee caps, nonce management, destination review, and replay protection. Disable arbitrary calldata/sign-message requests through the chat bridge.

Helios can verify aspects of untrusted RPC responses but still depends on consensus/execution inputs and weak-subjectivity checkpoints; its repository describes these trust roots and API requirements ([Helios repository](https://github.com/a16z/helios)). Verification is not query privacy: an execution provider can still receive the address being queried.

### Node modes

| Mode | Exposure | Production disposition |
|---|---|---|
| User-controlled node over approved transport | User's infrastructure sees requests; hosting/provider may observe operation | Preferred candidate, still reviewed |
| Third-party RPC over Tor | Provider sees address/query/time; network origin reduced | Not equivalent to no address disclosure; blocked where baseline requires more |
| Local verification over third-party RPC | Better response integrity, not private reads | Same metadata gate |
| Per-account provider/circuit separation | Reduces trivial batching but not chain/collusion links | Mitigation only, never proof |
| PIR/TEE/ORAM or shielded protocol | New trust, maturity, contract, recovery, and legal issues | Research only until qualified |

Never batch unrelated accounts, include contact labels, or ask a remote service for the entire wallet portfolio. Disable token/NFT auto-discovery that contacts unknown hosts.

### Stealth addresses and privacy protocols

ERC-5564 specifies stealth addresses/announcements, and its security discussion explicitly warns that funding a stealth wallet can breach privacy ([ERC-5564](https://ercs.ethereum.org/ERCS/erc-5564)). TGP must review announcement scanning, spam, viewing/spending key separation, recovery, gas funding, token transfer behavior, contract observations, and sender knowledge.

A stealth address is not a private-payment guarantee. No production “gas hop” automation is specified to claim unlinkability; if safely spending cannot be demonstrated without prohibited linkage, the feature remains receive-only experimental or unavailable.

Kohaku is useful ecosystem research, but its repository warns that some packages are work in progress and contain unaudited code ([Kohaku repository](https://github.com/ethereum/kohaku)). Privacy Pools, Railgun, Tornado-related tooling, and PQ account proposals each need their own manifest, cryptographic audit, contract/deployment review, custody/control analysis, recovery design, and jurisdiction decision.

## Contact payment product rules

### One-to-one only

Application-generated payment requests, addresses, TXIDs, proofs, and swap offers are only supported in one-to-one channels. “Pay privately” from group details opens a chosen person's direct relationship and does not publish a group event or payment completion badge.

This avoids adding a signed group financial transcript by design, but is not a blanket deniability guarantee. MLS does not itself claim deniability, and pairwise PQXDH deniability has documented assumptions and limits ([MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html), [PQXDH specification](https://signal.org/docs/specifications/pqxdh/)).

### Payment lifecycle

| Stage | Meaning | Who may assert it |
|---|---|---|
| Request received | Valid bounded encrypted request, no funds moved | Chat parser/core |
| Review prepared | Current wallet intent/fees/source evaluated | Local wallet |
| Authorized | User approved this exact review revision | Local authorization controller |
| Awaiting signature | Hardware/offline signing incomplete | Wallet |
| Signed, held | Signed object retained locally, not broadcast | Wallet with explicit leakage warning |
| Scheduled, unsigned | Intent held; transaction not yet signed | Preferred scheduling mode |
| Broadcast submitted | Transaction submitted, not settlement | Wallet/network adapter |
| Observed pending | Locally observed in applicable mempool/chain view | Wallet |
| Confirming / finalized / spendable | Chain-specific observed evidence | Wallet, with reorg rules |
| Cancelled before broadcast | Local action stopped; no guarantee if signature escaped | Wallet |
| Request expired | Request no longer approvable; existing broadcast unaffected | Bridge/core |
| Failed / conflicted / replaced / reorged | Chain-specific exception | Wallet reconciliation |

For ETH distinguish submitted, included, safe/finalized observations as implemented; for BTC distinguish mempool/confirmations/conflict/replacement; for XMR distinguish confirmations and wallet-reported unlock/spendability. A generic “Paid” label is insufficient.

### Retention and payment cards

After locally observed settlement and a proposed 24-hour review window, compliant local chat UI may minimize the card to “Payment details removed from this chat.” Pending disputes, incomplete swaps, refund deadlines, or required recovery material must not be purged prematurely.

Wallet transaction records and public-chain data do not disappear when chat details expire. The contact/payment mapping is separately configurable, excluded from default message sync/backup, and explained before enabling retention; recipients and previous exports may retain their own copies.

Default ordinary chat history remains Keep. Payment-card minimization is a distinct disclosed data policy, not silent deletion of all financial records or a guarantee of non-evidence.

### Delayed and scheduled payments

Prefer holding an unsigned reviewed intent until the chosen time. Recheck destination validity, expiry, source availability, network, fee cap, nonce/input conflicts, and policy before signing.

Automatic future signing is unavailable in the baseline unless a separate restricted authorization design qualifies. If the app is locked/asleep, show “Awaiting your authorization,” not a false scheduled guarantee.

An advanced signed-held mode must warn that anyone obtaining the signed transaction may broadcast it and that cancellation is only local until conflicting/replacement behavior is safely established. Randomized broadcast jitter is distinct from a user-selected schedule and has no universal correlation-resistance claim.

## Atomic swaps and independent tools

### Protocol catalog and current evidence

| Candidate | Verified technical distinction | v0.6 decision |
|---|---|---|
| eigenwallet/COMIT-family | Fetched implementation README supports buyer sends BTC/receives XMR and warns the cryptography is not formally audited ([implementation README](https://github.com/eigenwallet/core/blob/master/swap/README.md)) | Research/testnet only; no generic bidirectional claim |
| BasicSwap | Project describes BTC/XMR in both directions and requires its node to remain online during the swap ([BasicSwap FAQ](https://basicswapdex.com/faq.html)) | External candidate; protocol/online/implementation review required |
| Haveno | Uses 2-of-3 multisig involving an arbitrator, rather than the same trust model as a two-party atomic swap ([Haveno protocol](https://docs.haveno.exchange/overview/trade-protocol/)) | Not classified as interchangeable atomic swap |
| Serai | Fetched project docs say mainnet has not launched ([Serai documentation](https://docs.serai.exchange/)) | Deferred; no production dependency |
| Athanor ETH-XMR | Repository is archived and describes beta software ([Athanor repository](https://github.com/AthanorLabs/atomic-swap)) | Reject as production dependency without maintained reviewed successor |
| Payjoin | Payment collaboration protocol, not cross-chain exchange ([BIP77 documentation](https://payjoin.org/docs/how-it-works/payjoin-v2-bip-77/)) | Separate feature and threat model |
| CoinJoin | Transaction collaboration with protocol-specific coordination and observations ([Wasabi protocol documentation](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html)) | External export boundary only; no hosted TGP coordinator |

These are project descriptions, not TGP endorsements or implementation audit results. No claim is made that a named protocol removes all correlation or all central dependencies.

### Swap engine requirements

The runtime must be a maintained reviewed implementation, not a bespoke translation of a paper. TGP's code may orchestrate local consent/state/UI, but the selected protocol must provide complete funding, redemption, cancellation, refund, timeout, chain-reorg, fee, and recovery semantics.

| Abstract state | Allowed next action | Must remain protected |
|---|---|---|
| Disabled | Read capability explanation | No network discovery or funds |
| Offer draft/received | Validate direction, assets, bounds, peer, protocol | No implicit acceptance |
| Reviewed | Show amounts, all fees, worst-case loss, deadlines, dependencies | No stale quote authorization |
| Coverage checked | Verify supported watcher/signer/refund prerequisites | No funding if coverage absent |
| Prepared | Persist recovery journal and required authorizations | No partial irreversible funding without recoverable state |
| Funded | Monitor protocol/chain events under exact engine rules | Do not allow arbitrary fee bump or generic cancellation |
| Counterparty pending | Wait/timeout under protocol | Do not declare loss or success early |
| Redeem/refund eligible | Perform only engine-authorized operation | Secrets/transaction validity and fee coverage |
| Completed/refunded | Reconcile both chain outcomes | Retain necessary recovery evidence until safe retention point |
| Intervention required | Show exact unresolved condition and safe export | Never generic “try again” double funding |

This table is not a wire protocol or a promise that every state exists identically in every engine. Each adapter supplies a protocol-specific state mapping and test vectors before mainnet eligibility.

### Deadline coverage

Mobile background execution cannot be relied on to meet adversarial timelocks. Before funding, the selected engine must establish that required actions can be performed under documented device/watcher availability, key authorization, network delay, fee spikes, chain reorg, storage failure, and lock/reboot conditions.

| Coverage option | Requirement | Residual limit |
|---|---|---|
| Desktop companion | Always-on qualified runtime, synchronized recovery state, separately authorized financial capability | Desktop can fail; chat companion grants alone are insufficient |
| User-operated watcher | Narrow protocol-specific authority, encrypted recovery material, no arbitrary spend power | Hosting, availability, secrets, collusion, and metadata remain |
| Pre-authorized recovery transactions | Exact engine support, valid fee/nonce/timelock conditions | Fees/reorg/transaction validity can defeat simplistic assumptions |
| Phone alone | Only if real-device adversarial evidence meets protocol needs | Otherwise blocked |
| TGP-hosted watchtower | Not part of selected service model | No hidden custody/control or contact/payment database |

A watcher holding a secret or adaptor material may have more power than “monitor only.” Its authority must be derived from the exact protocol rather than assumed harmless.

The UI must not say “refund guaranteed,” “risk-free,” or “your phone will automatically recover funds.” Worst-case outcomes and support limits appear before funding.

### External tool integration contract

TGP runs no mixer, CoinJoin coordinator, swap maker, pool, order-routing service, or settlement backend. Export-only design reduces some operational roles but is not legal immunity or proof of metadata equivalence.

“Export PSBT to CoinJoin” is not assumed to be universally supported. An adapter must demonstrate the actual tool's accepted input format and semantics; otherwise provide neutral standards-based wallet export only or no integration.

JoinMarket NG describes maker/taker coordination and end-to-end communication over a Tor-integrated market, while Wasabi documents a coordinator that receives clear input/output information under its protocol roles ([JoinMarket NG](https://github.com/joinmarket-ng/joinmarket-ng/), [Wasabi CoinJoin documentation](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html)). Neither description supports “no one sees anything,” and no fixed number of rounds or transformation sequence is specified as making funds unlinkable.

### Adapter manifest

```yaml
adapter_id: "example.disabled"
manifest_version: 1
status: "research-only"
protocol:
  name: "required"
  version: "exact pinned version"
  implementation_commit: "required"
  reproducible_artifact_digest: "required"
  license_review: "required"
supported:
  chains: []
  directions: []
  networks: ["test-only-until-approved"]
destinations: []             # exact role, host/onion, transport, redirects policy
data_sent: []                # fields, purpose, plaintext recipient
data_received: []
custody_and_control:
  tgp_can_spend: false
  third_party_authorities: []
fees:
  network: "explicit"
  protocol: "explicit"
  anti_spam_or_penalty: "explicit"
  tgp_percentage: 0
recovery:
  deadlines: "protocol-specific"
  required_online_roles: []
  secret_authorities: []
  journal_format: "required"
  failure_and_refund_tests: []
privacy:
  baseline_comparison: "required"
  residual_linkage: []
  source_ancestry_preserved: true
legal:
  reviewed_jurisdictions: []
  opinion_date: null
  distribution_constraints: []
evidence:
  independent_review: null
  remediation: null
  compatibility_matrix: null
```

A missing field blocks activation. A manifest cannot authorize a new destination dynamically without signed update policy and user review, and a new signature on a manifest cannot turn an experimental adapter into a validated one.

## Financial acceptance tests

| Test | Given / When / Then |
|---|---|
| FIN-01 | Given chat-only build, when all message journeys run, then no wallet service, key, endpoint, or seed prompt is required |
| FIN-02 | Given existing BTC/ETH hardware connection, when Connect completes, then no recovery phrase was requested or transmitted |
| FIN-03 | Given imported descriptor/address, when sync runs, then no contact name/chat ID reaches adapter, provider, logs, or hardware telemetry |
| FIN-04 | Given BTC filter mode, when captures are reviewed, then no xpub/address query is sent; block-fetch/broadcast observations are separately documented |
| FIN-05 | Given ETH third-party RPC, when address query is made, then UI discloses the provider's address visibility and baseline-blocked contact spend remains blocked |
| FIN-06 | Given quarantined funds, when a user tries Pay contact, then no warning-only bypass grants baseline eligibility |
| FIN-07 | Given a payment message, when parsed, then no signing/broadcast occurs without current separate local authorization |
| FIN-08 | Given changed amount/destination/fee/source after review, when authorization is attempted, then review revision fails and user must review again |
| FIN-09 | Given a group, when Pay privately is chosen, then only a one-to-one flow opens and no group payment event is emitted |
| FIN-10 | Given a peer “paid” claim, when chain data does not verify it, then UI says claimed/unverified rather than settled |
| FIN-11 | Given signed-held transaction, when cancel is selected, then app explains the signature may already be broadcast if copied |
| FIN-12 | Given chain reorg/conflict/replacement, when wallet reconciles, then state can move backward accurately without double spend |
| FIN-13 | Given hardware return payload mismatch, when imported, then no broadcast and no silent acceptance of changed recipient/change/fee |
| FIN-14 | Given external tool return, when imported, then typed limits/network/intent/recovery data are revalidated |
| FIN-15 | Given missing swap coverage, when Start is tapped, then no funding request or counterparty commitment is sent |
| FIN-16 | Given watcher offline/fee spike/reorg/reboot/lock, when swap recovery is exercised, then outcomes match exact engine threat model or mainnet stays blocked |
| FIN-17 | Given settlement-card minimization, when retention runs, then pending refund/recovery state is not destroyed and wallet/public-chain history is not called erased |
| FIN-18 | Given local profile deletion, when wallet exists, then separate wallet backup/removal consent is required |
| FIN-19 | Given an ordinary chat archive or support package, when inspected, then wallet seeds/private view keys are absent and contact-payment maps are excluded by default; any eligible mapping export is separate and explicitly reviewed, never a secret-recovery request from support |
| FIN-20 | Given legal restriction or adapter retirement, when new starts are disabled, then required recovery information and lawful safe export/intervention paths are preserved; no guarantee of an otherwise prohibited refund transaction |

## Financial release decision

The selected initial financial goal is isolated non-custodial wallet management and retained XMR request/send design after its own gates. Native BTC/ETH management is not permission to claim private contact payment equivalence; public-chain contact spending, shielded protocols, CoinJoin integration, and swaps remain independently gated or blocked.

No engineering or legal approval is inferred from this volume. The final legal section of the master document specifies jurisdiction review, prohibited service roles, and launch/retirement handling.
