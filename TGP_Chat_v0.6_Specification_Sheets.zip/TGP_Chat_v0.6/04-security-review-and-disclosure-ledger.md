# TGP Chat v0.6: Security Review and Disclosure Ledger

This is a pre-implementation architecture review against the supplied v0.5 requirements. It is not an independent security audit, penetration test, formal proof, or finding that the proposed architecture preserves a measurable percentage of privacy.

## Review method and baseline

### Baseline discipline

v0.5 describes intended protections, candidates, and release gates, not a validated implementation. “Before” below therefore means the applicable documented v0.5 design, not measured deployed behavior.

Each review compares eight required dimensions: content confidentiality, relationship privacy, network metadata, authority, persistence, endpoint attack surface, failure behavior, and evidence. A design can improve one dimension while worsening another; the no-regression rule blocks shipping the worsening dimension rather than allowing a net score.

### Threat actors and boundaries

| Actor or failure | Relevant access | Required response and residual limit |
|---|---|---|
| Passive local-network observer | Connection destination, timing, volume, transport fingerprints | Protected route and padding reduce exposure; no global correlation guarantee |
| Active censor | Blocking, packet injection, delay, bridge enumeration | Maintained PT options and fail-closed behavior; shutdown may defeat availability |
| One relay operator | Queue capabilities, message sizes, timings, its forwarding role | No content keys; minimize identifiers; live observation remains |
| Colluding relays/hosting providers | Combined timing and routing observations | No assumed independence; composition analysis required |
| Malicious rendezvous | Invite timing, races, withheld or substituted ceremony messages | Reviewed transcript/PAKE binding, one-use local state; denial of service remains |
| Directory/signing compromise | Malicious endpoint recommendations or release metadata | Separate identity authority; signed freshness, rollback and governance defenses |
| Malicious contact/member | Authorized plaintext, screenshots, transcript exports | Minimize unnecessary signed evidence; cannot prevent recipient disclosure |
| Lost locked device | Encrypted files, OS backups, hardware-dependent protections | Separate keys/leases, no broad recovery; offline guessing/forensics remain |
| Unlocked endpoint malware | Authorized memory, input, UI, keys reachable at runtime | Isolation and least privilege; no app-level guarantee against full OS control |
| Controller compromise | Enrollment/continuity power in selected scopes | Visible grants, peer admission, conflict handling; high-consequence role remains |
| Compromised companion | Only selected content/grants | No expansion, wallet, future-chat, or automatic controller rights |
| Platform/store operator | Install/account/push metadata, OS execution | Explicit exceptions, no content keys; platform cannot be made invisible by TGP |
| Blockchain/RPC observer | Public transfers, queried addresses, transaction propagation | Chain-specific limits; no source-history erasure |
| Swap peer/watcher | Protocol state, deadlines, fees, possibly recovery secrets | Exact authority/deadline review; no generic trustless/risk-free claim |
| Rollback/crash/disk failure | Stale state, lost queues, partial writes | Transactional crypto state and fail-closed recovery; no plaintext fallback |
| Legal demand | Existing operational/business data, compelled actions within law | Minimize retained data, truthful lawful-process policy, independent counsel |

### Evidence status

All evidence below is required future work unless explicitly labeled upstream background. Citing a library or protocol establishes its documented behavior, not that TGP's implementation passed a test.

Signal's direct-protocol documentation and analysis qualify deniability, and MLS makes no deniability claim; these are reasons to restrict public language, not grounds to promise legal non-evidence ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/), [PoPETs analysis](https://petsymposium.org/popets/2024/popets-2024-0148.pdf), [MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)).

## Eight-dimension feature reviews

### AUD-01: First launch, display name, and tutorial

**Scope:** F-001–F-004, F-011, F-015. **Verdict:** Preserves by design, unverified; faster setup must not alter key protection.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local keys and protected history | Same; background key creation only after secure prerequisites |
| Relationship privacy | No account/directory, per-contact presentation | No uniqueness request; no global username; checklist local |
| Network metadata | Tor setup required | Earlier bootstrap may reveal earlier app activity; compare same user journey, no extra analytics |
| Authority | Local profile/controller creation | Same; no tutorial completion grants trust |
| Persistence | Local profile and settings | Small encrypted hint/checklist preferences only; clearable |
| Endpoint attack surface | Platform and core setup | Shared TS UI adds no remote code; bridge/parser hardening required |
| Failure behavior | Fail closed on protection/route failure | Setup can remain local/offline; no registration or direct fallback |
| Evidence | First-launch/identity/network gates | Packet capture from installation through first message; empty-name and interrupted-setup tests |

### AUD-02: One-use QR and remote invitation

**Scope:** F-006–F-008. **Verdict:** Conditional on reviewed invitation composition and PQ requirement.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Reviewed PAKE candidate and separate secret | Concrete candidate orchestration; no unreviewed hybrid combiner |
| Relationship privacy | No public lookup | Expiring rendezvous has no person fields; remote service still sees ceremony activity |
| Network metadata | Protected rendezvous traffic | Same boundary; rate/length/attempt patterns must be bounded |
| Authority | Invite plus explicit contact establishment | Scan never auto-enrolls device or signs payment |
| Persistence | One-use expiring invitation | Local burned state and bounded replay proof; server deletion not sole authority |
| Endpoint attack surface | QR/link/PAKE parsing | Typed scanner, strict URL/scheme/length/version; no universal handler |
| Failure behavior | Wrong guess burns invite | Local race/concurrency handling; malicious server may cause denial of service, never bypass |
| Evidence | Invite attack matrix | Wrong-secret, double-claim, replay, crash, expiry/skew, substituted profile, malicious rendezvous review |

### AUD-03: Comparison, key changes, and signed cards

**Scope:** F-005, F-009, F-010, F-012, F-013. **Verdict:** Comparison preserves by design; reusable links/cards conditional.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Verification independent of encryption | Same; no false decryption guarantee from green badge |
| Relationship privacy | Scoped key records; optional signed card | Reusable capabilities/card signatures may add cross-context evidence; default off |
| Network metadata | No directory lookup | Build checks use approved transport; link access patterns reviewed |
| Authority | Explicit comparison and continuity review | QR physical provenance explicit; transferred records labeled |
| Persistence | Local prior fingerprints and notes | Same with bounded event history; no provider key-history directory |
| Endpoint attack surface | Canonical representation and manifest parsing | Accessible comparison alternatives, hostile-card/link tests |
| Failure behavior | Key change pauses trust | Affected send blocked until review; no automatic “new phone” assumption |
| Evidence | VER/DIST gates | Human comparison study, key substitution, stale/replayed cards, signed manifest rollback tests |

### AUD-04: Direct protocol and scoped endpoint sessions

**Scope:** F-016, F-029, F-030. **Verdict:** Conditional on selected profile, licensing, scoped identity, and independent composition review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Hybrid handshake and evolving sessions required | PQXDH + maintained Triple Ratchet candidate; no weaker compatibility fallback |
| Relationship privacy | Scope-local authority, no universal public credential | Must realize this with selected library; global Signal-style service account not imported |
| Network metadata | Padded two-relay delivery | Crypto/prekey traffic must not create stable cross-contact service identifier |
| Authority | Explicit endpoint admission | Protocol session possession is not authority to expand recipients |
| Persistence | Protected session state, key deletion | SPQR/prekeys/skipped keys bounded; atomic outbox/state writes |
| Endpoint attack surface | Maintained protocol implementation | Rust/FFI/serialization dependencies pinned and reviewed |
| Failure behavior | Unsupported security profile fails closed | No first-reply downgrade, state rollback, or cloned active session |
| Evidence | CRYPTO/DEV gates | Exact profile vectors, downgrade tests, crash consistency, secret lifecycle, external protocol review |

### AUD-05: Delivery, offline queue, drafts, and mutation events

**Scope:** F-017–F-023, F-026. **Verdict:** Preserves by design, unverified.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | E2EE content/local encrypted cache | Replies, edits, reactions remain encrypted under same scope |
| Relationship privacy | No server-readable labels | Pin/archive/mute/drafts local; reactions expose activity only to existing recipients |
| Network metadata | Queue/receipt patterns exist | New interaction event volume changes metadata; quantify and bound before equivalence claim |
| Authority | Authenticated typed events | Edit/reaction cannot mutate membership or target another scope |
| Persistence | Keep default, local retry source | Draft and mutation retention explicit; no unbounded hidden edit archive |
| Endpoint attack surface | Bounded message parser | Additional event variants fuzzed; inert text rendering |
| Failure behavior | Retry/dedup and honest labels | No duplicate visible action, false delivery, stale edit resurrection |
| Evidence | MSG/SYN gates | Event algebra/property tests; duplicate/reorder/conflict/lock/disk-full matrix |

### AUD-06: Expiry, search, and view-once

**Scope:** F-024, F-025, F-035. **Verdict:** Conditional on local-key/index/replay implementation.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Locked chats excluded from active search | Same; per-chat index/key boundaries, no global plaintext FTS |
| Relationship privacy | Queries local | No remote suggestions/search telemetry |
| Network metadata | Expiry control events scoped | No extra read-triggered signal unless existing policy explicitly allows |
| Authority | Shared authenticated timer; local view restriction | No sender authority to prove recipient destruction |
| Persistence | Keep default; eligible expiry/tombstones | Bounded replay state prevents duplicate reopening; backups may retain old copies |
| Endpoint attack surface | Search/index/media parsing | Sanitized snippets, no quoted locked/expired original |
| Failure behavior | No expiry restart on sync/import | Clock uncertainty visible; modified recipients remain outside guarantee |
| Evidence | SEC/MSG/BKP tests | Relock memory tests, stale replay, skew, duplicate view, archive resurrection tests |

### AUD-07: Transport broker, bridges, and network status

**Scope:** F-056–F-058. **Verdict:** Preserves by design, unverified; platform/PT support conditional.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Transport never receives plaintext keys | Same, opaque message payloads |
| Relationship privacy | Context isolation required | Reviewed context IDs; no universal device token to destinations |
| Network metadata | Tor with bootstrap/PT exceptions | Earlier bootstrap same disclosed transport role; no DNS/redirect leaks |
| Authority | User-reviewed endpoint configuration | Imported config preview cannot silently replace route |
| Persistence | Cached successful method | No retained per-contact route history; bridge secrets protected |
| Endpoint attack surface | Tor/native/PT dependencies | Pin exact platform packages, verify provenance, update lifecycle |
| Failure behavior | App fail closed | All app dependencies denied direct fallback |
| Evidence | NET/PLAT gates | Device egress capture for each feature during network loss/IPv6/DNS/redirect scenarios |

### AUD-08: Federated relays, directory, queues, and quotas

**Scope:** F-059, F-098. **Verdict:** Conditional; operator diversity and metadata composition not proven.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Relay ciphertext only | Same, no content keys |
| Relationship privacy | Two-role relay design | Nested envelopes/capabilities; colluding operators remain able to correlate |
| Network metadata | Queue sizes/activity visible in role | Explicit actor ledger; no “no metadata” claim |
| Authority | Relay cannot admit recipients | Directory selects infrastructure only; not identity authority |
| Persistence | RAM queue up to seven days | Same upper bound, no durable promise; inspect swap/dumps/snapshots |
| Endpoint attack surface | Relay wire parser and admin surface | Bounded Rust parser, separate control plane, no content index |
| Failure behavior | Restart loses queue, sender retries | Reject/evict explicitly; no false durability or persistent backup workaround |
| Evidence | OPS/META gates | Malicious relay, collusion simulation, queue pressure, restart/TTL, operator governance review |

### AUD-09: Private groups and membership

**Scope:** F-037–F-041, F-044. **Verdict:** Conditional on hybrid profile, ordering/freshness, and metadata review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | MLS preferred, hybrid requirement unresolved | Maintained OpenMLS candidate; no classical fallback |
| Relationship privacy | Members know group roster; service should not | Encrypted operations and scoped credentials; group signatures not blanket deniability |
| Network metadata | Client fanout | Recipient-specific wrapping; timing and count costs measured |
| Authority | Admin/member/coordinator distinct | Consent and role validation in addition to MLS validity |
| Persistence | Current/limited old state and local content | Bound epochs/skipped state; no pre-join archive by default |
| Endpoint attack surface | Group protocol/state parser | Current dependencies/advisories; hostile commit/key package fuzzing |
| Failure behavior | Stop forks and unsafe stale sends | No arrival-time resolution, silent election, or stale state clone |
| Evidence | GRP/CRYPTO/META gates | Unauthorized add/remove, all device variants, coordinator loss, fork/partition, library composition audit |

### AUD-10: Large groups and community umbrella

**Scope:** F-042, F-043. **Verdict:** Shared-mailbox/server-fanout proposal blocked; client-fanout expansion experimental.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Small private groups | MLS can preserve content secrecy but is not enough |
| Relationship privacy | No provider roster/shared room requirement | Shared mailbox can join all readers/writers; rotating IDs do not remove within-epoch linkage |
| Network metadata | Small fanout bursts | Larger fanout leaks volume/capacity patterns; measure, do not claim unchanged |
| Authority | Small-group explicit admin/coordinator | Community-wide admins and directories add authority/linkage; separate scope required |
| Persistence | Group-local state | Umbrella membership/cross-group map adds sensitive state |
| Endpoint attack surface | Bounded group workload | Larger state/buffers/token protocols increase attack surface |
| Failure behavior | Bounded coordinator/queue limits | Large-scale overload must reduce availability, never weaken validation |
| Evidence | Capacity targets only | Comparative metadata analysis and worst-case endpoint/fanout measurements required; no production approval |

Anonymous credentials and Privacy Pass are not sufficient by themselves to make a shared mailbox unlinkable; the architecture and collusion assumptions must be analyzed separately ([Privacy Pass architecture](https://www.rfc-editor.org/rfc/rfc9576.html), [MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)).

### AUD-11: Media sanitization and endpoint transfer

**Scope:** F-031–F-034, F-049. **Verdict:** Conditional on parser containment and actual metadata fixtures.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Protected attachments, local sanitize | Same, encrypted staging and bounded worker |
| Relationship privacy | Same chat recipients | No external transcoder, URL thumbnail, or metadata service |
| Network metadata | Attachment size/transfer activity | Padded chunks reduce lengths but volume remains |
| Authority | User chooses file/recording | Picker does not grant send; preview and Send remain separate |
| Persistence | Local protected cache | Unsent staging TTL and worker crash cleanup explicit |
| Endpoint attack surface | Codec/document parsers | More formats add attack surface; sandbox/memory/CPU constraints mandatory |
| Failure behavior | Unsafe file rejected/disclosed | No silent “cleaned” label or plaintext temp fallback |
| Evidence | MED/SEC gates | Malformed media corpus, decoder fuzzing, metadata residual checks, worker escape tests |

### AUD-12: External attachment blob service

**Scope:** F-036. **Verdict:** Blocked in strict production baseline until new observer/persistence equivalence is established.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Endpoint transfer / separately gated store | Ciphertext-only store can preserve content secrecy |
| Relationship privacy | No necessary common blob observer | Common blob ID/access patterns can join recipients |
| Network metadata | Endpoint/relay transfer timing | New storage service sees upload/download, size buckets, retries |
| Authority | User endpoints control availability | Bearer fetch capabilities add leakage/theft/revocation semantics |
| Persistence | No automatic external durable copy | New ciphertext persists outside device/RAM queue |
| Endpoint attack surface | Attachment parsers | Upload/resume/token/manifest APIs added |
| Failure behavior | Delivery may require endpoint online | Store outage must not enable direct/plain storage |
| Evidence | Architecture unresolved | Explicit baseline comparison, token lifecycle review, multi-device/resume/TTL/crash tests; consent insufficient |

### AUD-13: Device pairing and selected history

**Scope:** F-050–F-052. **Verdict:** Preserves by design, unverified.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Fresh endpoint sessions, selected history | Same; no copied live ratchet/leaf |
| Relationship privacy | New device learns selected scopes | No full profile roster/nicknames/wallet copied |
| Network metadata | Pairing and transfer activity | Protect transfer context; size/date range remains observable by participants |
| Authority | Controller grants, peer/group admission | Pairing does not bypass admission; zero scopes/history initially |
| Persistence | Explicit history recipient expansion | Manifest/range and destination visible before transfer |
| Endpoint attack surface | Pairing/archives/FFI | Typed bounded import, compared transcript, cancellation |
| Failure behavior | Partial grants visible | No universal trust after interruption; per-scope status |
| Evidence | DEV/SYN/BKP gates | Replay/mismatch, locked scope, future-chat denial, partial completion, archive exclusions |

### AUD-14: Revocation, controller migration, and loss

**Scope:** F-053–F-055, F-094. **Verdict:** Conditional on continuity/freshness design; no automatic companion promotion.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Old copies retained; future access revoked as state propagates | Same, honest applied/pending states |
| Relationship privacy | Scoped device identities | No provider universal device inventory |
| Network metadata | Revocation/update messages | Prioritize without exposing control type unnecessarily |
| Authority | Explicit migration, separate recovery candidate | Fresh successor state, no timestamp arbitration or archive cloning |
| Persistence | Old keys/backups may survive | Explain conflict/old-controller risk; no erase-everywhere claim |
| Endpoint attack surface | Authority event/recovery parser | Reviewed transitions and bounded journal |
| Failure behavior | Offline senders may be stale | Strict freshness trades availability; irrecoverable loss may require new identity/group |
| Evidence | DEV/RECOVER gates | Old device still online, duplicate successors, interrupted transfer, offline participants, rollback |

### AUD-15: App/chat lock, panic, and profile deletion

**Scope:** F-065–F-067, F-070, F-071, F-103. **Verdict:** Preserves by design, unverified; destructive experiments not production.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | App lock and per-chat keys distinct | Same, key leases/search/media caches cleared on lock |
| Relationship privacy | Generic notifications and previews | No route/contact/wallet detail in locked error surfaces |
| Network metadata | Locked ciphertext may queue | No unlock pulse analytics; background behavior documented |
| Authority | Local unlock distinct from wallet authority | Panic cannot sign, revoke remote device, or wipe ambiguously |
| Persistence | Protected DB, best-effort erasure | WAL/cache/backup behaviors tested; wallets protected from chat reset |
| Endpoint attack surface | OS lock/biometric/clipboard | Narrow adapters and no secret clipboard by default |
| Failure behavior | No plaintext fallback | Reboot/process death returns locked; disk-full does not export temp plaintext |
| Evidence | SEC/PLAT tests | Memory/storage/recents/clipboard/notification/accessibility/lock-race tests |

### AUD-16: Decoy, disguise, and destructive dead-man options

**Scope:** F-068, F-069, destructive part of F-070. **Verdict:** Experimental/deferred; no forensic-deniability assurance.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Optional concealed local state | No weakening of real vault encryption |
| Relationship privacy | Filesystem/app artifacts may reveal hidden use | Same residual; do not market invisible app |
| Network metadata | Alternate icon does not change traffic | No invisibility implication |
| Authority | Local deliberate configuration | No remote trigger; auto-lock preferred |
| Persistence | Flash/backups can retain traces | Key destruction cannot prove every physical copy gone |
| Endpoint attack surface | Alternate launcher/credential paths | More high-risk code, false-trigger states |
| Failure behavior | Coercion/clock/non-use risks | Never wipe from ambiguous PIN or accidental timeout |
| Evidence | No validation | Human safety review, platform forensics, irreversible-action tests; feature stays disabled |

### AUD-17: Platforms, notifications, and desktop rendering

**Scope:** F-072, F-073. **Verdict:** Conditional per platform; existing v0.5 platform exception is not a new blanket exemption.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | No content keys in push/share extensions | Same; JS receives only permitted UI plaintext |
| Relationship privacy | Minimal push token/wake mapping | Token reuse/collusion can join scopes; no hidden global device directory |
| Network metadata | Platform services outside app Tor guarantee | Clearly disclosed; default iOS app-open |
| Authority | Push cannot admit/unlock/capture | Same; desktop IPC cannot create grants/spend from content |
| Persistence | OS preview/search/backup restrictions | Actual webview/JS caches/extensions tested |
| Endpoint attack surface | Platform services/rendering/FFI | RN/JSI/Tauri/CSP/custom commands increase composition surface |
| Failure behavior | OS may suspend/force-stop | Availability decreases rather than key protection relaxed |
| Evidence | PLAT/DESK/IOS gates | Real non-debug devices, lock/reboot/force-stop/push denial, webview injection/IPC tests |

### AUD-18: Calls and handoff

**Scope:** F-045–F-048. **Verdict:** Experimental; production blocked where new media observer/association exceeds baseline.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Gated encrypted media candidate | Dedicated call-only keys, no nonparticipant decryption |
| Relationship privacy | Media relay associations disclosed | Multiple streams may be joined to call; no metadata-free claim |
| Network metadata | Tor-only duration/volume | Must prove no UDP/STUN/direct path; latency constraints remain |
| Authority | Explicit call endpoints/capture | New chat device cannot silently join call |
| Persistence | Bounded buffers, no recordings | No automatic transcript or failed-call recording |
| Endpoint attack surface | Codecs, mic/camera, media stack | Large new surface requires sandboxing/audit |
| Failure behavior | Pause/end on unsafe route/rekey | No direct fallback, pre-consent capture, or double microphone handoff |
| Evidence | CALL/META gates | Packet capture actual stack, sender spoof/replay, capture instrumentation, rekey/handoff interruption |

### AUD-19: Wallet activation and existing-wallet connection

**Scope:** F-074, F-078–F-080. **Verdict:** Conditional isolation; contact spend from linked/unknown history blocked.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Separate XMR wallet keys | Separate BTC/ETH roots/stores; watch-only/hardware connection |
| Relationship privacy | No stable shared chat/wallet ID | Local bridge map unavoidable for intentional contact payment; protected/minimized |
| Network metadata | XMR node traffic over Tor | New chain sync/provider patterns; no claim of baseline equivalence automatically |
| Authority | Separate wallet authorization | Connect never asks seed; chat pairing grants no spending |
| Persistence | Wallet recovery separate | Descriptors/public addresses are sensitive; source labels local |
| Endpoint attack surface | One wallet stack | Additional chain/hardware/PSBT parsers contained or module disabled |
| Failure behavior | Node unavailable fails closed | No hosted-wallet/RPC direct fallback; unknown history remains quarantine |
| Evidence | WAL/FIN gates | IPC attacks, independent key roots, wallet-free build, egress captures, provenance-policy tests |

### AUD-20: XMR receive/send

**Scope:** F-075, XMR portions of F-081/F-082/F-085. **Verdict:** Preserves intended baseline only after exact implementation review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local spend/view keys, encrypted requests | Same; no hosted scan view-key export |
| Relationship privacy | Local contact/subaddress map, intended peer sees request | Same; map not default-synced/exported |
| Network metadata | Remote node timing/query/broadcast observations | Exact RPC/decoy/trusted flags reviewed; Tor does not hide query contents from node |
| Authority | Separate recipient/amount/fee review | Same, revision-bound local authorization |
| Persistence | Local wallet history and separate seed | Chat-card minimization cannot erase needed wallet recovery |
| Endpoint attack surface | Wallet/node/hardware adapter | Rust library must supply complete wallet policy and current consensus support |
| Failure behavior | Reorg/offline/restore state explicit | No universal unlock-time promise or chain claim from peer message |
| Evidence | WAL/PAY gates | Node malice, fee/decoy tests, restore height, hardware exact matrix, reorg and crash tests |

### AUD-21: BTC/ETH contact payments

**Scope:** F-076, F-077, contact-spend portions of F-081/F-082/F-088. **Verdict:** Blocked where public-chain/RPC disclosure exceeds private-payment baseline.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Private-chain request model | Chat remains encrypted, but public transfer details are outside it |
| Relationship privacy | No public sender/recipient/amount edge of the same kind | BTC/ETH ledger/source history may link counterparties; fresh addresses do not erase it |
| Network metadata | XMR node query patterns | ETH RPC sees queried account; BTC block/broadcast patterns remain |
| Authority | Explicit signing | Same, but more transaction types/contracts would expand authority |
| Persistence | Private wallet records | Public-chain records persist independently of app deletion |
| Endpoint attack surface | XMR stack | BTC/ETH parsers, fee/nonce/PSBT/hardware/contract risks |
| Failure behavior | Chain-specific send states | Reorg/conflict/nonce replacement must not cause duplicate authorization |
| Evidence | No equivalence established | No opt-in warning can close known ledger regression; management-only scope is the safe reduced release |

### AUD-22: Payment bridge, scheduling, guardrails, and card retention

**Scope:** F-081–F-086. **Verdict:** Conditional on strict local authority and retention implementation.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Typed E2EE request, no automatic spending | Same, bounded transient bridge read models |
| Relationship privacy | Local intentional payment mapping | Minimize map; financial cards only one-to-one; no group completion event |
| Network metadata | Request and transaction timings can correlate | Delay/jitter not claimed to defeat correlation |
| Authority | Separate signing/broadcast review | Unsigned schedule preferred; future auto-sign unavailable by default |
| Persistence | Local request/history | Card detail expiry distinct from wallet/chain retention; no unsafe pending-state purge |
| Endpoint attack surface | Request parser | Version/amount/network/address/revision checks; no arbitrary calldata |
| Failure behavior | Duplicate/expired request handled | Expired request does not reverse broadcast; copied signed transaction may escape cancellation |
| Evidence | PAY/FIN gates | Substitution/replay, stale review, lock-at-deadline, source policy, card-retention/refund preservation tests |

### AUD-23: Payjoin, stealth receive, swaps, and external privacy tools

**Scope:** F-087–F-091. **Verdict:** Experimental/deferred; not a no-regression pass.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | No exchange/mixing service | New external protocols see role-specific payment information |
| Relationship privacy | No protocol coordinator/maker/watcher | Counterparties, coordinators, gas funders, pools, or watchers can add association |
| Network metadata | Existing wallet requests | New discovery, contract, directory, timeout, and settlement patterns |
| Authority | User wallet signing | Watcher/adaptor/recovery secrets may confer power; no generic monitor-only assumption |
| Persistence | Ordinary wallet history | New recovery journals, contract state, exported files, pending deadlines |
| Endpoint attack surface | Wallet protocol | External engines/PSBT/contract/proof parsers are significant expansion |
| Failure behavior | No timelocked swap obligation | Missing deadlines/fees/reorg can lose funds; phone background not assumed |
| Evidence | No TGP evidence | Protocol-specific independent audit, legal opinion, watcher simulation, external-tool format tests; mainnet disabled until complete |

### AUD-24: Backups, offline signing, diagnostics, releases, and funding

**Scope:** F-092–F-102, F-104. **Verdict:** Preserves by design with explicit independent gates; recovery additions deferred.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Encrypted selected archive; separate wallet backup | Same; no seeds/live state in ordinary archive/support export |
| Relationship privacy | Local diagnostics, separate billing | No production graph, export preview, no global entitlement join |
| Network metadata | Opt-in checks via protected transport | Same, no automatic remote crash/engagement/price calls |
| Authority | Restore content not live membership | Drill non-authoritative; signed updates do not bypass local security |
| Persistence | User-selected archives may survive | Explicit destination/old-copy warnings, no server sync |
| Endpoint attack surface | Archive/update/QR/file parsers | Bounded type markers, signature/rollback checks, reproducible supply chain |
| Failure behavior | Corrupt restore fails safe | No live-state clone, unsigned update, or support recovery backdoor |
| Evidence | BKP/DIST/OPS/MET gates | Hostile archives, rollback/reproducibility, redaction, wallet-free build, cohort consent tests |

### AUD-25: Blocking, activity signals, and external links

**Scope:** F-014, F-027, F-028. **Verdict:** Blocking and inert links preserve by design, unverified; additional activity signals remain off and require a separate no-regression result.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local block and explicit external opening | Block never exports content; link rendering never fetches; external browser receives only deliberate handoff |
| Relationship privacy | No public block list; activity signals off | Block list stays local; typing/read/last-online cannot silently reveal relationships/activity |
| Network metadata | Protected delivery; no automatic previews | Blocking stops applicable local subscriptions; external opening is a separate disclosed browser boundary |
| Authority | User controls local block and external launch | Peer message cannot unblock, enable signals, open a handler, or alter settings |
| Persistence | Local block state; external history beyond client control | Preserve local block after restart; clipboard/browser may retain deliberately exported URL |
| Endpoint attack surface | URL parser and optional OS handler | Strict scheme/type/length validation; no script/file/command activation from content |
| Failure behavior | No content fetch without action | Malformed link inert; blocked capability update may remain pending; no global erase/ban claim |
| Evidence | Local privacy and transport gates | TST-012/014/019; blocking idempotency; URL parser fuzzing; default read/typing packet captures |

### AUD-26: Privacy Report and local checks

**Scope:** F-060. **Verdict:** Preserves by design, unverified; external observer tests require a distinct disclosure and cannot establish universal anonymity.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local diagnostics need no message keys | Report inspects bounded transport/config evidence, not chat bodies or wallet secrets |
| Relationship privacy | No central privacy-score dashboard | No user/contact/queue IDs uploaded; exported evidence previewed |
| Network metadata | Explicit checks may themselves generate traffic | Local checks default; external test names destination/observation before consent |
| Authority | Diagnostics not a security override | A failed check cannot change node/bridge, disable Tor, or grant permissions automatically |
| Persistence | Bounded local evidence | Timestamp/config scope and clear control; no permanent behavior history |
| Endpoint attack surface | Instrumentation and evidence parser | Bounded local results; no arbitrary diagnostic script from server |
| Failure behavior | Missing evidence is not success | Not tested/Inconclusive distinguished from scoped Passed; offline checks remain honest |
| Evidence | Local check and export tests | TST-020/053; zero external packets before consent; result provenance and redaction review |

### AUD-27: Cover traffic, volunteer proxy, VPN, and nearby radio

**Scope:** F-061–F-064. **Verdict:** Experimental; each remains independently disabled until its eight-dimension delta is acceptable.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | E2EE protected online path; optional experiments | Cover traffic carries no extra plaintext; proxy relays others' traffic, not content keys; VPN scope and nearby E2EE each separately reviewed |
| Relationship privacy | No proximity directory or volunteer identity account | Nearby radio can expose proximity; proxy/VPN may create new observations; none silently joins contact identity |
| Network metadata | Tor metadata limits retained | Cover traffic changes volume/timing; proxy reveals contribution; VPN affects other-app routing; radio exposes discovery identifiers |
| Authority | Explicit opt-in for each experiment | No invitation/remote command enables radio, VPN, proxy, or lower-padding mode; OS VPN permission is not wallet authority |
| Persistence | Minimal local experimental configuration | No remote participation ledger, nearby contact database, or bandwidth-reward identity |
| Endpoint attack surface | Optional transport/radio/OS APIs | Separate dependencies/permissions/sandboxes and parser tests; resource caps per experiment |
| Failure behavior | No hidden automatic fallback | Proxy stop does not break chat assumptions; VPN scope failures honest; radio never auto-activates when Tor fails |
| Evidence | Separate experiment and platform gates | Captures, timing/bandwidth/battery measurements, OS kill-switch scope, proximity analysis and lawful-use review for each exact mode |

## Disclosure ledger

### Actor-specific minimum observations

| Actor | May receive/observe | Must not receive | Retention rule |
|---|---|---|---|
| Intended direct peer | Shared profile fields, plaintext content, its endpoint/security state, explicit financial request | Unrelated contacts, full wallet inventory, local private labels | Peer controls its own copies |
| Admitted group member | Group content/roster/roles and scoped endpoints | Unrelated relationship map, pre-join archive by default | Local policy; copying remains possible |
| Ingress relay | Opaque envelope, next relay role, timing/size bucket | Content keys, plaintext roster, wallet data | RAM queue and minimal live state only |
| Destination relay | Queue capabilities, timing/size/poll patterns | Content keys, civil identity, provider-readable people directory | Seven-day upper queue TTL; no durable promise |
| Rendezvous | Expiring opaque ceremony mailbox/activity | Names, wallet fields, universal profile ID | One use/ten-minute proposed expiry |
| Directory distributor | Generic infrastructure manifest fetch | Contact set, wallet account list | No per-client history |
| Optional blob service | Ciphertext objects, size buckets, fetch activity | Decryption key/plaintext | Disabled pending review |
| Optional media relay | Encrypted streams and session/volume associations | Content keys/plain media | Bounded live buffers; feature gated |
| Platform push service | Token/wake timing under opt-in mode | Body/sender/title/amount/balance/keys | Platform policy plus reviewed mapping expiry |
| BTC peer/node | Filters/blocks requested and broadcast transaction as applicable | xpub/address query in approved filter mode; chat labels | External operator behavior not controlled by TGP |
| ETH RPC provider | Queried account/method/time and submitted transaction | Contact labels, chat IDs, full unrelated portfolio batching | External operator behavior not controlled by TGP |
| XMR remote node | RPC/broadcast patterns according to exact wallet implementation | Private view/spend key, contact ledger | External behavior not controlled by TGP |
| Hardware signer | Necessary transaction/policy data | Chat history/contact graph by default | Device/vendor implementation reviewed |
| External financial tool | Explicit export fields/protocol data | Universal messaging identity or unrequested seed | Tool-specific disclosed policy |
| Support | Only previewed chosen diagnostic/report fields | Seeds, private keys, full archives by routine request | Published case retention required |
| Billing processor | Separate purchase information | Messaging contact/group map | Applicable minimum legal/business retention |

No table entry means “this actor learns nothing.” External service retention cannot be guaranteed by a local client; if it is material to a no-regression requirement, absence of enforceable evidence blocks the dependent feature.

### Mandatory delta form

Every implementation change includes:

```text
Change ID / feature / build / platform / owner
Baseline requirement and exact capability configuration
Observer and colluding-observer sets
Data fields before and after
Destination and transport before and after
Recipient/authority set before and after
Retention and deletion before and after
Linkability/equality/timing/size effects
Endpoint parser/permission/dependency changes
Outage/crash/rollback/partition behavior
Required tests, independent review, findings, remediation
Verdict and scope; no aggregate percentage
Security/product/platform/operations approval
```

## Blocking issues and remediation order

| Issue | Consequence | Required resolution |
|---|---|---|
| SEC-B01 Scoped identity/library composition | Global credentials could link unrelated chats | Independent protocol/metadata review before direct release |
| SEC-B02 Invitation hybrid composition | Low-entropy ceremony may not meet inherited PQ/anti-guess requirements | Select reviewed complete protocol; do not handwrite combiner |
| SEC-B03 Group hybrid suite | Candidate libraries/drafts are not approved production profile | Exact suite/dependency/interoperability/advisory review |
| SEC-B04 Authority freshness | Offline endpoints can send under stale membership | Define strict freshness and availability cost; test partitions |
| SEC-B05 Mobile wallet boundary | Same-process modules may not meet isolation | OS-qualified boundary or separately installed/disabled financial module |
| SEC-B06 Public-chain contact linkage | BTC/ETH transfers can expose relationships | Keep contact spending blocked under strict rule |
| SEC-B07 Shared group mailbox | New provider-readable activity grouping | Keep server-fanout/mailbox experiment off; prove equivalence or reject |
| SEC-B08 External blob persistence | New observer/retained ciphertext | Endpoint transfer baseline; external service remains blocked |
| SEC-B09 Live calls | New media metadata/parsers/platform assumptions | Independent feasibility/security/metadata gates |
| SEC-B10 Swap deadlines/control | Missed actions or excessive watcher power | Exact engine, coverage proof, recovery tests, legal approval |
| SEC-B11 Recovery conflict | Copied authority creates competing controllers | No automatic continuity/companion promotion |
| SEC-B12 Legal/service classification | Noncustodial label may not resolve operational duties | Jurisdiction-specific counsel opinion before distribution/service |

### Review conclusion

v0.6 is more specific and testable than v0.5, but specificity is not proof of security improvement. Direct messaging, local organization, scoped devices, retained XMR design, and carefully bounded UX can target the existing privacy contract; large shared mailboxes, external blob retention, public-chain contact payments, live media, and swap integrations remain blocked or experimental where their new exposures are unresolved.

No deadline, usability score, funding need, or opt-in checkbox overrides that conclusion. The release gates must be met capability by capability, and the final legal section independently constrains where and how each approved capability may be offered.
