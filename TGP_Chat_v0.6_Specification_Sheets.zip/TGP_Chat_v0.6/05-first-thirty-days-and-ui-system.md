# TGP Chat v0.6: First Thirty Days and UI System

This volume specifies the navigation, safe tap budgets, contextual education, first-thirty-day journeys, visual system, and interaction rules. The companion screen catalog defines each supported screen/sheet/control contract; experimental capabilities have a disabled explanation rather than a misleading enabled pathway.

## Navigation and information architecture

### Primary navigation

```text
Before wallet activation:          After wallet activation:
Chats | You                       Chats | Wallet | You

Chats
  Search
  All / Compared / Needs review / Locked filters
  Conversation list
  + : Connect / New group
      Request / Pay / Swap only after wallet activation and capability eligibility

Direct conversation
  Header: contact + independent trust/route states
  Timeline: text, media, security events, eligible payment cards
  Composer: text / attachment / voice / send
  Header tap: Contact details
    Compare identity / Shared media / Disappearing messages / Lock chat
    Devices in this chat / Block / Delete
    Pay or Request only when enabled and eligible

Group conversation
  Header: group + actual membership state
  Timeline/composer
  Header tap: Group details
    Members / Pending invites / Policy / Shared media / Leave
    Add/remove only for authorized role
    Pay privately opens selected person's 1:1; no group payment card

Wallet, after explicit activation
  Wallet selector
  Sync/provenance status
  Receive / Pay / Request
  History
  + Add wallet
  Advanced financial tools behind wallet settings

You
  Local profile and per-contact presentation guidance
  Devices
  Privacy & Network
  Security & Vault
  Backup & Restore
  Notifications
  Help & Tutorial
  Privacy Report
  About & Build
  Advanced
    Relay / node / bridge overrides
    Cover traffic / volunteer proxy / device-wide VPN experiments
    Financial adapters / offline signing / source labels
    Continuity archive / disguise / destructive experiments
```

The global plus menu must not become a wall of financial tools. It starts with Connect and New group; optional items appear only after the relevant module is explicitly activated and qualified, with unavailable experiments represented in Advanced rather than the main action list.

### Desktop adaptation

Use a navigation rail, chat list, main pane, and optional detail pane. Keep the same action labels and authority semantics; keyboard shortcuts are accelerators, never alternate security paths.

No browser-tab client is implied. Closing a window does not mean locked; the tray/background preference and lock status are explicit, and OS session lock invokes the selected local lock policy.

## Tap counting and safe friction

### Counting convention

A tap is one activation of an app control. Typing, scanning time, scrolling, biometric/OS prompts, file-picker navigation, hardware-wallet interaction, and independent comparison time are measured separately rather than hidden in a flattering count.

The budget begins on the named screen in an unlocked state. Extra taps caused by a changed key, locked vault, missing permission, offline route, or consequential review are legitimate safety branches and are reported separately.

| Task | Routine pathway | App tap target | Mandatory extra work |
|---|---|---:|---|
| Open a chat | Chats → conversation | 1 | Chat unlock if configured |
| Send text | Chat → type → Send | 1 after typing | Trust changes block send |
| Connect by in-person QR | Chats + → Connect → Scan → confirm provenance | 4 | OS permission, scan, peer ceremony |
| Show invite QR | Chats + → Connect → Show mine | 3 | No system sharing by default |
| Remote invite | + → Connect → Remote invite → create | 4 | Secret conveyed separately; no auto-verification |
| Compare existing contact | Chat header → Compare | 2 | Actual comparison + explicit match |
| Reply | Long press → Reply | 2 | Type and Send counted separately |
| React | Long press → reaction | 2 | Removal via selected reaction |
| Image send | Attachment → Photos → select → Send | 4 | OS picker, sanitization, preview |
| Voice note | Voice → Record → Stop → Send | 4 | Permission and preview; cancel always visible |
| New group | + → New group → select people → Review → Invite | 5 plus selections | Acceptance/admission asynchronous |
| Group members | Group header → Members | 2 | Role actions separate |
| Link device | You → Devices → Link | 3 | Reauth, scan, both-screen comparison, grants/history review |
| Lock now | You → Lock now | 2 | Panic accelerator may be 1 |
| Search | Chats → Search | 1 | Locked content excluded |
| Activate wallet | You → Wallet → Activate | 3 | Separate explanation and chain/connection choices |
| Receive | Wallet → Receive | 1 | Wallet/amount/address reveal as required |
| Pay from chat | Contact details → Pay → review | 2 to review | Eligibility, amount, signing, separate authorization |
| Backup | You → Backup & Restore → Export | 3 | Scope, passphrase, destination, confirmation |
| Revoke device | You → Devices → device → Revoke | 4 | Reauthentication and retained-copy warning |
| Privacy report | You → Privacy Report | 2 | External test requires separate consent |

No performance target rewards skipping verification, removing the recipient review, preselecting all chats, or combining backup and wallet recovery into an ambiguous Continue.

## First-thirty-day journeys

### Day zero: installation to the first contact

1. Download a signed supported build; installation/store behavior remains a platform boundary.
2. Optional About/Build inspection before creating a profile.
3. Welcome explains no registration and concise limits.
4. Enter optional display name; no uniqueness check or public username.
5. Confirm local protection; no seed or financial setup.
6. Tor bootstrap and key preparation run behind the name/protection work where safe.
7. Empty Chats offers Connect and three dismissible local hints.
8. Connect offers Show QR, Scan QR, and Remote invite.
9. In-person scan binds keys and explicit physical provenance; remote link remains not independently compared.
10. Complete contact/session establishment and display truthful state.
11. Type/send a first message; local queued bubble appears promptly.
12. Inspect receipt details if desired; no read receipt or last-online by default.

Offline branch: create local profile and draft, explain unavailable route, retry through permitted transport. Wrong/expired invite branch: terminate attempt and generate fresh material; never silently reuse a compromised invite.

### Days one through three: everyday messaging

Try reply/reaction/edit, encrypted local search, a second contact, local pin/mute/archive, one sanitized image, and a voice note. Contextual hints appear only at the relevant control and can be dismissed permanently.

Permission denial is normal: manual invitation entry remains available without camera; typed messaging remains available without microphone/photos. No repeated permission nag or contacts permission is required.

Notifications are a deliberate availability choice. iOS starts with app-open delivery; platform notices disclose the different metadata path before registration.

### Days three through seven: small group and desktop

Create an invitation-only group from existing contacts, review roster/policy, send invitations, and wait for acceptance/admission. Pending people are not shown as readers.

Link a desktop as a companion using both-device comparison. Select chats from an initially empty list, choose no history or an explicit range, review once, then show per-scope active/pending progress; no wallet or future-chat grant.

If groups are not qualified, the same path ends at a truthful availability sheet. It cannot secretly use a classical profile, server-readable room, or all-device trust shortcut.

### Week two: local protection and recovery preparation

Set a per-chat vault, try lock/unlock, configure optional prospective disappearing messages, export a selected encrypted archive, and run a non-authoritative recovery drill. Teach Keep versus expiry and delete-here versus requested deletion before consequential use.

Privacy Report shows scoped results: Tested path passed, Issue detected, Not tested, or Inconclusive. It never presents a universal privacy percentage.

### Week three: optional wallet

Open Wallet explicitly and choose create, hardware/watch-only connect, or restore. Existing BTC/ETH funds enter management-only provenance review; no seed is requested on Connect.

Configure the appropriate node mode, sync locally, reveal a receive address deliberately, and review the difference between public-chain transfer, provider query privacy, chat encryption, and local contact mapping. A blocked contact-spend action remains blocked even if the user accepts a warning.

For an eligible retained XMR payment flow, view/request in one-to-one chat, review exact amount/network/recipient/fee, separately authorize, and follow chain-specific state. Backup and drill wallet recovery independently.

### Week four: trust changes and long-term maintenance

Exercise a contact key change, a new endpoint awaiting approval, a lost-device revocation, an offline participant still pending update, and controller migration/loss explanation. Never imply that removing a device erases its stored content.

Review build/update evidence and perform an archive drill. Advanced swap/external-tool screens explain why unavailable capabilities are disabled and what evidence is missing; the thirty-day journey does not require a user to risk real funds.

## Shared screen contract

### Layout and controls

Every screen has a visible title, one clear primary action when meaningful, and a discoverable Back/Close control. Sensitive full-screen review flows do not dismiss through accidental outside taps; destructive actions use explicit wording.

Buttons implement enabled, disabled-with-reason, pressed, focused, loading, success, and error states. Double tapping cannot duplicate sends, grants, exports, or payments; the Rust core enforces idempotency beyond visual disabling.

Long press and swipe are optional accelerators. Every action also has an accessible labeled control; swiping cannot silently spend, export, grant, or destroy.

### Universal states

| State | Required behavior |
|---|---|
| Empty | Explain what exists and offer the next safe action; no fabricated example contact/balance |
| Loading | Show local/remote stage; cancellation remains possible before irreversible effect |
| Offline | Permit safe local work; label queued/not broadcast; no direct fallback |
| Locked | Remove relevant plaintext and require appropriate unlock; no previews behind blur |
| Error | State what did and did not happen, plus a safe next step |
| Partial | Show per-scope/per-endpoint/per-file status; no global success check |
| Permission denied | Explain limited capability and offer non-permission alternative where possible |
| Unsupported | Name required version/capability without enabling weaker mode |
| App backgrounded | Apply lock/capture policy; late async callbacks cannot revive plaintext |
| Disk full | Stop protected writes safely; never use unencrypted temporary storage |
| Cancelled | Return to prior safe state; explain if any external effect already happened |

### Network and disclosure behavior

Every app-managed request goes through the broker. Screens with no network action must remain genuinely offline-capable; opening a tab must not trigger hidden price, avatar, analytics, token, node, or update requests.

An OS picker/share sheet, external browser/wallet, platform notification registration, hardware device, nearby radio, or support upload is a boundary transition. Show it at the point of use, not only in a privacy policy.

### Accessibility

Read titles, warnings, exact recipient/amount/network, trust provenance, and pending states in logical order. Critical state changes receive a polite announcement; errors requiring action receive clear focus without stealing input repeatedly.

Support dynamic text, large touch targets, keyboard navigation, visible focus, reduced motion, high contrast, and non-camera comparison alternatives. Never depend only on color, gesture, tiny caption, hover, haptic, or a countdown animation.

### Navigation and interruption

Back returns to the previous screen without granting authority. For unsent content, offer Keep draft/Discard where meaningful; for signed/exported/broadcast effects, explain actual state rather than promising reversal.

Reentering a review revalidates its current revision. An OS-returned file/QR/signature cannot resume into an already-authorized broadcast after the original review expired or the wallet locked.

## Visual design specification

### Palette retained from v0.5

| Token | Hex | Meaning |
|---|---|---|
| `bg.primary` | `#1C211A` | Main near-black olive canvas |
| `surface.primary` | `#252B21` | Cards, navigation, sheets |
| `surface.raised` | `#303729` | Raised/selected surfaces |
| `brand.forest` | `#324D3F` | Structural forest panels |
| `brand.tan` | `#D4C6A6` | Warm secondary surface |
| `text.primary` | `#F4EBD9` | Main cream text |
| `text.secondary` | `#B8B09C` | Supporting readable text |
| `accent.gold` | `#C2A14E` | Primary actions and focus |
| `accent.gold.light` | `#E2C27C` | Highlighted foreground |
| `status.success` | `#73B887` | Specifically satisfied positive state |
| `status.warning` | `#E2B75F` | Review, stale, degraded |
| `status.danger` | `#D7786D` | Failure/destructive |
| `text.on-light` | `#1C211A` | Text on tan/gold |

Gold is an action accent, not verification. Green means a specifically supported positive state, not “anonymous,” “safe from all adversaries,” or “settled” when only broadcast.

Typography: 24sp title, 18–20sp section headings, 16sp body, 14sp support, 12–13sp noncritical meta. Use tabular currency figures, 8dp spacing grid, 16dp common gutters, 24dp section gaps, 48dp target touch areas, 16dp cards, and 12dp controls.

The actual composited screens must be contrast-tested against WCAG requirements rather than treating token choice as compliance; normal text and large text have different contrast thresholds, and color alone is insufficient ([WCAG 2.2](https://www.w3.org/TR/WCAG22/)). Topographic texture stays out of message-heavy surfaces, safety numbers, warnings, and amounts.

### Component inventory

- **Conversation row:** Local display label, minimal permitted preview, independent trust/unread/lock state, no wallet amount by default.
- **Trust header:** Encryption, comparison provenance, pending endpoints, route availability as separate inspectable states.
- **Delivery label:** Queued/relay accepted/received/partial/expired/failed; details show evidence source.
- **Security event card:** Specific changed authority, affected scope, Review action; not an ordinary dismissible promotional banner.
- **Payment card:** Request versus claimed payment versus locally verified chain state; sensitive details can minimize independently.
- **Grant checklist:** None selected initially; scope count and old-history decision separately visible.
- **Review sheet:** Exact intended external effect, current revision, consequence, separate authorization.
- **Disabled capability sheet:** Clear reason, missing evidence/support, safe alternative; no hidden override.
- **Progress list:** Per-scope/per-endpoint state, resumable/cancellable when safe; no false all-done state.
- **Hint card:** Local/dismissible, no overlay over warnings, no remote experimentation/analytics.

## Exact copy rules

| Situation | Required direction |
|---|---|
| Optional name | “This is a display name, not a public username.” |
| Uncompared relationship | “Encrypted. Identity not independently compared.” |
| In-person QR | “Compared from this QR in person.” |
| Transferred comparison | “Comparison record transferred from your controller.” |
| New endpoint | “This device becomes another recipient in the chats you select.” |
| History transfer | “Selected history will be stored on this device.” |
| Revocation | “This blocks future access as updates take effect. It does not erase stored copies.” |
| Offline send | “Queued on this device. Nothing was sent directly.” |
| Public chain | “This transfer is visible on a public blockchain.” |
| Existing wallet | “Connecting does not remove links in this wallet's earlier history.” |
| ETH provider | “This provider can see the address you ask about.” |
| Swap unavailable | “This setup cannot safely cover the required deadlines.” |
| Support | “Review exactly what you will share. Never send your recovery phrase.” |
| Local deletion | “Delete from this device” rather than “Erase everywhere” |
| Legal availability | “This financial feature is not offered in the selected region.” |

Translations require security-copy review for changes to authority, timing, certainty, or scope. A shorter translated label cannot replace “Received by an authorized endpoint” with “Everyone read.”

## Coverage and completeness boundary

The screen catalog enumerates the product-owned states and controls within the declared first-thirty-day scope. OS/store dialogs, external applications, hardware-wallet firmware screens, future protocol-specific swap branches, and unimplemented jurisdiction-specific notices require platform/adapter annexes before those capabilities ship.

That boundary is deliberate: inventing exact third-party screens would be less complete than identifying the dependency. A new screen/control in implementation must be added to the catalog and traceability matrix before release, including its negative states and disclosure delta.
