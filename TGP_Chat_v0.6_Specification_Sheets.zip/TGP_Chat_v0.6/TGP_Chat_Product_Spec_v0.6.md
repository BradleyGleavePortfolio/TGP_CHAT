# TGP Chat Product Specification v0.6

Comprehensive product, engineering, security, interaction, financial-tool, verification, and lawful-launch specification. Prepared 5 November 2026 for product owner Bradley; this is a proposed design baseline, not an implemented product, independent audit, or legal opinion.

## How to read this specification

The document contains 104 feature records, 145 product-owned screen records with fourteen fields each, 27 eight-dimension security review groups, and 58 shared adversarial test scenarios plus 20 financial scenarios. It includes a traceability crosswalk for 155 inherited identifiers across 29 v0.5 requirement families.

Read in the requested order: goal and plain-English features; technical architecture and financial implementation; security comparison; download-to-day-thirty UX and screens; implementation/verification/traceability; finally country restrictions and lawful-launch requirements. The last section is deliberately legal, with no appendix after it.

The binding rule is no regression in any privacy/security dimension. Faster flows and optional tools do not waive it; public-chain contact payments, large shared mailboxes, persistent external blobs, calls, swaps, and some recovery schemes remain blocked or experimental wherever their equivalence has not been established.

## Contents

- [Goal State and Complete Feature Catalog](#goal-state-and-complete-feature-catalog)
- [Rust and TypeScript Technical Specification](#rust-and-typescript-technical-specification)
- [Wallets, Payments, and Financial Tools](#wallets-payments-and-financial-tools)
- [Eight-Dimension Security Review and Disclosure Ledger](#eight-dimension-security-review-and-disclosure-ledger)
- [First Thirty Days and UI System](#first-thirty-days-and-ui-system)
- [Tap-Level Screen Catalog](#tap-level-screen-catalog)
- [Implementation, Verification, and Release Contract](#implementation-verification-and-release-contract)
- [Feature and Baseline Traceability](#feature-and-baseline-traceability)
- [Legal, Country Restrictions, and Lawful Launch](#legal-country-restrictions-and-lawful-launch)

---

## Goal State and Complete Feature Catalog

This volume defines the product contract, binding security constraints, and cumulative feature inventory for TGP Chat v0.6. It is a normative design proposal, not a claim that an implementation exists, has passed tests, or has received an independent security audit.

| Field | Specification |
|---|---|
| Version | 0.6, detailed product and engineering baseline |
| Date | 5 November 2026 |
| Product owner | Bradley |
| Application stack | Rust application/security core and services; TypeScript presentation |
| Platforms | Android first; separately qualified iOS, macOS, Windows, Linux |
| Baseline | Supplied TGP Chat Product Specification v0.5, dated 3 November 2026 |
| Document status | Proposed specification; all implementation evidence initially absent |
| Normative vocabulary | MUST is mandatory; SHOULD needs a recorded exception; MAY is optional |
| Intended readers | Product, design, client, protocol, wallet, security, operations, release, legal, accessibility |
| Precedence | Privacy invariants, then explicit requirements, then selected policies, then candidates, then targets |
| Approval rule | A smaller supported release is preferable to a privacy regression |

### Goal state explanation

#### Product owner's goal, reproduced verbatim

> We want to produce an app that allows for near-instant connection to anyone, anywhere, without being identified or blocked ever. We want to allow crypto currency exchange direct via contacts without this connecting identities inherently (must be strong enough to avoid being irrefutable evidence, at least). We want this app to be easy to use, free for chatting, and have world class UI. It will serve as the counterparty to the surveillance states and financial entrapment of the USA platforms!

#### Engineering interpretation and limits

The quotation is the owner's aspiration, not approved customer-facing security language. v0.6 MUST NOT turn “ever,” “anywhere,” or the proposed evidence threshold into guarantees that the architecture cannot establish.

| Goal phrase | Testable product interpretation | Boundary that remains |
|---|---|---|
| Near-instant connection | Immediate local feedback, background key generation/transport bootstrap, short connection ceremony | First network contact requires a working route and an available peer or queued delivery |
| Anyone, anywhere | No required phone, email, country-specific registration, or provider account | Distribution, network access, devices, censorship, and law can restrict availability |
| Without being identified | No mandatory real-world identity; scope-local public keys and presentation; no address-book upload | Contacts can recognize each other; endpoints, platforms, public ledgers, and traffic may identify activity |
| Without being blocked ever | Multiple maintained transport options, self-hosting, signed distribution, honest offline queues | Total shutdown and sufficiently capable blocking remain possible |
| Direct exchange via contacts | Locally authorized non-custodial payment tools, E2EE request transport, no TGP custody | Payment peers and relevant protocols necessarily learn some payment information |
| Without connecting identities inherently | No shared messaging/wallet identifier, no TGP-readable contact/payment database, minimal typed bridge | Existing blockchain history, endpoints, counterparties, amount/timing, exports, and RPC queries may associate activity |
| Not irrefutable evidence | Avoid unnecessary third-party-verifiable application signatures on payment chat messages | No messaging or payment product can guarantee how evidence will be interpreted |
| Free for chatting | No payment, token, wallet, subscription, or financial identity required for core chat | Resource quotas and measured capacity still apply |
| World-class UI | Short safe pathways, accessible controls, truthful state, progressive disclosure | Verification, granting access, spending, recovery, and destructive actions retain deliberate friction |
| Counterparty to surveillance | Minimize collection and control; publish source, protocols, limits, and evidence | Open source and decentralization are not immunity from compromise, traffic analysis, or legal process |

Signal's PQXDH specification describes qualified offline deniability rather than a universal evidence guarantee, and a published analysis identifies deniability differences from X3DH ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/), [PoPETs deniability analysis](https://petsymposium.org/popets/2024/popets-2024-0148.pdf)). MLS explicitly does not claim deniability and leaves application authentication and delivery choices to the deployment ([MLS architecture, RFC 9750](https://www.rfc-editor.org/rfc/rfc9750.html)).

#### Safe public product statement

Proposed wording: “Private conversations without phone-number registration. You control which people and devices receive your messages, and TGP infrastructure does not hold the keys to read them. Optional wallets remain separate from your chat identity. Public-chain payments, recipients, platforms, and compromised devices have limits we explain before you use them.”

This wording is still conditional on implementation evidence. The claims register in the verification volume determines which clauses a particular release may publish.

### Privacy constitution and no-regression rule

#### Ranked tenets retained

- **Data minimization:** Do not collect information that the service does not need.
- **Safe default:** Do not make users discover switches to obtain the baseline protections.
- **Device-held keys:** TGP infrastructure never receives content-decryption keys or wallet spending secrets.
- **No custody:** TGP does not custody, pool, mix, settle, or take a percentage of user payments.
- **Reviewed cryptography:** Do not invent primitives, combiners, key exchange, consensus, or recovery constructions.
- **Truthful boundaries:** Describe what is protected, what is visible, and what remains unproven.
- **Usable security:** Make routine safe actions simple and consequential authority changes explicit.

#### Binding invariants

| ID | Binding requirement | Concrete failure that blocks release |
|---|---|---|
| INV-01 | No mandatory registration identity or TGP account | First launch requires phone, email, social login, or wallet |
| INV-02 | No public people directory, contact upload, or provider-readable roster | Service can enumerate a person's contacts or organization |
| INV-03 | Adding a person, endpoint, or history recipient requires explicit approval | Pairing silently shares every chat |
| INV-04 | App-managed online traffic uses the approved protected transport or fails closed | A library opens direct DNS/HTTP/STUN after Tor failure |
| INV-05 | Independent endpoints never share live ratchets, MLS leaves, or database keys | Backup clones a running session onto a second active device |
| INV-06 | Device enrollment grants only selected scopes | New device receives future chats automatically |
| INV-07 | Local deletion, requested deletion, expiry, and future revocation stay distinct | “Erase everywhere” is displayed without such authority |
| INV-08 | Messaging enrollment never grants wallet spending authority | Linked desktop can sign with the phone's wallet |
| INV-09 | Encryption, comparison, membership, route, and device health remain separate states | One green shield implies all protections |
| INV-10 | Platform services and exports have explicit boundaries | Push or external opening silently discloses content |
| INV-11 | Core security is not paywalled or joined to billing identity | Paid entitlement becomes a reusable messaging identity |
| INV-12 | Important claims name configuration and evidence | “Audited” without build, scope, findings, and exclusions |
| INV-13 | No optional feature can waive an existing privacy invariant | A warning is used to justify a direct-network fallback |
| INV-14 | Financial and messaging keys, storage, identifiers, and authorization are separate | Chat root derives wallet seed or wallet logs include chat ID |
| INV-15 | A chain transformation does not certify identity unlinkability | Swap or CoinJoin changes a wallet label to “anonymous” |
| INV-16 | Untrusted content cannot grant authority | QR, message, attachment, or URI auto-signs, enrolls, exports, or broadcasts |
| INV-17 | No provider-controlled content recovery or security bypass | TGP password reset decrypts chats or funds |
| INV-18 | Unknown/unsupported security state stops the affected action | Client chooses weaker profile to preserve availability |
| INV-19 | Secret deletion and crash consistency are explicit security properties | Rollback reuses nonce or restores an erased send key |
| INV-20 | No production social graph is collected for analytics or support | Engagement dashboard needs per-profile contact relationships |

#### What “not even 1%” means operationally

Privacy is not reduced to a fabricated percentage. Each proposed change must be compared with the applicable v0.5 capability under the same threat model, platform, operating conditions, data retention, and adversary access.

For each dimension record the baseline, proposed behavior, observer, data field, destination, retention, joinability, evidence, and verdict. A new observer, newly accessible plaintext, new stable identifier, broader recipient set, longer retention, weaker recovery authority, extra uncontained parser, or failure-mode downgrade is a blocking regression until the design is changed or equivalence is established.

“Unmeasured” is not “equal.” An optional feature may be designed and documented without qualifying for production. User consent is necessary for deliberate disclosure but cannot prove that the no-regression rule has been met.

| Verdict | Meaning | Release action |
|---|---|---|
| Preserves by design, unverified | Intended boundary is unchanged | Implement and test; no public assurance yet |
| Candidate improvement, unverified | Design removes an exposure but composition remains untested | Require comparative evidence |
| Conditional | Named evidence or containment decision is missing | Disabled in release until condition closes |
| Blocked | Known new exposure conflicts with binding rule | Do not ship affected capability |
| Deferred | Product does not commit implementation | Keep inventory and reevaluation criteria |
| Validated for scope | Exact tested build/configuration has acceptable evidence | Only scoped claim may ship |

No feature in this specification is marked Validated. The security volume is an architecture-level pre-implementation review, not an independent audit.

#### Critical disposition of the eight upgrades

| Upgrade | v0.6 disposition |
|---|---|
| Faster onboarding | Retain all checks; parallelize safe local work; target shorter setup, not weaker verification |
| Messaging UX | Add local-first events with bounded schemas and unchanged recipients |
| Large communities | Client-fanout private groups first; shared-mailbox scaling blocked pending metadata equivalence |
| Multimedia | Local sanitization and bounded endpoint transfer first; external blob storage separately gated |
| Native Bitcoin | Isolated optional wallet management specified; contact spending blocked where public-ledger disclosure violates baseline |
| Decentralized infrastructure | Open federated relays, BYO endpoints, independent operation, signed non-authoritative directory |
| Financial interoperability | Typed adapters and export boundaries; no TGP-operated swap/mixing service; no unlinkability certification |
| Wallet usability/recovery | Hardware/watch-only connection, separate backups/drills; no shared seed or automatic social recovery |

The earlier phrase “Move funds privately” is not retained as a production promise. v0.6 uses “Review external privacy tools,” explains residual linkage, and never declares that prior wallet history has been removed.

### Product requirements in plain English

#### Classification and priority

Core means required for a useful chat release, not “all features ship at once.” Optional means removable without harming chat; Advanced means hidden from the routine UI; Experimental means not production-enabled without separate approval; Deferred means no current implementation commitment.

P0 is necessary for the affected capability to ship, P1 is a planned enhancement once its dependencies close, and P2 is optional exploration. A P0 wallet requirement does not force the wallet into the first messaging release.

#### Identity, onboarding, and contact features

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX screen family |
|---|---|---|---|---|
| F-001 Local profile | Start without a phone, email, provider account, or payment | Core P0 | T-01 | O |
| F-002 Display name | Choose an optional name stored locally; no global username search | Core P0 | T-01 | O, C |
| F-003 Per-contact presentation | Use a different name/avatar for each relationship | Core P1 | T-01 | C |
| F-004 Fast setup | Prepare keys and protected connection while entering basic information | Core P0 | T-01, T-04 | O, N |
| F-005 Build verification | Inspect release version, signed digest, and independent build status | Advanced P0 | T-15 | H |
| F-006 QR connection | Scan an in-person one-use invitation and bind the session to its keys | Core P0 | T-02 | C |
| F-007 Separate-secret invite | Connect remotely using a link and separately conveyed secret | Core P0 | T-02 | C |
| F-008 Invite lifecycle | See expiry, cancel, rotate, and reject reused invitations | Core P0 | T-02 | C |
| F-009 Identity comparison | Compare canonical safety data and record how it was compared | Core P0 | T-02 | C |
| F-010 Key-change review | Pause affected sends when previously compared keys change | Core P0 | T-02 | R |
| F-011 Local contact labels | Rename or annotate contacts without transmitting private labels | Core P1 | T-01 | C |
| F-012 Contact cards | Share explicitly chosen signed fields only after export warning | Advanced P2 | T-02 | C |
| F-013 Reusable contact link | Optional revocable discovery capability, never a public account | Experimental P2 | T-02 | C |
| F-014 Block contact | Stop local receipt/fanout and revoke relevant delivery capabilities | Core P0 | T-03 | C |
| F-015 Contextual tutorial | Dismissible local hints and a three-task checklist, not a slideshow | Core P1 | T-16 | O, H |

#### Messaging features

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-016 Direct messages | E2EE private text with independent endpoint sessions | Core P0 | T-03 | M |
| F-017 Truthful delivery | Distinguish queued, relay accepted, endpoint received, partial, failed, expired | Core P0 | T-03 | M |
| F-018 Offline queue | Read eligible local history and queue text without pretending it arrived | Core P0 | T-03 | M, N |
| F-019 Drafts | Retain an encrypted local draft; no draft synchronization by default | Core P1 | T-03 | M |
| F-020 Reply | Reply to a scoped event without leaking a locked/deleted quote | Core P1 | T-03 | M |
| F-021 Reactions | Add/remove idempotent E2EE reactions | Core P1 | T-03 | M |
| F-022 Edits | Show edited messages; bound edit authority and conflict behavior | Core P1 | T-03 | M |
| F-023 Pins/archive/mute | Organize conversations locally without server labels | Core P1 | T-03 | M |
| F-024 Search | Search unlocked local content and local contact labels only | Core P0 | T-03, T-05 | M |
| F-025 Disappearing messages | Optional authenticated prospective expiry; no remote-erasure promise | Core P0 | T-03 | S |
| F-026 Delete controls | Separate delete here and requests to others | Core P0 | T-03 | M, S |
| F-027 Receipts/typing | Read receipts, typing, last-online off; proposed activation separately reviewed | Advanced P2 | T-03 | S |
| F-028 URL safety | No automatic remote previews; explicit external-opening boundary | Core P0 | T-06 | M |
| F-029 Compatibility | Reject unsupported security profiles without silent downgrade | Core P0 | T-03 | R |
| F-030 Scoped security events | Changes to recipients and authority are not ordinary settings | Core P0 | T-03 | R |

#### Media, groups, and communities

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-031 Image sharing | Normalize and strip supported metadata from a send copy | Collaboration P1 | T-06 | A |
| F-032 Documents | Warn when metadata cannot be safely removed; explicit original export | Collaboration P1 | T-06 | A |
| F-033 Voice notes | User-initiated recording, local codec, protected transfer | Collaboration P1 | T-06 | A |
| F-034 Video files | Bounded local re-encode and preview; no remote transcoding | Collaboration P1 | T-06 | A |
| F-035 View-once | Compliant-client view restriction with copying limitation | Collaboration P2 | T-06 | A |
| F-036 Attachment storage | Optional ciphertext blobs with separate retention and metadata review | Experimental P2 | T-06 | A |
| F-037 Private groups | Invite contacts, accept, approve endpoints, and admit cryptographically | Collaboration P0 | T-07 | G |
| F-038 Group roles | Explicit administrator/member/coordinator powers, no master reader | Collaboration P0 | T-07 | G |
| F-039 Group privacy | Encrypted roster/policy and recipient-specific delivery wrapping | Collaboration P0 | T-07 | G |
| F-040 Group removal | Remove people or devices with visible rekey progress | Collaboration P0 | T-07 | G, R |
| F-041 Group conflicts | Pause on contradictory authenticated state; no timestamp election | Collaboration P0 | T-07 | R |
| F-042 Large groups | Raise tested fanout capacity without new server-visible group identifiers | Experimental P2 | T-07 | G |
| F-043 Communities | Invite-only collection of separately protected groups | Experimental P2 | T-07 | G |
| F-044 Group history | No pre-join history by default; explicit authorized transfer | Collaboration P0 | T-07, T-08 | G, D |
| F-045 Voice calls | Tor-only feasibility-gated one-to-one voice | Experimental P1 | T-09 | L |
| F-046 Group voice/video | Four-person voice, then one-to-one video after separate gates | Experimental P2 | T-09 | L |
| F-047 Call admission | Only actual admitted call endpoints receive media secrets | Experimental P0 | T-09 | L |
| F-048 Call handoff | Explicit target admission and old capture retirement | Experimental P2 | T-09 | L |
| F-049 Recording/transcription | No TGP cloud transcript or default recording | Core restriction P0 | T-06, T-09 | A, L |

#### Devices, transport, and local security

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-050 Scoped device linking | Link only selected chats, with fresh independent endpoint keys | Collaboration P0 | T-08 | D |
| F-051 History range | Separately choose none, 24 hours, seven days, or custom eligible history | Collaboration P0 | T-08 | D |
| F-052 Device inventory | Show grants and locally observed last-seen information | Collaboration P0 | T-08 | D |
| F-053 Revoke device | Stop new fanout locally and propagate scoped removal/rekey | Collaboration P0 | T-08 | R |
| F-054 Controller migration | Transfer scoped authority without cloning sessions | Advanced P0 | T-08 | R |
| F-055 Controller loss | Explain what survives and how to re-establish trust | Core P0 | T-08, T-12 | R |
| F-056 Automatic protected route | Connect via maintained Tor/pluggable transports | Core P0 | T-04 | N |
| F-057 Fail-closed broker | Libraries cannot bypass routing when connection fails | Core P0 | T-04 | N |
| F-058 BYO infrastructure | Independently configure relays, chain nodes, and bridges | Advanced P1 | T-04, T-10 | N, W |
| F-059 Federated relays | Open implementation, signed directory, operation independent of TGP | Core P0 | T-04 | N |
| F-060 Privacy report | Local scoped checks, not an anonymity score | Advanced P1 | T-14 | H |
| F-061 Cover traffic | Measured experimental padding/timing profile, no global-observer guarantee | Experimental P2 | T-04 | N |
| F-062 Snowflake contribution | Separate optional volunteer proxy with battery/network warning | Experimental P2 | T-04 | N |
| F-063 Device-wide VPN | Separate Android permission and exact tested traffic scope | Experimental P2 | T-04 | N |
| F-064 Local radio/mesh | Explicit proximity mode, never automatic online fallback | Experimental P2 | T-13 | N |
| F-065 App lock | Entry lock with device protection and configurable inactivity | Core P0 | T-05 | S |
| F-066 Per-chat vault | Independent keys/passphrase and locked-search exclusion | Core P0 | T-05 | S |
| F-067 Panic lock | Immediate local lock/capture stop with no remote trigger | Core P0 | T-05 | S |
| F-068 Decoy/disguise | Best-effort local presentation, never forensic-deniability claim | Experimental P2 | T-05 | S |
| F-069 Destructive wipe | Separate high-friction local configuration, not ordinary panic | Experimental P2 | T-05 | S |
| F-070 Dead-man behavior | Auto-lock only by default; auto-wipe deferred/experimental | Advanced P2 | T-05 | S |
| F-071 Clipboard/screenshot | Reduce supported capture paths; no absolute prevention promise | Core P0 | T-05 | S, W |
| F-072 Platform notifications | Minimal content; iOS platform path only after explicit choice | Optional P0 | T-11 | H |
| F-073 Desktop | Installed multipane companion with strict rendering/native boundary | Collaboration P0 | T-11 | D, H |

#### Wallets, payments, recovery, and operations

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-074 Wallet activation | No wallet tab or seed ceremony during chat onboarding | Optional P0 | T-10 | W |
| F-075 Native XMR | Local scan, separate keys, subaddresses, own/remote node over protected route | Optional P0 | T-10 | W |
| F-076 Native BTC | Descriptor wallet, local filter matching, PSBT/hardware workflows | Optional P0 | T-10 | W |
| F-077 Native ETH | Account isolation, own node preference, verified responses where supported | Optional P0 | T-10 | W |
| F-078 Connect existing funds | Watch-only or hardware first, no seed requested merely to connect | Optional P0 | T-10 | W |
| F-079 Imported-wallet quarantine | Preserve provenance and block contact payment where identity link remains | Optional P0 | T-10 | W |
| F-080 Source labels | Local conservative labels prevent accidental merging, not an anonymity score | Advanced P0 | T-10 | W |
| F-081 Contact requests | Typed E2EE one-to-one requests; no signing from chat payload | Optional P0 | T-10 | P |
| F-082 Review/sign/send | Exact network, recipient, amount, fees, source, and separate authorization | Optional P0 | T-10 | P |
| F-083 Delay/schedule | Explicit not-broadcast hold, cancellation limits, fresh review rules | Advanced P1 | T-10 | P |
| F-084 Spend guardrails | Local limits/large-send delay without coercion-resistance claim | Advanced P1 | T-10 | P |
| F-085 Transaction history | Chain-specific status; reveal TXIDs/proofs only deliberately | Optional P0 | T-10 | P |
| F-086 Fiat estimates | Off by default; manual or protected identifier-free cached rate | Advanced P2 | T-10 | W |
| F-087 Payjoin | Protocol-reviewed negotiation; never silently fall back to a plain payment | Experimental P1 | T-10 | P |
| F-088 Silent/stealth receive | Experimental scanning/gas/recovery review, no unlinkability promise | Experimental P2 | T-10 | W |
| F-089 Contact swaps | One-to-one negotiation, reviewed engine, proven deadline coverage | Experimental P2 | T-10 | X |
| F-090 External financial tools | Manifest and explicit export/import, no custody or TGP coordinator | Advanced P2 | T-10 | X |
| F-091 CoinJoin/mixer tools | No built-in automated route; user-chosen external boundary and legal review | Deferred P2 | T-10 | X |
| F-092 Wallet backup/drill | Chain-specific separate recovery and no-spend restore drill | Optional P0 | T-12 | B |
| F-093 Chat backup/restore | Selected encrypted archive, no seeds or live protocol state | Core P0 | T-12 | B |
| F-094 Continuity archive | Separately protected, high-consequence authority recovery | Experimental P2 | T-12 | R, B |
| F-095 Multisig/social recovery | Bitcoin descriptor study; no generic split-seed/contact recovery launch | Deferred P2 | T-12 | B |
| F-096 Cold/offline transfer | Typed bounded QR/file unsigned/signed transaction transfer | Advanced P1 | T-13 | W, P |
| F-097 Local diagnostics | Redacted bounded local evidence with preview before export | Advanced P0 | T-14 | H |
| F-098 Abuse controls | Capability quotas, local block, explicit selected-content report | Core P0 | T-04, T-14 | C, H |
| F-099 Distribution/updates | Signed manifests, provenance, reproducibility, rollback defenses | Core P0 | T-15 | H |
| F-100 Funding/support | No ads, graph monetization, chat fee, payment skim, or secret recovery | Core policy P0 | T-14 | H |
| F-101 Accessibility | Large text, screen readers, keyboard, reduced motion, accessible ceremonies | Core P0 | T-16 | All |
| F-102 Privacy-preserving research | Lab/cohort measurement without production behavior tracking | Core policy P0 | T-16 | H |
| F-103 Account deletion equivalent | Delete local profile/keys, explain retained external copies and wallets | Core P0 | T-05 | S |
| F-104 Security incident response | Capability-specific containment, signed fixes, scoped public claims | Core P0 | T-15 | H |

#### Explicit non-goals and rejected shortcuts

- **Public social layer:** No public feed, public handle search, global organization listing, address-book matching, or public community discovery.
- **Provider recovery:** No master decryption key, admin escrow, support seed handling, account password reset, or cloud-readable archive.
- **Network shortcuts:** No direct-media fallback, hidden DNS, automatic external thumbnails, direct RPC fallback, or background third-party analytics.
- **Financial service:** No fiat on-ramp, brokerage, TGP liquidity maker, hosted swap coordinator, pooled treasury, percentage fee, or hosted mixing infrastructure.
- **Universal privacy badge:** No “untraceable,” “unblockable,” “anonymous wallet,” “zero clustering,” “not evidence,” or percentage security score.
- **Scope expansion by convenience:** No all-chat pairing, silent history sharing, automatic administrator promotion, or wallet replication through message sync.
- **Unreviewed recovery:** No custom Shamir splitting, automatic contact-held seed shares, or treating a copied archive as proof that the original controller is gone.
- **Unqualified media:** No automatic cloud transcription, default call recording, bot ecosystem, external AI reading messages, or initial screen sharing.

### Users, outcomes, and product acceptance

#### Working user stories

- **New private-chat user:** As a person connecting to one intended contact, I want a short setup without registration so I can begin without creating a provider account.
- **Small-team member:** As an invited participant, I want to understand who and which devices can read future messages so I can make an informed admission choice.
- **Controller owner:** As someone adding a laptop, I want to select exactly which chats and history it receives so unrelated relationships remain outside its access.
- **Existing-wallet owner:** As someone who already holds BTC or ETH, I want to inspect/manage funds without exporting seeds or disclosing chat identity to a provider.
- **Payment recipient:** As someone receiving a request, I want to distinguish a request from a transaction and a peer claim from locally observed settlement.
- **Lost-device user:** As someone who lost a phone, I want an honest recovery path that does not imply unavailable remote erasure or recovery powers.
- **Accessibility user:** As someone using a screen reader or large text, I want the same comparison, grant, and spending decisions without bypassing security.
- **Hostile-network user:** As someone with intermittent or blocked internet, I want clear queued states and safe route recovery without silent weaker connections.

#### Success targets, not reported results

| Outcome | Proposed target | Measurement and guardrail |
|---|---|---|
| Setup to first queued message | Median below 45 seconds in defined guided lab condition | Report invite, route, typing, and verification separately |
| Local interaction feedback | 95th percentile under 100 ms on declared reference devices | Never synthesize delivery or admission success |
| Warm chat opening | 95th percentile under 300 ms for unlocked local history | Locked-chat keys must not be kept solely to improve speed |
| Safe task completion | At least 90% unassisted completion in a consented formative cohort | Cohort size/protocol set before evaluation; no production tracking |
| Critical comprehension | No observed severe misunderstanding of recipient/spend authority in release study | Any severe error triggers redesign/retest, not averaging away |
| Egress policy | Zero prohibited direct flows in the adversarial matrix | One unexplained packet blocks the affected build |
| Crypto/authority failures | Zero known unresolved critical/high exploitable findings | Evidence must identify assessor, build, scope, and remediation |
| Wallet removal | All core chat tests pass in a wallet-free build | No financial dependency in onboarding or chat transport |
| Capacity | Supported limits come from measured worst-case workloads | Published limits may be lower than design targets |

The 45-second target is a new design ambition, not a measured improvement over v0.5. No comparative performance percentage is asserted.

#### Definition of a complete v0.6 specification

Every catalog feature must map to a technical owner, a concrete state/authority model, a disclosure comparison, screen pathways, and release evidence. Experimental and deferred features are complete as decisions only when the blocking question, safe disabled UI behavior, and reevaluation criteria are explicit.

Implementation tickets may subdivide requirements but may not silently remove them. Any conflict between a convenient product action and an invariant blocks the affected action and requires an ADR, not a discretionary UI warning.

---

## Rust and TypeScript Technical Specification

This volume describes how every non-financial feature in the catalog is intended to operate, including trust boundaries, state machines, persistence, failure handling, and implementation acceptance. The financial subsystem receives its own volume because mixing wallet authority into a general chat architecture would obscure the highest-consequence boundaries.

### Architecture overview

#### Logical component graph

```text
TypeScript UI
  | typed, capability-scoped commands and read models
  v
Rust application facade
  +-- profile/contact/verification state
  +-- direct-session engine --> independent endpoint sessions
  +-- group engine ---------> separate MLS leaf per endpoint
  +-- admission/authority --> explicit reviewed scope transitions
  +-- vault/storage -------> protected local records and local search
  +-- archive/sync --------> selected content, never live-state cloning
  +-- media worker --------> bounded sanitization/decoding/capture
  +-- network broker ------> Tor --> ingress relay --> destination relay
  +-- platform adapters ---> OS key protection / notifications / files
  +-- payment bridge ------> isolated Rust wallet runtime

Rust services, separately deployable:
  relay | rendezvous | signed directory | optional blob experiment
  optional platform wake adapter, independent of message content

No TGP account database. No global profile key visible to every peer.
No server-side contact directory. No server-side wallet API.
```

The graph defines responsibilities, not proven process isolation. Desktop, Android, and iOS need separate realizations; a box in a diagram is not a security boundary until access, IPC, memory, sockets, files, and failure behavior are tested.

#### Proposed source layout

| Area | Rust crate or TypeScript package | Responsibility and restrictions |
|---|---|---|
| Domain types | `tgp-types` | Versioned event IDs, bounded values, typed identifiers; no sockets or key storage |
| Application facade | `tgp-app` | Command authorization, cancellation, idempotency, UI read models |
| Identity | `tgp-identity` | Scope-local identity objects, continuity, verified key records |
| Direct crypto | `tgp-direct` | Narrow maintained protocol adapter; no UI-defined crypto choices |
| Invitations | `tgp-invite` | Ceremony orchestration, one-use lifecycle, reviewed PAKE adapter |
| Groups | `tgp-groups` | MLS adapter, policy, membership/ordering/fork handling |
| Authority | `tgp-authority` | Grants, migrations, revocations, distinct role checks |
| Storage | `tgp-store` | Encrypted records, transactions, migration, outbox, tombstones |
| Vault | `tgp-vault` | Unlock leases, key wrapping, per-scope key availability |
| Sync/archive | `tgp-sync`, `tgp-archive` | Selected data transport, eligible-history containers, no live state |
| Network | `tgp-net` | Only approved socket ownership, destination policy, transport lifecycle |
| Delivery | `tgp-delivery` | Envelopes, queue capabilities, receipt and retry state |
| Media | `tgp-media` | Bounded worker, safe formats, metadata removal, encrypted staging |
| Calls | `tgp-call` | Experimental admission/capture/key-state controller |
| Notifications | `tgp-notify` | Minimal wake adapters with no message database access |
| Wallet facade | `tgp-wallet` | Separate runtime facade; excluded from chat-only build |
| Bridge | `tgp-pay-bridge` | Narrow request intents and result handles; no raw seed API |
| Diagnostics | `tgp-diagnostics` | Local checks, bounded redaction, user-reviewed export |
| Updates | `tgp-release` | Signed metadata, compatibility, rollback decisions |
| Relay | `tgp-relayd` | Opaque capability queues, quotas, TTL, no content keys |
| Rendezvous | `tgp-rendezvousd` | Expiring invitation mailbox, no person directory |
| Directory | `tgp-directory` | Signed infrastructure manifests and operator declarations |
| Blob experiment | `tgp-blobd` | Default-disabled ciphertext-only attachment experiment |
| Mobile shell | `apps/mobile` | React Native TypeScript; native UI/key/permission adapters |
| Desktop shell | `apps/desktop` | Tauri 2 TypeScript UI; explicit command permissions |
| Shared UI | `packages/tokens`, `packages/components` | Visual tokens, accessible components, no transport |
| View models | `packages/view-models` | Derived presentation only, not security authority |
| Bridge types | `packages/core-api` | Generated bounded command/result types |
| Copy | `packages/copy` | Localized exact language, separate from protocol reason codes |
| Test vectors | `fixtures/protocol`, `fixtures/ux` | Synthetic contacts/funds only; never production secrets |

#### Process realization

| Platform | Proposed realization | Required limitation |
|---|---|---|
| Desktop | Sandboxed webview, Rust app process, separately sandboxed wallet/media workers, network broker | Tauri is not automatically a wallet process sandbox; OS-specific policies required |
| Android | RN UI/native facade; isolated media worker; separately permissioned wallet service where feasible; controlled network service | Shared UID/files/process permissions must be measured, not assumed isolated because different services |
| iOS | RN UI and Rust libraries in app sandbox; restricted extensions; wallet keys separately protected; separate install if strict process boundary cannot be met | Arbitrary persistent child processes cannot be assumed; in-process modules are not equivalent to independent OS sandboxes |
| Servers | Separate deployments, credentials, service roles, no shared relationship logs | Separate hostnames under one operator do not prove operator independence |

If the financial isolation requirement cannot be established on a platform, its integrated wallet stays disabled and the separately installed-wallet/export option is evaluated. This is an explicit platform gate, not permission to weaken INV-14.

React Native UniFFI bindings can generate TypeScript and JSI/C++ integration from Rust annotations, but the project is an integration dependency rather than a proof of secret isolation ([UniFFI React Native bindings](https://github.com/jhugman/uniffi-bindgen-react-native)). Tauri capabilities need explicit review of custom commands and merged window permissions; its documentation notes that registered commands can otherwise be available broadly ([Tauri capabilities](https://v2.tauri.app/security/capabilities/)).

### Cryptographic specification and qualification

#### Profile register

| Surface | Preferred candidate | Mandatory condition | Prohibited shortcut |
|---|---|---|---|
| Direct handshake | libsignal-supported PQXDH profile | Pin exact implementation/profile; review scoped identity and prekey publication | Describe a generic KEM plus X25519 as “Signal” |
| Direct message evolution | Maintained libsignal Double Ratchet plus supported SPQR/Triple Ratchet | Require selected profile; no first-message compatibility downgrade in TGP production profile | Claim initial PQ handshake provides continuing PQ recovery |
| Group messaging | OpenMLS using approved hybrid PQ suite | Actual suite, codepoint, implementation, dependency fixes, interoperability, composition review | Production classical-only fallback to meet schedule |
| Low-entropy invitation | Reviewed PAKE implementation; CPace is a candidate | Full invitation composition review, one-use failure policy, transcript binding, PQ requirement analysis | Handwritten CPace-plus-KEM combiner |
| High-entropy invitation | Reviewed authenticated encrypted channel anchored in one-use QR secret | Mutual binding of scope keys, fresh endpoint keys, expiry, and capabilities | Treat a public link as a secret |
| Pairing | Reviewed compared-transcript secure channel | Fresh keys on new device; confirm both devices | Copy live session database |
| Local database | SQLCipher-class reviewed implementation | Exact configuration, database/WAL/temp behavior, per-chat separation | Assume one encrypted DB protects chats from other unlocked chats |
| Passphrase derivation | Argon2id | Benchmark and pin minimum parameters per supported device class | Fast hash or silent low-memory downgrade |
| Attachment/archive encryption | Maintained streaming/container construction | Unique key/nonces, chunk authentication, manifest binding, truncation/order checks | Assemble a novel AEAD stream by concatenation |
| Directory/releases | Maintained signature scheme/profile with threshold/offline release governance as reviewed | Signed version/expiry, rollback checks, rotation, transparent evidence | One online signing key as sole update authority |
| Call frames | Reviewed SFrame-compatible candidate plus independent call admission | Full sender authenticity, replay, counters, rekey, transport profile | “Uses SFrame” as complete call security |
| Wallet signing | Chain/hardware-supported protocols | Exact device/firmware/application matrix | Reuse messaging identity as payment signing key |

Signal describes SPQR as an ongoing post-quantum ratchet combined with the Double Ratchet to form the Triple Ratchet; its rollout logic includes a compatibility phase that is not automatically suitable for TGP's strict profile ([Signal SPQR](https://signal.org/blog/spqr/)). PQXDH's documented authentication and deniability limits must remain in TGP's claims rather than being replaced by “fully post-quantum anonymous messaging” ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/)).

OpenMLS's historical X-Wing experiment uses a draft suite without a standard IANA assignment, and the current IETF PQ suite work is still described as an Internet-Draft in the fetched material ([OpenMLS PQ experiment](https://blog.openmls.tech/posts/2024-04-11-pq-openmls/), [MLS PQ ciphersuites draft](https://datatracker.ietf.org/doc/html/draft-ietf-mls-pq-ciphersuites-06)). Therefore the production group profile remains a blocking ADR, not a solved checklist item.

#### Dependency governance

libsignal is AGPLv3, describes use outside Signal as unsupported, and exposes APIs that may change; adopting it requires a maintained compatibility strategy and license/distribution review ([libsignal repository](https://github.com/signalapp/libsignal)). SQLCipher Community Edition has attribution and license-notice requirements that must appear in the application and release materials ([SQLCipher licensing](https://www.zetetic.net/sqlcipher/license/)).

An upstream audit does not validate TGP composition. OpenMLS reports an independent SRLabs assessment with remediations in identified releases and a remaining low-severity item, while a libcrux dependency advisory identifies an AArch64 constant-time select/swap issue and patched versions ([OpenMLS audit report announcement](https://blog.phnx.im/openmls-independent-security-audit/), [RustSec advisory RUSTSEC-2026-0212](https://rustsec.org/advisories/RUSTSEC-2026-0212.html)).

The build gate MUST consume current advisories, exact lockfiles, compiler flags, architecture-specific tests, and license inventory. No dependency version in this proposal is a timeless safe-version declaration.

#### Key hierarchy and secret lifecycle

```text
OS random source
  +--> device wrapping/gating key (non-synchronizing where supported)
  +--> local app settings/store key
  +--> per-conversation vault keys
  +--> independent relationship identity and endpoint state
  +--> independent group credentials and MLS leaf state
  +--> independent pairing ephemeral state
  +--> independent archive encryption material
  +--> wallet runtime randomness --> separate per-wallet recovery/signing roots

No arrow from messaging root to wallet root.
No universal externally visible device certificate across relationships.
No reuse of a running ratchet or MLS sending leaf across installations.
```

Scope-local credentials may be managed under local organizational authority, but the exported credentials MUST NOT expose a universal root/certificate. This requires protocol review; it is not achieved by displaying different avatars.

Key access is expressed as bounded unlock leases. Background queues may accept/store ciphertext under a low-privilege spool key if reviewed, but locked content keys and wallet spending keys stay unavailable. UI state, biometric success, and a cached route status are not interchangeable with authority to use a key.

Secret erasure is best-effort memory hygiene plus explicit storage lifecycle; the OS, allocator, flash, snapshots, and recipient copies constrain absolute claims. Crash tests must establish that send-state persistence never moves backward into nonce/key reuse.

### Common application contracts

#### Typed command boundary

The frontend sends intent, never raw protocol state. Rust checks current authority, vault state, version, bounds, capability, and expected revision before causing an effect.

```typescript
type CommandEnvelope<T> = {
  apiVersion: 1;
  commandId: string;           // locally unique, not a provider account ID
  expectedRevision?: string;   // optimistic concurrency, not wall-clock authority
  intent: T;
};

type SendTextIntent = {
  kind: "send_text";
  localConversationHandle: string;
  draftHandle: string;         // core-owned text, with bounded input API
  replyToLocalEvent?: string;
};

type LinkScopeIntent = {
  kind: "approve_device_scopes";
  pairingHandle: string;
  selectedScopes: string[];
  historyPlanHandle: string;   // reviewed separately, defaults to none
};
```

These are application schemas, not a custom cryptographic wire protocol. Generated types help prevent accidental misuse but Rust authorization remains mandatory for hostile or compromised frontend inputs.

Commands return `accepted`, `requires_review`, `blocked`, `conflict`, or `failed`, plus machine reason code and safe localized-copy key. Long tasks emit a capability-scoped progress stream that is cancelled/purged on lock; a late callback cannot resurrect an obsolete screen or grant.

#### Encrypted event classes

| Class | Examples | Authorization |
|---|---|---|
| Content | Text, attachment descriptor, voice note | Admitted sender in current permitted state |
| Content mutation | Edit, reaction, deletion request | Author/policy check, target in same scope |
| Relationship | Endpoint proposal, admission, key change | Relationship continuity policy |
| Group control | Proposal, commit, role/policy change | MLS validity plus application authority and consent |
| Own-device sync | Allowed local preference or selected archive manifest | Explicit grant; cannot expand authority |
| Financial request | One-to-one bounded payment intent | Display only until local wallet review |
| Call control | Invite, accept, endpoint change | Call-specific admission, not chat membership alone |

Every event binds protocol version, scope, sender endpoint, event type, replay identity, parent/context where applicable, bounded payload length, and expiry semantics. Unknown authority-bearing versions stop the affected operation; unknown non-authority content may show “Unsupported message” without granting anything.

#### Common limits

These are proposed initial hard limits to be reduced if tests require, not measured capacity. Security-sensitive limits are authenticated or locally enforced and cannot be changed by a remote feature flag.

| Object | Initial proposal | Failure behavior |
|---|---|---|
| Text event | 16 KiB UTF-8 content before envelope overhead | Composer explains limit; no truncation that changes meaning silently |
| Normal control object | 64 KiB decoded application object, except approved crypto profile payloads | Reject before unbounded allocation |
| Local decrypted text page | 100 events / bounded bytes | Pagination, cancellable search |
| Image send copy | 12 MP and 10 MiB after conversion | Resize locally or cancel |
| General attachment | 25 MiB endpoint-transfer pilot | Show unavailable above limit |
| Voice note | 5 minutes / 10 MiB | Stop with visible limit; no background recording |
| Video file | 30 seconds / 20 MiB pilot | Local compression or cancel |
| QR/file import | Typed per-format limit; no unbounded decompression | Reject hostile nesting, duplicate chunks, oversize |
| Relay ciphertext | Approved padded-cell profile and per-capability quota | Explicit rejection/backpressure |
| Archive | Streaming parser, bounded per-record and total declared size | Validate capacity before commit |
| Future/stale protocol buffering | Exact library/profile limits set in release manifest | Stop affected scope and request reviewed recovery |

The raw maxima do not override library protocol constraints. Benchmarks and review must establish viable values before production.

### Technical feature sheets

#### T-01: Local identity, setup, and profile

**Covers:** F-001 through F-004, F-011, F-015. The local profile is an organizer of independent relationships, not a provider account.

- **Creation:** First launch checks OS entropy, creates protected local storage and independent profile settings, then begins the approved Tor bootstrap. Cryptographic identity generation may run in parallel with name entry only when all required hardware/protection prerequisites are satisfied.
- **Name semantics:** “What should this contact call you?” is optional. No uniqueness check, availability request, public search, email lookup, or directory write occurs. Default name may be “You” locally until deliberately shared.
- **Presentation:** Per-contact name/avatar disclosure is inside that relationship's E2EE channel. Reusing a photo/name across contexts is warned as a human linkage choice, not forbidden.
- **Permissions:** No contacts, precise location, microphone, camera, notification, or full-photo-library permission at launch. Request a narrow permission only at its first useful action.
- **Tutorial:** Local checklist state is ordinary protected local preference data. Dismiss/reset works offline, does not contact analytics, and cannot mutate security policy.
- **Failure:** Entropy/key-store failure prevents creation with actionable copy. A route failure does not prevent local profile editing or cause registration fallback. Interrupted setup resumes from an authenticated local checkpoint, never regenerating identity silently.
- **Acceptance:** Given two fresh unrelated relationships, when packets and exported credentials are compared, then no mandatory global profile credential links them. Given an empty name, then Connect still works and no remote availability lookup occurs.

#### T-02: Invitations, comparison, contact lifecycle

**Covers:** F-005 through F-014. A connection ceremony must bind the intended peer, scoped keys, fresh endpoint keys, routing capabilities, protocol profile, nonce, and expiry.

| Invite state | Allowed action | Terminal rule |
|---|---|---|
| Draft | Edit local label, choose QR or remote ceremony | No remote authority |
| Published | Present one-use material; wait; cancel | Ten-minute proposed lifetime |
| Claimed | Bind candidate peer transcript; stop parallel claims | No content grant yet |
| Comparing | Show canonical comparison/provenance | Mismatch cancels and destroys attempt |
| Established | Persist new relationship/session atomically | Invite cannot be reused |
| Burned / expired / cancelled | Create a fresh invite only | Old material cannot reactivate |

The one-wrong-guess policy limits successful malicious contact but also permits invitation denial of service. Malicious rendezvous infrastructure cannot be trusted to enforce attempts: the inviter must persist its own accepted/burned state and reject concurrent transcripts. Offline guessing resistance and online races require a reviewed protocol, not only a server counter.

CPace is a candidate PAKE, not described here as an already-final deployed TGP standard; the fetched history places the draft in the RFC Editor process ([CPace publication history](https://datatracker.ietf.org/doc/draft-irtf-cfrg-cpace/history/)). Magic-Wormhole's one-time-code design is relevant prior art but not permission to copy incomplete protocol pieces ([Magic-Wormhole protocol security](https://github.com/magic-wormhole/magic-wormhole-protocols/security)).

For an in-person QR, scan authenticates possession of the displayed secret and binds the displayed key, not a person's civil identity. “Compared from this QR in person” is available only after the scanner explicitly confirms physical provenance and the peer ceremony completes. Remote QR/link arrival remains “Encrypted; identity not independently compared.”

Safety representations use the selected protocol's canonical encoding. Do not invent a short visually pleasing fingerprint. A local comparison record stores key fingerprint, scope, method, date, and optional local note; transferred verification shows its origin.

Optional signed contact cards deliberately create portable signature evidence, so they remain advanced, carry explicit fields, exclude wallet/contact mapping, and cannot become the default payment identity credential. Reusable links are disabled until capability enumeration, spam, revocation, persistence, and cross-context linkage are reviewed.

Blocking a peer stops local sends and active receipt subscriptions, rotates/revokes applicable queue capabilities, purges pending unsolicited payloads under policy, and offers separate local-history deletion. It cannot erase the peer's archive or prevent the peer generating a new unrelated invitation.

#### T-03: Direct messaging, event mutation, queues, and search

**Covers:** F-016 through F-030. A direct relationship contains separately authorized endpoints, each with independent sessions; multi-device delivery must not turn into one cloned sender state.

| Send state | Evidence | Permitted UI |
|---|---|---|
| Draft | Local encrypted draft only | Unsent draft |
| Queued | Crash-consistent local outbox record and required state | Queued on this device |
| Relay accepted | Authenticated acknowledgment of queue acceptance | Accepted by relay |
| Endpoint received | Authenticated application receipt from identified endpoint | Received by an authorized endpoint |
| Partial | Some, not all, required endpoints acknowledged | Partially received |
| Failed | Rejection, incompatibility, expiry, resource failure | Failed with reason and safe retry |
| Expired | Policy expiry before successful receipt | Expired before receipt |

Prepare outbound message and persist ratchet advance/outbox transaction under reviewed crash-consistency semantics before network emission. Retry stable application event identity through approved protocol retransmission; do not re-encrypt using stale send keys after a crash. Exactly-once display is achieved by bounded deduplication, not a claim of exactly-once network transport.

Delivery receipts disclose availability and device participation even when they do not disclose reading. Existing v0.5 receipt semantics remain the baseline; additional per-person/group receipt details require a metadata delta review. Typing, last-online, and read receipts stay off and are not silently enabled by a new UI.

Replies refer to scoped event IDs. Render a quote only if the original is locally available and permitted; expired/deleted/locked source becomes “Original message unavailable.” Edits are authenticated author mutations with a bounded proposed 15-minute window, visible “Edited,” and deterministic per-author revision ordering; security/control events are never editable content. Conflicting authorized edits show a local conflict if they cannot be safely ordered.

Reactions are scoped add/remove operations with stable actor and event identity inside E2EE. Pin/archive/mute are local unless a separate group policy explicitly authorizes a visible group pin. Swipe shortcuts only perform reversible local actions; delete/export/spend require explicit controls.

Default history retention is Keep. Optional disappearing policy uses a validated bounded sender timestamp and authenticated policy revision; offline delay, clock uncertainty, copied archives, and modified recipients remain explicit. Timer changes are prospective. Locked-chat indexing uses per-chat protection and is removed from active memory/results on relock; no global plaintext FTS database.

External URLs are inert text until tapped. Render scheme/host, ask before opening another app, and never fetch tracking pixels or preview thumbnails automatically. Link parsing cannot invoke native commands, wallet sign, invitation acceptance, or shell execution.

**Acceptance:** Inject duplicate, stale, malformed, future-version, edit-by-other-author, cross-scope reply, expired target, and lock-during-search events. Each must produce a bounded truthful result without unauthorized action or plaintext residue in global search.

#### T-04: Tor, relays, decentralization, and resilience

**Covers:** F-056 through F-064, F-098. A reviewed network broker owns app-managed online networking, including node, update, rate, diagnostic, attachment, and media requests.

Arti is the preferred Rust integration candidate, but the target platform must demonstrate all required lifecycle and transport functions. The fetched Arti release notes include security fixes and recommend upgrading; they do not establish every mobile transport feature ([Arti release notes](https://blog.torproject.org/arti_2_7_0_released/)). Current Tor anti-censorship work includes multiple transports, but none proves universal unblockability ([Tor anti-censorship review](https://blog.torproject.org/staying-ahead-of-censors-2025/)).

| Boundary | Requirement |
|---|---|
| Socket ownership | Messaging/wallet libraries receive a broker interface, not arbitrary network clients |
| Name resolution | Approved path only; test IPv4, IPv6, DNS, redirects, proxy bypass, localhost exceptions |
| Bootstrap exception | Tor/bridge/PT setup is documented transport traffic, not application direct fallback |
| Context separation | Distinct broker identities for unrelated chats, wallet accounts, updates, diagnostics |
| No hidden client | Disable dependency telemetry, HTTP fallbacks, remote fonts, crash clients, STUN and vendor checks |
| Route failure | Pause network effect; local queues remain protected; no weaker retry path |
| Endpoint change | Parse and show type/operator/address before saving; no auto-import from arbitrary QR |

Proposed message path: sender through Tor to ingress relay A; A forwards an opaque nested envelope to destination relay B; recipient retrieves from B through its own protected path. A may learn the chosen destination relay and traffic patterns; B sees mailbox activity, timing, and retrieval patterns. Relays must not receive civil identity, plaintext contact list, or universal sender credential. Collusion and timing remain review questions.

Queue creation uses random bearer capabilities with separated send/receive/admin authority and bounded quotas. Capability rotation must prevent old senders or revoked devices continuing delivery where protocol design allows; compromised capabilities still permit traffic observation or disruption within their scope.

Directory manifests contain relay onion address, supported protocol/security profile, operator declaration, expiry, capacity class, and signing metadata. Client verifies signatures/version/freshness; the directory is a discovery aid, not identity authority. BYO configuration remains available with equivalent protocol requirements. Different declared operators are a selection rule, not proof of independence.

Relays keep undelivered ciphertext in memory with seven days as an upper bound, not a durability promise. Restart may lose accepted packets; the sender retains protected retry sources. Disable swap/core dumps/snapshots/backups where possible and test actual hosting behavior; “RAM only” is not proved by application intent.

Aggregate operational counts may include process liveness and coarse resource/error classes. Exclude queue ID histories, source/destination pair logs, contact-level counters, per-user analytics, and persistent request traces. Rate limiting uses narrow capabilities, bounded resource budgets, and reviewed onion-service anti-DoS tools, not phone verification.

Cover traffic, volunteer Snowflake proxy, device-wide VPN, and nearby radio are separate experiments. They cannot be defaulted on as unexplained “more privacy,” because each changes bandwidth, observability, battery, permissions, and the threat model.

**Acceptance:** Kill Tor during every network-capable feature and inspect device/relay captures. A UI error is not sufficient; one direct escape fails the build.

#### T-05: Storage, vaults, local lock, and deletion

**Covers:** F-065 through F-071, F-103. Global app lock, chat vault lock, wallet unlock, screen lock, and decoy state are separate state machines.

| Store | Content | Protection |
|---|---|---|
| App settings | Local preferences, non-sensitive UI state | Device-bound app-store encryption |
| Relationship vault | Content, labels, comparison records, local index | Separate per-chat vault key and lease |
| Crypto state | Independent sessions, prekeys, MLS state | Protected security store, transactional semantics |
| Ciphertext spool | Unopened envelopes and bounded routing data | Low-privilege encrypted spool; no content key |
| Media cache | Encrypted staged/original received bodies | Scope-local keys, TTL and size quotas |
| Wallet | Seeds, descriptors, outputs, account history | Separate runtime/storage hierarchy |
| Payment associations | Locally approved minimal contact/payment map | Separate bridge protection and clear retention |

A per-chat passphrase wraps the relevant chat key using a reviewed construction and Argon2id profile; it must not simply hide a row in a globally unlocked database. Hardware wrapping is used where supported but does not imply every key type lives inside secure hardware.

On lock: cancel plaintext streams; clear composer/search/view caches; close relevant database/key leases; replace thumbnails; suppress notification details; terminate or pause capture according to explicit call policy. Incoming ciphertext may queue without decrypting locked content. The keyboard, clipboard, OS histories, accessibility services, and compromised OS remain residual boundaries.

Panic lock is one local action with no remote trigger. It stops capture and locks sensitive views; destructive erasure is a separate experimental action with prior configuration and deliberate confirmation. Cryptographic key destruction is not a claim of physical overwrite of all flash blocks or backups.

Decoy/disguise and dead-man auto-wipe stay experimental; no marketing claims of forensic invisibility or guaranteed plausible deniability. Auto-lock is the safe inactivity behavior.

Delete local profile requires review of affected local chats, keys, archives, and wallets. A messaging reset MUST NOT silently destroy an activated wallet; wallet removal has a separate recovery check and confirmation. Existing recipient copies, external exports, and public-chain records remain outside local deletion authority.

#### T-06: Attachments, voice notes, and multimedia

**Covers:** F-028, F-031 through F-036, F-049. Importing media is an untrusted parser operation and a potential metadata disclosure, not just selecting a file.

1. Obtain a narrow OS picker handle; do not request whole-library access unnecessarily.
2. Copy bytes into protected staging with size checks before decode.
3. Detect actual type and reject ambiguous/polyglot formats where unsupported.
4. Run a bounded sandboxed decode/sanitize pipeline.
5. Normalize image orientation and strip supported metadata from the send copy.
6. Re-encode supported audio/video locally; cap duration, dimensions, decoded memory, and CPU.
7. Show preview and whether sanitization succeeded, was partial, or is unsupported.
8. Bind descriptor, encrypted body manifest, type, length buckets, and integrity data.
9. Deliver through permitted protected transfer only.
10. Delete staging according to scope policy, including interruption and disk-full cleanup.

Documents cannot all be truthfully labeled “metadata removed.” Offer “Send original file” with a specific warning or cancel when safe normalization is unavailable. Do not silently mutate professional/evidentiary originals.

Default attachment delivery is endpoint-originated protected chunk transfer within the approved retention baseline. External ciphertext storage is a separate disabled experiment because even unreadable blobs introduce a new observer and persistence. Its candidate design uses random blob IDs, separate keys inside E2EE messages, padded authenticated chunks, fetch capability separation, and capped TTL; these do not themselves establish no regression.

One-time fetch tokens do not automatically support offline recipients, retries, linked devices, and multiple group members. The ADR must specify per-endpoint capability issuance, retry/resume, consumed-token races, revocation, relay failover, and leakable object equality before enabling storage.

Voice notes start only after visible user action and microphone permission. Cancel deletes the unsent recording; app lock/process interruption stops capture and preserves only a deliberately recoverable encrypted draft if policy permits. A call failure cannot silently become a recording.

View-once removes compliant in-app access after the defined opening event, but must retain sufficient bounded replay state to avoid reopening from duplicate delivery. It cannot prevent recording by a recipient or another device.

**Acceptance:** Fuzz malformed headers, decompression bombs, truncated chunks, duplicate/reordered chunks, wrong manifest, metadata fixtures, huge image dimensions, worker crashes, and relock during preview. No media worker receives wallet or authority keys.

#### T-07: Groups, large groups, and communities

**Covers:** F-037 through F-044. The preferred group foundation is MLS with encrypted group operations, application-level consent/role policy, and independent endpoint leaves.

RFC 9750 warns that delivery infrastructure may learn membership and that anonymous credentials alone do not establish metadata privacy; it recommends encrypted group operation messages where possible ([MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)). TGP therefore does not treat “MLS + rotating mailbox” as a demonstrated no-regression scaling solution.

| Tier | Design target, not supported claim | Current disposition |
|---|---|---|
| Private group pilot | Up to 32 people / 128 endpoints, inherited envelope | Must pass crypto/authority/metadata gates |
| Expanded private group | Up to 64 people with explicit endpoint cap | Same client-fanout model; benchmark first |
| Large group experiment | 256 people and a separately measured endpoint cap | Disabled; no production shared mailbox |
| Community experiment | Invite-only collection of independent groups | Disabled until directory/admin linkage review |

Group creation: select existing relationship contacts; create local draft; review title/roster/policy; send encrypted invitations; receive acceptance; obtain fresh group-scoped credential/key package; validate consent/current policy; authorize proposal; serialize valid transition; persist MLS state; mark membership active only after admission.

Creator starts as administrator and explicit transition coordinator. Administrator authority permits policy-approved admission/removal, not decrypting absent content, exporting another vault, or spending group funds. Coordinator orders valid transitions, not authorizing otherwise invalid ones.

Each group endpoint uses a separate group-scoped signing credential. A person's mapping to that credential is disclosed to admitted group participants through reviewed authenticated channels, not a global TGP identity service. This may affect deniability, but no group-deniability claim is approved without independent analysis.

Client fanout wraps each recipient's outer delivery separately so identical inner MLS ciphertext is not trivially equal at different queues. Actual padding/traffic equivalence remains measured. Server fanout, shared mailbox IDs, Privacy Pass credentials, or rendezvous optimizations are separate ADRs because they can join readers/writers even if IDs rotate.

Only explicit call-to-one-to-one actions may initiate payments from group context. Application-generated payment requests, addresses, TXIDs, swap offers, and proofs are not group event types. Users can still manually type financial data into text; UI cannot promise universal content detection without prohibited content inspection.

Removal has local stop, authorized proposal, committed transition, per-endpoint receipt, and unconfirmed states. Remove person targets all represented endpoints. Removed members retain old keys/content; offline senders may not know removal yet. Strict freshness blocks affected sends when the client lacks required current-state evidence.

Conflicting authenticated child states stop affected application sends. Recover through authenticated missing-transition retrieval or a reviewed fresh admission; do not choose state by latest timestamp, silently elect a coordinator, or restore cloned MLS state. If safe continuity is unavailable after coordinator loss, create a successor group explicitly.

#### T-08: Devices, selective sync, migration, and loss

**Covers:** F-050 through F-055, F-044. Controller is a local authority role, companion is an independently operating endpoint with explicit grants.

Pairing generates fresh new-device keys and a one-use ten-minute candidate invitation, creates a compared secure channel, requires confirmation on both devices, selects zero scopes initially, selects no history initially, reviews access once, then performs peer/group admission per scope. Pairing success is not conversation authorization.

| Data or power | Companion default |
|---|---|
| Selected new messages | Only after scope admission |
| Unselected/future conversations | None |
| Old content | None until separate range review |
| Attachments | On request and authorized |
| Local nicknames and private notes | Not copied |
| Verification | May transfer only with explicit provenance |
| Wallet seed, balance, view key, payment labels | Never through chat pairing |
| Enrollment/controller power | None |
| Group administrator power | Not inherited |
| Calls | Off until separately enabled and admitted |

Selected history becomes an encrypted archive of eligible content, not ratchets/group leaves. Transfer is resumable/cancellable; recipient sees which content is historical/imported. Expired/deleted content is excluded under current policy; reading/importing does not restart expiry.

Revocation immediately stops local new fanout, rotates capabilities where applicable, emits authenticated scoped changes, and triggers group rekey. UI tracks “Applied here,” “Awaiting peer/group update,” “Acknowledged,” and “Unconfirmed.” Offline participants can remain stale; no global instant-revocation claim.

Controller migration is an explicit authority transfer using compared transcript and fresh endpoint state. Transfer only chosen continuity authority, publish scoped successor events, retire old enrollment power after reviewed completion, and show partial progress. Concurrent successor claims pause automatic acceptance.

Controller loss does not promote a companion. Without separately approved continuity recovery, keep surviving readable history but re-establish identity/grants through fresh ceremonies. Old controller presence cannot be disproved by importing an archive.

#### T-09: Experimental voice/video

**Covers:** F-045 through F-049. Asynchronous voice notes are the supported fallback capability; live calls qualify independently.

Tor's SOCKS interface does not support the usual UDP ASSOCIATE operation, so a generic UDP-first call stack cannot be assumed to work safely ([Tor SOCKS extensions](https://spec.torproject.org/socks-extensions.html)). The media profile must prove a maintained Tor-compatible transport, no STUN/direct candidate leaks, bounded latency/memory, and safe capture state.

| Call state | Capture | Key access | UI |
|---|---|---|---|
| Preparing / inviting | Off | Signaling only | Preparing protected call |
| Ringing | Off | No media grant yet | Incoming call |
| Connecting | Permission/preview only as explicitly chosen | Call-specific admission in progress | Setting up encrypted media |
| Live | Explicitly enabled microphone/camera | Only admitted endpoints | Actual participant list |
| Reconnecting | Paused by default | Current keys retained only under policy | Reconnecting; no weaker route |
| Security update | Paused | Rekey/admission pending | Paused for security update |
| Ended / failed | Off | Session secrets erased under profile | End reason; separate voice-note action |

Chat membership does not confer call decryption. Use a separately reviewed call subgroup or equivalent so nonparticipating members lack media secrets. New endpoint admission, leave, handoff, and multiple-device answers must rekey and keep only the selected active endpoint.

SFrame is a frame-protection candidate, not complete signaling, admission, key management, or transport ([SFrame RFC 9605](https://www.rfc-editor.org/rfc/rfc9605.html)). The application must solve sender authenticity, replay, counter uniqueness, rotations, malicious participants, call/endpoint binding, and bounded out-of-order buffering.

Media infrastructure may observe session duration, traffic, and associations. That new exposure blocks production under the strict no-regression rule until equivalent protection is demonstrated; opt-in calling is not an automatic exception.

#### T-11: Platform, notifications, and frontend hardening

**Covers:** F-072, F-073, all platform realizations. Rust owns security decisions; TypeScript receives only currently permitted plaintext/read models.

Desktop Tauri configuration MUST explicitly enumerate enabled capabilities and custom-command permissions, deny remote content/remote command access, avoid shell and arbitrary filesystem APIs, restrict window creation, use a strict CSP, and load only signed bundled UI. Tauri's Isolation pattern can filter IPC but does not replace Rust validation or OS-level wallet/media isolation ([Tauri capabilities](https://v2.tauri.app/security/capabilities/), [Tauri Isolation pattern](https://v2.tauri.app/concept/inter-process-communication/isolation/)).

RN bridges MUST avoid serializing seeds, private protocol keys, or universal authority objects into JavaScript. Even necessary message plaintext in the UI remains a JS-memory exposure; lock/cancellation/redaction tests are required. No over-the-air arbitrary JavaScript update channel.

Android background availability needs real-device tests for Doze, force-stop, reboot, permission denial, foreground-service limits, and battery restrictions. Foreground-service rules vary by platform version and service type, so permanent operation is not a valid assumption ([Android foreground-service changes](https://developer.android.com/develop/background-work/services/fgs/changes)).

iOS default is app-open delivery. Optional minimal platform notifications preserve the v0.5 exception only after token/wake linkage review; no preview, sender, title, amount, balance, or content key. Disable registration when user turns it off, with explicit deletion/expiry semantics.

UnifiedPush remains a separately reviewed option: the distributor and its server are real infrastructure actors, not a serverless guarantee ([UnifiedPush FAQ](https://unifiedpush.org/users/faq/)). All notification modes must explain availability separately from content confidentiality.

Desktop locks on OS session lock/user switch/sleep policy, uses generic notifications, disables OS search indexing and plaintext recent-file previews, and separates closing a window from locking the app. Each OS needs its own signed update/storage/file-picker/keyboard/accessibility tests.

#### T-12: Backup and recovery

**Covers:** F-092 through F-095. There are three distinct recoveries: content archive, identity continuity, and wallet funds; none implies the others.

| Archive class | Included | Excluded |
|---|---|---|
| Chat history | Selected eligible messages, explicitly selected local metadata, manifest | Seeds, live ratchets, MLS sending leaves, media session state, implicit controller authority |
| Continuity candidate | Explicit chosen scoped recovery credentials under separate protection | Proof original device is gone; automatic group readmission |
| Wallet backup | Chain-specific seed/passphrase/descriptor/restore data under explicit wallet ceremony | Chat history and universal contact mapping by default |

Container parser validates version, authenticated manifest, declared limits, record count, chunk/order integrity, expiry eligibility, destination capacity, and compatibility before committing. Stream into protected storage; no plaintext temporary directory. Password failure cannot distinguish secret content or permit reduced KDF work silently.

Recovery drills restore into a temporary non-authoritative local context, verify content/fund derivation without spending, and destroy temporary secrets. A chat drill cannot activate old endpoints; a wallet drill cannot broadcast or transfer funds.

Social recovery, generic seed splitting, and Bitcoin multisig remain separate studies. SLIP-39 compatibility must be checked against the exact wallet/hardware format rather than assuming arbitrary BIP39 seeds, Monero mnemonics, and all devices are interchangeable. Never route recovery shares automatically through the same profile being recovered.

#### T-13: Offline transfer and nearby experiments

**Covers:** F-064, F-096. Offline QR/file transfer uses explicit type markers, version, bounds, sequence/integrity checks, destination/network review, and no private-key export.

Transaction signing QR, receive-address QR, contact invitation QR, verification QR, device pairing QR, and configuration QR are different types. A generic scanner routes to preview only; scanning cannot sign, broadcast, enroll, grant, or replace settings.

Nearby radio requires separate consent, authenticated known peers, local-radio metadata disclosure, replay/expiry limits, and no automatic internet bypass. Initial mesh is at most a text-only prototype with no wallet synchronization or promised settlement.

#### T-14: Diagnostics, support, abuse, funding

**Covers:** F-060, F-097, F-098, F-100. Diagnostics are local, bounded, and opt-in to export.

Allowed local evidence includes tested route, app version, error category, coarse resource readings, and relevant configuration fields after redaction. Exclude content, keys, seed fragments, address/contact maps, complete device/roster inventories, public IP tests without consent, and automatic crash dumps.

Before export show exact fields and recipient/retention policy. Support cannot look up a person's chats or recover secrets. User abuse reporting previews exactly selected content leaving protected storage; there is no universal server decryption or content scanning.

Chat, verification, revocation, updates, and baseline security remain free. Any separately billed support/capacity service must not share a reusable entitlement identifier with unrelated relationships. No payment skim or privacy-reducing analytics to prove revenue.

#### T-15: Distribution, updates, and incidents

**Covers:** F-005, F-099, F-104. Release records include source revision, artifact digest/signature, platform, security profile, dependency lock/SBOM, build recipe, license notices, independent rebuild result, known findings, compatibility, and rollback instructions.

Update checks are opt-in and use approved transport. Store/OS delivery is a separately disclosed platform service; neither artifact signing nor in-app digest comparison proves runtime OS integrity. Security updates are never paywalled.

Incident response protects release authority first, disables affected new actions without destroying user funds/recovery access, communicates scoped impact, obtains remediation/retest, and publishes updated evidence. An emergency switch must not strand an in-flight swap, erase keys, unlock vaults, or weaken routing.

#### T-16: UX infrastructure, accessibility, and measurement

**Covers:** F-015, F-101, F-102. Shared TS components render independent trust/route/authority/availability states from core-owned data.

Use system text scaling, screen-reader order and provenance, keyboard navigation, visible focus, reduced motion, non-color status, and accessible non-camera alternatives. Critical warnings and exact amounts never appear only in captions, tooltips, or truncating banners.

Local responsiveness is measured separately from relay delivery and settlement. Laboratory packet captures and consented research cohorts provide evidence; production engagement tracking, social-graph collection, or universal device IDs are not added for convenience.

### Security-relevant error contract

| Reason code | User-facing direction | Safe action |
|---|---|---|
| `ROUTE_UNAVAILABLE` | Protected connection unavailable; nothing was sent directly | Keep queued; retry or inspect connection |
| `IDENTITY_CHANGED` | This contact's key changed; review before sending | Pause affected sends; compare |
| `ENDPOINT_PENDING` | A new device is awaiting approval | Review scoped recipient change |
| `GROUP_CONFLICT` | Group state needs review | Pause affected sends; authenticated recovery |
| `PROFILE_UNSUPPORTED` | This version cannot use the required security profile | Update or leave action unavailable |
| `VAULT_LOCKED` | Unlock this chat to continue | No preview or auto-unlock |
| `STORAGE_FULL` | Not enough protected storage; no plaintext fallback | Cancel/retry after explicit cleanup |
| `INVITE_INVALID` | Invitation expired, used, or cancelled | Create new invitation |
| `MEDIA_UNSAFE` | This file cannot be safely prepared | Cancel or explicitly reviewed original-file option |
| `WALLET_POLICY_BLOCK` | Contact payment unavailable from this wallet under current policy | Keep management-only; no weaker override |
| `DEADLINE_COVERAGE_MISSING` | This device cannot safely start this swap | No funding; review supported external tool |
| `AUTHORITY_CONFLICT` | Competing authority changes require review | No automatic successor selection |

Reason codes must not expose unrelated contact names, account addresses, seeds, or internal secret data in notifications or logs. All retry controls revalidate current policy rather than replaying a previously approved authority action blindly.

---

## Wallets, Payments, and Financial Tools

This volume specifies a non-custodial financial subsystem that does not become a messaging identity system. It explicitly separates managing existing BTC/ETH from proving that a contact payment is unlinkable, because a local software boundary cannot erase public-chain history or information already known to an exchange, provider, counterparty, or compromised endpoint.

### Financial product contract

#### What TGP can and cannot promise

- **Can design for:** No TGP-held seed, spend key, private view key, plaintext contact/payment ledger, universal wallet/chat identifier, hosted transaction signer, or server-side wallet account.
- **Can test:** Wallet/chat IPC permissions, separate key roots/stores, no forbidden fields to nodes, no direct network escape, no address/xpub upload in approved BTC mode, chain-specific state accuracy, explicit sign/export/broadcast authorization.
- **Cannot promise:** Existing KYC history disappears, a public-chain transaction is unobservable, Tor makes an RPC query's address invisible to its recipient, counterparties cannot preserve evidence, or an atomic swap is a privacy certificate.
- **Must withhold:** Contact-spending capability when its known disclosure exceeds the applicable baseline or a required isolation/cryptographic/legal gate is unresolved.

Ethereum's wallet-privacy discussion identifies address/RPC, IP, timing, portfolio grouping, analytics, and public-chain relationships as distinct exposures ([Ethereum wallet privacy](https://ethereum.org/latest/next-great-wallet-private/)). Bitcoin compact filter integration provides client-side filter processing, but that does not establish that all subsequent block fetching or broadcasting is unobservable ([BDK-Kyoto documentation](https://docs.rs/bdk_kyoto/latest/bdk_kyoto/)).

#### Wallet activation is not chat enrollment

Wallet activation is optional, device-specific, and reversible without breaking messaging. A linked chat device receives no wallet seed, address list, balance, transaction history, private view key, source labels, or spending permission.

No financial vocabulary appears in first-run chat setup. An incoming request can be viewed without activating a wallet, but viewing cannot install a provider, register an account, sign, broadcast, or authorize a later payment.

#### Capability tiers

| Tier | Capability | Default and restrictions |
|---|---|---|
| W0 Disabled | No wallet runtime loaded | Initial state; chat-only build supported |
| W1 Watch-only | Inspect approved descriptor/address data locally | No signing; imported history labeled identity-linkage unknown/known |
| W2 Hardware connected | Prepare intent, obtain external signature | Seed never requested; exact device/firmware/chain matrix |
| W3 Local software signer | Separately protected chain-specific keys | Explicit restore/create ceremony, isolated runtime, separate backup |
| W4 Contact payment eligible | Typed one-to-one requests and authorized send | Only if applicable no-regression and chain gates pass |
| W5 Advanced external tools | Export/import into user-chosen independent software | Separate disclosure and legal gate; no automatic privacy upgrade |
| W6 Experimental swap | Reviewed engine with proven deadline coverage | Disabled by default; mainnet unavailable until all gates pass |

A wallet may remain W1 or W2 indefinitely. UI must not imply that connecting funds makes them suitable for private contact payments.

### T-10: Financial architecture

#### Runtime separation

```text
Chat runtime                         Wallet runtime
  local relationship handle            independent wallet handle
  encrypted request card                chain account/descriptor/output state
  minimal local status                  separate signing/recovery keys
  no seed or full wallet history        no contact roster or message history
           |                           |
           +-- typed local bridge -----+
                one-use operation handles
                bounded intents/results
                separate local authorization

Wallet network API --> network broker (wallet-specific isolation context)
                   --> own node / approved chain peer / reviewed provider

Nothing above requires a TGP-hosted wallet server.
```

On desktop the intended boundary is an OS-sandboxed wallet worker with separate filesystem access and narrow IPC. On mobile, same-process library separation does not meet the same guarantee; if the required boundary cannot be demonstrated, use management-only or separate-wallet software rather than claiming equivalence.

Wallet UI presents a local contact label only through a core-owned transient review model. It must not send that label to a chain adapter, node, hardware vendor server, analytics provider, or external tool unless an explicit export includes it.

#### Keys and databases

| Material | Location | Export rule |
|---|---|---|
| XMR spend/recovery secret | Wallet-only protected store or hardware | Explicit protected backup/restore only |
| XMR private view key | Wallet-only scan context | Never remote/light-wallet upload in approved baseline |
| BTC descriptor/xpub | Local wallet protected store | Sensitive portfolio information; hardware/backup export only as reviewed |
| BTC private signing keys | Hardware or wallet signer | Never chat bridge or general diagnostics |
| ETH signing key | Hardware or wallet signer | No arbitrary dapp access, personal-sign, or account enumeration by chat |
| Chain state | Wallet database | No chat IDs/names in adapter-owned records |
| Payment/contact association | Separately protected local bridge map | Minimal purpose/retention; never default chat sync |
| External tool operation state | Adapter-local encrypted store | Exact manifest/export and recovery rules |
| Swap recovery journal | Isolated encrypted recovery store | High-consequence backup, no default contact association |

Creating keys independently is necessary but not sufficient. Shared timestamps, device compromise, broker identifiers, backup names, logs, provider batching, and clipboard/export fields can still join contexts.

#### Typed bridge schema

```typescript
type Chain = "xmr-mainnet" | "btc-mainnet" | "eth-mainnet";

type PaymentRequestV1 = {
  version: 1;
  kind: "payment_request";
  requestNonce: string;       // random, scoped to one request
  chain: Chain;
  recipientAddress: string;
  amountAtomic?: string;     // integer string; no floating point
  memo?: string;             // bounded, encrypted, not a node field
  expiresAt: string;
};

type PreparePayment = {
  kind: "prepare_payment";
  localRequestHandle: string;
  selectedWalletHandle: string;
  amountAtomic: string;
  sourcePolicyHandle: string;
};

type ReviewedPayment = {
  reviewHandle: string;
  revision: string;
  chain: Chain;
  destinationDisplay: string;
  amountAtomic: string;
  feeCapAtomic: string;
  riskClass: "baseline-eligible" | "management-only" | "blocked";
  expiresAt: string;
};

type AuthorizePayment = {
  kind: "authorize_payment";
  reviewHandle: string;
  expectedRevision: string;
  localAuthorizationHandle: string;
};
```

The encrypted chat transport binds the request to its relationship context; a global contact ID does not enter the wire payload or chain adapter. Review handles are local, short-lived, non-reusable authorization references, not transferable bearer tokens that permit an external message to sign.

Required validation: payload version/type/length; chain/network; address checksum/encoding; amount range; asset precision; request nonce duplication; expiry/skew; destination substitution; currently admitted sender; wallet capability; local vault state; source policy; fees; and review revision. Unknown network/contract calls fail closed.

The bridge does not expose arbitrary transaction signing, arbitrary Ethereum calldata, seed export, unrestricted filesystem, external URL fetch, or “mark transaction paid” as trusted facts. A peer can send a payment claim; the wallet independently determines what it can verify.

### Connecting existing BTC/ETH safely

#### Connection journey

1. User opens You → Wallet → Activate.
2. User sees that wallet recovery is separate from chat recovery.
3. User chooses Connect existing, Create new, or Restore from recovery.
4. Connect existing offers Hardware or Watch-only first; it never asks for a seed.
5. User selects chain and supported device/format.
6. App previews requested public data and its privacy implications.
7. Local parser validates network, descriptor/address syntax, derivation/policy, and ownership proof only where the protocol requires it.
8. No network request is made until the user reviews the node/peer profile.
9. Wallet sync runs through its own broker context, with no contact metadata.
10. Wallet receives a provenance label and management-only status.
11. Contact payment eligibility remains blocked unless separately established.
12. User may disconnect, remove imported public data, or inspect source/exposure details without sending funds.

“Restore from recovery” is intentionally a different path. It means introducing spend-capable secrets into the device and must not be hidden behind the harmless-sounding word “Connect.”

#### Quarantine is a safety policy, not a cleansing mechanism

| Local provenance label | Meaning | Permitted behavior |
|---|---|---|
| Externally linked | User/import evidence indicates exchange/KYC/public identity association | Management-only; no contact payment |
| History unknown | TGP cannot determine prior linkage | Conservative management-only default |
| New local wallet | Keys generated locally with no imported history | Not proof of anonymity; evaluate funding and future activity |
| Reviewed protocol output | An approved tool produced an output under a recorded profile | Preserve source ancestry; no automatic unlinkability label |
| Contact-associated | User deliberately linked a local payment to a relationship | Protect local map; no sync/export by default |
| Mixed-source selection | Spend combines inputs/accounts with different local provenance | Block automatic merge; explicit advanced review still cannot waive baseline |

Source labels are local policy metadata. They are not factual assertions about ownership, legality, sanctions status, or whether a blockchain analyst can make a link.

The app MUST NOT offer “remove KYC history,” “clean coins,” “guaranteed private hop,” or a BTC→XMR→BTC recipe as a privacy guarantee. Swaps, CoinJoin, pools, delays, fresh addresses, and separate circuits may change some observations but cannot establish that no identity link remains.

#### Key distinctions the UI must teach

- **Wallet connection:** Imports public monitoring data or associates a hardware signer locally.
- **Wallet restore:** Introduces recovery/spending capability into this device.
- **Blockchain privacy:** Concerns what ledger observers can infer, independently of TGP.
- **Network privacy:** Concerns what nodes/providers and network observers see.
- **Local association privacy:** Concerns the protected contact/payment map on the endpoint.
- **Counterparty knowledge:** The intended payment peer knows the request and interaction.
- **Provider confidentiality:** TGP infrastructure does not receive decryptable financial contents, while traffic correlation remains a separate question.

### Monero specification

#### Node and scanning model

Run wallet scanning locally, keep private view/spend keys on-device or hardware, and reach own/approved remote node through the broker. Do not introduce a hosted light-wallet server that receives private view keys merely to improve speed.

Monero documentation distinguishes local scanning from remote-node observations and warns that malicious nodes can bias or withhold data; it also distinguishes own-node operation from protected transaction propagation ([Monero remote nodes and privacy](https://docs.getmonero.org/interacting/remote-nodes/)). TGP must therefore test the exact RPC pattern, trusted-node flags, decoy selection, fee validation, output queries, and broadcast path rather than saying “Tor makes any node safe.”

Rust wallet library selection must cover complete wallet policy, not only transaction construction. The fetched `monero-wallet` documentation explicitly says it is not a complete wallet and does not itself maintain state, select outputs, or run background work ([monero-wallet documentation](https://docs.rs/monero-wallet/0.2.0/monero_wallet/)).

#### Receive, send, and recovery

Generate fresh receive subaddresses per request/context, store contact mapping locally, and avoid displaying balance/address until requested. A new subaddress does not hide a user's identity from a person to whom they deliberately identify themselves.

Send review shows exact XMR amount, recipient comparison state, address, network, wallet/source policy, estimated fee, delay policy, and optional guardrail. Coin-control capability is only exposed if the maintained wallet stack supports it safely; UI calls them wallet outputs rather than applying BTC terminology indiscriminately.

Settlement UI uses observed transaction state, confirmations, and actual unlocked/spendable status. It must not hard-code one universal “safe after N confirmations” promise or equate a chat receipt with chain finality.

Mnemonic/restore format is pinned to a supported wallet matrix. Polyseed encodes creation-date information and has feature/compatibility distinctions that cannot be replaced by a generic seed screen ([Polyseed specification](https://docs.getmonero.org/mnemonics/polyseed/)).

Future protocol upgrades, including FCMP++/new addressing, are disabled until official activation, maintained libraries, interoperability, hardware support, and recovery tests are confirmed. This spec does not rely on an estimated activation date from secondary coverage.

### Bitcoin specification

#### Wallet model

Preferred candidate: maintained BDK descriptor wallet with separately selected signer, local filter matching through a Kyoto-compatible BIP157/158 client or own-node mode, and explicit PSBT workflows. BDK-Kyoto documents block-header/filter/block processing but does not establish built-in Tor support in the fetched page, so broker integration is a blocking test rather than an assumed capability ([BDK-Kyoto documentation](https://docs.rs/bdk_kyoto/latest/bdk_kyoto/)).

| Concern | Requirement |
|---|---|
| Address reuse | Fresh address per request; warn before deliberate reuse |
| Portfolio disclosure | No xpub/descriptor upload to a public service |
| Filter privacy | Local matching, review block-fetch patterns and peer correlation |
| Coin selection | Conservative source-label boundaries; change handling; fee calculation locally |
| Signing | Hardware/air-gapped PSBT first; never unrestricted raw-sign request |
| Broadcast | Approved protected peer path/own-node integration; no direct fallback |
| Fee bump | Chain-specific reviewed RBF/CPFP workflow; no silent extra signing |
| Reorg | Confirmed state can move backward; show chain uncertainty |
| Backup | Descriptor/policy/network/origin/derivation and signer recovery requirements |
| Multisig | Deferred until descriptor recovery and hardware policy registration qualify |

Bitcoin Core release notes describe a private-broadcast option, but TGP cannot claim to inherit its protection merely by naming the option ([Bitcoin Core release notes](https://bitcoin.org/en/releases/31.0/)). Actual node version, configuration, dependencies, network behavior, and current advisories must be qualified independently.

#### PSBT workflow

Prepare a bounded PSBT locally, review destination/amount/fees/change/policy, transfer only required signing material, verify the signer-returned transaction matches the reviewed intent, validate signature/sighash/network/fee bounds, then separately authorize broadcast. Unknown/proprietary fields are bounded and rejected or stripped under reviewed policy.

Hardware compatibility means exact model, firmware, chain application, transport, descriptor policy, address types, PSBT variants, and recovery behavior. A hardware abstraction crate is an integration candidate, not a promise that all listed hardware works on all TGP platforms ([async-hwi documentation](https://docs.rs/async-hwi/0.0.34/async_hwi/)).

#### Payjoin

Payjoin can improve some transaction-structure privacy properties but cannot erase all public-chain, participant, timing, or source-history information. It does not satisfy the strict contact-payment requirement automatically.

BIP77 uses encrypted asynchronous proposals and OHTTP-supported directory communication in its documented design ([Payjoin BIP77](https://payjoin.org/docs/how-it-works/payjoin-v2-bip-77/)). A TGP-specific chat transport for proposal payloads must be reviewed for protocol equivalence and cannot be marketed as interoperable BIP77 solely because it carries a PSBT.

Requirements: validate receiver contribution and ownership assumptions; bound additional fee; preserve intended recipient amount; reject malicious substitutions; handle conflicting spends; keep change policy; time out safely; retain recovery state; never silently fall back to an ordinary payment after a Payjoin failure. A failed negotiation cannot move funds without fresh ordinary-payment review, and a baseline-blocked contact payment has no fallback.

#### Silent payments

Silent-payment receiving stays experimental until scanning, light-client data, restore performance, hardware support, and amount/source correlation are reviewed. Fresh addresses are not a claim that the source wallet is unlinkable.

### Ethereum specification

#### Scope

Initial design scope is native ETH management with explicit own-node/provider configuration. ERC-20 breadth, arbitrary dapps, WalletConnect, ENS reverse lookups, NFT previews, DeFi approvals, account-abstraction sponsorship, and bridge integrations are not silently included.

Use maintained Rust transaction primitives such as an alloy-class adapter, explicit chain ID, integer amounts, bounded fee caps, nonce management, destination review, and replay protection. Disable arbitrary calldata/sign-message requests through the chat bridge.

Helios can verify aspects of untrusted RPC responses but still depends on consensus/execution inputs and weak-subjectivity checkpoints; its repository describes these trust roots and API requirements ([Helios repository](https://github.com/a16z/helios)). Verification is not query privacy: an execution provider can still receive the address being queried.

#### Node modes

| Mode | Exposure | Production disposition |
|---|---|---|
| User-controlled node over approved transport | User's infrastructure sees requests; hosting/provider may observe operation | Preferred candidate, still reviewed |
| Third-party RPC over Tor | Provider sees address/query/time; network origin reduced | Not equivalent to no address disclosure; blocked where baseline requires more |
| Local verification over third-party RPC | Better response integrity, not private reads | Same metadata gate |
| Per-account provider/circuit separation | Reduces trivial batching but not chain/collusion links | Mitigation only, never proof |
| PIR/TEE/ORAM or shielded protocol | New trust, maturity, contract, recovery, and legal issues | Research only until qualified |

Never batch unrelated accounts, include contact labels, or ask a remote service for the entire wallet portfolio. Disable token/NFT auto-discovery that contacts unknown hosts.

#### Stealth addresses and privacy protocols

ERC-5564 specifies stealth addresses/announcements, and its security discussion explicitly warns that funding a stealth wallet can breach privacy ([ERC-5564](https://ercs.ethereum.org/ERCS/erc-5564)). TGP must review announcement scanning, spam, viewing/spending key separation, recovery, gas funding, token transfer behavior, contract observations, and sender knowledge.

A stealth address is not a private-payment guarantee. No production “gas hop” automation is specified to claim unlinkability; if safely spending cannot be demonstrated without prohibited linkage, the feature remains receive-only experimental or unavailable.

Kohaku is useful ecosystem research, but its repository warns that some packages are work in progress and contain unaudited code ([Kohaku repository](https://github.com/ethereum/kohaku)). Privacy Pools, Railgun, Tornado-related tooling, and PQ account proposals each need their own manifest, cryptographic audit, contract/deployment review, custody/control analysis, recovery design, and jurisdiction decision.

### Contact payment product rules

#### One-to-one only

Application-generated payment requests, addresses, TXIDs, proofs, and swap offers are only supported in one-to-one channels. “Pay privately” from group details opens a chosen person's direct relationship and does not publish a group event or payment completion badge.

This avoids adding a signed group financial transcript by design, but is not a blanket deniability guarantee. MLS does not itself claim deniability, and pairwise PQXDH deniability has documented assumptions and limits ([MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html), [PQXDH specification](https://signal.org/docs/specifications/pqxdh/)).

#### Payment lifecycle

| Stage | Meaning | Who may assert it |
|---|---|---|
| Request received | Valid bounded encrypted request, no funds moved | Chat parser/core |
| Review prepared | Current wallet intent/fees/source evaluated | Local wallet |
| Authorized | User approved this exact review revision | Local authorization controller |
| Awaiting signature | Hardware/offline signing incomplete | Wallet |
| Signed, held | Signed object retained locally, not broadcast | Wallet with explicit leakage warning |
| Scheduled, unsigned | Intent held; transaction not yet signed | Preferred scheduling mode |
| Broadcast submitted | Transaction submitted, not settlement | Wallet/network adapter |
| Observed pending | Locally observed in applicable mempool/chain view | Wallet |
| Confirming / finalized / spendable | Chain-specific observed evidence | Wallet, with reorg rules |
| Cancelled before broadcast | Local action stopped; no guarantee if signature escaped | Wallet |
| Request expired | Request no longer approvable; existing broadcast unaffected | Bridge/core |
| Failed / conflicted / replaced / reorged | Chain-specific exception | Wallet reconciliation |

For ETH distinguish submitted, included, safe/finalized observations as implemented; for BTC distinguish mempool/confirmations/conflict/replacement; for XMR distinguish confirmations and wallet-reported unlock/spendability. A generic “Paid” label is insufficient.

#### Retention and payment cards

After locally observed settlement and a proposed 24-hour review window, compliant local chat UI may minimize the card to “Payment details removed from this chat.” Pending disputes, incomplete swaps, refund deadlines, or required recovery material must not be purged prematurely.

Wallet transaction records and public-chain data do not disappear when chat details expire. The contact/payment mapping is separately configurable, excluded from default message sync/backup, and explained before enabling retention; recipients and previous exports may retain their own copies.

Default ordinary chat history remains Keep. Payment-card minimization is a distinct disclosed data policy, not silent deletion of all financial records or a guarantee of non-evidence.

#### Delayed and scheduled payments

Prefer holding an unsigned reviewed intent until the chosen time. Recheck destination validity, expiry, source availability, network, fee cap, nonce/input conflicts, and policy before signing.

Automatic future signing is unavailable in the baseline unless a separate restricted authorization design qualifies. If the app is locked/asleep, show “Awaiting your authorization,” not a false scheduled guarantee.

An advanced signed-held mode must warn that anyone obtaining the signed transaction may broadcast it and that cancellation is only local until conflicting/replacement behavior is safely established. Randomized broadcast jitter is distinct from a user-selected schedule and has no universal correlation-resistance claim.

### Atomic swaps and independent tools

#### Protocol catalog and current evidence

| Candidate | Verified technical distinction | v0.6 decision |
|---|---|---|
| eigenwallet/COMIT-family | Fetched implementation README supports buyer sends BTC/receives XMR and warns the cryptography is not formally audited ([implementation README](https://github.com/eigenwallet/core/blob/master/swap/README.md)) | Research/testnet only; no generic bidirectional claim |
| BasicSwap | Project describes BTC/XMR in both directions and requires its node to remain online during the swap ([BasicSwap FAQ](https://basicswapdex.com/faq.html)) | External candidate; protocol/online/implementation review required |
| Haveno | Uses 2-of-3 multisig involving an arbitrator, rather than the same trust model as a two-party atomic swap ([Haveno protocol](https://docs.haveno.exchange/overview/trade-protocol/)) | Not classified as interchangeable atomic swap |
| Serai | Fetched project docs say mainnet has not launched ([Serai documentation](https://docs.serai.exchange/)) | Deferred; no production dependency |
| Athanor ETH-XMR | Repository is archived and describes beta software ([Athanor repository](https://github.com/AthanorLabs/atomic-swap)) | Reject as production dependency without maintained reviewed successor |
| Payjoin | Payment collaboration protocol, not cross-chain exchange ([BIP77 documentation](https://payjoin.org/docs/how-it-works/payjoin-v2-bip-77/)) | Separate feature and threat model |
| CoinJoin | Transaction collaboration with protocol-specific coordination and observations ([Wasabi protocol documentation](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html)) | External export boundary only; no hosted TGP coordinator |

These are project descriptions, not TGP endorsements or implementation audit results. No claim is made that a named protocol removes all correlation or all central dependencies.

#### Swap engine requirements

The runtime must be a maintained reviewed implementation, not a bespoke translation of a paper. TGP's code may orchestrate local consent/state/UI, but the selected protocol must provide complete funding, redemption, cancellation, refund, timeout, chain-reorg, fee, and recovery semantics.

| Abstract state | Allowed next action | Must remain protected |
|---|---|---|
| Disabled | Read capability explanation | No network discovery or funds |
| Offer draft/received | Validate direction, assets, bounds, peer, protocol | No implicit acceptance |
| Reviewed | Show amounts, all fees, worst-case loss, deadlines, dependencies | No stale quote authorization |
| Coverage checked | Verify supported watcher/signer/refund prerequisites | No funding if coverage absent |
| Prepared | Persist recovery journal and required authorizations | No partial irreversible funding without recoverable state |
| Funded | Monitor protocol/chain events under exact engine rules | Do not allow arbitrary fee bump or generic cancellation |
| Counterparty pending | Wait/timeout under protocol | Do not declare loss or success early |
| Redeem/refund eligible | Perform only engine-authorized operation | Secrets/transaction validity and fee coverage |
| Completed/refunded | Reconcile both chain outcomes | Retain necessary recovery evidence until safe retention point |
| Intervention required | Show exact unresolved condition and safe export | Never generic “try again” double funding |

This table is not a wire protocol or a promise that every state exists identically in every engine. Each adapter supplies a protocol-specific state mapping and test vectors before mainnet eligibility.

#### Deadline coverage

Mobile background execution cannot be relied on to meet adversarial timelocks. Before funding, the selected engine must establish that required actions can be performed under documented device/watcher availability, key authorization, network delay, fee spikes, chain reorg, storage failure, and lock/reboot conditions.

| Coverage option | Requirement | Residual limit |
|---|---|---|
| Desktop companion | Always-on qualified runtime, synchronized recovery state, separately authorized financial capability | Desktop can fail; chat companion grants alone are insufficient |
| User-operated watcher | Narrow protocol-specific authority, encrypted recovery material, no arbitrary spend power | Hosting, availability, secrets, collusion, and metadata remain |
| Pre-authorized recovery transactions | Exact engine support, valid fee/nonce/timelock conditions | Fees/reorg/transaction validity can defeat simplistic assumptions |
| Phone alone | Only if real-device adversarial evidence meets protocol needs | Otherwise blocked |
| TGP-hosted watchtower | Not part of selected service model | No hidden custody/control or contact/payment database |

A watcher holding a secret or adaptor material may have more power than “monitor only.” Its authority must be derived from the exact protocol rather than assumed harmless.

The UI must not say “refund guaranteed,” “risk-free,” or “your phone will automatically recover funds.” Worst-case outcomes and support limits appear before funding.

#### External tool integration contract

TGP runs no mixer, CoinJoin coordinator, swap maker, pool, order-routing service, or settlement backend. Export-only design reduces some operational roles but is not legal immunity or proof of metadata equivalence.

“Export PSBT to CoinJoin” is not assumed to be universally supported. An adapter must demonstrate the actual tool's accepted input format and semantics; otherwise provide neutral standards-based wallet export only or no integration.

JoinMarket NG describes maker/taker coordination and end-to-end communication over a Tor-integrated market, while Wasabi documents a coordinator that receives clear input/output information under its protocol roles ([JoinMarket NG](https://github.com/joinmarket-ng/joinmarket-ng/), [Wasabi CoinJoin documentation](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html)). Neither description supports “no one sees anything,” and no fixed number of rounds or transformation sequence is specified as making funds unlinkable.

#### Adapter manifest

```yaml
adapter_id: "example.disabled"
manifest_version: 1
status: "research-only"
protocol:
  name: "required"
  version: "exact pinned version"
  implementation_commit: "required"
  reproducible_artifact_digest: "required"
  license_review: "required"
supported:
  chains: []
  directions: []
  networks: ["test-only-until-approved"]
destinations: []             # exact role, host/onion, transport, redirects policy
data_sent: []                # fields, purpose, plaintext recipient
data_received: []
custody_and_control:
  tgp_can_spend: false
  third_party_authorities: []
fees:
  network: "explicit"
  protocol: "explicit"
  anti_spam_or_penalty: "explicit"
  tgp_percentage: 0
recovery:
  deadlines: "protocol-specific"
  required_online_roles: []
  secret_authorities: []
  journal_format: "required"
  failure_and_refund_tests: []
privacy:
  baseline_comparison: "required"
  residual_linkage: []
  source_ancestry_preserved: true
legal:
  reviewed_jurisdictions: []
  opinion_date: null
  distribution_constraints: []
evidence:
  independent_review: null
  remediation: null
  compatibility_matrix: null
```

A missing field blocks activation. A manifest cannot authorize a new destination dynamically without signed update policy and user review, and a new signature on a manifest cannot turn an experimental adapter into a validated one.

### Financial acceptance tests

| Test | Given / When / Then |
|---|---|
| FIN-01 | Given chat-only build, when all message journeys run, then no wallet service, key, endpoint, or seed prompt is required |
| FIN-02 | Given existing BTC/ETH hardware connection, when Connect completes, then no recovery phrase was requested or transmitted |
| FIN-03 | Given imported descriptor/address, when sync runs, then no contact name/chat ID reaches adapter, provider, logs, or hardware telemetry |
| FIN-04 | Given BTC filter mode, when captures are reviewed, then no xpub/address query is sent; block-fetch/broadcast observations are separately documented |
| FIN-05 | Given ETH third-party RPC, when address query is made, then UI discloses the provider's address visibility and baseline-blocked contact spend remains blocked |
| FIN-06 | Given quarantined funds, when a user tries Pay contact, then no warning-only bypass grants baseline eligibility |
| FIN-07 | Given a payment message, when parsed, then no signing/broadcast occurs without current separate local authorization |
| FIN-08 | Given changed amount/destination/fee/source after review, when authorization is attempted, then review revision fails and user must review again |
| FIN-09 | Given a group, when Pay privately is chosen, then only a one-to-one flow opens and no group payment event is emitted |
| FIN-10 | Given a peer “paid” claim, when chain data does not verify it, then UI says claimed/unverified rather than settled |
| FIN-11 | Given signed-held transaction, when cancel is selected, then app explains the signature may already be broadcast if copied |
| FIN-12 | Given chain reorg/conflict/replacement, when wallet reconciles, then state can move backward accurately without double spend |
| FIN-13 | Given hardware return payload mismatch, when imported, then no broadcast and no silent acceptance of changed recipient/change/fee |
| FIN-14 | Given external tool return, when imported, then typed limits/network/intent/recovery data are revalidated |
| FIN-15 | Given missing swap coverage, when Start is tapped, then no funding request or counterparty commitment is sent |
| FIN-16 | Given watcher offline/fee spike/reorg/reboot/lock, when swap recovery is exercised, then outcomes match exact engine threat model or mainnet stays blocked |
| FIN-17 | Given settlement-card minimization, when retention runs, then pending refund/recovery state is not destroyed and wallet/public-chain history is not called erased |
| FIN-18 | Given local profile deletion, when wallet exists, then separate wallet backup/removal consent is required |
| FIN-19 | Given an ordinary chat archive or support package, when inspected, then wallet seeds/private view keys are absent and contact-payment maps are excluded by default; any eligible mapping export is separate and explicitly reviewed, never a secret-recovery request from support |
| FIN-20 | Given legal restriction or adapter retirement, when new starts are disabled, then required recovery information and lawful safe export/intervention paths are preserved; no guarantee of an otherwise prohibited refund transaction |

### Financial release decision

The selected initial financial goal is isolated non-custodial wallet management and retained XMR request/send design after its own gates. Native BTC/ETH management is not permission to claim private contact payment equivalence; public-chain contact spending, shielded protocols, CoinJoin integration, and swaps remain independently gated or blocked.

No engineering or legal approval is inferred from this volume. The final legal section of the master document specifies jurisdiction review, prohibited service roles, and launch/retirement handling.

---

## Eight-Dimension Security Review and Disclosure Ledger

This is a pre-implementation architecture review against the supplied v0.5 requirements. It is not an independent security audit, penetration test, formal proof, or finding that the proposed architecture preserves a measurable percentage of privacy.

### Review method and baseline

#### Baseline discipline

v0.5 describes intended protections, candidates, and release gates, not a validated implementation. “Before” below therefore means the applicable documented v0.5 design, not measured deployed behavior.

Each review compares eight required dimensions: content confidentiality, relationship privacy, network metadata, authority, persistence, endpoint attack surface, failure behavior, and evidence. A design can improve one dimension while worsening another; the no-regression rule blocks shipping the worsening dimension rather than allowing a net score.

#### Threat actors and boundaries

| Actor or failure | Relevant access | Required response and residual limit |
|---|---|---|
| Passive local-network observer | Connection destination, timing, volume, transport fingerprints | Protected route and padding reduce exposure; no global correlation guarantee |
| Active censor | Blocking, packet injection, delay, bridge enumeration | Maintained PT options and fail-closed behavior; shutdown may defeat availability |
| One relay operator | Queue capabilities, message sizes, timings, its forwarding role | No content keys; minimize identifiers; live observation remains |
| Colluding relays/hosting providers | Combined timing and routing observations | No assumed independence; composition analysis required |
| Malicious rendezvous | Invite timing, races, withheld or substituted ceremony messages | Reviewed transcript/PAKE binding, one-use local state; denial of service remains |
| Directory/signing compromise | Malicious endpoint recommendations or release metadata | Separate identity authority; signed freshness, rollback and governance defenses |
| Malicious contact/member | Authorized plaintext, screenshots, transcript exports | Minimize unnecessary signed evidence; cannot prevent recipient disclosure |
| Lost locked device | Encrypted files, OS backups, hardware-dependent protections | Separate keys/leases, no broad recovery; offline guessing/forensics remain |
| Unlocked endpoint malware | Authorized memory, input, UI, keys reachable at runtime | Isolation and least privilege; no app-level guarantee against full OS control |
| Controller compromise | Enrollment/continuity power in selected scopes | Visible grants, peer admission, conflict handling; high-consequence role remains |
| Compromised companion | Only selected content/grants | No expansion, wallet, future-chat, or automatic controller rights |
| Platform/store operator | Install/account/push metadata, OS execution | Explicit exceptions, no content keys; platform cannot be made invisible by TGP |
| Blockchain/RPC observer | Public transfers, queried addresses, transaction propagation | Chain-specific limits; no source-history erasure |
| Swap peer/watcher | Protocol state, deadlines, fees, possibly recovery secrets | Exact authority/deadline review; no generic trustless/risk-free claim |
| Rollback/crash/disk failure | Stale state, lost queues, partial writes | Transactional crypto state and fail-closed recovery; no plaintext fallback |
| Legal demand | Existing operational/business data, compelled actions within law | Minimize retained data, truthful lawful-process policy, independent counsel |

#### Evidence status

All evidence below is required future work unless explicitly labeled upstream background. Citing a library or protocol establishes its documented behavior, not that TGP's implementation passed a test.

Signal's direct-protocol documentation and analysis qualify deniability, and MLS makes no deniability claim; these are reasons to restrict public language, not grounds to promise legal non-evidence ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/), [PoPETs analysis](https://petsymposium.org/popets/2024/popets-2024-0148.pdf), [MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)).

### Eight-dimension feature reviews

#### AUD-01: First launch, display name, and tutorial

**Scope:** F-001–F-004, F-011, F-015. **Verdict:** Preserves by design, unverified; faster setup must not alter key protection.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local keys and protected history | Same; background key creation only after secure prerequisites |
| Relationship privacy | No account/directory, per-contact presentation | No uniqueness request; no global username; checklist local |
| Network metadata | Tor setup required | Earlier bootstrap may reveal earlier app activity; compare same user journey, no extra analytics |
| Authority | Local profile/controller creation | Same; no tutorial completion grants trust |
| Persistence | Local profile and settings | Small encrypted hint/checklist preferences only; clearable |
| Endpoint attack surface | Platform and core setup | Shared TS UI adds no remote code; bridge/parser hardening required |
| Failure behavior | Fail closed on protection/route failure | Setup can remain local/offline; no registration or direct fallback |
| Evidence | First-launch/identity/network gates | Packet capture from installation through first message; empty-name and interrupted-setup tests |

#### AUD-02: One-use QR and remote invitation

**Scope:** F-006–F-008. **Verdict:** Conditional on reviewed invitation composition and PQ requirement.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Reviewed PAKE candidate and separate secret | Concrete candidate orchestration; no unreviewed hybrid combiner |
| Relationship privacy | No public lookup | Expiring rendezvous has no person fields; remote service still sees ceremony activity |
| Network metadata | Protected rendezvous traffic | Same boundary; rate/length/attempt patterns must be bounded |
| Authority | Invite plus explicit contact establishment | Scan never auto-enrolls device or signs payment |
| Persistence | One-use expiring invitation | Local burned state and bounded replay proof; server deletion not sole authority |
| Endpoint attack surface | QR/link/PAKE parsing | Typed scanner, strict URL/scheme/length/version; no universal handler |
| Failure behavior | Wrong guess burns invite | Local race/concurrency handling; malicious server may cause denial of service, never bypass |
| Evidence | Invite attack matrix | Wrong-secret, double-claim, replay, crash, expiry/skew, substituted profile, malicious rendezvous review |

#### AUD-03: Comparison, key changes, and signed cards

**Scope:** F-005, F-009, F-010, F-012, F-013. **Verdict:** Comparison preserves by design; reusable links/cards conditional.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Verification independent of encryption | Same; no false decryption guarantee from green badge |
| Relationship privacy | Scoped key records; optional signed card | Reusable capabilities/card signatures may add cross-context evidence; default off |
| Network metadata | No directory lookup | Build checks use approved transport; link access patterns reviewed |
| Authority | Explicit comparison and continuity review | QR physical provenance explicit; transferred records labeled |
| Persistence | Local prior fingerprints and notes | Same with bounded event history; no provider key-history directory |
| Endpoint attack surface | Canonical representation and manifest parsing | Accessible comparison alternatives, hostile-card/link tests |
| Failure behavior | Key change pauses trust | Affected send blocked until review; no automatic “new phone” assumption |
| Evidence | VER/DIST gates | Human comparison study, key substitution, stale/replayed cards, signed manifest rollback tests |

#### AUD-04: Direct protocol and scoped endpoint sessions

**Scope:** F-016, F-029, F-030. **Verdict:** Conditional on selected profile, licensing, scoped identity, and independent composition review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Hybrid handshake and evolving sessions required | PQXDH + maintained Triple Ratchet candidate; no weaker compatibility fallback |
| Relationship privacy | Scope-local authority, no universal public credential | Must realize this with selected library; global Signal-style service account not imported |
| Network metadata | Padded two-relay delivery | Crypto/prekey traffic must not create stable cross-contact service identifier |
| Authority | Explicit endpoint admission | Protocol session possession is not authority to expand recipients |
| Persistence | Protected session state, key deletion | SPQR/prekeys/skipped keys bounded; atomic outbox/state writes |
| Endpoint attack surface | Maintained protocol implementation | Rust/FFI/serialization dependencies pinned and reviewed |
| Failure behavior | Unsupported security profile fails closed | No first-reply downgrade, state rollback, or cloned active session |
| Evidence | CRYPTO/DEV gates | Exact profile vectors, downgrade tests, crash consistency, secret lifecycle, external protocol review |

#### AUD-05: Delivery, offline queue, drafts, and mutation events

**Scope:** F-017–F-023, F-026. **Verdict:** Preserves by design, unverified.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | E2EE content/local encrypted cache | Replies, edits, reactions remain encrypted under same scope |
| Relationship privacy | No server-readable labels | Pin/archive/mute/drafts local; reactions expose activity only to existing recipients |
| Network metadata | Queue/receipt patterns exist | New interaction event volume changes metadata; quantify and bound before equivalence claim |
| Authority | Authenticated typed events | Edit/reaction cannot mutate membership or target another scope |
| Persistence | Keep default, local retry source | Draft and mutation retention explicit; no unbounded hidden edit archive |
| Endpoint attack surface | Bounded message parser | Additional event variants fuzzed; inert text rendering |
| Failure behavior | Retry/dedup and honest labels | No duplicate visible action, false delivery, stale edit resurrection |
| Evidence | MSG/SYN gates | Event algebra/property tests; duplicate/reorder/conflict/lock/disk-full matrix |

#### AUD-06: Expiry, search, and view-once

**Scope:** F-024, F-025, F-035. **Verdict:** Conditional on local-key/index/replay implementation.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Locked chats excluded from active search | Same; per-chat index/key boundaries, no global plaintext FTS |
| Relationship privacy | Queries local | No remote suggestions/search telemetry |
| Network metadata | Expiry control events scoped | No extra read-triggered signal unless existing policy explicitly allows |
| Authority | Shared authenticated timer; local view restriction | No sender authority to prove recipient destruction |
| Persistence | Keep default; eligible expiry/tombstones | Bounded replay state prevents duplicate reopening; backups may retain old copies |
| Endpoint attack surface | Search/index/media parsing | Sanitized snippets, no quoted locked/expired original |
| Failure behavior | No expiry restart on sync/import | Clock uncertainty visible; modified recipients remain outside guarantee |
| Evidence | SEC/MSG/BKP tests | Relock memory tests, stale replay, skew, duplicate view, archive resurrection tests |

#### AUD-07: Transport broker, bridges, and network status

**Scope:** F-056–F-058. **Verdict:** Preserves by design, unverified; platform/PT support conditional.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Transport never receives plaintext keys | Same, opaque message payloads |
| Relationship privacy | Context isolation required | Reviewed context IDs; no universal device token to destinations |
| Network metadata | Tor with bootstrap/PT exceptions | Earlier bootstrap same disclosed transport role; no DNS/redirect leaks |
| Authority | User-reviewed endpoint configuration | Imported config preview cannot silently replace route |
| Persistence | Cached successful method | No retained per-contact route history; bridge secrets protected |
| Endpoint attack surface | Tor/native/PT dependencies | Pin exact platform packages, verify provenance, update lifecycle |
| Failure behavior | App fail closed | All app dependencies denied direct fallback |
| Evidence | NET/PLAT gates | Device egress capture for each feature during network loss/IPv6/DNS/redirect scenarios |

#### AUD-08: Federated relays, directory, queues, and quotas

**Scope:** F-059, F-098. **Verdict:** Conditional; operator diversity and metadata composition not proven.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Relay ciphertext only | Same, no content keys |
| Relationship privacy | Two-role relay design | Nested envelopes/capabilities; colluding operators remain able to correlate |
| Network metadata | Queue sizes/activity visible in role | Explicit actor ledger; no “no metadata” claim |
| Authority | Relay cannot admit recipients | Directory selects infrastructure only; not identity authority |
| Persistence | RAM queue up to seven days | Same upper bound, no durable promise; inspect swap/dumps/snapshots |
| Endpoint attack surface | Relay wire parser and admin surface | Bounded Rust parser, separate control plane, no content index |
| Failure behavior | Restart loses queue, sender retries | Reject/evict explicitly; no false durability or persistent backup workaround |
| Evidence | OPS/META gates | Malicious relay, collusion simulation, queue pressure, restart/TTL, operator governance review |

#### AUD-09: Private groups and membership

**Scope:** F-037–F-041, F-044. **Verdict:** Conditional on hybrid profile, ordering/freshness, and metadata review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | MLS preferred, hybrid requirement unresolved | Maintained OpenMLS candidate; no classical fallback |
| Relationship privacy | Members know group roster; service should not | Encrypted operations and scoped credentials; group signatures not blanket deniability |
| Network metadata | Client fanout | Recipient-specific wrapping; timing and count costs measured |
| Authority | Admin/member/coordinator distinct | Consent and role validation in addition to MLS validity |
| Persistence | Current/limited old state and local content | Bound epochs/skipped state; no pre-join archive by default |
| Endpoint attack surface | Group protocol/state parser | Current dependencies/advisories; hostile commit/key package fuzzing |
| Failure behavior | Stop forks and unsafe stale sends | No arrival-time resolution, silent election, or stale state clone |
| Evidence | GRP/CRYPTO/META gates | Unauthorized add/remove, all device variants, coordinator loss, fork/partition, library composition audit |

#### AUD-10: Large groups and community umbrella

**Scope:** F-042, F-043. **Verdict:** Shared-mailbox/server-fanout proposal blocked; client-fanout expansion experimental.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Small private groups | MLS can preserve content secrecy but is not enough |
| Relationship privacy | No provider roster/shared room requirement | Shared mailbox can join all readers/writers; rotating IDs do not remove within-epoch linkage |
| Network metadata | Small fanout bursts | Larger fanout leaks volume/capacity patterns; measure, do not claim unchanged |
| Authority | Small-group explicit admin/coordinator | Community-wide admins and directories add authority/linkage; separate scope required |
| Persistence | Group-local state | Umbrella membership/cross-group map adds sensitive state |
| Endpoint attack surface | Bounded group workload | Larger state/buffers/token protocols increase attack surface |
| Failure behavior | Bounded coordinator/queue limits | Large-scale overload must reduce availability, never weaken validation |
| Evidence | Capacity targets only | Comparative metadata analysis and worst-case endpoint/fanout measurements required; no production approval |

Anonymous credentials and Privacy Pass are not sufficient by themselves to make a shared mailbox unlinkable; the architecture and collusion assumptions must be analyzed separately ([Privacy Pass architecture](https://www.rfc-editor.org/rfc/rfc9576.html), [MLS architecture](https://www.rfc-editor.org/rfc/rfc9750.html)).

#### AUD-11: Media sanitization and endpoint transfer

**Scope:** F-031–F-034, F-049. **Verdict:** Conditional on parser containment and actual metadata fixtures.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Protected attachments, local sanitize | Same, encrypted staging and bounded worker |
| Relationship privacy | Same chat recipients | No external transcoder, URL thumbnail, or metadata service |
| Network metadata | Attachment size/transfer activity | Padded chunks reduce lengths but volume remains |
| Authority | User chooses file/recording | Picker does not grant send; preview and Send remain separate |
| Persistence | Local protected cache | Unsent staging TTL and worker crash cleanup explicit |
| Endpoint attack surface | Codec/document parsers | More formats add attack surface; sandbox/memory/CPU constraints mandatory |
| Failure behavior | Unsafe file rejected/disclosed | No silent “cleaned” label or plaintext temp fallback |
| Evidence | MED/SEC gates | Malformed media corpus, decoder fuzzing, metadata residual checks, worker escape tests |

#### AUD-12: External attachment blob service

**Scope:** F-036. **Verdict:** Blocked in strict production baseline until new observer/persistence equivalence is established.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Endpoint transfer / separately gated store | Ciphertext-only store can preserve content secrecy |
| Relationship privacy | No necessary common blob observer | Common blob ID/access patterns can join recipients |
| Network metadata | Endpoint/relay transfer timing | New storage service sees upload/download, size buckets, retries |
| Authority | User endpoints control availability | Bearer fetch capabilities add leakage/theft/revocation semantics |
| Persistence | No automatic external durable copy | New ciphertext persists outside device/RAM queue |
| Endpoint attack surface | Attachment parsers | Upload/resume/token/manifest APIs added |
| Failure behavior | Delivery may require endpoint online | Store outage must not enable direct/plain storage |
| Evidence | Architecture unresolved | Explicit baseline comparison, token lifecycle review, multi-device/resume/TTL/crash tests; consent insufficient |

#### AUD-13: Device pairing and selected history

**Scope:** F-050–F-052. **Verdict:** Preserves by design, unverified.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Fresh endpoint sessions, selected history | Same; no copied live ratchet/leaf |
| Relationship privacy | New device learns selected scopes | No full profile roster/nicknames/wallet copied |
| Network metadata | Pairing and transfer activity | Protect transfer context; size/date range remains observable by participants |
| Authority | Controller grants, peer/group admission | Pairing does not bypass admission; zero scopes/history initially |
| Persistence | Explicit history recipient expansion | Manifest/range and destination visible before transfer |
| Endpoint attack surface | Pairing/archives/FFI | Typed bounded import, compared transcript, cancellation |
| Failure behavior | Partial grants visible | No universal trust after interruption; per-scope status |
| Evidence | DEV/SYN/BKP gates | Replay/mismatch, locked scope, future-chat denial, partial completion, archive exclusions |

#### AUD-14: Revocation, controller migration, and loss

**Scope:** F-053–F-055, F-094. **Verdict:** Conditional on continuity/freshness design; no automatic companion promotion.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Old copies retained; future access revoked as state propagates | Same, honest applied/pending states |
| Relationship privacy | Scoped device identities | No provider universal device inventory |
| Network metadata | Revocation/update messages | Prioritize without exposing control type unnecessarily |
| Authority | Explicit migration, separate recovery candidate | Fresh successor state, no timestamp arbitration or archive cloning |
| Persistence | Old keys/backups may survive | Explain conflict/old-controller risk; no erase-everywhere claim |
| Endpoint attack surface | Authority event/recovery parser | Reviewed transitions and bounded journal |
| Failure behavior | Offline senders may be stale | Strict freshness trades availability; irrecoverable loss may require new identity/group |
| Evidence | DEV/RECOVER gates | Old device still online, duplicate successors, interrupted transfer, offline participants, rollback |

#### AUD-15: App/chat lock, panic, and profile deletion

**Scope:** F-065–F-067, F-070, F-071, F-103. **Verdict:** Preserves by design, unverified; destructive experiments not production.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | App lock and per-chat keys distinct | Same, key leases/search/media caches cleared on lock |
| Relationship privacy | Generic notifications and previews | No route/contact/wallet detail in locked error surfaces |
| Network metadata | Locked ciphertext may queue | No unlock pulse analytics; background behavior documented |
| Authority | Local unlock distinct from wallet authority | Panic cannot sign, revoke remote device, or wipe ambiguously |
| Persistence | Protected DB, best-effort erasure | WAL/cache/backup behaviors tested; wallets protected from chat reset |
| Endpoint attack surface | OS lock/biometric/clipboard | Narrow adapters and no secret clipboard by default |
| Failure behavior | No plaintext fallback | Reboot/process death returns locked; disk-full does not export temp plaintext |
| Evidence | SEC/PLAT tests | Memory/storage/recents/clipboard/notification/accessibility/lock-race tests |

#### AUD-16: Decoy, disguise, and destructive dead-man options

**Scope:** F-068, F-069, destructive part of F-070. **Verdict:** Experimental/deferred; no forensic-deniability assurance.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Optional concealed local state | No weakening of real vault encryption |
| Relationship privacy | Filesystem/app artifacts may reveal hidden use | Same residual; do not market invisible app |
| Network metadata | Alternate icon does not change traffic | No invisibility implication |
| Authority | Local deliberate configuration | No remote trigger; auto-lock preferred |
| Persistence | Flash/backups can retain traces | Key destruction cannot prove every physical copy gone |
| Endpoint attack surface | Alternate launcher/credential paths | More high-risk code, false-trigger states |
| Failure behavior | Coercion/clock/non-use risks | Never wipe from ambiguous PIN or accidental timeout |
| Evidence | No validation | Human safety review, platform forensics, irreversible-action tests; feature stays disabled |

#### AUD-17: Platforms, notifications, and desktop rendering

**Scope:** F-072, F-073. **Verdict:** Conditional per platform; existing v0.5 platform exception is not a new blanket exemption.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | No content keys in push/share extensions | Same; JS receives only permitted UI plaintext |
| Relationship privacy | Minimal push token/wake mapping | Token reuse/collusion can join scopes; no hidden global device directory |
| Network metadata | Platform services outside app Tor guarantee | Clearly disclosed; default iOS app-open |
| Authority | Push cannot admit/unlock/capture | Same; desktop IPC cannot create grants/spend from content |
| Persistence | OS preview/search/backup restrictions | Actual webview/JS caches/extensions tested |
| Endpoint attack surface | Platform services/rendering/FFI | RN/JSI/Tauri/CSP/custom commands increase composition surface |
| Failure behavior | OS may suspend/force-stop | Availability decreases rather than key protection relaxed |
| Evidence | PLAT/DESK/IOS gates | Real non-debug devices, lock/reboot/force-stop/push denial, webview injection/IPC tests |

#### AUD-18: Calls and handoff

**Scope:** F-045–F-048. **Verdict:** Experimental; production blocked where new media observer/association exceeds baseline.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Gated encrypted media candidate | Dedicated call-only keys, no nonparticipant decryption |
| Relationship privacy | Media relay associations disclosed | Multiple streams may be joined to call; no metadata-free claim |
| Network metadata | Tor-only duration/volume | Must prove no UDP/STUN/direct path; latency constraints remain |
| Authority | Explicit call endpoints/capture | New chat device cannot silently join call |
| Persistence | Bounded buffers, no recordings | No automatic transcript or failed-call recording |
| Endpoint attack surface | Codecs, mic/camera, media stack | Large new surface requires sandboxing/audit |
| Failure behavior | Pause/end on unsafe route/rekey | No direct fallback, pre-consent capture, or double microphone handoff |
| Evidence | CALL/META gates | Packet capture actual stack, sender spoof/replay, capture instrumentation, rekey/handoff interruption |

#### AUD-19: Wallet activation and existing-wallet connection

**Scope:** F-074, F-078–F-080. **Verdict:** Conditional isolation; contact spend from linked/unknown history blocked.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Separate XMR wallet keys | Separate BTC/ETH roots/stores; watch-only/hardware connection |
| Relationship privacy | No stable shared chat/wallet ID | Local bridge map unavoidable for intentional contact payment; protected/minimized |
| Network metadata | XMR node traffic over Tor | New chain sync/provider patterns; no claim of baseline equivalence automatically |
| Authority | Separate wallet authorization | Connect never asks seed; chat pairing grants no spending |
| Persistence | Wallet recovery separate | Descriptors/public addresses are sensitive; source labels local |
| Endpoint attack surface | One wallet stack | Additional chain/hardware/PSBT parsers contained or module disabled |
| Failure behavior | Node unavailable fails closed | No hosted-wallet/RPC direct fallback; unknown history remains quarantine |
| Evidence | WAL/FIN gates | IPC attacks, independent key roots, wallet-free build, egress captures, provenance-policy tests |

#### AUD-20: XMR receive/send

**Scope:** F-075, XMR portions of F-081/F-082/F-085. **Verdict:** Preserves intended baseline only after exact implementation review.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local spend/view keys, encrypted requests | Same; no hosted scan view-key export |
| Relationship privacy | Local contact/subaddress map, intended peer sees request | Same; map not default-synced/exported |
| Network metadata | Remote node timing/query/broadcast observations | Exact RPC/decoy/trusted flags reviewed; Tor does not hide query contents from node |
| Authority | Separate recipient/amount/fee review | Same, revision-bound local authorization |
| Persistence | Local wallet history and separate seed | Chat-card minimization cannot erase needed wallet recovery |
| Endpoint attack surface | Wallet/node/hardware adapter | Rust library must supply complete wallet policy and current consensus support |
| Failure behavior | Reorg/offline/restore state explicit | No universal unlock-time promise or chain claim from peer message |
| Evidence | WAL/PAY gates | Node malice, fee/decoy tests, restore height, hardware exact matrix, reorg and crash tests |

#### AUD-21: BTC/ETH contact payments

**Scope:** F-076, F-077, contact-spend portions of F-081/F-082/F-088. **Verdict:** Blocked where public-chain/RPC disclosure exceeds private-payment baseline.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Private-chain request model | Chat remains encrypted, but public transfer details are outside it |
| Relationship privacy | No public sender/recipient/amount edge of the same kind | BTC/ETH ledger/source history may link counterparties; fresh addresses do not erase it |
| Network metadata | XMR node query patterns | ETH RPC sees queried account; BTC block/broadcast patterns remain |
| Authority | Explicit signing | Same, but more transaction types/contracts would expand authority |
| Persistence | Private wallet records | Public-chain records persist independently of app deletion |
| Endpoint attack surface | XMR stack | BTC/ETH parsers, fee/nonce/PSBT/hardware/contract risks |
| Failure behavior | Chain-specific send states | Reorg/conflict/nonce replacement must not cause duplicate authorization |
| Evidence | No equivalence established | No opt-in warning can close known ledger regression; management-only scope is the safe reduced release |

#### AUD-22: Payment bridge, scheduling, guardrails, and card retention

**Scope:** F-081–F-086. **Verdict:** Conditional on strict local authority and retention implementation.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Typed E2EE request, no automatic spending | Same, bounded transient bridge read models |
| Relationship privacy | Local intentional payment mapping | Minimize map; financial cards only one-to-one; no group completion event |
| Network metadata | Request and transaction timings can correlate | Delay/jitter not claimed to defeat correlation |
| Authority | Separate signing/broadcast review | Unsigned schedule preferred; future auto-sign unavailable by default |
| Persistence | Local request/history | Card detail expiry distinct from wallet/chain retention; no unsafe pending-state purge |
| Endpoint attack surface | Request parser | Version/amount/network/address/revision checks; no arbitrary calldata |
| Failure behavior | Duplicate/expired request handled | Expired request does not reverse broadcast; copied signed transaction may escape cancellation |
| Evidence | PAY/FIN gates | Substitution/replay, stale review, lock-at-deadline, source policy, card-retention/refund preservation tests |

#### AUD-23: Payjoin, stealth receive, swaps, and external privacy tools

**Scope:** F-087–F-091. **Verdict:** Experimental/deferred; not a no-regression pass.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | No exchange/mixing service | New external protocols see role-specific payment information |
| Relationship privacy | No protocol coordinator/maker/watcher | Counterparties, coordinators, gas funders, pools, or watchers can add association |
| Network metadata | Existing wallet requests | New discovery, contract, directory, timeout, and settlement patterns |
| Authority | User wallet signing | Watcher/adaptor/recovery secrets may confer power; no generic monitor-only assumption |
| Persistence | Ordinary wallet history | New recovery journals, contract state, exported files, pending deadlines |
| Endpoint attack surface | Wallet protocol | External engines/PSBT/contract/proof parsers are significant expansion |
| Failure behavior | No timelocked swap obligation | Missing deadlines/fees/reorg can lose funds; phone background not assumed |
| Evidence | No TGP evidence | Protocol-specific independent audit, legal opinion, watcher simulation, external-tool format tests; mainnet disabled until complete |

#### AUD-24: Backups, offline signing, diagnostics, releases, and funding

**Scope:** F-092–F-102, F-104. **Verdict:** Preserves by design with explicit independent gates; recovery additions deferred.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Encrypted selected archive; separate wallet backup | Same; no seeds/live state in ordinary archive/support export |
| Relationship privacy | Local diagnostics, separate billing | No production graph, export preview, no global entitlement join |
| Network metadata | Opt-in checks via protected transport | Same, no automatic remote crash/engagement/price calls |
| Authority | Restore content not live membership | Drill non-authoritative; signed updates do not bypass local security |
| Persistence | User-selected archives may survive | Explicit destination/old-copy warnings, no server sync |
| Endpoint attack surface | Archive/update/QR/file parsers | Bounded type markers, signature/rollback checks, reproducible supply chain |
| Failure behavior | Corrupt restore fails safe | No live-state clone, unsigned update, or support recovery backdoor |
| Evidence | BKP/DIST/OPS/MET gates | Hostile archives, rollback/reproducibility, redaction, wallet-free build, cohort consent tests |

#### AUD-25: Blocking, activity signals, and external links

**Scope:** F-014, F-027, F-028. **Verdict:** Blocking and inert links preserve by design, unverified; additional activity signals remain off and require a separate no-regression result.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local block and explicit external opening | Block never exports content; link rendering never fetches; external browser receives only deliberate handoff |
| Relationship privacy | No public block list; activity signals off | Block list stays local; typing/read/last-online cannot silently reveal relationships/activity |
| Network metadata | Protected delivery; no automatic previews | Blocking stops applicable local subscriptions; external opening is a separate disclosed browser boundary |
| Authority | User controls local block and external launch | Peer message cannot unblock, enable signals, open a handler, or alter settings |
| Persistence | Local block state; external history beyond client control | Preserve local block after restart; clipboard/browser may retain deliberately exported URL |
| Endpoint attack surface | URL parser and optional OS handler | Strict scheme/type/length validation; no script/file/command activation from content |
| Failure behavior | No content fetch without action | Malformed link inert; blocked capability update may remain pending; no global erase/ban claim |
| Evidence | Local privacy and transport gates | TST-012/014/019; blocking idempotency; URL parser fuzzing; default read/typing packet captures |

#### AUD-26: Privacy Report and local checks

**Scope:** F-060. **Verdict:** Preserves by design, unverified; external observer tests require a distinct disclosure and cannot establish universal anonymity.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | Local diagnostics need no message keys | Report inspects bounded transport/config evidence, not chat bodies or wallet secrets |
| Relationship privacy | No central privacy-score dashboard | No user/contact/queue IDs uploaded; exported evidence previewed |
| Network metadata | Explicit checks may themselves generate traffic | Local checks default; external test names destination/observation before consent |
| Authority | Diagnostics not a security override | A failed check cannot change node/bridge, disable Tor, or grant permissions automatically |
| Persistence | Bounded local evidence | Timestamp/config scope and clear control; no permanent behavior history |
| Endpoint attack surface | Instrumentation and evidence parser | Bounded local results; no arbitrary diagnostic script from server |
| Failure behavior | Missing evidence is not success | Not tested/Inconclusive distinguished from scoped Passed; offline checks remain honest |
| Evidence | Local check and export tests | TST-020/053; zero external packets before consent; result provenance and redaction review |

#### AUD-27: Cover traffic, volunteer proxy, VPN, and nearby radio

**Scope:** F-061–F-064. **Verdict:** Experimental; each remains independently disabled until its eight-dimension delta is acceptable.

| Dimension | v0.5 before | v0.6 after / condition |
|---|---|---|
| Content confidentiality | E2EE protected online path; optional experiments | Cover traffic carries no extra plaintext; proxy relays others' traffic, not content keys; VPN scope and nearby E2EE each separately reviewed |
| Relationship privacy | No proximity directory or volunteer identity account | Nearby radio can expose proximity; proxy/VPN may create new observations; none silently joins contact identity |
| Network metadata | Tor metadata limits retained | Cover traffic changes volume/timing; proxy reveals contribution; VPN affects other-app routing; radio exposes discovery identifiers |
| Authority | Explicit opt-in for each experiment | No invitation/remote command enables radio, VPN, proxy, or lower-padding mode; OS VPN permission is not wallet authority |
| Persistence | Minimal local experimental configuration | No remote participation ledger, nearby contact database, or bandwidth-reward identity |
| Endpoint attack surface | Optional transport/radio/OS APIs | Separate dependencies/permissions/sandboxes and parser tests; resource caps per experiment |
| Failure behavior | No hidden automatic fallback | Proxy stop does not break chat assumptions; VPN scope failures honest; radio never auto-activates when Tor fails |
| Evidence | Separate experiment and platform gates | Captures, timing/bandwidth/battery measurements, OS kill-switch scope, proximity analysis and lawful-use review for each exact mode |

### Disclosure ledger

#### Actor-specific minimum observations

| Actor | May receive/observe | Must not receive | Retention rule |
|---|---|---|---|
| Intended direct peer | Shared profile fields, plaintext content, its endpoint/security state, explicit financial request | Unrelated contacts, full wallet inventory, local private labels | Peer controls its own copies |
| Admitted group member | Group content/roster/roles and scoped endpoints | Unrelated relationship map, pre-join archive by default | Local policy; copying remains possible |
| Ingress relay | Opaque envelope, next relay role, timing/size bucket | Content keys, plaintext roster, wallet data | RAM queue and minimal live state only |
| Destination relay | Queue capabilities, timing/size/poll patterns | Content keys, civil identity, provider-readable people directory | Seven-day upper queue TTL; no durable promise |
| Rendezvous | Expiring opaque ceremony mailbox/activity | Names, wallet fields, universal profile ID | One use/ten-minute proposed expiry |
| Directory distributor | Generic infrastructure manifest fetch | Contact set, wallet account list | No per-client history |
| Optional blob service | Ciphertext objects, size buckets, fetch activity | Decryption key/plaintext | Disabled pending review |
| Optional media relay | Encrypted streams and session/volume associations | Content keys/plain media | Bounded live buffers; feature gated |
| Platform push service | Token/wake timing under opt-in mode | Body/sender/title/amount/balance/keys | Platform policy plus reviewed mapping expiry |
| BTC peer/node | Filters/blocks requested and broadcast transaction as applicable | xpub/address query in approved filter mode; chat labels | External operator behavior not controlled by TGP |
| ETH RPC provider | Queried account/method/time and submitted transaction | Contact labels, chat IDs, full unrelated portfolio batching | External operator behavior not controlled by TGP |
| XMR remote node | RPC/broadcast patterns according to exact wallet implementation | Private view/spend key, contact ledger | External behavior not controlled by TGP |
| Hardware signer | Necessary transaction/policy data | Chat history/contact graph by default | Device/vendor implementation reviewed |
| External financial tool | Explicit export fields/protocol data | Universal messaging identity or unrequested seed | Tool-specific disclosed policy |
| Support | Only previewed chosen diagnostic/report fields | Seeds, private keys, full archives by routine request | Published case retention required |
| Billing processor | Separate purchase information | Messaging contact/group map | Applicable minimum legal/business retention |

No table entry means “this actor learns nothing.” External service retention cannot be guaranteed by a local client; if it is material to a no-regression requirement, absence of enforceable evidence blocks the dependent feature.

#### Mandatory delta form

Every implementation change includes:

```text
Change ID / feature / build / platform / owner
Baseline requirement and exact capability configuration
Observer and colluding-observer sets
Data fields before and after
Destination and transport before and after
Recipient/authority set before and after
Retention and deletion before and after
Linkability/equality/timing/size effects
Endpoint parser/permission/dependency changes
Outage/crash/rollback/partition behavior
Required tests, independent review, findings, remediation
Verdict and scope; no aggregate percentage
Security/product/platform/operations approval
```

### Blocking issues and remediation order

| Issue | Consequence | Required resolution |
|---|---|---|
| SEC-B01 Scoped identity/library composition | Global credentials could link unrelated chats | Independent protocol/metadata review before direct release |
| SEC-B02 Invitation hybrid composition | Low-entropy ceremony may not meet inherited PQ/anti-guess requirements | Select reviewed complete protocol; do not handwrite combiner |
| SEC-B03 Group hybrid suite | Candidate libraries/drafts are not approved production profile | Exact suite/dependency/interoperability/advisory review |
| SEC-B04 Authority freshness | Offline endpoints can send under stale membership | Define strict freshness and availability cost; test partitions |
| SEC-B05 Mobile wallet boundary | Same-process modules may not meet isolation | OS-qualified boundary or separately installed/disabled financial module |
| SEC-B06 Public-chain contact linkage | BTC/ETH transfers can expose relationships | Keep contact spending blocked under strict rule |
| SEC-B07 Shared group mailbox | New provider-readable activity grouping | Keep server-fanout/mailbox experiment off; prove equivalence or reject |
| SEC-B08 External blob persistence | New observer/retained ciphertext | Endpoint transfer baseline; external service remains blocked |
| SEC-B09 Live calls | New media metadata/parsers/platform assumptions | Independent feasibility/security/metadata gates |
| SEC-B10 Swap deadlines/control | Missed actions or excessive watcher power | Exact engine, coverage proof, recovery tests, legal approval |
| SEC-B11 Recovery conflict | Copied authority creates competing controllers | No automatic continuity/companion promotion |
| SEC-B12 Legal/service classification | Noncustodial label may not resolve operational duties | Jurisdiction-specific counsel opinion before distribution/service |

#### Review conclusion

v0.6 is more specific and testable than v0.5, but specificity is not proof of security improvement. Direct messaging, local organization, scoped devices, retained XMR design, and carefully bounded UX can target the existing privacy contract; large shared mailboxes, external blob retention, public-chain contact payments, live media, and swap integrations remain blocked or experimental where their new exposures are unresolved.

No deadline, usability score, funding need, or opt-in checkbox overrides that conclusion. The release gates must be met capability by capability, and the final legal section independently constrains where and how each approved capability may be offered.

---

## First Thirty Days and UI System

This volume specifies the navigation, safe tap budgets, contextual education, first-thirty-day journeys, visual system, and interaction rules. The companion screen catalog defines each supported screen/sheet/control contract; experimental capabilities have a disabled explanation rather than a misleading enabled pathway.

### Navigation and information architecture

#### Primary navigation

```text
Before wallet activation:          After wallet activation:
Chats | You                       Chats | Wallet | You

Chats
  Search
  All / Compared / Needs review / Locked filters
  Conversation list
  + : Connect / New group
      Request / Pay / Swap only after wallet activation and capability eligibility

Direct conversation
  Header: contact + independent trust/route states
  Timeline: text, media, security events, eligible payment cards
  Composer: text / attachment / voice / send
  Header tap: Contact details
    Compare identity / Shared media / Disappearing messages / Lock chat
    Devices in this chat / Block / Delete
    Pay or Request only when enabled and eligible

Group conversation
  Header: group + actual membership state
  Timeline/composer
  Header tap: Group details
    Members / Pending invites / Policy / Shared media / Leave
    Add/remove only for authorized role
    Pay privately opens selected person's 1:1; no group payment card

Wallet, after explicit activation
  Wallet selector
  Sync/provenance status
  Receive / Pay / Request
  History
  + Add wallet
  Advanced financial tools behind wallet settings

You
  Local profile and per-contact presentation guidance
  Devices
  Privacy & Network
  Security & Vault
  Backup & Restore
  Notifications
  Help & Tutorial
  Privacy Report
  About & Build
  Advanced
    Relay / node / bridge overrides
    Cover traffic / volunteer proxy / device-wide VPN experiments
    Financial adapters / offline signing / source labels
    Continuity archive / disguise / destructive experiments
```

The global plus menu must not become a wall of financial tools. It starts with Connect and New group; optional items appear only after the relevant module is explicitly activated and qualified, with unavailable experiments represented in Advanced rather than the main action list.

#### Desktop adaptation

Use a navigation rail, chat list, main pane, and optional detail pane. Keep the same action labels and authority semantics; keyboard shortcuts are accelerators, never alternate security paths.

No browser-tab client is implied. Closing a window does not mean locked; the tray/background preference and lock status are explicit, and OS session lock invokes the selected local lock policy.

### Tap counting and safe friction

#### Counting convention

A tap is one activation of an app control. Typing, scanning time, scrolling, biometric/OS prompts, file-picker navigation, hardware-wallet interaction, and independent comparison time are measured separately rather than hidden in a flattering count.

The budget begins on the named screen in an unlocked state. Extra taps caused by a changed key, locked vault, missing permission, offline route, or consequential review are legitimate safety branches and are reported separately.

| Task | Routine pathway | App tap target | Mandatory extra work |
|---|---|---:|---|
| Open a chat | Chats → conversation | 1 | Chat unlock if configured |
| Send text | Chat → type → Send | 1 after typing | Trust changes block send |
| Connect by in-person QR | Chats + → Connect → Scan → confirm provenance | 4 | OS permission, scan, peer ceremony |
| Show invite QR | Chats + → Connect → Show mine | 3 | No system sharing by default |
| Remote invite | + → Connect → Remote invite → create | 4 | Secret conveyed separately; no auto-verification |
| Compare existing contact | Chat header → Compare | 2 | Actual comparison + explicit match |
| Reply | Long press → Reply | 2 | Type and Send counted separately |
| React | Long press → reaction | 2 | Removal via selected reaction |
| Image send | Attachment → Photos → select → Send | 4 | OS picker, sanitization, preview |
| Voice note | Voice → Record → Stop → Send | 4 | Permission and preview; cancel always visible |
| New group | + → New group → select people → Review → Invite | 5 plus selections | Acceptance/admission asynchronous |
| Group members | Group header → Members | 2 | Role actions separate |
| Link device | You → Devices → Link | 3 | Reauth, scan, both-screen comparison, grants/history review |
| Lock now | You → Lock now | 2 | Panic accelerator may be 1 |
| Search | Chats → Search | 1 | Locked content excluded |
| Activate wallet | You → Wallet → Activate | 3 | Separate explanation and chain/connection choices |
| Receive | Wallet → Receive | 1 | Wallet/amount/address reveal as required |
| Pay from chat | Contact details → Pay → review | 2 to review | Eligibility, amount, signing, separate authorization |
| Backup | You → Backup & Restore → Export | 3 | Scope, passphrase, destination, confirmation |
| Revoke device | You → Devices → device → Revoke | 4 | Reauthentication and retained-copy warning |
| Privacy report | You → Privacy Report | 2 | External test requires separate consent |

No performance target rewards skipping verification, removing the recipient review, preselecting all chats, or combining backup and wallet recovery into an ambiguous Continue.

### First-thirty-day journeys

#### Day zero: installation to the first contact

1. Download a signed supported build; installation/store behavior remains a platform boundary.
2. Optional About/Build inspection before creating a profile.
3. Welcome explains no registration and concise limits.
4. Enter optional display name; no uniqueness check or public username.
5. Confirm local protection; no seed or financial setup.
6. Tor bootstrap and key preparation run behind the name/protection work where safe.
7. Empty Chats offers Connect and three dismissible local hints.
8. Connect offers Show QR, Scan QR, and Remote invite.
9. In-person scan binds keys and explicit physical provenance; remote link remains not independently compared.
10. Complete contact/session establishment and display truthful state.
11. Type/send a first message; local queued bubble appears promptly.
12. Inspect receipt details if desired; no read receipt or last-online by default.

Offline branch: create local profile and draft, explain unavailable route, retry through permitted transport. Wrong/expired invite branch: terminate attempt and generate fresh material; never silently reuse a compromised invite.

#### Days one through three: everyday messaging

Try reply/reaction/edit, encrypted local search, a second contact, local pin/mute/archive, one sanitized image, and a voice note. Contextual hints appear only at the relevant control and can be dismissed permanently.

Permission denial is normal: manual invitation entry remains available without camera; typed messaging remains available without microphone/photos. No repeated permission nag or contacts permission is required.

Notifications are a deliberate availability choice. iOS starts with app-open delivery; platform notices disclose the different metadata path before registration.

#### Days three through seven: small group and desktop

Create an invitation-only group from existing contacts, review roster/policy, send invitations, and wait for acceptance/admission. Pending people are not shown as readers.

Link a desktop as a companion using both-device comparison. Select chats from an initially empty list, choose no history or an explicit range, review once, then show per-scope active/pending progress; no wallet or future-chat grant.

If groups are not qualified, the same path ends at a truthful availability sheet. It cannot secretly use a classical profile, server-readable room, or all-device trust shortcut.

#### Week two: local protection and recovery preparation

Set a per-chat vault, try lock/unlock, configure optional prospective disappearing messages, export a selected encrypted archive, and run a non-authoritative recovery drill. Teach Keep versus expiry and delete-here versus requested deletion before consequential use.

Privacy Report shows scoped results: Tested path passed, Issue detected, Not tested, or Inconclusive. It never presents a universal privacy percentage.

#### Week three: optional wallet

Open Wallet explicitly and choose create, hardware/watch-only connect, or restore. Existing BTC/ETH funds enter management-only provenance review; no seed is requested on Connect.

Configure the appropriate node mode, sync locally, reveal a receive address deliberately, and review the difference between public-chain transfer, provider query privacy, chat encryption, and local contact mapping. A blocked contact-spend action remains blocked even if the user accepts a warning.

For an eligible retained XMR payment flow, view/request in one-to-one chat, review exact amount/network/recipient/fee, separately authorize, and follow chain-specific state. Backup and drill wallet recovery independently.

#### Week four: trust changes and long-term maintenance

Exercise a contact key change, a new endpoint awaiting approval, a lost-device revocation, an offline participant still pending update, and controller migration/loss explanation. Never imply that removing a device erases its stored content.

Review build/update evidence and perform an archive drill. Advanced swap/external-tool screens explain why unavailable capabilities are disabled and what evidence is missing; the thirty-day journey does not require a user to risk real funds.

### Shared screen contract

#### Layout and controls

Every screen has a visible title, one clear primary action when meaningful, and a discoverable Back/Close control. Sensitive full-screen review flows do not dismiss through accidental outside taps; destructive actions use explicit wording.

Buttons implement enabled, disabled-with-reason, pressed, focused, loading, success, and error states. Double tapping cannot duplicate sends, grants, exports, or payments; the Rust core enforces idempotency beyond visual disabling.

Long press and swipe are optional accelerators. Every action also has an accessible labeled control; swiping cannot silently spend, export, grant, or destroy.

#### Universal states

| State | Required behavior |
|---|---|
| Empty | Explain what exists and offer the next safe action; no fabricated example contact/balance |
| Loading | Show local/remote stage; cancellation remains possible before irreversible effect |
| Offline | Permit safe local work; label queued/not broadcast; no direct fallback |
| Locked | Remove relevant plaintext and require appropriate unlock; no previews behind blur |
| Error | State what did and did not happen, plus a safe next step |
| Partial | Show per-scope/per-endpoint/per-file status; no global success check |
| Permission denied | Explain limited capability and offer non-permission alternative where possible |
| Unsupported | Name required version/capability without enabling weaker mode |
| App backgrounded | Apply lock/capture policy; late async callbacks cannot revive plaintext |
| Disk full | Stop protected writes safely; never use unencrypted temporary storage |
| Cancelled | Return to prior safe state; explain if any external effect already happened |

#### Network and disclosure behavior

Every app-managed request goes through the broker. Screens with no network action must remain genuinely offline-capable; opening a tab must not trigger hidden price, avatar, analytics, token, node, or update requests.

An OS picker/share sheet, external browser/wallet, platform notification registration, hardware device, nearby radio, or support upload is a boundary transition. Show it at the point of use, not only in a privacy policy.

#### Accessibility

Read titles, warnings, exact recipient/amount/network, trust provenance, and pending states in logical order. Critical state changes receive a polite announcement; errors requiring action receive clear focus without stealing input repeatedly.

Support dynamic text, large touch targets, keyboard navigation, visible focus, reduced motion, high contrast, and non-camera comparison alternatives. Never depend only on color, gesture, tiny caption, hover, haptic, or a countdown animation.

#### Navigation and interruption

Back returns to the previous screen without granting authority. For unsent content, offer Keep draft/Discard where meaningful; for signed/exported/broadcast effects, explain actual state rather than promising reversal.

Reentering a review revalidates its current revision. An OS-returned file/QR/signature cannot resume into an already-authorized broadcast after the original review expired or the wallet locked.

### Visual design specification

#### Palette retained from v0.5

| Token | Hex | Meaning |
|---|---|---|
| `bg.primary` | `#1C211A` | Main near-black olive canvas |
| `surface.primary` | `#252B21` | Cards, navigation, sheets |
| `surface.raised` | `#303729` | Raised/selected surfaces |
| `brand.forest` | `#324D3F` | Structural forest panels |
| `brand.tan` | `#D4C6A6` | Warm secondary surface |
| `text.primary` | `#F4EBD9` | Main cream text |
| `text.secondary` | `#B8B09C` | Supporting readable text |
| `accent.gold` | `#C2A14E` | Primary actions and focus |
| `accent.gold.light` | `#E2C27C` | Highlighted foreground |
| `status.success` | `#73B887` | Specifically satisfied positive state |
| `status.warning` | `#E2B75F` | Review, stale, degraded |
| `status.danger` | `#D7786D` | Failure/destructive |
| `text.on-light` | `#1C211A` | Text on tan/gold |

Gold is an action accent, not verification. Green means a specifically supported positive state, not “anonymous,” “safe from all adversaries,” or “settled” when only broadcast.

Typography: 24sp title, 18–20sp section headings, 16sp body, 14sp support, 12–13sp noncritical meta. Use tabular currency figures, 8dp spacing grid, 16dp common gutters, 24dp section gaps, 48dp target touch areas, 16dp cards, and 12dp controls.

The actual composited screens must be contrast-tested against WCAG requirements rather than treating token choice as compliance; normal text and large text have different contrast thresholds, and color alone is insufficient ([WCAG 2.2](https://www.w3.org/TR/WCAG22/)). Topographic texture stays out of message-heavy surfaces, safety numbers, warnings, and amounts.

#### Component inventory

- **Conversation row:** Local display label, minimal permitted preview, independent trust/unread/lock state, no wallet amount by default.
- **Trust header:** Encryption, comparison provenance, pending endpoints, route availability as separate inspectable states.
- **Delivery label:** Queued/relay accepted/received/partial/expired/failed; details show evidence source.
- **Security event card:** Specific changed authority, affected scope, Review action; not an ordinary dismissible promotional banner.
- **Payment card:** Request versus claimed payment versus locally verified chain state; sensitive details can minimize independently.
- **Grant checklist:** None selected initially; scope count and old-history decision separately visible.
- **Review sheet:** Exact intended external effect, current revision, consequence, separate authorization.
- **Disabled capability sheet:** Clear reason, missing evidence/support, safe alternative; no hidden override.
- **Progress list:** Per-scope/per-endpoint state, resumable/cancellable when safe; no false all-done state.
- **Hint card:** Local/dismissible, no overlay over warnings, no remote experimentation/analytics.

### Exact copy rules

| Situation | Required direction |
|---|---|
| Optional name | “This is a display name, not a public username.” |
| Uncompared relationship | “Encrypted. Identity not independently compared.” |
| In-person QR | “Compared from this QR in person.” |
| Transferred comparison | “Comparison record transferred from your controller.” |
| New endpoint | “This device becomes another recipient in the chats you select.” |
| History transfer | “Selected history will be stored on this device.” |
| Revocation | “This blocks future access as updates take effect. It does not erase stored copies.” |
| Offline send | “Queued on this device. Nothing was sent directly.” |
| Public chain | “This transfer is visible on a public blockchain.” |
| Existing wallet | “Connecting does not remove links in this wallet's earlier history.” |
| ETH provider | “This provider can see the address you ask about.” |
| Swap unavailable | “This setup cannot safely cover the required deadlines.” |
| Support | “Review exactly what you will share. Never send your recovery phrase.” |
| Local deletion | “Delete from this device” rather than “Erase everywhere” |
| Legal availability | “This financial feature is not offered in the selected region.” |

Translations require security-copy review for changes to authority, timing, certainty, or scope. A shorter translated label cannot replace “Received by an authorized endpoint” with “Everyone read.”

### Coverage and completeness boundary

The screen catalog enumerates the product-owned states and controls within the declared first-thirty-day scope. OS/store dialogs, external applications, hardware-wallet firmware screens, future protocol-specific swap branches, and unimplemented jurisdiction-specific notices require platform/adapter annexes before those capabilities ship.

That boundary is deliberate: inventing exact third-party screens would be less complete than identifying the dependency. A new screen/control in implementation must be added to the catalog and traceability matrix before release, including its negative states and disclosure delta.

---

## Tap-Level Screen Catalog

This catalog defines the product-owned screens, sheets, controls, and negative states for the first thirty days, including optional and advanced branches. It is a design contract rather than implemented UI; disabled experimental records do not imply those features are available.

Every record inherits the universal state, interruption, accessibility, and transport rules in the UI-system volume. Back, Close, outside-tap, system Back, Escape, keyboard equivalents, and swipe behavior are explicitly constrained below; additional implementation controls require a catalog update.

### Catalog conventions

- **Activation:** Every named control has its specified effect; no other effect is implied. Text entry is local until the explicit submit action.
- **Back and gestures:** Back/Close/Escape returns without granting authority; sensitive review sheets do not dismiss on outside tap. A safe draft may be kept/discarded explicitly. Swipes never sign, spend, export, enroll, or destroy.
- **States:** Each record lists its distinctive states; all also implement empty/loading/offline/locked/error/partial/unsupported/cancelled according to the shared contract.
- **Accessibility:** All records require large text without clipped warnings, labeled controls, visible focus, keyboard/screen-reader parity, non-color status, reduced motion, and accessible alternatives to camera-only ceremonies.
- **Exact copy:** Quoted strings are normative English direction; localization must preserve certainty, scope, and authority. Dynamic names/amounts are escaped, not interpreted as markup.
- **Tests:** Each listed negative criterion supplements the shared Given/When/Then screen tests; no screen is validated merely because its record exists.

### Screen index

| ID | Screen | Availability |
|---|---|---|
| O-01 | Download and installation boundary | Core |
| O-02 | Welcome and concise limits | Core |
| O-03 | Optional display name | Core |
| O-04 | Local protection setup | Core |
| O-05 | Preparing protected connection | Core |
| O-06 | Empty Chats | Core |
| O-07 | Three things to try tutorial | Core |
| O-08 | Contextual permission rationale | Core |
| C-01 | Connect chooser | Core unless marked |
| C-02 | Show one-use contact QR | Core unless marked |
| C-03 | Typed QR scanner and import preview | Core unless marked |
| C-04 | Create remote invitation | Core unless marked |
| C-05 | Enter link and secret | Core unless marked |
| C-06 | Contact/session confirmation | Core unless marked |
| C-07 | Canonical identity comparison | Core unless marked |
| C-08 | Contact details | Core unless marked |
| C-09 | Local label and per-contact presentation | Core unless marked |
| C-10 | Advanced contact link and card | Core unless marked |
| C-11 | Block contact confirmation | Core unless marked |
| M-01 | Conversation timeline and composer | Core |
| M-02 | Chats list and filters | Core |
| M-03 | Message action sheet | Core |
| M-04 | Edit or reply draft | Core |
| M-05 | Reaction picker | Core |
| M-06 | Delivery and event details | Core |
| M-07 | Local search | Core |
| M-08 | Local organization actions | Core |
| M-09 | Delete and requested deletion | Core |
| M-10 | External URL boundary | Core |
| M-11 | Unsupported message or security profile | Core |
| A-01 | Attachment chooser | Collaboration, gated |
| A-02 | Sanitized image preview | Collaboration, gated |
| A-03 | Document/original-file disclosure | Collaboration, gated |
| A-04 | Voice note recording and preview | Collaboration, gated |
| A-05 | Received media viewer and shared media | Collaboration, gated |
| A-06 | Video preparation and preview | Collaboration, gated |
| A-07 | Attachment transfer status | Collaboration, gated |
| A-08 | External blob storage unavailable | Collaboration, gated |
| G-01 | Select group contacts | Collaboration, gated |
| G-02 | Review group and policy | Collaboration, gated |
| G-03 | Invitation and admission progress | Collaboration, gated |
| G-04 | Incoming group invitation review | Collaboration, gated |
| G-05 | Joining group | Collaboration, gated |
| G-06 | Group details | Collaboration, gated |
| G-07 | Members and endpoints | Collaboration, gated |
| G-08 | Group policy and role review | Collaboration, gated |
| G-09 | Remove person or device | Collaboration, gated |
| G-10 | Leave group | Collaboration, gated |
| G-11 | Large group/community unavailable | Collaboration, gated |
| G-12 | Share selected earlier group history | Collaboration, gated |
| D-01 | Device inventory | Collaboration, gated |
| D-02 | Link-device ceremony start | Collaboration, gated |
| D-03 | Compare both devices | Collaboration, gated |
| D-04 | Select conversation grants | Collaboration, gated |
| D-05 | Choose history and review access | Collaboration, gated |
| D-06 | Linking and history transfer progress | Collaboration, gated |
| D-07 | Desktop companion workspace | Collaboration, gated |
| S-01 | Security and Vault hub | Core unless marked |
| S-02 | App locked / panic result | Core unless marked |
| S-03 | App passphrase and inactivity policy | Core unless marked |
| S-04 | Create/change per-chat vault | Core unless marked |
| S-05 | Unlock one chat | Core unless marked |
| S-06 | Disappearing message policy | Core unless marked |
| S-07 | Capture and clipboard controls | Core unless marked |
| S-08 | Advanced local concealment and destructive controls | Core unless marked |
| S-09 | Delete local profile review | Core unless marked |
| S-10 | Read, typing, and availability signals | Core unless marked |
| B-01 | Backup and Restore hub | Core/optional by archive type |
| B-02 | Select chat archive content | Core/optional by archive type |
| B-03 | Archive passphrase and review | Core/optional by archive type |
| B-04 | Choose encrypted archive destination | Core/optional by archive type |
| B-05 | Archive export result | Core/optional by archive type |
| B-06 | Select and unlock chat archive | Core/optional by archive type |
| B-07 | Review archive restore | Core/optional by archive type |
| B-08 | Non-authoritative chat recovery drill | Core/optional by archive type |
| B-09 | Separate wallet backup | Core/optional by archive type |
| B-10 | Wallet no-spend recovery drill | Core/optional by archive type |
| B-11 | Multisig and social recovery study | Core/optional by archive type |
| N-01 | Connection status | Core/Advanced |
| N-02 | Connection assistance | Core/Advanced |
| N-03 | Bridge configuration import | Core/Advanced |
| N-04 | Message relay directory and BYO | Core/Advanced |
| N-05 | Endpoint review and test | Core/Advanced |
| N-06 | Advanced traffic profile | Core/Advanced |
| N-07 | Volunteer proxy and device VPN experiments | Core/Advanced |
| N-08 | Nearby/offline radio experiment | Core/Advanced |
| H-01 | You hub | Core/Advanced |
| H-02 | Notification availability choice | Core/Advanced |
| H-03 | Local Privacy Report | Core/Advanced |
| H-04 | Help and troubleshooting | Core/Advanced |
| H-05 | Diagnostic/report preview | Core/Advanced |
| H-06 | Support export/handoff result | Core/Advanced |
| H-07 | Tutorial and local hints settings | Core/Advanced |
| H-08 | About, licenses, and build evidence | Core/Advanced |
| H-09 | Update review and rollback protection | Core/Advanced |
| H-10 | Advanced hub | Core/Advanced |
| H-11 | Legal availability and user obligations | Core/Advanced |
| H-12 | Funding without chat identity | Core/Advanced |
| H-13 | Consented research and feedback | Core/Advanced |
| H-14 | Security incident notice | Core/Advanced |
| W-01 | Activate optional wallet | Optional, platform/chain gated |
| W-02 | Choose create, connect, or restore | Optional, platform/chain gated |
| W-03 | Existing wallet connection method | Optional, platform/chain gated |
| W-04 | Hardware connection and policy review | Optional, platform/chain gated |
| W-05 | Watch-only import preview | Optional, platform/chain gated |
| W-06 | Provenance and management-only quarantine | Optional, platform/chain gated |
| W-07 | Chain node and privacy profile | Optional, platform/chain gated |
| W-08 | Wallet synchronization | Optional, platform/chain gated |
| W-09 | Wallet home | Optional, platform/chain gated |
| W-10 | Receive address and request context | Optional, platform/chain gated |
| W-11 | Create new wallet and recovery preparation | Optional, platform/chain gated |
| W-12 | Restore wallet recovery | Optional, platform/chain gated |
| W-13 | Wallet settings and source labels | Optional, platform/chain gated |
| W-14 | Offline signing transfer | Optional, platform/chain gated |
| W-15 | Optional fiat estimates | Optional, platform/chain gated |
| W-16 | Silent and stealth receiving experiments | Optional, platform/chain gated |
| P-01 | Create one-to-one payment request | Optional, eligibility gated |
| P-02 | Incoming request card and details | Optional, eligibility gated |
| P-03 | Select payer wallet and amount | Optional, eligibility gated |
| P-04 | Exact payment review | Optional, eligibility gated |
| P-05 | Separate wallet authorization | Optional, eligibility gated |
| P-06 | Hardware or air-gapped signature return | Optional, eligibility gated |
| P-07 | Signed/ready/broadcast decision | Optional, eligibility gated |
| P-08 | Payment progress and chain observation | Optional, eligibility gated |
| P-09 | History and transaction detail | Optional, eligibility gated |
| P-10 | Delay or schedule payment | Optional, eligibility gated |
| P-11 | Spend guardrails | Optional, eligibility gated |
| P-12 | Payjoin negotiation review | Optional, eligibility gated |
| X-01 | Financial tools catalog | Experimental/deferred; mainnet disabled |
| X-02 | Adapter manifest review | Experimental/deferred; mainnet disabled |
| X-03 | Contact swap offer | Experimental/deferred; mainnet disabled |
| X-04 | Swap financial and deadline review | Experimental/deferred; mainnet disabled |
| X-05 | Active swap and recovery | Experimental/deferred; mainnet disabled |
| X-06 | External tool export/import | Experimental/deferred; mainnet disabled |
| R-01 | Contact key changed | Core/Advanced |
| R-02 | New endpoint approval | Core/Advanced |
| R-03 | Revoke lost device | Core/Advanced |
| R-04 | Controller migration | Core/Advanced |
| R-05 | Controller lost | Core/Advanced |
| R-06 | Group or authority conflict | Core/Advanced |
| R-07 | Continuity archive experiment | Core/Advanced |
| L-01 | Pre-call or unavailable call | Experimental; disabled until qualified |
| L-02 | Incoming call and endpoint selection | Experimental; disabled until qualified |
| L-03 | Live call, rekey, and handoff | Experimental; disabled until qualified |
| L-04 | Call ended or failed | Experimental; disabled until qualified |

### Day 0: onboarding

#### O-01: Download and installation boundary

| Record field | Required behavior |
|---|---|
| Entry points | Official distribution page/store before first launch. |
| Layout and elements | Supported platforms; signed artifact/version; verify instructions; store and direct download choices. |
| Every control activation | Platform → show matching artifact; Download → chosen supported distribution; Verify → H-08 instructions; Help → H-04. |
| Distinctive states | Unavailable platform: no fake download; interrupted download: platform retry; not yet installed: no local identity. |
| Exact copy | “Install a supported signed build. A matching hash does not prove your device is uncompromised.” |
| Data read / written | No profile exists. Distribution may expose platform/store account, IP and download activity. |
| Network calls | Distribution is browser/store-controlled, not claimed to pass through the app broker. |
| Cryptographic operations | Artifact signature/digest verified by platform or independent instructions; no messaging keys. |
| Disclosure-ledger effect | Store/website sees distribution metadata; no registration or contact graph. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wrong-platform artifact cannot be presented as supported; verification instructions name exact version/digest. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-02: Welcome and concise limits

| Record field | Required behavior |
|---|---|
| Entry points | First launch after install or confirmed local reset. |
| Layout and elements | Product promise; three concise boundaries; Start; Restore; About. |
| Every control activation | Start → O-03; Restore → B-06; About → H-08; limits row → expanded local explanation. |
| Distinctive states | No permissions requested; offline: all copy works; restored draft setup: Resume label; unsupported OS: block before key creation. |
| Exact copy | “Private conversations without phone-number registration. Recipients can still copy what you send.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: First-launch capture has no account, analytics, contact, wallet, or price request. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-03: Optional display name

| Record field | Required behavior |
|---|---|
| Entry points | O-02 Start. |
| Layout and elements | Optional name field; local-avatar placeholder; Continue; Skip; explanatory label. |
| Every control activation | Name field → local keyboard; Continue → validate bounds then O-04; Skip → empty optional name then O-04; avatar → local picker preview, no automatic upload. |
| Distinctive states | Empty accepted; overlength/control-character input gets field error; offline unchanged; interrupted setup keeps protected draft. |
| Exact copy | “This is a display name, not a public username. You can use a different name with each contact.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate and empty names work without remote availability lookup; Unicode bounds do not corrupt layout. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-04: Local protection setup

| Record field | Required behavior |
|---|---|
| Entry points | O-03 Continue/Skip. |
| Layout and elements | Device-protection availability; app-lock choice; passphrase option; Continue; details. |
| Every control activation | Use device protection → native protected setup; Add app passphrase → S-03; Continue → O-05 only after required protection; Details → local capability explanation. |
| Distinctive states | No hardware feature: honest capability message; no device lock: explain approved alternative; cancellation returns without half-created identity. |
| Exact copy | “App lock protects entry to TGP. Chat vaults and wallet authorization are separate.” |
| Data read / written | Write local protection configuration and wrapped keys only after successful setup. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Biometric cancellation cannot mark setup successful; no silent insecure-key fallback. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-05: Preparing protected connection

| Record field | Required behavior |
|---|---|
| Entry points | Protection succeeds; may overlap safe setup work. |
| Layout and elements | Separate Key preparation and Protected connection progress; Continue locally; Connection help. |
| Every control activation | Continue locally → O-06 with offline banner; Help → N-02; Cancel route attempt → local mode, not identity deletion. |
| Distinctive states | Key failure blocks contact creation; Tor failure permits local UI; progress is stage-based, not fabricated countdown. |
| Exact copy | “Preparing your device and protected connection. Nothing will be sent directly if the route fails.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | Explicit approved Tor/bootstrap/PT activity only; no external IP test. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Keygen and route status remain separate; route loss never shows green from Wi-Fi connectivity. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-06: Empty Chats

| Record field | Required behavior |
|---|---|
| Entry points | Setup complete; no conversations. |
| Layout and elements | Chats/You tabs; Search; +; Connect call-to-action; optional three-task checklist. |
| Every control activation | Connect or + → C-01; Search → M-07 empty state; You → H-01; Try checklist → O-07; dismiss hint → local preference. |
| Distinctive states | Offline: Connect explains queued ceremony limits; locked app: S-02; no fake sample chats or unread counts. |
| Exact copy | “Connect with your first contact. No address-book access is needed.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet tab is absent before activation and checklist dismissal creates no network request. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-07: Three things to try tutorial

| Record field | Required behavior |
|---|---|
| Entry points | Empty Chats hint or H-07. |
| Layout and elements | Connect a contact; Compare identity; Send a message; progress; dismiss/reset. |
| Every control activation | Task → matching safe screen; Dismiss → prior screen and local hide; Reset → local unchecked state; Close → prior screen. |
| Distinctive states | Incomplete stays local; offline tasks can explain next step; no forced slideshow; security warning always above hints. |
| Exact copy | “These tips stay on this device. You can skip them.” |
| Data read / written | Only local checklist completion/hide state; no behavior event upload. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tutorial cannot mark comparison complete or bypass any identity ceremony. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

#### O-08: Contextual permission rationale

| Record field | Required behavior |
|---|---|
| Entry points | First camera/microphone/photo/notification action. |
| Layout and elements | One permission purpose; Allow; Not now; alternative path. |
| Every control activation | Allow → OS permission dialog; Not now → parent unchanged; Enter manually → typed invite where applicable; Open settings only after explicit tap. |
| Distinctive states | Denied/permanently denied/revoked are distinct; app resume rechecks permission; no repeating prompt loop. |
| Exact copy | “Use the camera to scan this code. You can enter an invitation manually instead.” |
| Data read / written | Permission state only; no permission grants inferred from previous attempt. |
| Network calls | No network solely for permission rationale. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Deny camera and complete a manual invite path; mic denial leaves text available. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |


### Contacts and verification

#### C-01: Connect chooser

| Record field | Required behavior |
|---|---|
| Entry points | Chats + → Connect, or empty Chats. |
| Layout and elements | Scan QR; Show my QR; Remote invite; Back. |
| Every control activation | Scan → C-03; Show mine → C-02; Remote invite → C-04; Back → Chats. |
| Distinctive states | Offline: show what can be prepared locally; current invite active: show resume/replace; locked profile: unlock first. |
| Exact copy | “Choose how to connect. Remote links are not an independent identity comparison.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Scanner route is typed and cannot turn a wallet QR into an enrollment grant. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-02: Show one-use contact QR

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Show mine. |
| Layout and elements | QR, expiry, one-use label, Regenerate, Cancel invite, remote alternative. |
| Every control activation | Regenerate → invalidate old then new QR; Cancel invite → burn local state and close; Remote alternative → C-04; received claim → C-06 review. |
| Distinctive states | Expired/burned/claimed: QR unavailable; offline: no claim of discoverability; parallel claimant: review conflict. |
| Exact copy | “One use. Expires in 10 minutes. Show this in person only if you intend to compare this key.” |
| Data read / written | Ephemeral invite, nonce/expiry and persistent used/burned marker; no global name record. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Old QR, replay, simultaneous claim and crash cannot create a second relationship. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-03: Typed QR scanner and import preview

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Scan or authorized pairing/financial scanner. |
| Layout and elements | Camera frame, torch if supported, Enter manually, selected import type, Cancel. |
| Every control activation | Torch → local camera setting; Manual → C-05; scan → typed preview only; Confirm contact QR → C-06; wrong QR type → explanatory route chooser, no action. |
| Distinctive states | Permission denied → O-08/manual; malformed/oversize → reject; camera interruption stops capture; no automatic URL launch. |
| Exact copy | “Review this code before continuing. Scanning does not authorize a payment or device.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receive-address, transaction, config and pairing QR cannot be accepted as a contact invitation. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-04: Create remote invitation

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Remote invite. |
| Layout and elements | Link panel, separate secret panel, expiry, Create, Copy link, Reveal secret, Cancel. |
| Every control activation | Create → reviewed one-use ceremony material; Copy link → copy only link with warning; Reveal secret → protected display; Cancel → burn; Done → wait state. |
| Distinctive states | Do not expose both pieces through one default share action; expired/wrong attempt needs fresh invite; locked hides secret. |
| Exact copy | “Send the link and secret through separate trusted channels. This does not independently compare identity.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Chosen external channel may retain link/secret; TGP never assumes that channel is private. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: One wrong eligible guess burns attempt locally; copy/share excludes the separate secret. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-05: Enter link and secret

| Record field | Required behavior |
|---|---|
| Entry points | C-03 Manual or typed/deep-link preview. |
| Layout and elements | Link field; secret field with visibility toggle; Connect; Cancel. |
| Every control activation | Paste → validate type/length locally; Show secret → temporary reveal; Connect → C-06 after reviewed ceremony; Cancel → clear transient secret. |
| Distinctive states | Missing/malformed input: inline error; expired/used/burned: no retry with same invite; route unavailable: no direct fallback. |
| Exact copy | “A link alone is not enough. Ask the inviter for the separate secret.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Deep link cannot auto-submit, leak secret to clipboard/logs, or accept unknown protocol version. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-06: Contact/session confirmation

| Record field | Required behavior |
|---|---|
| Entry points | Valid QR or remote ceremony candidate. |
| Layout and elements | Peer presentation, comparison provenance, selected security profile, Accept, Decline, details. |
| Every control activation | Accept → persist scoped relationship/session then M-01; Decline → terminal invite cancellation; Details → C-07; in-person checkbox → provenance only after explicit physical-source confirmation. |
| Distinctive states | Changed transcript/profile/mismatch: stop; pending peer: show waiting; offline: no completed contact claim. |
| Exact copy | “Encrypted. Identity not independently compared.” / “Compared from this QR in person.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: A remote QR image cannot be marked in-person compared automatically. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-07: Canonical identity comparison

| Record field | Required behavior |
|---|---|
| Entry points | Contact details → Compare, or establishment review. |
| Layout and elements | Canonical numeric/word/QR representation; provenance; Match; Does not match; accessible text. |
| Every control activation | Show QR → canonical comparison QR; Match → explicit method confirmation then local record; Mismatch → pause scope and R-01; Close → no comparison upgrade. |
| Distinctive states | Key change invalidates old view; locked hides comparison data; transferred record labeled; no truncated short fingerprint. |
| Exact copy | “Compare through an independent trusted channel. Only confirm if the complete representation matches.” |
| Data read / written | Fingerprint, scope, comparison method/date and optional local note. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Stale comparison view cannot verify a new key; screen-reader path exposes full canonical data. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-08: Contact details

| Record field | Required behavior |
|---|---|
| Entry points | M-01 header. |
| Layout and elements | Local label, shared profile, trust provenance, Compare, devices, media, timer, lock, Pay/Request if eligible, Block, Delete. |
| Every control activation | Compare → C-07; Devices → R-02 scoped list; Media → A-05; Timer → S-06; Lock → S-04; Pay/Request → P-03/P-01; Block → C-11; Delete → M-09; Edit label → C-09. |
| Distinctive states | Locked: no private detail; incompatible/pending endpoints visible; financial actions absent/blocked by policy. |
| Exact copy | “These details apply to this relationship, not every device or conversation.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No full profile device inventory or wallet address is fetched merely by opening contact details. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-09: Local label and per-contact presentation

| Record field | Required behavior |
|---|---|
| Entry points | C-08 Edit or You profile. |
| Layout and elements | Private nickname/note; shared-with-this-contact name/avatar; separate labels; Save/Cancel. |
| Every control activation | Edit private fields → local draft; Change shared avatar → local picker preview; Save → local fields plus explicit scoped profile event if shared fields changed; Cancel → discard. |
| Distinctive states | Offline shared change queued; locked unavailable; overlength/unsafe avatar rejected; no global propagation. |
| Exact copy | “Private labels stay here. Shared fields are sent only to this contact.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Local nickname never enters profile event, node request, contact card, or diagnostic export by default. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-10: Advanced contact link and card

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Contact tools. |
| Layout and elements | Separate reusable-link and signed-card sections; disabled status; explicit field preview; revoke/export. |
| Every control activation | Reusable link → disabled-gate explanation until approved; Card fields → opt-in selection; Export → boundary review if qualified; Revoke link → capability invalidation, not recipient erasure. |
| Distinctive states | Unqualified capability has no Create button; signature evidence warning before export; old cards may survive revocation. |
| Exact copy | “A signed card can be kept and shown to others. It is not used as your payment identity.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Portable signatures/reusable capabilities may link contexts; no default activation. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet fields/private labels excluded; signed-card export cannot silently enable a reusable link. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

#### C-11: Block contact confirmation

| Record field | Required behavior |
|---|---|
| Entry points | C-08 Block or unsolicited request review. |
| Layout and elements | Affected relationship, stop-receipt explanation, optional delete-here choice unchecked, Block/Cancel. |
| Every control activation | Block → stop local fanout/subscriptions and rotate/revoke applicable capabilities; Delete here → separate M-09 review; Cancel → no effect. |
| Distinctive states | Offline: applied here/pending remote capability update; existing peer copies retained; repeated block idempotent. |
| Exact copy | “This stops this relationship here. It does not erase messages stored by the other person.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Block cannot delete wallet funds, revoke unrelated contacts, or claim a global identity ban. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |


### Everyday messaging

#### M-01: Conversation timeline and composer

| Record field | Required behavior |
|---|---|
| Entry points | Chats row or completed connection. |
| Layout and elements | Trust/route header; timeline; composer; attachment; voice; Send; details; optional qualified call. |
| Every control activation | Header → C-08/G-06; Text → local draft; Send → core validation/outbox; Attachment → A-01; Voice → A-04; long press → M-03; status → M-06; Call → L-01 only if qualified. |
| Distinctive states | Empty prompts first message; offline labels queued; locked → S-05; pending authority/key change blocks send; partial receipt explicit. |
| Exact copy | “Queued on this device.” / “Accepted by relay.” / “Received by an authorized endpoint.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Double Send, crash after commit, route loss, locked target, and late callback do not duplicate or leak content. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-02: Chats list and filters

| Record field | Required behavior |
|---|---|
| Entry points | Chats tab. |
| Layout and elements | Search, All/Compared/Needs review/Locked filters, rows, +, multi-select local organization. |
| Every control activation | Row → M-01 or S-05; Search → M-07; filter → local query; + → safe action menu; swipe → M-08 reversible options; long press row → local selection. |
| Distinctive states | No matches shows filter reset; locked rows no preview; offline keeps eligible local history; security-event count not read receipt. |
| Exact copy | “Locked chats stay out of message search until you unlock them.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Filters never confuse app lock, comparison, route, decoy, and group admission. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-03: Message action sheet

| Record field | Required behavior |
|---|---|
| Entry points | Long press or accessible message menu. |
| Layout and elements | Reply, reactions, Edit if author/eligible, Copy, Delete here/request, Details; no secret unsafe actions. |
| Every control activation | Reply → composer reference; reaction → scoped add/remove; Edit → M-04; Copy → clipboard warning/policy; Delete → M-09; Details → M-06; Close → unchanged. |
| Distinctive states | Expired/unsupported target limits actions; locked dismisses; edits unavailable for security/payment/control events. |
| Exact copy | “Copying leaves TGP's protected storage and may remain in clipboard history.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Other-author edit/cross-scope reply cannot be invoked by crafted frontend command. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-04: Edit or reply draft

| Record field | Required behavior |
|---|---|
| Entry points | M-03 Reply/Edit. |
| Layout and elements | Visible Replying to/Editing label; original availability; text; Save/Send; Cancel. |
| Every control activation | Save edit → authenticated revision event; Send reply → scoped content event; Cancel → restore ordinary draft; quoted source → only if currently authorized. |
| Distinctive states | Original expired/deleted/locked → unavailable placeholder; edit window closed → block; conflicting revision → visible review. |
| Exact copy | “Edited” / “Original message unavailable.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: A quote cannot recover expired/locked plaintext; edit replay cannot change authority state. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-05: Reaction picker

| Record field | Required behavior |
|---|---|
| Entry points | M-03 reaction action or selected existing reaction. |
| Layout and elements | Bounded reaction set; current selection; Remove; Close. |
| Every control activation | Choose → idempotent scoped reaction; selected reaction → remove; Close → unchanged; accessible More menu has same actions. |
| Distinctive states | Offline queues event; expired/unknown target reject; locked dismisses; no typing/online signal. |
| Exact copy | “Reaction queued” when offline; do not imply recipient read. |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate add/remove and reordering converge without extra counts or cross-scope mutation. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-06: Delivery and event details

| Record field | Required behavior |
|---|---|
| Entry points | Message status or Details. |
| Layout and elements | Local queued time; relay receipt; known authorized endpoint receipts; expiry/failure; Retry/Cancel if eligible. |
| Every control activation | Retry → revalidate current state and resend safely; Cancel queued → stop pending local effect if possible; receipt row → scoped evidence explanation; Close → timeline. |
| Distinctive states | Relay restart may lose accepted queue; partial endpoint receipt not everyone; unknown → unconfirmed. |
| Exact copy | “Relay acceptance is not proof that a person received or read this message.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No receipt is synthesized from an animation, HTTP success, or local bubble. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-07: Local search

| Record field | Required behavior |
|---|---|
| Entry points | Chats Search or conversation search. |
| Layout and elements | Query field; current scope/filter; unlocked results; Clear query/history; Cancel. |
| Every control activation | Type → bounded local query; result → authorized message context; Clear → local clear; scope → local filter; Cancel → purge active result model. |
| Distinctive states | No results explicit; locked scope excluded; relock purges results/snippets; indexing progress cancellable; offline unaffected. |
| Exact copy | “Search runs on this device. Locked chats are excluded.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | None. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Relock during query clears snippets and navigation targets; no query in network/analytics logs. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-08: Local organization actions

| Record field | Required behavior |
|---|---|
| Entry points | Chat swipe or row action menu. |
| Layout and elements | Pin/unpin; mute duration; archive/unarchive; local-only label; Close. |
| Every control activation | Pin → local list preference; Mute → local notification policy; Archive → hide from main list with Undo; Unarchive → restore; Close → unchanged. |
| Distinctive states | Offline fully works; locked rows keep generic label; Undo never reverses an already requested remote effect because none occurs. |
| Exact copy | “These organization changes stay on this device unless you separately enable eligible own-device sync.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Local mute/archive cannot emit read receipt, membership change, or wallet event. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-09: Delete and requested deletion

| Record field | Required behavior |
|---|---|
| Entry points | Message/contact action. |
| Layout and elements | Delete here; request deletion on linked devices/participants where supported; exact scope; Cancel. |
| Every control activation | Delete here → local eligible deletion; Request → authenticated bounded request with acknowledgment progress; Cancel → unchanged; scope help → limits. |
| Distinctive states | Unconfirmed/offline recipient remains unconfirmed; locked content deletion obeys key/store policy; wallet records unaffected. |
| Exact copy | “Others may have copied, exported, or photographed this content.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No global erased success; delayed content/import cannot silently resurrect within defined replay/expiry policy. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-10: External URL boundary

| Record field | Required behavior |
|---|---|
| Entry points | Tapped message link. |
| Layout and elements | Readable scheme/host; tracking/external-app warning; Open externally; Copy; Cancel. |
| Every control activation | Open → OS/browser handoff after consent; Copy → clipboard boundary; Cancel → no fetch; suspicious scheme → unsupported, no handler launch. |
| Distinctive states | Offline no automatic retry; locked dismisses; URL parsing bounded; no preview fetch on rendering. |
| Exact copy | “Opening leaves TGP. The destination and your browser may observe this visit.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | No app fetch for preview; external browser behavior is outside app transport guarantee. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: javascript/file/custom-command schemes and redirect tricks cannot invoke native authority. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

#### M-11: Unsupported message or security profile

| Record field | Required behavior |
|---|---|
| Entry points | Unknown event/version or incompatible endpoint. |
| Layout and elements | Safe placeholder; reason; update guidance; export-safe diagnostics; no raw unsafe rendering. |
| Every control activation | Update → H-09; Details → reason without secret payload; Diagnostics → H-05; Back → timeline; unsupported security state blocks affected send. |
| Distinctive states | Unknown ordinary content can be placeholder; unknown authority-bearing version fails closed; no weaker profile option. |
| Exact copy | “This version cannot use the required security profile.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unsupported event never becomes a generic settings update or authority grant. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |


### Attachments and voice notes

#### A-01: Attachment chooser

| Record field | Required behavior |
|---|---|
| Entry points | Composer attachment. |
| Layout and elements | Photos, camera if qualified, document, Cancel; current limits. |
| Every control activation | Photos/document → narrow OS picker; Camera → O-08 then capture; chosen file → A-02/A-03/A-06; Cancel → composer unchanged. |
| Distinctive states | Permission denied offers supported picker/manual alternative; oversize detected before decode; no auto-send on OS return. |
| Exact copy | “Choose a file, then review the send copy before sending.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Drag/drop/share extension stages review only; unknown type rejected safely. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-02: Sanitized image preview

| Record field | Required behavior |
|---|---|
| Entry points | Selected supported image. |
| Layout and elements | Send-copy preview; metadata result; resize; view-once choice; Send; Cancel. |
| Every control activation | Resize → local bounded re-encode; view-once → explicit limits; Send → descriptor/body queue; Cancel → protected staging cleanup; metadata row → exact removed/remaining fields. |
| Distinctive states | Sanitizing progress; failure not labeled cleaned; offline queued transfer; lock cancels plaintext preview. |
| Exact copy | “Metadata removed from this send copy. Your original is unchanged. Recipients can still copy the image.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: EXIF/GPS/orientation fixtures, decompression bombs, relock and worker crash stay bounded. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-03: Document/original-file disclosure

| Record field | Required behavior |
|---|---|
| Entry points | Selected document or unsanitizable format. |
| Layout and elements | Filename/type/size; metadata limitation; Send original; Cancel; unsupported-type explanation. |
| Every control activation | Send original → explicit disclosure confirmation then approved transfer; Cancel → remove staging; safe preview → bounded worker only if supported. |
| Distinctive states | Unsupported parser: no unsafe preview; offline queue explicit; locked hides file contents; no remote conversion. |
| Exact copy | “TGP cannot safely remove all metadata from this file. Sending the original may reveal author or editing information.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No false sanitize success; external viewer not launched automatically. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-04: Voice note recording and preview

| Record field | Required behavior |
|---|---|
| Entry points | Composer Voice. |
| Layout and elements | Record/Stop, duration, waveform, Play, Delete, Send, Cancel; visible microphone state. |
| Every control activation | Record → permission then capture; Stop → encrypted draft preview; Play → local playback; Delete/Cancel → stop/delete; Send → approved protected transfer. |
| Distinctive states | Lock/background stops capture under policy; duration cap enforced; denied mic leaves text; failed call never enters this screen automatically. |
| Exact copy | “Recording on this device. Nothing is sent until you choose Send.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No pre-consent or post-cancel capture; interrupted unsent audio does not upload. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-05: Received media viewer and shared media

| Record field | Required behavior |
|---|---|
| Entry points | Attachment bubble or Contact/Group shared media. |
| Layout and elements | Authorized media list/view, Download if needed, Save externally, view-once limits, Close. |
| Every control activation | Download → protected approved transfer; Open → bounded local viewer; Save → explicit OS export boundary; Close → purge transient preview; view-once open → consume under replay policy. |
| Distinctive states | Expired/unavailable/missing chunks explicit; no cloud fallback; locked denies body; partial download resumable only with valid capability. |
| Exact copy | “Saving outside TGP creates a copy controlled by the destination.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate view-once delivery cannot reopen; external export excludes unrelated files/keys. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-06: Video preparation and preview

| Record field | Required behavior |
|---|---|
| Entry points | Selected supported video. |
| Layout and elements | Local processing progress; duration/dimension cap; preview; audio toggle; Send; Cancel. |
| Every control activation | Trim/resize if supported → local work; Play → local preview; Send → reviewed prepared copy; Cancel → worker cancellation and cleanup. |
| Distinctive states | Over cap offers smaller local copy or cancel; no remote transcoder; disk-full leaves no plaintext temp; lock clears preview. |
| Exact copy | “Preparing video on this device. Larger transfers are not available in this build.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Codec time/memory caps, malformed frames, interruption and denied permissions handled without leaks. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-07: Attachment transfer status

| Record field | Required behavior |
|---|---|
| Entry points | Attachment progress indicator. |
| Layout and elements | Queued/preparing/transferring/partial/received/expired states; bytes bucket; Retry; Cancel. |
| Every control activation | Retry → validate manifest/capability/expiry; Cancel → stop uncompleted local transfer; Details → limits; Close → timeline with actual progress. |
| Distinctive states | Sender offline may prevent body fetch; no durable-store claim; token consumed/expired produces honest unavailable state. |
| Exact copy | “The message arrived, but this attachment is not available yet.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Message receipt never implies attachment receipt; reordered/truncated chunks cannot render unverified body. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

#### A-08: External blob storage unavailable

| Record field | Required behavior |
|---|---|
| Entry points | Advanced attachment options or oversized offline transfer. |
| Layout and elements | Disabled capability explanation; current endpoint-transfer limits; Back. |
| Every control activation | Read why → privacy/persistence explanation; Back → safe transfer flow; no Enable bypass. |
| Distinctive states | Always disabled until storage gate closes; outage does not switch to public file host. |
| Exact copy | “External attachment storage is not enabled because its added metadata and retention have not met the privacy requirement.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | None. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No storage endpoint contacted and no upload token created from disabled UI. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |


### Groups and community experiments

#### G-01: Select group contacts

| Record field | Required behavior |
|---|---|
| Entry points | Chats + → New group. |
| Layout and elements | Existing authenticated contacts; none selected; search local labels; Continue; Cancel. |
| Every control activation | Select person → local draft roster; Continue → G-02; search → local filter; Cancel → discard draft; unqualified group build → G-11. |
| Distinctive states | No contacts offers Connect; incompatible/pending contact explained; no public invite entry or phone lookup. |
| Exact copy | “Choose people you already connected with. Nobody receives messages until they accept and are admitted.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Selection alone cannot send invite or create member leaf. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-02: Review group and policy

| Record field | Required behavior |
|---|---|
| Entry points | G-01 Continue. |
| Layout and elements | Title/avatar; selected people; administrator/coordinator explanation; history none; Keep default; Invite/Back. |
| Every control activation | Edit roster → G-01; policy rows → G-08; avatar → local sanitize; Invite → encrypted invitations and G-03; Back → preserved draft. |
| Distinctive states | Policy changes revalidate preview; offline invitations queued; all recipients shown; no automatic pre-join history. |
| Exact copy | “New members receive new messages after admission. Earlier history is not shared by default.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No hidden endpoint, public mailbox, or wallet/treasury created by group creation. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-03: Invitation and admission progress

| Record field | Required behavior |
|---|---|
| Entry points | G-02 Invite. |
| Layout and elements | Per-person Invited/Accepted/Joining/Member; expiry; Cancel pending; Open group. |
| Every control activation | Person row → current evidence; Cancel pending → revoke unused invite; Open group → G-06/M-01 with pending banner; Retry → current-state validation. |
| Distinctive states | Partial success explicit; peer offline stays pending; expired invite needs fresh review; not all green until committed. |
| Exact copy | “Accepted is not yet admitted. Pending people cannot read group content.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No group ciphertext delivered to merely invited or accepted endpoints. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-04: Incoming group invitation review

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated one-to-one group invitation. |
| Layout and elements | Inviter comparison; roster; policy; history boundary; Accept; Decline. |
| Every control activation | Accept → consent/key-package step and G-05; Decline → bounded reply and no membership; roster/policy → readable local detail. |
| Distinctive states | Expired/revoked/materially changed invite → renew review; unsupported hybrid profile blocks join; no auto-download archive. |
| Exact copy | “Accepting asks to join this group. Admission still needs to complete.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Forwarded invite cannot delegate admission to an unrelated relationship. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-05: Joining group

| Record field | Required behavior |
|---|---|
| Entry points | G-04 Accept. |
| Layout and elements | Consent accepted; cryptographic admission progress; Cancel before admission; Open when ready. |
| Every control activation | Cancel → withdraw pending consent if not committed; Open → conversation only after valid persisted state; Details → per-endpoint admission. |
| Distinctive states | Missing commit/partition → joining; conflicting state → R-06; process death resumes safely; no live-state copy. |
| Exact copy | “Finishing protected admission. You are not a recipient until this completes.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Optimistic UI cannot enable sends or content decryption before valid admission. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-06: Group details

| Record field | Required behavior |
|---|---|
| Entry points | Group conversation header. |
| Layout and elements | Title; actual member count; pending count; Members; Policy; Media; role actions; Leave; Pay privately. |
| Every control activation | Members → G-07; Policy → G-08; Media → A-05; Add → G-01 scoped add flow; Leave → G-10; Pay privately → select member then 1:1 P-03. |
| Distinctive states | Locked hides content; stale group pauses affected controls; unauthorized role actions not offered; no group payment event. |
| Exact copy | “Members and their admitted devices can receive new group messages.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Pay privately emits no group request/address/TXID/completion badge. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-07: Members and endpoints

| Record field | Required behavior |
|---|---|
| Entry points | G-06 Members. |
| Layout and elements | People, scoped authorized endpoints, role, pending devices, remove/promote controls by role. |
| Every control activation | Person → its group endpoints; pending → R-02; Remove → G-09; role change → G-08 reviewed policy transition; Back → details. |
| Distinctive states | Not a global device inventory; offline status is locally observed, not global last-online; pending not active. |
| Exact copy | “These are devices admitted to this group, not all devices a person owns.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Companion/controller role cannot inherit group administration silently. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-08: Group policy and role review

| Record field | Required behavior |
|---|---|
| Entry points | G-02/G-06/G-07. |
| Layout and elements | Admission rules; roles/coordinator; history/expiry; explicit changed-fields diff; Apply/Cancel. |
| Every control activation | Change field → draft only; Apply → authority/consent/parent-state check and valid transition; Cancel → no change; transfer coordinator → separate confirmed transition. |
| Distinctive states | Coordinator offline: admin waits; unsupported broadening blocks; conflicting parent → R-06; no last-write-wins security policy. |
| Exact copy | “This changes who can admit recipients or what future messages follow. Review before applying.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Invalid admin signature, replayed policy, concurrent child states and silent timer changes rejected. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-09: Remove person or device

| Record field | Required behavior |
|---|---|
| Entry points | G-07 authorized Remove. |
| Layout and elements | Exact person/all endpoints or one endpoint; retained-copy warning; Remove; Cancel; progress. |
| Every control activation | Remove → local stop plus authorized group transition; progress → per-state applied/pending; Cancel before commit → no promise after published effect. |
| Distinctive states | Offline coordinator/peers pending; old content not erased; removed endpoint cannot receive new epoch secrets after valid transition. |
| Exact copy | “Removal blocks future access as the group updates. Stored copies remain.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Remove person covers every represented endpoint; stale client cannot fabricate completed global revocation. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-10: Leave group

| Record field | Required behavior |
|---|---|
| Entry points | G-06 Leave. |
| Layout and elements | Local departure versus cryptographic removal; keep/delete local history choices; Leave/Cancel. |
| Every control activation | Leave → stop local participation and authenticated leave request; Delete here → separate M-09; Cancel → unchanged. |
| Distinctive states | Last administrator/coordinator requires reviewed transfer or successor-group warning; offline removal may remain pending. |
| Exact copy | “You stop participating here now. Completing group rekey may require another authorized participant.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Leave cannot delete everyone else's history or silently transfer administrator authority. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-11: Large group/community unavailable

| Record field | Required behavior |
|---|---|
| Entry points | Capacity limit or You → Advanced → Communities. |
| Layout and elements | Measured current limit; experimental tier explanation; Create separate private group; Back. |
| Every control activation | Create private group → G-01 only if qualified; Details → metadata/capacity gate; Back → prior; no shared-mailbox override. |
| Distinctive states | Unsupported capacity is honest; no auto-sharding that changes recipient set; no public discovery. |
| Exact copy | “Larger communities are not enabled until their metadata, authority, and capacity requirements pass.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | None until a separately reviewed private-group action. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crossing capacity cannot silently switch to server fanout or classical encryption. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

#### G-12: Share selected earlier group history

| Record field | Required behavior |
|---|---|
| Entry points | Authorized group details → History transfer. |
| Layout and elements | Recipient endpoint; prior authorization; range none by default; eligible content; forwardable disclosure; Share/Cancel. |
| Every control activation | Select range → eligible manifest; locked source → S-05; Share → reviewed participant-authorized archive flow; Cancel → no history. |
| Distinctive states | Role/consent/profile changes invalidate; expired/deleted excluded; new group membership alone grants no old history. |
| Exact copy | “This creates another stored copy of the selected earlier history.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Administrator cannot export another member's unavailable/locked content or silently share all old history. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |


### Devices and selected history

#### D-01: Device inventory

| Record field | Required behavior |
|---|---|
| Entry points | You → Devices. |
| Layout and elements | Controller/companion role; local names; selected grants; last seen by this device; Link; device rows. |
| Every control activation | Link → D-02; device → grant detail and R-03 revoke; migration → R-04; lost controller help → R-05. |
| Distinctive states | Empty companions explicit; pending scopes separate; no authoritative global online time; wallet state never listed. |
| Exact copy | “Linked devices receive only the chats you approve. Wallets are separate.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Companion cannot enroll/promote itself or inspect unrelated profile grant inventory. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-02: Link-device ceremony start

| Record field | Required behavior |
|---|---|
| Entry points | Controller D-01 Link or new desktop companion setup. |
| Layout and elements | Role explanation; reauthenticate controller; scan/show pairing QR; Cancel; expiry. |
| Every control activation | Controller reauth → scanner; new device Show QR → fresh one-use invite; Scan → D-03; Cancel → destroy pending pairing. |
| Distinctive states | Companion role denied; expired/reused code terminal; offline no completed grant; permission alternative accessible. |
| Exact copy | “The new device will become another recipient only in the chats you choose.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Contact invitation and payment QR cannot be treated as pairing invitation. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-03: Compare both devices

| Record field | Required behavior |
|---|---|
| Entry points | Valid pairing candidate. |
| Layout and elements | Full transcript comparison on both devices; Matches; Does not match; destination local name. |
| Every control activation | Matches → local confirmation waits for both then D-04; Mismatch → invalidate attempt; name → local device label; Close → no grants. |
| Distinctive states | One-sided confirmation pending; transcript changes resets approval; interruption cannot create universal trust. |
| Exact copy | “Compare both screens. Confirm on both devices only if they match.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Replayed transcript or single-device confirmation cannot activate scopes. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-04: Select conversation grants

| Record field | Required behavior |
|---|---|
| Entry points | Both-device comparison succeeds. |
| Layout and elements | None selected; eligible chats; locked scopes need unlock; new-message permission; Continue. |
| Every control activation | Select → draft grant; locked scope → S-05; Continue → D-05; Select all not default and requires explicit action if offered; Back → no grant. |
| Distinctive states | Unavailable/incompatible scopes explained; no future-chat toggle; no wallet/admin permission. |
| Exact copy | “Only selected conversations will be offered to this device. Other and future chats stay excluded.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crafted selection cannot grant wallet, enrollment, future chats, or locked plaintext. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-05: Choose history and review access

| Record field | Required behavior |
|---|---|
| Entry points | D-04 Continue. |
| Layout and elements | Per-scope history None/24h/7d/custom; approximate size; attachments on request; single combined review; Link selected. |
| Every control activation | Range → eligible local manifest; custom → bounded dates; Link selected → D-06 and peer/group admissions; Back → preserved draft no effect. |
| Distinctive states | Expired/deleted excluded; locked scope needs separate unlock; disk/network estimate not certainty; no history default. |
| Exact copy | “Selected history will be stored on this device. No live session state or wallet is copied.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Import/transfer cannot restart expiry or clone running ratchets/leaves. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-06: Linking and history transfer progress

| Record field | Required behavior |
|---|---|
| Entry points | D-05 authorized Link. |
| Layout and elements | Per-scope active/awaiting peer/awaiting group/transferring; pause/cancel eligible work; Done. |
| Every control activation | Scope → reason/evidence; Pause archive → stop history only; Cancel pending scope → bounded cancellation; Done → D-01. |
| Distinctive states | Partial admission explicit; no content before scope active; archive resumable only with valid current grant; crash idempotent. |
| Exact copy | “4 chats active. 1 awaiting approval.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Cancelling archive does not revoke unrelated active scopes or leave a universal partially trusted endpoint. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

#### D-07: Desktop companion workspace

| Record field | Required behavior |
|---|---|
| Entry points | Qualified installed desktop after pairing. |
| Layout and elements | Rail, chat list, main conversation, detail pane, lock control, local notification preference. |
| Every control activation | Rail tabs → same mobile destinations; chat → M-01; details → scoped pane; Lock → S-02; close window → explicit tray/exit preference, not assumed lock. |
| Distinctive states | OS session lock purges plaintext; wallet absent/not configured; permission denial limits feature; no browser remote content. |
| Exact copy | “This installation has only its selected chat grants. No wallet was linked.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Keyboard-only pairing/chat/lock works; webview injection cannot call sign/export/enroll APIs. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |


### Security, locks, and deletion

#### S-01: Security and Vault hub

| Record field | Required behavior |
|---|---|
| Entry points | You → Security & Vault. |
| Layout and elements | App lock; chat vaults; inactivity; Lock now; clipboard/capture limits; Advanced local controls. |
| Every control activation | App lock → S-03; chat vaults → select S-04; inactivity → local policy review; Lock now → S-02; Advanced → S-08. |
| Distinctive states | Hardware capability honest; locked app must unlock before settings; no global all-secure badge. |
| Exact copy | “App entry, chat vaults, and wallet signing use separate authorization.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Changing app-lock preference cannot unlock every chat or wallet. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-02: App locked / panic result

| Record field | Required behavior |
|---|---|
| Entry points | Manual lock, panic accelerator, inactivity, screen-off policy. |
| Layout and elements | Generic app title; unlock; recovery limits; no chat names, previews, balances, or camera capture. |
| Every control activation | Unlock → appropriate native/passphrase flow; help → local no-reset explanation; panic action while open → stop capture and lock immediately. |
| Distinctive states | Bad attempt rate-limited; process death/reboot remains locked; biometric unavailable offers approved alternative not bypass. |
| Exact copy | “Unlock TGP. TGP cannot reset a forgotten local secret.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | No unlock analytics; only permitted background ciphertext handling. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Panic clears views/search/capture and does not silently wipe, spend, or send remote commands. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-03: App passphrase and inactivity policy

| Record field | Required behavior |
|---|---|
| Entry points | O-04 or S-01 App lock. |
| Layout and elements | Passphrase/confirm; visibility; device protection; lock timing; Save/Cancel. |
| Every control activation | Visibility → temporary local reveal; Save → derive/wrap under approved profile and persist policy; Cancel → discard; timing row → explicit future local policy. |
| Distinctive states | Weak/unequal fields error; memory/KDF unsupported blocks, no silent cheaper derivation; biometric convenience separately explained. |
| Exact copy | “Use a strong local secret. Losing it may make protected local data unavailable.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Passphrase never enters logs/clipboard/diagnostics; parameter change cannot silently downgrade KDF. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-04: Create/change per-chat vault

| Record field | Required behavior |
|---|---|
| Entry points | Contact details Lock or S-01 selected chat. |
| Layout and elements | Exact chat; passphrase/confirm; independent-key explanation; optional biometric re-unlock; Save. |
| Every control activation | Save → rewrap/create distinct vault key and relock/reindex safely; biometric choice → explicit convenience scope; Cancel → no protection change. |
| Distinctive states | Existing vault requires unlock; failed migration leaves old valid protection or fail-closed recovery; no global DB-only hiding. |
| Exact copy | “This chat has a separate vault key. Unlocking another chat does not unlock it.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Memory/storage dump while different chat open cannot obtain this locked vault key through ordinary app access. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-05: Unlock one chat

| Record field | Required behavior |
|---|---|
| Entry points | Locked chat row, search target, or selected grant. |
| Layout and elements | Generic protected-chat label where necessary; passphrase/biometric; unlock duration; Cancel. |
| Every control activation | Unlock → bounded scope key lease then intended screen; Cancel → no preview; show secret → temporary; wrong attempt → rate-limited. |
| Distinctive states | Relock cancels dependent search/media/export; no transfer or sync bypass; device key unavailable means blocked. |
| Exact copy | “Unlock this chat only. Your other locked chats stay locked.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Late callbacks after cancel/relock cannot repopulate message previews. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-06: Disappearing message policy

| Record field | Required behavior |
|---|---|
| Entry points | Contact/group details Timer. |
| Layout and elements | Keep default; timer options; prospective anchor/clock explanation; Apply; Cancel. |
| Every control activation | Select → draft; Apply → authenticated current-scope policy change; existing-content delete → separate M-09; Cancel → unchanged. |
| Distinctive states | Offline change pending; conflicting group state blocks; imported/read content never restarts timer; recipients can copy. |
| Exact copy | “This applies to new messages. Expiry is not proof that every copy is destroyed.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Clock skew, offline-before-receipt, timer conflict and archive restore follow defined bounds. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-07: Capture and clipboard controls

| Record field | Required behavior |
|---|---|
| Entry points | S-01 or sensitive copy action. |
| Layout and elements | Supported screenshot/recents controls; clipboard preference/clear; limitations; Save. |
| Every control activation | Toggle supported protection → local policy; Clear clipboard → best-effort platform action; Save → local; Back → no unapproved change. |
| Distinctive states | Unsupported OS says unavailable; external cameras/OS histories cannot be ruled out; secrets never auto-copied. |
| Exact copy | “These controls reduce supported capture paths. Other devices or a compromised OS may still capture content.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No claim that FLAG_SECURE or clipboard clearing defeats all recording/history. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-08: Advanced local concealment and destructive controls

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Local controls. |
| Layout and elements | Separate Decoy/disguise, Panic lock, Inactivity lock, Destructive wipe experiments; disabled labels. |
| Every control activation | Panic → S-02; inactivity → S-03; decoy/disguise/wipe → unavailable risk explanation unless separately qualified; no remote trigger. |
| Distinctive states | Experimental defaults off; no ambiguous duress PIN; auto-lock available, auto-wipe unavailable by default. |
| Exact copy | “Concealment is best effort. It does not guarantee plausible deniability or forensic invisibility.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No destructive action can be activated by ordinary unlock, peer message, timeout clock glitch, or support command. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-09: Delete local profile review

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Delete local profile. |
| Layout and elements | Local chats/keys/settings affected; external-copy warning; separate wallet warning; Export backup; Delete profile; Cancel. |
| Every control activation | Backup → B-02; Delete → reauth and explicit final local confirmation; existing wallet → separate recovery/removal review, no implicit destruction; Cancel → unchanged. |
| Distinctive states | Failed deletion reports exact partial local state; public chain/recipient/export copies remain; no server account to reset. |
| Exact copy | “Delete from this device. This does not erase recipient copies, external backups, or blockchain records.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Chat reset cannot silently destroy funds or claim all external data erased. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

#### S-10: Read, typing, and availability signals

| Record field | Required behavior |
|---|---|
| Entry points | Security/privacy settings → Activity signals. |
| Layout and elements | Read receipts, typing, last-online off; metadata explanation; individual capability status. |
| Every control activation | Signal row → disclosure/no-regression review; unqualified Enable → unavailable explanation, not toggle; Back → no change. |
| Distinctive states | Default off; one-to-one versus group separately scoped; no inherited enablement through pairing or restore. |
| Exact copy | “These signals reveal activity. They remain off unless their privacy requirement is separately met.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening or reading messages emits no read/typing/last-online event under default policy. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |


### Backup, restore, and drills

#### B-01: Backup and Restore hub

| Record field | Required behavior |
|---|---|
| Entry points | You → Backup & Restore. |
| Layout and elements | Export chat archive; Restore chat archive; Recovery drill; Wallet recovery separate; continuity experiment. |
| Every control activation | Export → B-02; Restore → B-06; Drill → B-08; Wallet → B-09; Continuity → R-07 unavailable unless approved. |
| Distinctive states | No cloud account/connect; locked scope needs unlock; no “recover account” generic button. |
| Exact copy | “History, identity continuity, and wallet recovery are different operations.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Choosing chat restore never prompts for wallet seed or activates old session. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-02: Select chat archive content

| Record field | Required behavior |
|---|---|
| Entry points | B-01 Export. |
| Layout and elements | Chats none/explicit selection; date range; local metadata options; attachment choice; exclusions; Continue. |
| Every control activation | Select/range → eligible manifest; metadata → explicit opt-in; Continue → B-03; locked scope → S-05; Cancel → discard plan. |
| Distinctive states | Expired/deleted excluded; approximate size; disk capacity checked; live sessions/authority/wallet excluded. |
| Exact copy | “This archive contains selected history, not active sessions, group leaves, or wallet recovery.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Manifest exactly matches eligible selected scope/range and exclusions. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-03: Archive passphrase and review

| Record field | Required behavior |
|---|---|
| Entry points | B-02 Continue. |
| Layout and elements | Strong passphrase/confirm; no-reset warning; manifest summary; Continue; Cancel. |
| Every control activation | Continue → validated KDF/profile and B-04; reveal → temporary; Back → plan; Cancel → clear transient secret. |
| Distinctive states | Weak/mismatch error; unsupported KDF blocks; no remembered secret or provider recovery. |
| Exact copy | “Keep this passphrase separately. TGP cannot recover it.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No plaintext export before authenticated container setup; KDF minimum enforced. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-04: Choose encrypted archive destination

| Record field | Required behavior |
|---|---|
| Entry points | B-03. |
| Layout and elements | Encrypted file type/name without contact labels; destination boundary; Save; Cancel. |
| Every control activation | Save → OS picker then authenticated protected streaming export; Cancel → clean partial protected state; external cloud chosen → metadata warning remains. |
| Distinctive states | Disk full/cancel/OS failure never creates plaintext temp; partial file invalid and reported; local archive can be retained only explicitly. |
| Exact copy | “The destination may retain this encrypted file, its size, and upload time.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Destination sees no plaintext; contact names excluded from default filename. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-05: Archive export result

| Record field | Required behavior |
|---|---|
| Entry points | Completed/failed export. |
| Layout and elements | Exact selected archive result, destination label, integrity status, Drill, Done; partial/error branch. |
| Every control activation | Drill → B-08; Done → B-01; Retry → fresh validated export; reveal file → OS boundary. |
| Distinctive states | Only successful finalized container shows success; cancellation/partial export distinguished; no remote durable promise. |
| Exact copy | “Encrypted archive saved. This does not back up wallet funds or reactivate identity on another device.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Success requires completed authentication/finalization and destination write evidence. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-06: Select and unlock chat archive

| Record field | Required behavior |
|---|---|
| Entry points | Welcome Restore or B-01. |
| Layout and elements | OS file selection; type/version; passphrase; Inspect; Cancel. |
| Every control activation | Choose → bounded header parse; Inspect → authenticate/decrypt manifest then B-07; Cancel → clear temp/secret; unsupported file → reject. |
| Distinctive states | Wrong secret/corrupt/oversize/incompatible handled safely; no plaintext preview before integrity; no wallet format guessing. |
| Exact copy | “Restoring history does not restore a running session or prove an old controller is gone.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Hostile nesting, huge declared size, truncated tags and wrong type cannot exhaust resources or bypass auth. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-07: Review archive restore

| Record field | Required behavior |
|---|---|
| Entry points | B-06 valid manifest. |
| Layout and elements | Eligible content/ranges/provenance; excluded expired items; fresh-endpoint explanation; Import selected; Cancel. |
| Every control activation | Select → local import plan; Import → transactional protected import; Cancel → no data; continuity request → separate R-07. |
| Distinctive states | Partial import exact count/error; no duplicate resurrection; incompatible active-state fields rejected; locked destination policy maintained. |
| Exact copy | “Imported messages are history. Contacts and groups may need fresh connection or admission.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No ratchet/group leaf/controller/wallet authority activated from ordinary archive. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-08: Non-authoritative chat recovery drill

| Record field | Required behavior |
|---|---|
| Entry points | B-01/B-05. |
| Layout and elements | Choose archive; temporary isolated context; verify sample eligible content; Finish; Cancel. |
| Every control activation | Choose/unlock → same bounded parser; Verify → local sample integrity; Finish/Cancel → destroy temporary context; no Send control. |
| Distinctive states | Offline fully possible; wrong passphrase fail safe; drill cannot join groups or create duplicate active endpoint. |
| Exact copy | “This checks recovery without reactivating old message sessions.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No outbound message/session enrollment and no temporary plaintext residue after drill. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-09: Separate wallet backup

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings or B-01 wallet recovery. |
| Layout and elements | Selected chain/wallet; supported recovery format; hardware versus local; protected reveal; descriptor/height requirements; Confirm. |
| Every control activation | Reveal → separate wallet reauth and protected native view; Confirm understanding → local backup status; Export supported public policy → explicit boundary; Cancel → hide. |
| Distinctive states | No screenshots/clipboard default; hardware seed never requested; format-specific prerequisites; no generic seed splitting. |
| Exact copy | “This recovers funds, not chats. A watch-only export is not a spending backup.” |
| Data read / written | Wallet-only recovery metadata; no chat archive insertion. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Seed/view-key material never crosses chat bridge or general support export. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-10: Wallet no-spend recovery drill

| Record field | Required behavior |
|---|---|
| Entry points | Wallet backup result/settings. |
| Layout and elements | Chain-specific temporary restore; verify derived address/policy/height; no-spend label; Finish. |
| Every control activation | Start → separate local protected input; Verify → derive/check without broadcast; Finish → destroy temp secrets; Cancel → cleanup. |
| Distinctive states | Wrong format/network/passphrase explicit; hardware follows exact matrix; no funds moved, no provider lookup required unless separately reviewed sync. |
| Exact copy | “This drill does not send a transaction or link a wallet to another chat device.” |
| Data read / written | Isolated temporary wallet context; no contact mapping. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No signing/broadcast and no automatic source-label promotion from successful restore. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

#### B-11: Multisig and social recovery study

| Record field | Required behavior |
|---|---|
| Entry points | Backup hub → Advanced recovery. |
| Layout and elements | Bitcoin descriptor multisig study; generic social recovery unavailable; exact signer/loss/timelock requirements; Back. |
| Every control activation | Study row → non-actionable design status; Back → backup hub; no split-seed, contact-share, or contract-deploy control. |
| Distinctive states | All deferred paths remain disabled; no assurance contacts can recover funds; no chat identity used as on-chain recovery authority. |
| Exact copy | “Do not split or send a recovery phrase through contacts. This recovery feature is not available.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Contact/group members cannot enroll themselves as recovery signers or receive secret shares. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |


### Network and infrastructure

#### N-01: Connection status

| Record field | Required behavior |
|---|---|
| Entry points | Header route badge or You → Privacy & Network. |
| Layout and elements | Connecting/Tor/PT/offline/degraded; last local check; Retry; Assistance; Advanced endpoints. |
| Every control activation | Retry → approved broker attempt; Assistance → N-02; endpoints → N-04; report → H-03; Close → prior. |
| Distinctive states | Wi-Fi not Tor; no universal green privacy score; stale status timestamp; offline queues remain local. |
| Exact copy | “Protected connection unavailable. Nothing was sent directly.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Status never derives security from hop count or internet connectivity alone. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-02: Connection assistance

| Record field | Required behavior |
|---|---|
| Entry points | N-01 Help or O-05. |
| Layout and elements | Supported transport choices/automatic retry; manual bridge; concise network limits; Cancel. |
| Every control activation | Try supported method → broker/PT attempt; Manual bridge → N-03; Cancel → local offline mode; details → local explanation. |
| Distinctive states | Unsupported PT unavailable by platform; repeated failure bounded backoff; no TGP-branded secret bridge guarantee. |
| Exact copy | “Some networks block all available routes. TGP cannot guarantee access during a shutdown.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Failed PT never opens direct message/node/update request. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-03: Bridge configuration import

| Record field | Required behavior |
|---|---|
| Entry points | N-02 manual or Advanced bridges. |
| Layout and elements | Typed bridge/PT fields; operator/address preview; Save/Test; Cancel; remove. |
| Every control activation | Paste/scan → parse preview only; Test → approved transport bootstrap; Save → reviewed config; Remove → revert to safe automatic profile; Cancel → unchanged. |
| Distinctive states | Malformed/unsupported type rejected; QR cannot replace config silently; no content sends during config test. |
| Exact copy | “This changes transport setup, not your message relay or wallet node.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Bridge, relay, chain node and payment QR types remain distinct. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-04: Message relay directory and BYO

| Record field | Required behavior |
|---|---|
| Entry points | Privacy & Network → Relays. |
| Layout and elements | Signed manifest status; declared operators; selected roles; Add own; inspect; Save. |
| Every control activation | Relay → N-05; Add → typed onion/protocol preview; Save → compatibility/operator rule check; refresh → broker fetch without client identity. |
| Distinctive states | Expired manifest warns/blocks unsafe use; same declared operator not silently accepted; BYO not proof trusted. |
| Exact copy | “Different declared operators reduce concentration. They do not prove non-collusion.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Directory update cannot change person identity, add recipients, or enable weaker profile. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-05: Endpoint review and test

| Record field | Required behavior |
|---|---|
| Entry points | Relay/node/config selection. |
| Layout and elements | Endpoint type, onion/host, operator, transport, data exposure, Test/Save/Cancel. |
| Every control activation | Test → role-specific reachability only; Save → current typed endpoint profile; Cancel → no change; disclosure → exact observer fields. |
| Distinctive states | Redirect/host/protocol mismatch rejected; timeout local error; no wallet secret in health query. |
| Exact copy | “Reachable means this endpoint answered this test. It is not a privacy endorsement.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Node test cannot upload descriptor/view key or contact label. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-06: Advanced traffic profile

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Network experiments. |
| Layout and elements | Cover-traffic measurement status; padding profile; cost/latency; disabled production toggle until approved. |
| Every control activation | Read results → local evidence; qualified profile selection → explicit resource/disclosure review; Back → unchanged; no magic-anonymity switch. |
| Distinctive states | Unqualified stays off; battery/data costs visible; app suspension limits explained. |
| Exact copy | “Cover traffic does not guarantee protection against a global observer.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Profile change cannot lower baseline padding or bypass route on battery pressure. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-07: Volunteer proxy and device VPN experiments

| Record field | Required behavior |
|---|---|
| Entry points | Advanced network. |
| Layout and elements | Separate volunteer Snowflake proxy and device-wide VPN cards; disabled/current capability; stop control if qualified. |
| Every control activation | Proxy details → role/battery/network disclosure; VPN details → exact traffic scope/OS permission; Stop → immediate local stop; no default activation. |
| Distinctive states | Unsupported/platform conflict remains off; proxy contribution not own route privacy; VPN other-app effects explicit. |
| Exact copy | “Contributing a proxy is different from using Snowflake to connect.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No claim all-device kill switch without scope tests; no rewards or anonymity gain implied. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

#### N-08: Nearby/offline radio experiment

| Record field | Required behavior |
|---|---|
| Entry points | Advanced → Nearby transfer. |
| Layout and elements | Disabled prototype status; proximity/radio identifiers; authenticated peer requirement; Back. |
| Every control activation | Read limits → local; qualified explicit start only after separate consent; Stop → radio discovery ends; Back → no automatic Tor bypass. |
| Distinctive states | No wallet sync/settlement promise; no multi-hop internet claim; denied radio permission normal. |
| Exact copy | “Nearby transfers can reveal proximity and radio activity. This is not an automatic fallback.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No Bluetooth/Wi-Fi discovery before explicit action and qualified platform gate. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |


### You, help, notifications, and build

#### H-01: You hub

| Record field | Required behavior |
|---|---|
| Entry points | You tab. |
| Layout and elements | Local profile; Devices; Privacy & Network; Security & Vault; Backup & Restore; Notifications; Help; Privacy Report; About; Advanced; Lock. |
| Every control activation | Profile → C-09; Devices → D-01; Network → N-01; Security → S-01; Backup → B-01; Notifications → H-02; Help → H-04; Report → H-03; About → H-08; Advanced → H-10; Lock → S-02. |
| Distinctive states | Wallet activation entry available without active tab; locked state reveals no settings secrets; no account/billing identity display required. |
| Exact copy | “Your profile is local. There is no TGP account password to reset.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening You triggers no wallet, rate, support, update, or engagement network request. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-02: Notification availability choice

| Record field | Required behavior |
|---|---|
| Entry points | You Notifications or contextual request. |
| Layout and elements | Platform-specific app-open/foreground/reviewed distributor/platform notice choices; minimal payload; Save; Disable. |
| Every control activation | Select → local draft plus exposure explanation; Save → OS permission and reviewed registration only if approved; Disable → mapping removal/expiry and generic availability update. |
| Distinctive states | iOS default app-open; denied/delayed/force-quit explicit; no sender/body/amount preview default; no content-key accessibility downgrade. |
| Exact copy | “Optional platform notices expose notification metadata. Message content still uses the protected route.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | Only explicit approved platform/distributor registration, separately disclosed from broker content transport. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Push cannot decrypt vault, activate capture, authorize device, or sign funds. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-03: Local Privacy Report

| Record field | Required behavior |
|---|---|
| Entry points | You Privacy Report or N-01. |
| Layout and elements | Scope/date; route/fail-closed/resolver checks; Passed/Issue/Not tested/Inconclusive; Run; clear; external-test opt-in. |
| Every control activation | Run → bounded local checks; check → evidence details; external test → separate observer consent; Clear → local history deletion; Export → H-05. |
| Distinctive states | No universal score; offline local checks still run; unavailable instrumentation inconclusive not passed. |
| Exact copy | “These results apply only to the tested path and time. They are not an anonymity guarantee.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No external IP/DNS request before consent; results cite local test scope/configuration. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-04: Help and troubleshooting

| Record field | Required behavior |
|---|---|
| Entry points | You Help or inline error. |
| Layout and elements | Local FAQ, error code, tutorial, recovery limits, support export, legal availability. |
| Every control activation | FAQ → bundled local content; tutorial → H-07; support → H-05; legal → H-11; external article → explicit M-10 boundary. |
| Distinctive states | Offline help available; support cannot inspect chats/reset seeds; no automatic log upload. |
| Exact copy | “Support will never ask for your recovery phrase or private keys.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Help article links cannot silently fetch tracking pixels or prefill secrets. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-05: Diagnostic/report preview

| Record field | Required behavior |
|---|---|
| Entry points | Help support or Privacy Report Export. |
| Layout and elements | Exact fields/content selected; redactions; recipient/retention; Remove field; Export/Cancel. |
| Every control activation | Field → readable value; Remove → exclude; Export → H-06 after final explicit boundary; Cancel → no disclosure; content report → explicitly selected content only. |
| Distinctive states | No seed/key/address-contact map default; locked content unavailable; missing retention policy blocks submission. |
| Exact copy | “Review exactly what you will share. Exporting leaves private local storage.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Redaction at source, bounded package, no hidden fields or automatic complete history. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-06: Support export/handoff result

| Record field | Required behavior |
|---|---|
| Entry points | H-05 Export. |
| Layout and elements | Chosen destination/service, file preview summary, submission state, Done/Cancel. |
| Every control activation | Choose destination → OS share/file boundary; Submit where supported → explicit authorized send; Done → help; Cancel before send → no submission. |
| Distinctive states | Partial/failed submission honest; already sent cannot be recalled by Cancel; no support data directory joined to messaging. |
| Exact copy | “The selected support destination controls its copy under the stated retention policy.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Final package matches preview byte-for-field and excludes unrelated secrets. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-07: Tutorial and local hints settings

| Record field | Required behavior |
|---|---|
| Entry points | You Help Tutorial. |
| Layout and elements | Three-task checklist; hint examples; reset; dismiss all; no analytics. |
| Every control activation | Task → O-07 matching safe path; Reset → local reset; Dismiss all → local preference; Back → help. |
| Distinctive states | Offline works; no remotely targeted experiments; never covers active security warning. |
| Exact copy | “Tutorial progress stays on this device.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tutorial state contains no messages, wallet data, contact names, or behavior upload. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-08: About, licenses, and build evidence

| Record field | Required behavior |
|---|---|
| Entry points | You About or pre-setup About. |
| Layout and elements | Version/platform/source commit; artifact/signature status; independent rebuild status; audit scope; licenses; Check updates. |
| Every control activation | Build details → exact evidence; licenses → bundled notices; audit → scope/findings not blanket badge; Check → H-09 only after opt-in. |
| Distinctive states | Cannot inspect installed package: says so; missing independent rebuild not mislabeled reproducible; offline cached evidence timestamped. |
| Exact copy | “A signed matching artifact does not prove runtime device integrity.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: AGPL/SQLCipher/other notices visible; upstream audit never represented as TGP audit. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-09: Update review and rollback protection

| Record field | Required behavior |
|---|---|
| Entry points | H-08 explicit Check or permitted stored preference. |
| Layout and elements | Signed version/profile/compatibility; security notes; download/install; Later; evidence. |
| Every control activation | Check/download → broker; Install → platform signed artifact flow; Later → unchanged unless unsafe capability blocked under policy; evidence → exact build scope. |
| Distinctive states | Invalid/expired/rollback signature rejects; offline no direct fallback; no remote JS injection; pending swap recovery not stranded. |
| Exact copy | “Review the supported security profile and known issues for this build.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tampered manifest/artifact, old signed version and compromised UI cannot bypass release checks. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-10: Advanced hub

| Record field | Required behavior |
|---|---|
| Entry points | You Advanced. |
| Layout and elements | Separated Network, Financial tools, Offline signing, Continuity, local experiments, Delete profile; explanations. |
| Every control activation | Network → N-04/N-06; Financial → X-01; Offline signing → W-14; Continuity → R-07; Local controls → S-08; Delete → S-09. |
| Distinctive states | Disabled experiments visible as explanations only; no tap sequence bypass; normal features remain outside. |
| Exact copy | “Advanced controls do not relax the privacy requirements.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Feature flags/hidden deep links cannot turn blocked capability on. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-11: Legal availability and user obligations

| Record field | Required behavior |
|---|---|
| Entry points | You Help Legal or financial eligibility notice. |
| Layout and elements | Selected distribution region; policy date; software/use/service distinctions; country restrictions; no legal guarantee; counsel contact. |
| Every control activation | Region info → local signed policy display; financial restriction → exact capability explanation; external law → M-10 boundary; Back → no action. |
| Distinctive states | Unknown/unreviewed jurisdiction: no financial service start; no silent IP/GPS collection; changing region not presented as bypass. |
| Exact copy | “Privacy tools do not make unlawful transactions lawful. This is not legal advice.” |
| Data read / written | Minimum local policy selection, not mandatory identity/country telemetry. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Legal block does not erase keys, disable safe recovery, or add hidden identity collection. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-12: Funding without chat identity

| Record field | Required behavior |
|---|---|
| Entry points | You About → Support development. |
| Layout and elements | Free-chat policy; voluntary options; separate billing boundary; no rewards/token/percentage; Back. |
| Every control activation | Read model → local; voluntary contribution → explicit external/payment boundary and eligible policy; paid optional service → separate unlinked entitlement review if ever approved. |
| Distinctive states | No donation required; external processor may retain business records; no donor badge attached to profile. |
| Exact copy | “Core private chat and security do not require payment.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No chat/contact/queue ID in invoice, donation payload, analytics, or entitlement claim. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-13: Consented research and feedback

| Record field | Required behavior |
|---|---|
| Entry points | Help → Research, only if project offers a separate study. |
| Layout and elements | Optional protocol, collected fields, researcher, retention, consent, withdraw; no production tracking toggle. |
| Every control activation | Read protocol → exact study; Consent → separate approved recruitment boundary; Withdraw → stated process; feedback → H-05 selected content. |
| Distinctive states | No active study says none; refusal leaves features unchanged; no silent random assignment or behavioral SDK. |
| Exact copy | “Using TGP does not enroll you in research.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No experimental group identifier, keystrokes, contact behavior, or wallet activity transmitted in normal app use. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

#### H-14: Security incident notice

| Record field | Required behavior |
|---|---|
| Entry points | Verified signed release/capability notice or local detected unsafe state. |
| Layout and elements | Exact affected build/capability; uncertainty; stop-new-operation scope; safe update/recovery; evidence. |
| Every control activation | Update → H-09; active financial recovery → X-05/W-14 as applicable; evidence → exact signed notice; Dismiss → cannot bypass local mandatory safety block. |
| Distinctive states | Offline clients may not receive notice; invalid notice cannot execute commands; content keys never uploaded; active recovery not wiped. |
| Exact copy | “This notice affects the named capability. It does not prove that all devices or past copies are safe.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Incident channel cannot erase keys, enroll device, change recipient, extract secrets, or strand funded operations. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |


### Wallet activation and connection

#### W-01: Activate optional wallet

| Record field | Required behavior |
|---|---|
| Entry points | You Wallet or eligible payment action. |
| Layout and elements | Separate recovery/isolation explanation; Activate; Not now; no default chain/account. |
| Every control activation | Activate → platform qualification check then W-02; Not now → chat unchanged; limits → local privacy explanation. |
| Distinctive states | Unqualified platform → management/export explanation only; no seed creation before choice; incoming request still viewable. |
| Exact copy | “Wallets are optional and separate from chat. Linking chats does not link funds.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Decline activation and all core chat journeys remain available. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-02: Choose create, connect, or restore

| Record field | Required behavior |
|---|---|
| Entry points | W-01. |
| Layout and elements | Create new wallet; Connect existing hardware/watch-only; Restore recovery; chain choice. |
| Every control activation | Create → W-11; Connect → W-03; Restore → W-12; chain → supported exact network only; Back → inactive/previous wallet. |
| Distinctive states | Unsupported chain disabled; no generic all-chain seed; chat name never passed to chain adapter. |
| Exact copy | “Connect does not require your seed. Restore introduces spending secrets into this device.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Normal Connect path contains no seed field. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-03: Existing wallet connection method

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Connect. |
| Layout and elements | Hardware first; watch-only descriptor/address; requested data preview; compatibility matrix. |
| Every control activation | Hardware → W-04; Watch-only → W-05; matrix → exact model/format/platform; Back → no imported authority. |
| Distinctive states | Unsupported hardware truthful; no account-based hosted wallet login; chain/network mismatch rejected. |
| Exact copy | “Connecting does not remove links in this wallet's earlier history.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No wallet provider registration, seed prompt, or TGP wallet account created. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-04: Hardware connection and policy review

| Record field | Required behavior |
|---|---|
| Entry points | W-03 Hardware. |
| Layout and elements | Device/firmware/chain app; transport permission; public policy requested; Connect/Cancel. |
| Every control activation | Connect → permitted local device session; approve public descriptor/address on hardware → W-06; Cancel → close session; unsupported → no speculative support. |
| Distinctive states | Disconnect/reconnect revalidates device/policy; no vendor analytics request; signer seed stays on hardware. |
| Exact copy | “Review the device and public wallet policy. No seed is requested.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | No vendor cloud request; only reviewed local hardware transport and later approved sync. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Different returned policy, substituted device, denied USB/Bluetooth and firmware mismatch block safely. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-05: Watch-only import preview

| Record field | Required behavior |
|---|---|
| Entry points | W-03 Watch-only. |
| Layout and elements | Typed descriptor/xpub/address import; network/derivation/policy preview; sensitive-data warning; Import/Cancel. |
| Every control activation | Paste/scan/file → bounded preview; Import → W-06 management-only record; Cancel → clear transient material; reveal → local deliberate. |
| Distinctive states | Wrong checksum/network/unsupported derivation rejected; no network validation upload; large QR/file bounded. |
| Exact copy | “Public wallet data can reveal your portfolio. TGP checks it locally and does not upload it to a public wallet service.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | None during import validation. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Imported descriptor cannot trigger remote URL, wallet derivation bomb, or signing authority. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-06: Provenance and management-only quarantine

| Record field | Required behavior |
|---|---|
| Entry points | Existing-wallet import/connection. |
| Layout and elements | Externally linked/history unknown choice; conservative explanation; management-only label; Continue; source details. |
| Every control activation | User provenance choice → local conservative tag; Continue → W-07; details → W-13; Pay contact → blocked explanation, no warning-only override. |
| Distinctive states | Unknown history stays conservative; fresh address/swap output does not auto-upgrade; no anonymous/clean badge. |
| Exact copy | “This wallet can be managed here. Contact payments remain unavailable while identity-linkage requirements are unmet.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Any external transformation preserves ancestry label and cannot unlock baseline-blocked spend automatically. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-07: Chain node and privacy profile

| Record field | Required behavior |
|---|---|
| Entry points | Wallet setup or settings. |
| Layout and elements | Own node/protected peer mode; chain-specific third-party exposure; endpoint type; Test/Save. |
| Every control activation | Own endpoint → N-05 typed test; approved BTC filter mode → local peer config; ETH RPC → explicit query exposure; Save → W-08 if qualified. |
| Distinctive states | No endpoint/no qualifying mode: wallet remains unsynced/limited; no default direct provider; XMR view-key service unavailable. |
| Exact copy | “Tor hides network origin from the endpoint, not the address or query you send it.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No batched unrelated ETH accounts, BTC xpub upload, or XMR private view-key export. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-08: Wallet synchronization

| Record field | Required behavior |
|---|---|
| Entry points | Approved node profile. |
| Layout and elements | Chain/profile, last locally verified state, headers/scan progress, pause, details. |
| Every control activation | Pause → stop optional sync safely; Details → exact node/query exposures; Done → W-09; node change → W-07 reviewed. |
| Distinctive states | Stale/partial/offline explicit; balance not final before required scan; provider proof/checkpoint failure blocks trusted claims. |
| Exact copy | “Synchronization is incomplete. Displayed funds or history may be incomplete.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Malicious provider, stale checkpoint, reorg and process death cannot show false complete/spendable state. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-09: Wallet home

| Record field | Required behavior |
|---|---|
| Entry points | Activated wallet tab. |
| Layout and elements | Selected wallet/network; hidden-by-default sensitive balance; sync/provenance; Receive/Pay/Request; History; add/settings. |
| Every control activation | Reveal balance → separate local wallet policy; Receive → W-10; Pay → P-03 eligible or block; Request → P-01; History → P-09; Add → W-02; Settings → W-13. |
| Distinctive states | Watch-only no signing; management-only contact Pay blocked; stale balance warning; chat device linkage never populates funds. |
| Exact copy | “Management-only” / “Watch-only” / “Sync incomplete” shown independently. |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening Wallet cannot expose contact roster or trigger hidden rates/token/NFT services. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-10: Receive address and request context

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Receive. |
| Layout and elements | Chain/network, fresh address/subaddress, optional amount, reveal/copy/QR; local label; external-share warning. |
| Every control activation | Reveal → protected display; Copy → deliberate clipboard boundary; QR → typed receive code; Request contact → P-01 eligible 1:1; Done → home. |
| Distinctive states | Fresh address not privacy guarantee; unsupported stealth/silent receive disabled; no reuse by default; stale scan caveat. |
| Exact copy | “This address can be shared. Public-chain receipts and funding history may still be linkable.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receive QR cannot be misparsed as contact/pairing or contain private key/contact label by default. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-11: Create new wallet and recovery preparation

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Create. |
| Layout and elements | Exact chain/recovery format; local creation; backup requirement; no inherited messaging root; Create/Cancel. |
| Every control activation | Create → independent wallet entropy and protected store; Backup → B-09; Continue → W-07 only under reviewed policy; Cancel → safe unactivated cleanup. |
| Distinctive states | Entropy/key protection failure blocks; new wallet not labeled anonymous; receive/spend readiness depends backup/capability rules. |
| Exact copy | “New keys do not make later funding anonymous. Back up this wallet separately.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | OS entropy and maintained chain wallet derivation in isolated wallet runtime; no messaging-key derivation. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Two wallet roots and messaging roots independent; backup acknowledgement does not certify written backup. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-12: Restore wallet recovery

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Restore. |
| Layout and elements | Exact chain/format; protected seed/passphrase input; XMR restore height/BTC descriptor needs; restore review. |
| Every control activation | Choose format → supported parser; input visibility → deliberate; Restore → wallet-only derivation and W-06/W-07; Cancel → clear transient secrets. |
| Distinctive states | Wrong format/network/passphrase uncertainty truthful; no seed guessing/upload; no chat or current membership recovery. |
| Exact copy | “Only enter recovery material on a trusted device. This operation can grant spending access.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Seed never enters JS/general diagnostics/clipboard; restore cannot silently become chat continuity. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-13: Wallet settings and source labels

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings/provenance detail. |
| Layout and elements | Node profile; local provenance/source tags; backup; hardware; guardrails; rates; disconnect/remove; advanced. |
| Every control activation | Node → W-07; source → local conservative view; Backup → B-09; Guardrails → P-11; Rates → W-15; Remove → separate backup/removal review; Advanced → X-01. |
| Distinctive states | No anonymity score; mixed-source selection blocked automatically; local label changes cannot change verified history facts. |
| Exact copy | “Source labels are local safety notes, not proof of ownership, legality, or unlinkability.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Disconnect removes local association only; no funds destroyed without separate explicit removal ceremony. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-14: Offline signing transfer

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Advanced → Offline signing. |
| Layout and elements | Typed unsigned transaction/PSBT, exact review summary, QR/file export, signed-return import; Cancel. |
| Every control activation | Export → explicit destination review; Import signed → bounded parse and intent comparison then P-07; Cancel → no broadcast; unknown type → reject. |
| Distinctive states | No private-key export; copied unsigned/public policy still sensitive; corrupt/mismatched returned payload blocked. |
| Exact copy | “Review destination, amount, network, change, and fee on the signing device.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Cross-network, sighash, fee, change and recipient substitution cannot pass return validation. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-15: Optional fiat estimates

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings Rates. |
| Layout and elements | Off default; manual rate; approved remote identifier-free source; cached time/staleness; Save. |
| Every control activation | Manual → local input; remote opt-in → exposure preview and broker fetch; Refresh → explicit request; Off → no future fetch. |
| Distinctive states | Stale/missing rate does not block exact-coin review; no wallet/contact ID in request; no direct fallback. |
| Exact copy | “Approximate value only. Not an executable exchange price.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet opening has zero rate traffic until enabled; failure leaves exact amounts usable. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

#### W-16: Silent and stealth receiving experiments

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Advanced → Receiving protocols. |
| Layout and elements | Bitcoin silent receive and Ethereum stealth/gas profiles separately listed; scanning/recovery/infrastructure evidence; unavailable. |
| Every control activation | Profile → exact limitations; recovery → required scan metadata; Back → ordinary deliberate receive only; no automatically enabled announcement scan. |
| Distinctive states | No production activation until all gates; ETH gas source can associate addresses; unsupported hardware honest. |
| Exact copy | “A different receiving address does not remove funding, scanning, gas, or endpoint linkage.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No external indexer, announcement service, or gas relayer contacted on catalog view. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |


### Payment requests and spending

#### P-01: Create one-to-one payment request

| Record field | Required behavior |
|---|---|
| Entry points | Qualified Wallet Request or contact details. |
| Layout and elements | Intended direct peer, comparison, chain, fresh address, optional integer amount/memo, expiry, Review. |
| Every control activation | Select peer → existing 1:1 only; amount/memo → bounded input; Review → P-02; Cancel → no request; group path → select person and open direct scope. |
| Distinctive states | No wallet still can view incoming request; unsupported/public-chain eligibility blocks creation; no group event. |
| Exact copy | “A request does not move funds.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No plaintext address/amount/contact map to TGP service and no hidden peer signature credential. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-02: Incoming request card and details

| Record field | Required behavior |
|---|---|
| Entry points | Typed E2EE direct request. |
| Layout and elements | Sender comparison; exact chain/address/amount/expiry; claimed versus observed status; Pay/Decline; details. |
| Every control activation | Pay → P-03 eligibility and wallet review; Decline → bounded local/optional scoped response; Details → safe fields; expired → no approval; activate wallet → W-01. |
| Distinctive states | Wrong network/address/replay/unknown version rejected; peer “paid” claim not settlement; locked hides sensitive detail. |
| Exact copy | “No funds have moved. Review in your wallet before authorizing.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crafted card cannot sign/broadcast or force wallet activation. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-03: Select payer wallet and amount

| Record field | Required behavior |
|---|---|
| Entry points | Pay contact or incoming request. |
| Layout and elements | Eligible wallet list, source policy, exact amount, request expiry, Continue. |
| Every control activation | Wallet → capability/provenance check; amount → integer validation; Continue → P-04; management-only → W-06 blocked explanation; Back → no effect. |
| Distinctive states | Insufficient funds/stale sync/unknown history blocks; no merge of different source tags; no public-chain warning override. |
| Exact copy | “Choose an eligible wallet. Connecting a wallet does not make contact payments private.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Changing wallet/source/amount invalidates any earlier review handle. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-04: Exact payment review

| Record field | Required behavior |
|---|---|
| Entry points | P-03 valid preparation. |
| Layout and elements | Recipient/key state; network; amount; fee/cap; source; destination; delay; worst relevant exposure; Authorize/Back. |
| Every control activation | Authorize → P-05 with current revision; source/fee/schedule edit → recompute review; destination reveal → deliberate; Back → no sign. |
| Distinctive states | Key/request/fee/source/chain change invalidates review; offline quote stale; no floating-point rounding ambiguity. |
| Exact copy | “Review the exact amount, network, destination, and fee before authorizing.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Substitution between review and authorization causes conflict, never silent sign. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-05: Separate wallet authorization

| Record field | Required behavior |
|---|---|
| Entry points | P-04 Authorize. |
| Layout and elements | Exact action summary; local native reauth/hardware choice; Confirm/Cancel; no chat-unlock reuse as sole authority. |
| Every control activation | Confirm → one-use authorization for reviewed revision; hardware → P-06; local sign → P-07; Cancel → no signature. |
| Distinctive states | Failed auth/rate limit/locked wallet blocks; process restart loses unconsumed UI authorization; no background auto-sign. |
| Exact copy | “Authorize this payment only. Chat access does not grant spending access.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Untrusted frontend cannot reuse handle for different recipient/amount or repeated spend. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-06: Hardware or air-gapped signature return

| Record field | Required behavior |
|---|---|
| Entry points | P-05 supported signer. |
| Layout and elements | Transaction review handoff; connection/export; waiting; import; Cancel. |
| Every control activation | Send to signer/export → reviewed typed payload; Import/return → exact intent validation; Cancel → no broadcast; changed payload → reject. |
| Distinctive states | Device disconnect, unsupported policy, partial QR, stale authorization safe; no seed prompt. |
| Exact copy | “A returned signature is checked against your reviewed transaction before broadcast.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wrong change/fee/network/sighash/recipient or extra transaction cannot sneak through. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-07: Signed/ready/broadcast decision

| Record field | Required behavior |
|---|---|
| Entry points | Valid local/hardware signing result. |
| Layout and elements | Signed status, broadcast policy, copied-signature warning, Broadcast if separate step, Cancel local hold. |
| Every control activation | Broadcast → broker submission under current valid policy; Hold → explicit signed-held advanced flow; Cancel → stop local submission, warn copied signature may escape. |
| Distinctive states | Unsigned schedule instead → P-10; route down stays not broadcast; unknown result reconciles chain before retry. |
| Exact copy | “Signed is not broadcast. A copied signed transaction may be broadcast elsewhere.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No automatic double broadcast/sign on timeout; cancel never claims chain reversal. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-08: Payment progress and chain observation

| Record field | Required behavior |
|---|---|
| Entry points | Broadcast submission or request status. |
| Layout and elements | Submitted/pending/confirming/chain-specific finality/spendability; local evidence; details; no chat delivery equivalence. |
| Every control activation | Details → P-09; Refresh → approved wallet observation; return chat → minimal card; error → safe chain-specific action not generic repeat. |
| Distinctive states | Reorg/conflict/replacement/expired request distinct; pending does not imply irreversible finality; peer claim labeled. |
| Exact copy | “This status comes from your wallet's current chain view, not a chat receipt.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Reorg can move state backward without duplicate payment or false terminal success. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-09: History and transaction detail

| Record field | Required behavior |
|---|---|
| Entry points | Wallet History or payment progress. |
| Layout and elements | Local sent/received/pending filters; chain status; local labels; reveal TXID/proof; export; mapping retention. |
| Every control activation | Row → exact transaction; Reveal TXID/proof → disclosure warning; Export → chosen minimal fields/destination; remove local mapping → separate confirmation; filter → local. |
| Distinctive states | Locked wallet hides; stale/reorg state visible; card minimization not public-chain erasure; no explorer auto-open. |
| Exact copy | “Sharing identifiers or proofs can reveal more about this payment.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Default history export excludes contact labels/mapping unless explicitly selected. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-10: Delay or schedule payment

| Record field | Required behavior |
|---|---|
| Entry points | P-04 schedule or Advanced. |
| Layout and elements | Unsigned intent default; chosen time; fee cap/expiry; lock/background limits; signed-held advanced warning; Save/Cancel. |
| Every control activation | Save → protected unsigned scheduled intent; due → revalidate and ask authorization; Cancel pending → remove local intent; signed-held → separate explicit qualified mode. |
| Distinctive states | App asleep/locked says awaiting authorization; spent inputs/nonce/expired request/changed fee requires new review; jitter distinct. |
| Exact copy | “Scheduling does not guarantee broadcast or hide timing. You may need to authorize again.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Clock change, reboot, request expiry and conflicting spend cannot trigger unauthorized late payment. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-11: Spend guardrails

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings Guardrails. |
| Layout and elements | Local daily threshold, large-send extra review/delay, reset timezone, remaining limit, Save. |
| Every control activation | Edit → local policy draft; Save → separate wallet auth if broadening; reset rule → explicit explanation; Back → unchanged. |
| Distinctive states | Not coercion-proof; cloned wallet/other signer may bypass local limits; no server enforcement; clock ambiguity conservative. |
| Exact copy | “These are local guardrails, not a guarantee against theft or coercion.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Limit broadening cannot be caused by contact payload, settings sync, or clock rollback. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

#### P-12: Payjoin negotiation review

| Record field | Required behavior |
|---|---|
| Entry points | Qualified BTC wallet Advanced → Payjoin. |
| Layout and elements | Protocol/version/direction; receiver/coordinator transport; exact extra-input/fee policy; review; no-fallback choice. |
| Every control activation | Start only if qualified → isolated negotiation; review changed transaction → P-04; cancel/failure → no plain-payment fallback; Back → no broadcast. |
| Distinctive states | Default experimental/off; rejected proposal not ordinary BTC send; timeout/replay/contribution mismatch stops. |
| Exact copy | “Payjoin is not a guarantee against transaction analysis. A failed negotiation will not send a plain payment.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receiver cannot add unauthorized outputs/fees or swap destination; no on-chain contact-spend eligibility bypass. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |


### External tools and swaps

#### X-01: Financial tools catalog

| Record field | Required behavior |
|---|---|
| Entry points | You Advanced or wallet Advanced. |
| Layout and elements | Per-adapter status, protocol/version, legal region, audit/deadline evidence; no ranked liquidity offers by default. |
| Every control activation | Adapter → X-02; Swap → X-03 disabled/qualified path; export tools → X-06; Back → no discovery traffic. |
| Distinctive states | Research-only stays disabled; missing manifest/review blocks; no auto-install or TGP hosted orderbook. |
| Exact copy | “Independent tools have different privacy, financial, and legal risks. None guarantees unlinkability.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening catalog performs no counterparty/coordinator discovery or address upload. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

#### X-02: Adapter manifest review

| Record field | Required behavior |
|---|---|
| Entry points | X-01 adapter. |
| Layout and elements | Exact destinations/data, custody/control, fees/penalties, recovery deadlines, evidence, region decision, Enable only if qualified. |
| Every control activation | Destination/data row → detailed field list; evidence → exact review; Enable → all-gates check plus explicit consent; disabled reason → no override. |
| Distinctive states | Unknown commit/license/audit/legal/retention blocks; updated manifest requires re-review; no broad destination wildcard. |
| Exact copy | “A non-custodial label does not prove safety or exemption from regulation.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Manifest cannot broaden destinations, secret authority or mainnet scope through unsigned runtime config. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

#### X-03: Contact swap offer

| Record field | Required behavior |
|---|---|
| Entry points | Qualified 1:1 swap action; otherwise disabled explanation. |
| Layout and elements | Peer, direction/assets/network, protocol engine, amounts/expiry; create/accept review; no group offer. |
| Every control activation | Create/accept → local bounded offer and X-04 only if eligible; Decline → no commitment; expired → new offer; Back → no funding. |
| Distinctive states | Mainnet default disabled; unsupported direction rejected; no generic BTC↔XMR/ETH↔XMR promise. |
| Exact copy | “An offer is not funding. Atomic does not mean risk-free.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Group route cannot emit offer; stale quote/direction/protocol mismatch rejected. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

#### X-04: Swap financial and deadline review

| Record field | Required behavior |
|---|---|
| Entry points | Valid qualified offer. |
| Layout and elements | Amounts, all fees/deposit/penalty, chain waits, exact engine worst case, watcher/signer authority, deadline coverage; Start. |
| Every control activation | Coverage details → evidence/role; Start → only if protocol/financial/legal/security gates pass; no coverage → blocked; Back → no funding. |
| Distinctive states | Phone-only background assumption fails; watcher offline/insufficient fees blocks; change in quote/coverage invalidates. |
| Exact copy | “This setup cannot safely cover the required deadlines.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Missing/forged watcher coverage cannot begin irreversible funding. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

#### X-05: Active swap and recovery

| Record field | Required behavior |
|---|---|
| Entry points | Only after separately qualified engine funding. |
| Layout and elements | Protocol-specific actual state, deadlines, required action, safe recovery export, no generic cancel/refund guarantee. |
| Every control activation | Required action → engine-authorized review; recovery export → explicit sensitive boundary; status → chain evidence; Stop UI → no false protocol cancellation. |
| Distinctive states | Offline/reorg/fee spike/reboot/peer refusal show exact unresolved state; journal retained; adapter retirement preserves recovery. |
| Exact copy | “Follow this protocol's recovery instructions. Do not assume closing the app cancels a funded swap.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Every engine terminal/refund/intervention path tested; no deletion of recovery secrets before safe completion. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

#### X-06: External tool export/import

| Record field | Required behavior |
|---|---|
| Entry points | Qualified external adapter or offline financial export. |
| Layout and elements | Tool/version/accepted format; exact fields; destination; residual exposure; Export/Import/Cancel. |
| Every control activation | Export → explicit OS/application boundary; Import → bounded network/intent/format validation; Cancel → no handoff; unsupported PSBT/tool pair → unavailable. |
| Distinctive states | No default CoinJoin/mixer coordinator; no automatically prescribed transformation route; return cannot mark funds anonymous. |
| Exact copy | “The external tool controls its own behavior. This does not remove prior wallet history.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unsupported interoperability cannot be shown as working; no seed/contact graph in default export. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |


### Trust changes and recovery

#### R-01: Contact key changed

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated replacement or detected identity mismatch. |
| Layout and elements | Prior/new fingerprints, known evidence not guessed cause, paused sends, Compare, local history, Cancel pending. |
| Every control activation | Compare → C-07 fresh representation; history → local previous records; cancel queue → scoped action; close → warning persists and unsafe sends stay blocked. |
| Distinctive states | Offline/missing evidence not auto-accepted; “new phone” only if authenticated evidence supports; no inherited green badge. |
| Exact copy | “This contact's key changed. Review before sending new content.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Reinstall claim cannot silently preserve verification or release queued messages. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-02: New endpoint approval

| Record field | Required behavior |
|---|---|
| Entry points | Contact/group scoped device proposal. |
| Layout and elements | Exact relationship/group, new scoped endpoint, authority/provenance, content effect, Approve/Reject. |
| Every control activation | Approve → current authority/consent/profile validation and admission; Reject → no recipient expansion; details → scoped provenance; group policy → G-08. |
| Distinctive states | Controller transfer record not independent person comparison; offline group transition pending; no global device model/name required. |
| Exact copy | “Approving makes this endpoint another recipient for this scope.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Approval cannot add future chats, old history, wallet authority, or unrelated group role. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-03: Revoke lost device

| Record field | Required behavior |
|---|---|
| Entry points | D-01 selected device. |
| Layout and elements | Selected grants; retained-copy warning; reauthenticate; Revoke; per-scope progress. |
| Every control activation | Revoke → immediate local fanout stop plus authenticated updates/rekeys; scope → pending/applied evidence; Done → inventory; Cancel before effect → unchanged. |
| Distinctive states | Offline peers pending; old copies remain; repeated revoke idempotent; no “erase everywhere”. |
| Exact copy | “This blocks future access as updates take effect. It does not erase stored copies.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unconfirmed remote update never shown as globally revoked; wallet access not inferred from chat revocation. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-04: Controller migration

| Record field | Required behavior |
|---|---|
| Entry points | Controller Devices → Migrate. |
| Layout and elements | Both-device reauth/comparison; selected continuity authority; fresh endpoint; successor review; Start/Cancel. |
| Every control activation | Compare → reviewed pairing ceremony; select → explicit scopes; Start → authenticated staged migration; progress → applied/pending; wallet migration → separate unavailable/path. |
| Distinctive states | Duplicate successors → R-06; interruption follows reviewed completion/rollback; no ratchet clone; old enrollment retired only under protocol. |
| Exact copy | “Migration transfers authority. It does not prove that every old copy has disappeared.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Old and new controller concurrent, interruption and conflicting successors cannot silently both enroll. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-05: Controller lost

| Record field | Required behavior |
|---|---|
| Entry points | Help recovery or surviving companion. |
| Layout and elements | What this device retains; no automatic promotion; archive/identity/wallet options; re-establish contact. |
| Every control activation | History → available local/ B-06; New identity → explicit fresh setup; wallet recovery → B-09/W-12 separate; continuity → R-07 if approved; Back → no authority. |
| Distinctive states | No approved continuity means honest loss/reset; companion cannot become controller by timeout; old device may remain active. |
| Exact copy | “A surviving companion keeps only its existing grants. It does not automatically gain controller power.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Recovery help cannot trigger silent trust promotion or server password reset. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-06: Group or authority conflict

| Record field | Required behavior |
|---|---|
| Entry points | Contradictory authenticated state, successors, or stale required transition. |
| Layout and elements | Affected scope, bounded local evidence, paused actions, authenticated recovery, support-safe export. |
| Every control activation | Recover → reviewed missing-state/fresh-admission path; Export diagnostics → H-05 bounded; successor group → explicit new group if required; Back → paused state remains. |
| Distinctive states | No wall-clock/arrival winner; no untrusted server rejoin; ordinary unrelated scopes may remain usable. |
| Exact copy | “This scope needs security review. Sending is paused rather than choosing an uncertain authority state.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Fork, partition, stale restore and malicious coordinator cannot force weaker accepted view. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

#### R-07: Continuity archive experiment

| Record field | Required behavior |
|---|---|
| Entry points | Backup hub or recovery help. |
| Layout and elements | Disabled high-consequence status; exact authority versus history distinction; old-controller risk; Back. |
| Every control activation | Read design → local explanation; approved future restore → separately gated ceremony only; Back → no authority; no Enable from normal backup. |
| Distinctive states | Default unavailable; copied archive cannot prove predecessor absence; wallet unrelated. |
| Exact copy | “Continuity recovery can create competing authority if an old copy still exists.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Ordinary archive contains no continuity authority; deep link cannot enable experimental restore. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |


### Experimental calls

#### L-01: Pre-call or unavailable call

| Record field | Required behavior |
|---|---|
| Entry points | Qualified conversation call action. |
| Layout and elements | Intended people/endpoints; route; trust warnings; audio default; Start; limits. |
| Every control activation | Start → only qualified profile then signaling; unsupported → local unavailable explanation; video preview → permission/local preview only; Cancel → no capture. |
| Distinctive states | Key/group/route issue blocks; no direct fallback; no mic/camera from merely opening pre-call. |
| Exact copy | “Setting up encrypted media is separate from sending a call invitation.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No microphone/camera before consent and no call key to nonparticipants. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

#### L-02: Incoming call and endpoint selection

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated qualified call invite. |
| Layout and elements | Generic locked-safe caller state; Answer on this device; Decline; trust/unlock requirement. |
| Every control activation | Answer → local permission/unlock and call admission; Decline → no media; other device answered → no capture; locked → required unlock. |
| Distinctive states | Ringing not live; timeout honest; push cannot release keys; duplicate answers arbitrate one endpoint. |
| Exact copy | “Answering admits this device to the protected call after setup completes.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Multiple-device answer race leaves at most one active media endpoint per person by default. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

#### L-03: Live call, rekey, and handoff

| Record field | Required behavior |
|---|---|
| Entry points | Qualified protected media active. |
| Layout and elements | Actual admitted roster; mic mute; camera off default; route; End; handoff; explicit state. |
| Every control activation | Mute → local capture/transmit control; Camera → preview/consent; Handoff → target admit/fresh state/old retire; End → stop capture/erase session state. |
| Distinctive states | Reconnecting/security update pauses media; unsafe rekey ends/pauses; app lock/panic applies capture policy; no automatic recording. |
| Exact copy | “TGP does not record this call. Participants or their devices may still record it.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Sender spoof/replay, outsider decrypt, route failure, lock and handoff interruption safe. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

#### L-04: Call ended or failed

| Record field | Required behavior |
|---|---|
| Entry points | User end, timeout, route/security failure. |
| Layout and elements | Actual end reason; no capture; separate voice-note option; retry pre-call; Done. |
| Every control activation | Voice note → A-04 fresh user action; Retry → L-01 full current-state review; Done → chat; no auto-record/upload. |
| Distinctive states | Failed route remains protected-only; no queued speech secretly retained; unsupported state explicit. |
| Exact copy | “The protected call ended. You can choose to record a separate voice message.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Call failure does not activate microphone, direct media, or asynchronous attachment automatically. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

### Screen change control

The catalog is closed for the declared scope, not a claim to know every future third-party interface. OS/store pickers and permission dialogs, hardware firmware, external tools, and exact protocol-specific swap recovery branches need versioned annexes before release.

A new button, menu item, automatic effect, external destination, permission, recipient, retained record, or authority transition must update this catalog, its disclosure comparison, and acceptance tests. A feature flag or deep link cannot bypass a disabled record's release gate.

---

## Implementation, Verification, and Release Contract

This volume turns the design into accountable implementation and evidence work. It does not declare any gate passed; the supplied material contains no TGP source checkout, runnable build, packet capture, independent assessment, user-study result, or jurisdiction-specific counsel opinion.

### Release status and decision vocabulary

#### What is selected and what is not

| Decision class | v0.6 status | Consequence |
|---|---|---|
| Product privacy invariants | Binding design requirements | Implementation cannot override them |
| Rust core / TypeScript presentation | Selected stack direction | Actual bridges/frameworks still qualify per platform |
| No registration / directory / contact upload | Selected product policy | Test first launch and every discovery path |
| Scope-local keys / explicit recipients | Selected authority requirement | Concrete library composition remains blocking |
| Protected broker / fail closed | Selected networking requirement | Actual sockets/resolution/platform exceptions need evidence |
| Two tabs before optional wallet | Selected navigation | Does not require wallet to ship |
| Keep history / no pre-join archive / no linked history by default | Selected privacy defaults | Every restore/sync path must preserve them |
| libsignal direct profile | Candidate, not approved integration | Licensing, scoped identity, PQ ratchet and metadata review |
| Hybrid OpenMLS | Candidate, production profile unresolved | No group production release before exact suite/interop review |
| Low-entropy hybrid invitation composition | Unresolved cryptographic decision | No homemade PAKE-plus-KEM production shortcut |
| Strict authority freshness | Requirement selected, mechanism unresolved | Membership/device-sensitive production sends blocked until resolved |
| Mobile wallet process isolation | Platform-specific unresolved decision | Separate installation or disabled financial module if necessary |
| Numeric performance/capacity targets | Proposed acceptance budgets | Lower supported limits after measurement; no claimed results |
| Large shared mailboxes / external blobs | Blocked baseline proposals | No production enablement through warnings |
| Public-chain contact spending | Blocked where privacy baseline is exceeded | Management is not automatic spend approval |
| Calls / swaps / financial adapters | Experimental, separate gates | No mainnet/live deployment approval in this document |
| Worldwide legal availability | Not established | Financial/service launch by jurisdiction only after approval |

The distinction matters because a comprehensive spec can deliberately identify unresolved engineering questions. Calling those questions “implemented,” “audited,” “production-ready,” or “privacy-preserving” without evidence would contradict the product's own requirements.

#### Priority and dependency rules

P0 requirements are hard requirements for their own capability, not a promise that every capability ships in the first release. Wallet, groups, calls, and continuity may remain absent while an independently qualified direct-chat release ships.

No calendar date or staffing assumption is specified. Work estimates follow experiments, named owners, resource measurements, and the chosen platform scope.

### Architecture decision register

| ADR | Required decision and proposed direction | Evidence required to close | Owner role / blocked scope |
|---|---|---|---|
| ADR-IDENTITY | Scope-local exported identity with no reusable universal certificate | Credential wire examples; joinability review; compromise boundaries | Security + protocol / all relationship scopes |
| ADR-SESSION | Independent direct sessions for authorized endpoints | Chosen API; crash/rollback tests; prekey publication; state lifetime | Protocol / direct chat, devices |
| ADR-PQ | Exact mandatory direct hybrid handshake and continuing ratchet profile | Versioned profile; vectors; downgrade review; composition assessment | Security / direct release |
| ADR-INVITE | Complete reviewed high-/low-entropy invitation protocol and one-wrong-guess policy | Formal transcript/state machine; concurrency/race review; accessible ceremony | Security / invitations |
| ADR-PAIR | Both-device compared channel, no live-state copy | Canonical transcript; comparison test; scoped-grant tests | Protocol + UX / device linking |
| ADR-GROUP | Group application authority, ordering, coordinator succession | State transition model; fork/partition simulation; recovery plan | Protocol / private groups |
| ADR-GROUP-PQ | Actual interoperable maintained hybrid group suite | Suite/codepoint/version; dependency advisories; interoperability and review | Security / group production |
| ADR-FANOUT | Client recipient-specific wrapping initially | Single/colluding relay review; size/timing captures; capacity curves | Protocol + operations / group metadata |
| ADR-FRESH | Exact authority freshness and offline availability tradeoff | Defined adversary/partition model; stale-controller and revoked-device tests | Security / revocation and affected sends |
| ADR-ARCHIVE | History format separate from continuity authority | Hostile parser tests; no state clone; expiry/import rules | Storage / backup |
| ADR-RECOVER | Old/new controller conflicts, loss and reset | Conflicting-successor model; re-establishment UX; peer continuity rules | Security / migration and continuity |
| ADR-TOR | Per-platform maintained Tor/PT integration | Real-device sockets/lifecycle/kill-switch matrix | Platform + network / platform support |
| ADR-MEDIA | Tor-compatible media transport with no direct fallback | Latency/loss/load experiment; packet captures; parser containment | Media + network / calls |
| ADR-MEDIA-KEY | Call-only subgroup and sender authentication | Replay/outsider/rekey/handoff assessment | Security + media / calls |
| ADR-IOS | App-open default, optional platform notices and content-key policy | Push token lifecycle; suspension/reboot tests; disclosure comparison | iOS lead / iOS availability claims |
| ADR-DESKTOP | Renderer/native/process/storage/update architecture | OS sandbox and command allowlist tests; build verification | Desktop lead / desktop release |
| ADR-ATTACH | Reviewed container, staging, transfer, retention | Malformed media/container tests; memory/disk bounds; metadata fixtures | Media + storage / attachments |
| ADR-OPS | Queue bounds, quotas, eviction, maintenance and no-log deployment | Actual host swap/dump/snapshot review; load tests; restart captures | Operations / relays |
| ADR-FUND | Separate funding/entitlements and mandatory business retention | Data-flow/legal review; no identity join; wallet-free billing tests | Product + legal / any paid optional service |
| ADR-MEASURE | Reference devices, network conditions, sample and thresholds | Preregistered lab protocol; no-production-analytics proof | Research + security / performance claims |
| ADR-WALLET-ISO | OS-realized wallet boundary per target | Memory/IPC/renderer attack tests; privilege diagram | Wallet + platform / financial activation |
| ADR-WALLET-XMR | Maintained complete scanner/signer/recovery implementation | Exact implementation review; output/fee/reorg fixtures | Wallet / XMR |
| ADR-WALLET-BTC | Descriptor/filter/PSBT/hardware compatibility | Tor network adapter; filter/query analysis; device/firmware matrix | Wallet / BTC management |
| ADR-WALLET-ETH | Exact node/light verification and address-query policy | Checkpoint trust; RPC exposure; account isolation | Wallet / ETH management |
| ADR-PAYJOIN | Exact protocol/direction/transport and no-fallback policy | Negotiation/fee/contribution tests; residual-linkage/legal review | Wallet + security / Payjoin |
| ADR-SWAP | One exact engine/direction plus deadline/watcher authority | Maintained source; audit; full recovery matrix; coverage proof | Wallet + legal / each swap adapter |
| ADR-LEGAL | Entity/activity/country/distribution/service classification | Written advice on current law and operating facts | Qualified counsel / affected launch |
| ADR-INCIDENT | Capability containment without exfiltration or stranding recovery | Signed notice/runbook simulation; offline-client limitations | Security + release / operational response |

Every ADR includes alternatives, rejected shortcuts, key/authority/data flows, exact versions and licenses, failure semantics, metadata delta, owner, reviewers, evidence, migration/rollback, public-claim consequences, and reevaluation triggers. An unfilled ADR remains open rather than being “approved by default.”

#### Authority freshness is a real availability decision

The system cannot assume that a disconnected endpoint instantly knows an unseen removal. v0.6 therefore requires a reviewed definition of acceptable freshness rather than promising both indefinite offline sending and immediate universal revocation.

Evaluate authenticated sequenced state with bounded leases/checkpoints, explicit coordinator dependencies, or another reviewed mechanism against malicious delay, collusion, partitions, compromised old controllers, rollback, and clock uncertainty. Do not choose a timeout election or wall-clock last-write-wins policy merely to keep the Send button working.

The ADR must state precisely which device can send, under what known state, after how much offline time, and which revocation claim can be made. Until that mechanism is approved, affected multi-device/group security claims and production operations remain blocked.

### Implementation contracts

#### Command execution and optimistic UI

```text
Receive typed command
  -> validate schema/version/size
  -> locate currently authorized scope and key lease
  -> validate permission and expected revision
  -> prepare bounded operation
  -> persist operation plus cryptographic state transactionally
  -> return truthful local state
  -> perform permitted network/external effect
  -> record evidence-backed transition
  -> publish minimal typed UI event
```

The renderer never decides authority from a hidden button or a cached green icon. All important checks also run in Rust, including stale revision, locked scope, unsupported security profile, recipient expansion, signing handle, and export selection.

An optimistic bubble may mean Queued only after a safe local commit. It cannot mean relayed, received, admitted, verified, paid, or confirmed without the corresponding evidence.

#### Transaction and idempotency requirements

| Operation | Stable identity | Atomic boundary | Retry/cancellation rule |
|---|---|---|---|
| Text/control send | Scoped event and operation IDs | Appropriate session advance + protected outbox | Never recreate from stale key state |
| Edit/reaction | Scoped target + author/revision/operation | Mutation eligibility + event persistence | Duplicate is not another edit/count |
| Invitation claim | Invite generation + transcript/attempt | Used/burned marker and accepted state | No second claimant after crash |
| Device grant | Pairing transcript + selected scope revision | Grant intent and independent admission state | Partial scopes remain distinguishable |
| Group transition | Authenticated parent state + transition ID | Validated state/epoch and derived secrets | Conflicts pause rather than arrival-order choice |
| Archive import | Archive integrity ID + import selection | Bounded transactional import batches | No duplicate resurrection/authority clone |
| Payment review | Wallet revision + request + intent digest | Immutable reviewed preparation | Any material change invalidates approval |
| Sign/broadcast | One-use authorization + chain transaction identity | Signed result and observed submission state | Reconcile unknown chain state before repeat |
| Swap | Engine-specific operation ID | Durable encrypted recovery journal | Cannot generic-cancel funded state |
| External export | Preview revision + destination + exact selection | Finalized approved package | Partial/failed state reported, no hidden extra fields |

Rollback resistance has limits on general-purpose endpoints. The implementation must detect/prohibit dangerous state reuse and document unrecoverable uncertainty; it cannot assume encrypted storage alone prevents snapshots restoring an old sender.

#### Retention and storage matrix

The following are design policies, not assertions about deployed servers. Each row needs storage-location, key, delete/replay, restart, and snapshot evidence.

| Data | Default policy | Required deletion/recovery behavior |
|---|---|---|
| Local message history | Keep until explicit deletion or selected prospective expiry | Encrypted per scope; no forced seven-day deletion |
| Unsent draft | Encrypted local, bounded size | Clear on explicit discard; hide/purge active plaintext on lock |
| Sender retry source | Until acknowledged/expired/cancelled according to policy | Necessary retry cannot imply relay durability |
| Relay ciphertext queue | RAM-only with seven-day maximum TTL | Earlier eviction/restart possible; no swap/dumps/snapshots/log traces by design |
| Invitation | One use, proposed ten-minute expiry | Burned/used replay protection survives relevant crash window |
| Skipped/prekey/replay state | Exact bounded profile policy | Cannot erase too early for supported delivery or retain without bound |
| Group roster/policy | Protected current state plus bounded authenticated recovery | No plaintext central group history |
| Media staging | Protected temporary content, bounded quotas | Cancellation/expiry/lock workers handled explicitly |
| Received attachment | Protected local cache according to content policy | Expiry removes eligible keys/cache references; recipient copies remain |
| Search index | Per-scope protected local index | Locked scopes excluded from active results and memory |
| Pairing grants | Current scoped authority and necessary revoked-state evidence | No full universal endpoint directory on peer infrastructure |
| Chat payment card details | Proposed minimization after settlement + 24 hours | Keep required unresolved-operation/recovery data; no chain erasure claim |
| Wallet transaction history | User-controlled local record with chain requirements | Chat deletion does not destroy funds or mandatory recovery state |
| Scheduled unsigned intent | Until executed/expired/cancelled | Revalidate at due time; no automatic authorization |
| Swap recovery journal | Until protocol-safe final state and user recovery policy | Retiring adapter cannot delete intervention/refund material |
| Local diagnostics | Bounded rotating redacted evidence | Exact cap/TTL and opt-in export; no remote automatic upload |
| Support case export | Only explicit reviewed selected fields | Recipient and published retention defined before send |
| Billing records | Separate minimum necessary business/legal record | No messaging/queue/contact identifier join |
| Study data | Separate consented study retention | No production behavior feed or hidden enrollment |
| External backups | User-chosen destination | Local delete cannot erase externally retained archive |

Exact skipped-key limits, replay windows, diagnostic TTLs, and platform temporary-file behavior are profile/implementation decisions requiring review, not conveniently infinite defaults. Missing numerical/configuration evidence blocks the relevant implementation gate.

### Acceptance test catalog

All tests start as Not run. The evidence package records real device/OS/build, chosen crypto/transport profile, prerequisites, inputs, expected and actual observations, packet/storage captures, reviewer, findings, remediation, and rerun.

#### Identity, protocol, and content

| Test | Given / when | Required result |
|---|---|---|
| TST-001 First launch | Fresh install; name skipped; all optional permissions denied | Local profile/chat available without registration, contacts, wallet, analytics |
| TST-002 Remote invite | Captured link without secret; wrong guess; reused/expired code | No connection; prescribed burn/expiry/replay behavior; no oracle bypass |
| TST-003 Invitation race | Two claimants and process death at each persistence point | At most intended valid accepted relationship; no invite reuse |
| TST-004 Comparison | Remote image, transferred record, stale fingerprint, actual in-person QR | Distinct provenance; no automatic false independent comparison |
| TST-005 Key change | Queued message exists; peer identity changes | Pause affected send; fresh review; no silent “new phone” trust |
| TST-006 Direct profile | Unsupported/downgrade/replayed handshake and first reply | Required profile or fail closed; no compatibility downgrade |
| TST-007 State crash | Crash/rollback/disk full around session advance and send | No nonce/key reuse; truthful retry or explicit blocked uncertainty |
| TST-008 Message algebra | Duplicate/reordered edits, reactions, replies, wrong-author event | Bounded deterministic result; no cross-scope mutation |
| TST-009 Receipt accuracy | Relay ACK, relay restart, one/multiple endpoint receipts | Correct queued/accepted/received/partial, never inferred read |
| TST-010 Expiry | Sender/receiver skew, long offline delay, import and duplicate | Prospective authenticated policy; no timer restart/resurrection |
| TST-011 Search lock | Query while unlocked, then relock/process background | Results/snippets/key leases cleared; locked scope excluded |
| TST-012 Link/parser | Malformed URL, QR, card, JSON, unknown security event | Bounded inert handling; no native authority or hidden fetch |

#### Network, infrastructure, and metadata

| Test | Given / when | Required result |
|---|---|---|
| TST-013 Full egress | Every network feature; IPv4/IPv6/DNS/redirect/proxy exceptions | Only permitted broker/bootstrap/platform scope; no hidden clients |
| TST-014 Route outage | Kill Tor during send, node, update, rate, diagnostics, media | No direct fallback; protected local pending state |
| TST-015 Context separation | Unrelated chats, wallet accounts, diagnostics, updates | No unintended reusable external identifier/circuit-level context join |
| TST-016 Relay host | Swap/core dumps/snapshots/crash/maintenance simulated | Verified deployment controls; accepted queue loss labeled honestly |
| TST-017 Relay quota | Flood malformed/valid bearer capabilities and large messages | Bounded per-capability resources; no civil-identity verification shortcut |
| TST-018 Directory | Invalid/old/expired/compromised recommendation | Reject per policy; cannot change identity authority or security profile |
| TST-019 Metadata comparison | Equivalent v0.5/v0.6 journeys, single/colluding observers | Field/size/timing/retention delta; no unsupported equality conclusion |
| TST-020 Privacy Report | Offline, incomplete instrumentation, optional external test | Passed only for observed scope; Not tested/Inconclusive otherwise |

#### Groups, devices, and recovery

| Test | Given / when | Required result |
|---|---|---|
| TST-021 Pairing comparison | Mismatch, replay, only one confirmed device | No grants or active linked scopes |
| TST-022 Selected grants | Empty defaults, locked chat, future chat, crafted wider command | Only eligible selected scopes; no wallet/admin/future-chat expansion |
| TST-023 History transfer | None/range/custom, expired media, interrupted archive | Selected eligible history only; no ratchet/leaf clone |
| TST-024 Partial admission | Some peers/groups offline or reject | Per-scope active/pending; no global linked success |
| TST-025 Revocation | Lost device offline; peer partition; stale sender | Current reviewed freshness behavior; no global erase claim |
| TST-026 Group consent | Invite accepted but commit absent; device lacks authorization | No content/access until valid admission |
| TST-027 Group role | Malicious member/admin/coordinator attempts extra powers | Distinct powers; invalid authority rejected |
| TST-028 Group conflict | Competing children, coordinator loss, fork/partition | Affected action paused; no timeout election or timestamp winner |
| TST-029 Group capacity | Declared people/endpoints; worst-case fanout and padding | Resource/metadata targets met or limit lowered; no server-fanout switch |
| TST-030 Controller recovery | Old controller alive, duplicate successor/archive, companion promotion | No automatic authority; conflict recovery preserves truthful limits |
| TST-031 Hostile backup | Corrupt/old/bomb archive, wrong secret, truncated chunk | Bounded authenticated parsing; no plaintext temp/live-state activation |
| TST-032 Recovery drill | Isolated archive/wallet drill completed/cancelled | No active sessions, fund movement, or retained temporary secrets |

#### Platform, multimedia, and UX

| Test | Given / when | Required result |
|---|---|---|
| TST-033 Lock lifecycle | App/chat/OS lock, background, reboot, process death | Correct key leases/previews/capture cleanup; no late UI plaintext |
| TST-034 Storage | WAL/temp/cache/recents/OS backup/search/crash dump inspected | No unintended plaintext/secret capture in supported boundary |
| TST-035 Notification | Denied/delayed/revoked push/distributor, force-quit/suspension | Honest availability; no body/amount/key in push; no content-key weakening |
| TST-036 Attachment sanitize | EXIF/GPS/document author/malformed codecs/huge dimensions | Exact sanitization result; unsupported original warning; bounded worker |
| TST-037 Transfer/view-once | Missing/reordered chunk, duplicate view, expired capability | Integrity/replay enforced; no cloud fallback or copy-prevention claim |
| TST-038 Media consent | Pre-call/invite/lock/panic/handoff/failure | No pre-consent/post-cancel capture; actual roster/rekey; no direct/STUN |
| TST-039 Renderer attack | Injected content/compromised TypeScript invokes native bridge | No arbitrary sign/export/enroll/socket/shell authority |
| TST-040 Accessibility | Large text, screen reader, keyboard, reduced motion | All consequential controls and full comparison data usable |
| TST-041 Comprehension | Consented user reviews verification/grants/payment/deletion | No severe scope/authority misunderstanding; redesign/retest if observed |
| TST-042 Thirty-day paths | New user and interruption branches across catalog | Every enabled control matches record; disabled feature cannot deep-link around gate |

#### Financial, operational, and release

| Test | Given / when | Required result |
|---|---|---|
| TST-043 Wallet removal | Build with financial crates/module absent | All declared core chat journeys pass |
| TST-044 Wallet isolation | Renderer/core compromise attempt and OS privilege inspection | Enforced claimed boundary or module unavailable; distinct keys/store/recovery |
| TST-045 Existing wallet | Hardware/watch-only Connect, mismatched network, unknown history | No seed; no provider upload; conservative labels; contact-spend gate |
| TST-046 Node privacy | BTC filter/XMR scan/ETH own and external node profiles | Exact documented requests; no view key/xpub/contact map leakage |
| TST-047 Spend authorization | Changed destination/amount/fee/source/request/nonce/revision | Stale review/authorization rejected; no replay signing |
| TST-048 Chain lifecycle | Unknown submit result, reorg, replacement/conflict, stale scan | Reconcile before repeat; chain-specific status; no generic finality |
| TST-049 Hardware return | Altered PSBT/intent/network/change/fee/sighash | Reject mismatched return; exact device/firmware supported matrix |
| TST-050 Scheduling | Clock jump/reboot/locked phone/expired request/fee change | No unauthorized automatic future sign; due requires revalidation |
| TST-051 Payjoin/receive | Malicious negotiation, indexer/gas metadata, unsupported adapter | No ordinary-payment fallback; no unlinkability certification |
| TST-052 Swap | Peer failure, deadlines, watcher failure, chain reorg, phone death | Exact engine recovery; no uncovered start; no guaranteed automatic refund |
| TST-053 Export/support | Package preview, redactions, destination failure | Exact selected fields; no hidden keys/labels; truthful external effect |
| TST-054 Release supply chain | Tampered/old manifest, dependency advisory, rebuild mismatch | Block/contain according to scoped policy; no blanket audit claim |
| TST-055 Incident | Signing compromise, crypto flaw, adapter retirement, offline clients | Safe containment; no remote key exfiltration/wipe; recovery retained |
| TST-056 Funding/research | Billing/study interactions, rejected optional permissions | No messaging-identity join; no production analytics; free chat retained |
| TST-057 Legal capability | Region unreviewed/restricted, policy update, active funded operation | No new prohibited service; lawful safe recovery; no hidden identity logs |
| TST-058 Claims | Every product/store/help/security statement compared with evidence | Unsupported absolute/scopeless claim removed before release |

### Capability release gates

| Gate | Applies to | Minimum exit evidence |
|---|---|---|
| REL-CORE | Direct text and local identity | INV-01–20 applicable; ADR-IDENTITY/SESSION/PQ/INVITE/TOR; TST-001–020,033–035,039–043,053–058 |
| REL-VAULT | App/chat lock, search, archives | Key/storage/restore review; TST-010–012,031–034,040–042 |
| REL-DEVICE | Scoped pairing/sync/revoke/migration | Freshness/authority review; TST-021–025,030–032; actual multi-endpoint tests |
| REL-GROUP | Small private groups | Exact approved hybrid profile, role/ordering/freshness, client-fanout metadata; TST-026–029 |
| REL-MEDIA | Images/documents/notes/video | Parser isolation, sanitized-copy fixture tests, protected transfer/limits; TST-036–037 |
| REL-PLATFORM | Each OS/background mode | Actual hardware/OS matrix; storage/permission/push/build/lock tests; no inherited approval |
| REL-WALLET-MANAGE | Each chain and platform | Isolation, key/recovery/node/provenance review, legal classification; TST-043–046,049 |
| REL-PAY-XMR | Eligible private payment scope | Exact retained XMR flow; typed bridge; review/sign/status/history; FIN-01–20 and TST-047–050 |
| REL-PAY-PUBLIC | BTC/ETH contact spending | No-regression equivalence first; currently blocked where public linkage exceeds baseline |
| REL-CALL | Each voice/video topology | Feasibility + privacy + capture/admission/rekey assessment; TST-038 and full real egress matrix |
| REL-ADAPTER | Each protocol/direction/version | Exact maintained engine, manifest, audit, legal, deadline/recovery evidence; TST-051–052 |
| REL-OPS | Each hosted role/deployment | Retention/abuse/cost/host/signing/incident evidence, not merely source configuration |
| REL-LEGAL | Each entity/activity/jurisdiction/channel | Written current legal classification and controls compatible with invariants |
| REL-CLAIMS | Every public capability statement | Claim ID, exact evidence, limitations, approvers, expiry/review trigger |

A user checking “I understand” is not exit evidence for REL-PAY-PUBLIC or any other blocked gate. The no-regression requirement remains stricter than accepting a disclosed risk.

#### Per-platform qualification matrix

| Target | Starting mode | Required device/lifecycle coverage | Non-assumption |
|---|---|---|---|
| Android | Primary development target | Supported OS range, low-memory, OEM battery policies, lock/reboot, foreground service, picker/USB | A service is not automatically an isolated security process |
| iOS | App-open delivery baseline | Supported devices, suspension/force-quit, key accessibility, notifications, background task limits | No arbitrary long-running child wallet process or guaranteed background swap watcher |
| macOS | Installed companion | App sandbox/entitlements, keychain behavior, screen lock, update/signing, external picker | Tauri logical isolation is not OS sandbox proof |
| Windows | Installed companion | Credential/storage behavior, OS lock, installer/signature/update, renderer constraints | Packaging alone does not prove process containment |
| Linux | Installed companion | Supported distro/display/keyring/package matrix, sandbox availability, permissions | Do not imply universal distro/hardware compatibility |

Each row needs the exact Rust, TypeScript, framework, native-bridge and transport versions. “Cross-platform” means independently tested capability variants, not one test run copied across five checkboxes.

### Claims register and evidence package

#### Initial claims disposition

| Claim | Status before implementation | Required revision/evidence |
|---|---|---|
| “No phone number required” | Design intent | First-launch and optional-flow proof; no hidden dependency |
| “TGP cannot read messages” | Design intent for declared infrastructure boundary | Key/data-flow audit, server capture, operational exceptions and client limitations |
| “Post-quantum secure” | Not approved as blanket phrase | Exact protocol component/version/threat scope and limitations |
| “Deniable / not evidence” | Not approved as universal/legal claim | Protocol-specific qualified wording only; no legal guarantee |
| “Untraceable payments” | Prohibited | No such claim |
| “Unblockable anywhere” | Prohibited | Censorship-resilient attempts with explicit shutdown limits |
| “Audited” | Not approved for TGP | Actual assessor/build/scope/findings/remediation/public report |
| “No logs” | Not approved as absolute | Enumerate operational data and retention; actual deployment evidence |
| “Reproducible builds” | Target | Independent rebuild result for exact artifact/platform |
| “Instant” | Not approved as universal | Local-feedback target separated from route/delivery/confirmation |
| “Non-custodial” | Intended technical scope, not legal exemption | Exact role/control/key review plus counsel classification |
| “Free private chat” | Binding product model, unimplemented | Wallet-free/entitlement-free actual release and sustainable quota policy |
| “Works in country X” | Not approved globally | Current distribution/network/legal/capability evidence |

An evidence record includes artifact hashes, source commit/lockfile, supported platforms, approved ADRs, threat model, disclosure deltas, executed tests, captures with sensitive-data handling, review/finding closure, accessibility/comprehension results, capacity/cost, legal decision, owner signatures, and incident/rollback plans. A signature, green CI run, or this specification is not a substitute for those materials.

### Delivery work packages and accountability

#### Implementation backlog

| Package | Deliverable | Dependency and stop condition |
|---|---|---|
| WP-FOUNDATION | Types, local stores, key leases, broker, dependency/provenance CI | Named owners and threat model; no hidden socket clients |
| WP-IDENTITY | Scoped credentials, compared invitation prototype | Close identity/PQ/invitation composition; block production otherwise |
| WP-DIRECT | Protected outbox, event algebra, receipts, search/vault | Crash/failure/locked-state tests before polished success UI |
| WP-INFRA | Minimal independent relay/rendezvous/directory roles | RAM/log/host/abuse metadata evidence; sustainable quotas |
| WP-DEVICE | Pairing, selection, per-scope admission/history, revoke | Exact freshness/migration rules; no universal trust |
| WP-GROUP | Hybrid engine integration and application authority | Profile/fork/partition/fanout review; no classical fallback |
| WP-MEDIA | Protected staging, sanitization, codec sandbox, transfer | No external blob service without no-regression result |
| WP-PLATFORM | Native key/permission/lifecycle integration per OS | Actual device matrix; degrade availability honestly |
| WP-DESIGN | Tokens/components, catalog, accessible ceremonies | Every control/negative state traced; severe misunderstanding blocks |
| WP-WALLET | Isolated optional chain adapters and recovery | Disable/separate module if OS containment unmet |
| WP-PAYMENT | Typed requests, exact review, separate signing, status | Source/privacy/legal eligibility; no public-chain override |
| WP-EXPERIMENT | Calls/Payjoin/stealth/swaps/nearby/continuity prototypes | Sandbox/testnet first; no mainnet launch assumed |
| WP-RELEASE | Independent assessment, reproducibility, claim/legal gates | Scoped approval; smaller supported release if necessary |

#### Accountable roles

Bradley is the product owner named in the supplied specification. Security, protocol, platform, wallet, media, operations, release, design/accessibility, research, support and qualified legal-counsel owners must be named before execution; this document does not invent staff or approvals.

One person may hold multiple roles, but every release decision needs a named accountable owner and an independent reviewer where required. Missing an owner is a planning blocker, not implicit product-owner consent to the unresolved risk.

### Specification change control

Any change to an invariant, recipient set, authority, transport, key lifecycle, retention, dependency/parser, external destination, recovery, jurisdiction, or public claim requires an explicit before/after delta and updated tests. Feature flags, remote configuration, deep links, adapters, translations, OS integrations, and “temporary” operational logging follow the same process.

Record a change as Preserve by design, Candidate improvement, Conditional, Blocked, Deferred, or Validated for exact scope. Never summarize a tradeoff as “99% private” or average away a regression in one dimension with a benefit in another.

---

## Feature and Baseline Traceability

This matrix maps all 104 product features to technical sheets, concrete screen records, eight-dimension reviews, owner roles, and release tests. It records intended coverage, not proof that code exists or a requirement has passed.

The screen catalog's family trace rows describe the broader surface; the per-feature screen assignments here are the more precise navigation mapping. Owner roles require actual named assignees before execution.

### Feature-to-evidence matrix

| Feature | Classification | Technical / owner role | Screen IDs | Eight-dimension review | Required tests / gate |
|---|---|---|---|---|---|
| F-001 Local profile | Core P0 | T-01; Identity/platform | O-02, O-03, O-04 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-002 Display name | Core P0 | T-01; Identity/platform | O-03, C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-003 Per-contact presentation | Core P1 | T-01; Identity/platform | C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-004 Fast setup | Core P0 | T-01, T-04; Identity/platform, Network/operations | O-04, O-05 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-005 Build verification | Advanced P0 | T-15; Release/security | O-01, H-08 | AUD-03 | TST-054,058; REL-CLAIMS / REL-PLATFORM |
| F-006 QR connection | Core P0 | T-02; Protocol/security | C-01, C-02, C-03, C-06 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-007 Separate-secret invite | Core P0 | T-02; Protocol/security | C-04, C-05, C-06 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-008 Invite lifecycle | Core P0 | T-02; Protocol/security | C-02, C-04, C-05 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-009 Identity comparison | Core P0 | T-02; Protocol/security | C-06, C-07 | AUD-03 | TST-001–005,012,039–042; REL-CORE |
| F-010 Key-change review | Core P0 | T-02; Protocol/security | R-01, C-07 | AUD-03 | TST-001–005,012,039–042; REL-CORE |
| F-011 Local contact labels | Core P1 | T-01; Identity/platform | C-08, C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-012 Contact cards | Advanced P2 | T-02; Protocol/security | C-10 | AUD-03 | TST-004,012,019,053; REL-CORE / REL-CLAIMS |
| F-013 Reusable contact link | Experimental P2 | T-02; Protocol/security | C-10 | AUD-03 | TST-002–003,012,017,019; REL-CORE / REL-OPS |
| F-014 Block contact | Core P0 | T-03; Messaging | C-11 | AUD-25 | TST-012,014,017,019; REL-CORE / REL-OPS |
| F-015 Contextual tutorial | Core P1 | T-16; Design/accessibility/research | O-06, O-07, H-07 | AUD-01 | TST-001,040–042,056; REL-CORE |
| F-016 Direct messages | Core P0 | T-03; Messaging | M-01 | AUD-04 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-017 Truthful delivery | Core P0 | T-03; Messaging | M-01, M-06 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-018 Offline queue | Core P0 | T-03; Messaging | M-01, M-06, N-01 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-019 Drafts | Core P1 | T-03; Messaging | M-01, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-020 Reply | Core P1 | T-03; Messaging | M-03, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-021 Reactions | Core P1 | T-03; Messaging | M-03, M-05 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-022 Edits | Core P1 | T-03; Messaging | M-03, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-023 Pins/archive/mute | Core P1 | T-03; Messaging | M-02, M-08 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-024 Search | Core P0 | T-03, T-05; Messaging, Storage/security | M-02, M-07 | AUD-06 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-025 Disappearing messages | Core P0 | T-03; Messaging | S-06 | AUD-06 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-026 Delete controls | Core P0 | T-03; Messaging | M-09, S-09 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-027 Receipts/typing | Advanced P2 | T-03; Messaging | S-10 | AUD-25 | TST-013–014,019,042; REL-CORE |
| F-028 URL safety | Core P0 | T-06; Media/storage | M-10 | AUD-25 | TST-012–014,039; REL-CORE |
| F-029 Compatibility | Core P0 | T-03; Messaging | M-11 | AUD-04 | TST-006,012,054; REL-CORE |
| F-030 Scoped security events | Core P0 | T-03; Messaging | M-01, R-01, R-02, R-06 | AUD-04 | TST-005,025–030,039–042; REL-CORE / REL-DEVICE / REL-GROUP |
| F-031 Image sharing | Collaboration P1 | T-06; Media/storage | A-01, A-02, A-05, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-032 Documents | Collaboration P1 | T-06; Media/storage | A-01, A-03, A-05 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-033 Voice notes | Collaboration P1 | T-06; Media/storage | A-04, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-034 Video files | Collaboration P1 | T-06; Media/storage | A-06, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-035 View-once | Collaboration P2 | T-06; Media/storage | A-02, A-05 | AUD-06 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-036 Attachment storage | Experimental P2 | T-06; Media/storage | A-08 | AUD-12 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-037 Private groups | Collaboration P0 | T-07; Group protocol | G-01, G-02, G-03, G-04, G-05 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-038 Group roles | Collaboration P0 | T-07; Group protocol | G-06, G-07, G-08 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-039 Group privacy | Collaboration P0 | T-07; Group protocol | G-02, G-06, G-07 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-040 Group removal | Collaboration P0 | T-07; Group protocol | G-09, G-10 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-041 Group conflicts | Collaboration P0 | T-07; Group protocol | G-08, R-06 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-042 Large groups | Experimental P2 | T-07; Group protocol | G-11 | AUD-10 | TST-019,025–029,040–042; REL-GROUP |
| F-043 Communities | Experimental P2 | T-07; Group protocol | G-11 | AUD-10 | TST-019,025–029,040–042; REL-GROUP |
| F-044 Group history | Collaboration P0 | T-07, T-08; Group protocol, Device/authority | G-02, G-12, D-05 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-045 Voice calls | Experimental P1 | T-09; Media/security | L-01, L-02, L-03, L-04 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-046 Group voice/video | Experimental P2 | T-09; Media/security | L-01, L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-047 Call admission | Experimental P0 | T-09; Media/security | L-01, L-02, L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-048 Call handoff | Experimental P2 | T-09; Media/security | L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-049 Recording/transcription | Core restriction P0 | T-06, T-09; Media/storage, Media/security | A-04, L-03, L-04 | AUD-11 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-050 Scoped device linking | Collaboration P0 | T-08; Device/authority | D-01, D-02, D-03, D-04, D-06 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-051 History range | Collaboration P0 | T-08; Device/authority | D-05, D-06 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-052 Device inventory | Collaboration P0 | T-08; Device/authority | D-01 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-053 Revoke device | Collaboration P0 | T-08; Device/authority | R-03 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-054 Controller migration | Advanced P0 | T-08; Device/authority | R-04 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-055 Controller loss | Core P0 | T-08, T-12; Device/authority, Recovery/security | R-05 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-056 Automatic protected route | Core P0 | T-04; Network/operations | O-05, N-01, N-02, N-03 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-057 Fail-closed broker | Core P0 | T-04; Network/operations | N-01, N-02, N-05 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-058 BYO infrastructure | Advanced P1 | T-04, T-10; Network/operations, Wallet/security/legal | N-03, N-04, N-05, W-07 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-059 Federated relays | Core P0 | T-04; Network/operations | N-04, N-05 | AUD-08 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-060 Privacy report | Advanced P1 | T-14; Operations/support | H-03 | AUD-26 | TST-020,053; REL-CORE / REL-CLAIMS |
| F-061 Cover traffic | Experimental P2 | T-04; Network/operations | N-06 | AUD-27 | TST-013–015,019; REL-CORE / REL-PLATFORM |
| F-062 Snowflake contribution | Experimental P2 | T-04; Network/operations | N-07 | AUD-27 | TST-013–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-063 Device-wide VPN | Experimental P2 | T-04; Network/operations | N-07 | AUD-27 | TST-013–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-064 Local radio/mesh | Experimental P2 | T-13; Platform/wallet | N-08 | AUD-27 | TST-012–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-065 App lock | Core P0 | T-05; Storage/security | S-01, S-02, S-03 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-066 Per-chat vault | Core P0 | T-05; Storage/security | S-04, S-05 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-067 Panic lock | Core P0 | T-05; Storage/security | S-02 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-068 Decoy/disguise | Experimental P2 | T-05; Storage/security | S-08 | AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-069 Destructive wipe | Experimental P2 | T-05; Storage/security | S-08 | AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-070 Dead-man behavior | Advanced P2 | T-05; Storage/security | S-03, S-08 | AUD-15, AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-071 Clipboard/screenshot | Core P0 | T-05; Storage/security | S-07, W-10, B-09 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-072 Platform notifications | Optional P0 | T-11; Platform | H-02 | AUD-17 | TST-013–014,033–035,039–042,054; REL-PLATFORM |
| F-073 Desktop | Collaboration P0 | T-11; Platform | D-07, H-08, H-09 | AUD-17 | TST-013–014,033–035,039–042,054; REL-PLATFORM |
| F-074 Wallet activation | Optional P0 | T-10; Wallet/security/legal | W-01, W-02 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-075 Native XMR | Optional P0 | T-10; Wallet/security/legal | W-07, W-08, W-09, W-10, W-11 | AUD-20 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-076 Native BTC | Optional P0 | T-10; Wallet/security/legal | W-03, W-04, W-05, W-07, W-14 | AUD-21 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-077 Native ETH | Optional P0 | T-10; Wallet/security/legal | W-07, W-08, W-09 | AUD-21 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-078 Connect existing funds | Optional P0 | T-10; Wallet/security/legal | W-03, W-04, W-05 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-079 Imported-wallet quarantine | Optional P0 | T-10; Wallet/security/legal | W-06 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-080 Source labels | Advanced P0 | T-10; Wallet/security/legal | W-06, W-13 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-081 Contact requests | Optional P0 | T-10; Wallet/security/legal | P-01, P-02 | AUD-20, AUD-21, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-082 Review/sign/send | Optional P0 | T-10; Wallet/security/legal | P-03, P-04, P-05, P-06, P-07 | AUD-20, AUD-21, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-083 Delay/schedule | Advanced P1 | T-10; Wallet/security/legal | P-10 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-084 Spend guardrails | Advanced P1 | T-10; Wallet/security/legal | P-11 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-085 Transaction history | Optional P0 | T-10; Wallet/security/legal | P-08, P-09 | AUD-20, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-086 Fiat estimates | Advanced P2 | T-10; Wallet/security/legal | W-15 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-087 Payjoin | Experimental P1 | T-10; Wallet/security/legal | P-12 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-088 Silent/stealth receive | Experimental P2 | T-10; Wallet/security/legal | W-16 | AUD-21, AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-089 Contact swaps | Experimental P2 | T-10; Wallet/security/legal | X-03, X-04, X-05 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-090 External financial tools | Advanced P2 | T-10; Wallet/security/legal | X-01, X-02, X-06 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-091 CoinJoin/mixer tools | Deferred P2 | T-10; Wallet/security/legal | X-01, X-02, X-06 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-092 Wallet backup/drill | Optional P0 | T-12; Recovery/security | B-09, B-10, W-12 | AUD-24 | TST-030–032,044,049,057; REL-VAULT / REL-WALLET-MANAGE |
| F-093 Chat backup/restore | Core P0 | T-12; Recovery/security | B-01, B-02, B-03, B-04, B-05, B-06, B-07, B-08 | AUD-24 | TST-030–032,044,049,057; REL-VAULT / REL-WALLET-MANAGE |
| F-094 Continuity archive | Experimental P2 | T-12; Recovery/security | R-07 | AUD-14, AUD-24 | TST-025,030–032; REL-DEVICE / REL-VAULT |
| F-095 Multisig/social recovery | Deferred P2 | T-12; Recovery/security | B-11 | AUD-24 | TST-030–032,044,049,057; REL-ADAPTER; deferred, not approved |
| F-096 Cold/offline transfer | Advanced P1 | T-13; Platform/wallet | W-14, P-06 | AUD-24 | TST-044,047,049; REL-WALLET-MANAGE / REL-ADAPTER |
| F-097 Local diagnostics | Advanced P0 | T-14; Operations/support | H-03, H-05, H-06 | AUD-24 | TST-017,020,053,056; REL-CORE / REL-OPS |
| F-098 Abuse controls | Core P0 | T-04, T-14; Network/operations, Operations/support | C-11, H-05, N-04 | AUD-08, AUD-24 | TST-017,020,053,056; REL-CORE / REL-OPS |
| F-099 Distribution/updates | Core P0 | T-15; Release/security | O-01, H-08, H-09 | AUD-24 | TST-054–055,058; REL-CLAIMS / REL-PLATFORM |
| F-100 Funding/support | Core policy P0 | T-14; Operations/support | H-04, H-12 | AUD-24 | TST-043,053,056–058; REL-CLAIMS / REL-LEGAL |
| F-101 Accessibility | Core P0 | T-16; Design/accessibility/research | O-08, C-07, D-03, H-07 | AUD-24 | TST-040–042; Every enabled capability |
| F-102 Privacy-preserving research | Core policy P0 | T-16; Design/accessibility/research | H-13 | AUD-24 | TST-041,056; REL-CLAIMS / REL-LEGAL |
| F-103 Account deletion equivalent | Core P0 | T-05; Storage/security | S-09 | AUD-15 | TST-030–034,043–044; REL-VAULT / REL-WALLET-MANAGE |
| F-104 Security incident response | Core P0 | T-15; Release/security | H-14, H-09 | AUD-24 | TST-054–055,057–058; REL-CLAIMS / REL-OPS |

### v0.5 requirement-family disposition

These IDs are extracted from the supplied v0.5 baseline and retained as provenance identifiers. The crosswalk states where their intent is carried or tightened; it does not overwrite an inherited privacy requirement with a convenient weaker implementation.

| Baseline IDs present | v0.6 feature coverage | Disposition / technical and release home |
|---|---|---|
| INV-01, INV-02, INV-03, INV-04, INV-05, INV-06, INV-07, INV-08, INV-09, INV-10, INV-11, INV-12 | INV-01–12 retained and extended by INV-13–20 | All volumes / all release gates |
| ID-01, ID-02, ID-03, ID-04 | F-001–004,006–008,011–013 | T-01/T-02; O/C; REL-CORE |
| VER-01, VER-02, VER-03, VER-04, VER-05 | F-005,009–010,030,052 | T-02/T-15; C/R/H; REL-CORE/REL-CLAIMS |
| MSG-01, MSG-02, MSG-03, MSG-04, MSG-05, MSG-06, MSG-07 | F-016–030 | T-03; M/S; REL-CORE/REL-VAULT |
| V3-01, V3-02, V3-03, V3-04, V3-05, V3-06 | F-024,060,065,085–086,097 | T-03/T-05/T-10/T-14; M/S/W/P/H |
| NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07 | F-056–064 | T-04; N; REL-CORE/REL-OPS/REL-PLATFORM |
| DEV-01, DEV-02, DEV-03, DEV-04, DEV-05, DEV-06, DEV-07, DEV-08 | F-050–055 | T-08; D/R; REL-DEVICE |
| SYN-01, SYN-02, SYN-03, SYN-04, SYN-05, SYN-06 | F-017–024,044,050–055,093–094 | T-03/T-07/T-08/T-12; M/G/D/R/B |
| GRP-01, GRP-02, GRP-03, GRP-04, GRP-05, GRP-06, GRP-07, GRP-08, GRP-09, GRP-10 | F-037–044 | T-07; G/R; REL-GROUP |
| CALL-01, CALL-02, CALL-03, CALL-04, CALL-05, CALL-06, CALL-07, CALL-08, CALL-09 | F-045–049 | T-09; L; REL-CALL |
| AND-01, AND-02, AND-03, AND-04 | F-056–057,065–067,071–072 | T-04/T-05/T-11; Android independently qualified |
| IOS-01, IOS-02, IOS-03, IOS-04, IOS-05, IOS-06 | F-056–057,065–067,071–072 | T-04/T-05/T-11; app-open default; REL-PLATFORM |
| DESK-01, DESK-02, DESK-03, DESK-04, DESK-05 | F-050–057,065–067,071–073 | T-08/T-11/T-15; D-07; REL-PLATFORM |
| SEC-01, SEC-02, SEC-03, SEC-04, SEC-05, SEC-06, SEC-07 | F-065–071,103 | T-05; S; destructive options remain experimental |
| BKP-01, BKP-02, BKP-03, BKP-04, BKP-05, BKP-06, BKP-07 | F-092–096 | T-12; B/R/W; history/continuity/wallet separate |
| WAL-01, WAL-02, WAL-03, WAL-04, WAL-05, WAL-06, WAL-07, WAL-08 | F-074–080,088,092,095–096 | T-10/T-12; W/B; optional isolation and chain gates |
| PAY-01, PAY-02, PAY-03, PAY-04, PAY-05, PAY-06, PAY-07 | F-081–087,089–091 | T-10; P/X; typed 1:1 only and separate auth |
| MED-01, MED-02, MED-03, MED-04 | F-031–036,049,071 | T-06; A; no implicit persistent cloud storage |
| OFF-01, OFF-02, OFF-03, OFF-04 | F-018,064,093,096 | T-03/T-13; M/N/W; no offline chain-settlement guarantee |
| UX-01, UX-02, UX-03, UX-04, UX-05 | F-015,101 and all screen pathways | T-16; UI system/catalog; original aesthetic retained, no new mockup approval claimed |
| ARCH-01, ARCH-02, ARCH-03, ARCH-04 | INV-01–20 and F-016,037,050,057,074,081 | Component/bridge/data boundary contracts; all capabilities |
| OPS-01, OPS-02, OPS-03, OPS-04, OPS-05, OPS-06 | F-017–018,059,097–100,104 | T-04/T-14/T-15; REL-OPS |
| DIST-01, DIST-02, DIST-03, DIST-04 | F-005,099,104 | T-15; H-08/H-09/H-14; REL-CLAIMS |
| FUND-01, FUND-02 | F-100 | T-14; H-12; no identity-linked billing/security paywall |
| SUP-01 | F-097–098,100 | T-14; H-04/H-05/H-06; selected export only |
| LEGAL-01 | All optional financial and operated services | Final legal volume; REL-LEGAL |
| MET-01, MET-02, MET-03, MET-04 | F-101–102 and success targets | T-16; consented cohorts/lab only, no production graph |
| GATE-01 | All feature evidence/release records | Verification volume; not a claim gates passed |
| NOT-01 | F-072 | T-11; H-02; platform-specific explicit modes |

### Explicit v0.5-to-v0.6 changes

| Change | Disposition | Privacy consequence / required evidence |
|---|---|---|
| Eight upgrade proposals | Consolidated into feature IDs and gates | No blanket approval of the earlier brainstorm |
| Local-first usability | More explicit taps, controls, empty/error/partial states | No authority check removed for speed |
| Crypto/library choices | Current candidate profiles and licensing/advisory notes | Actual composition remains open, no invented suite |
| Groups | 32-person/128-endpoint envelope retained as target; larger tiers experimental | Shared-mailbox/server-fanout scaling blocked without metadata equivalence |
| Media | Detailed local preparation and endpoint transfer | External persistent blob service not silently inherited |
| BTC/ETH | Native isolated management architecture added | Contact spending blocked where public metadata exceeds baseline |
| Existing funds | Hardware/watch-only first, conservative provenance | No seed on Connect or anonymous/clean label |
| Financial tools | Per-adapter manifests, explicit external boundary and legal gates | No automatic recommended mixer/swap route or guaranteed unlinkability |
| Scheduling/swaps | Explicit authorization and deadline/recovery contracts | No phone-background guarantee or generic automatic refund |
| Recovery | No-spend drills and history/continuity/wallet separation | No live-state clone or automatic social recovery |
| Security review | Feature-linked eight-dimension comparisons | Architecture review, not independent audit |
| First thirty days | Full declared product-owned screen/state catalog | External/OS/engine annexes remain release dependencies |
| Legality | Country/activity/actor restrictions at the end | No worldwide legality guarantee or covert compliance surveillance |

### Evidence status

All feature implementation/test statuses are Not implemented / Not tested for purposes of this document because no executable TGP implementation or results were supplied. Upstream references are background, and the authoring checks on this specification validate only document structure and coverage.

A future implementation must replace these initial statuses with traceable issue, commit, test, review, legal and release records. It must not interpret this matrix as security certification or authorization to deploy a financial service.

---

## Legal, Country Restrictions, and Lawful Launch

This section intentionally comes last in the master specification. It is a preliminary issue-spotting and launch-control framework dated 5 November 2026, not a legal opinion, a worldwide country clearance, a promise of legality, or advice to evade restrictions.

Some financial services, privacy-asset activities, marketing, sanctions dealings, and unlicensed operations are prohibited in particular jurisdictions. The legal analysis must distinguish an individual's own use, publishing software, operating a relay, arranging transactions, supplying liquidity, controlling recovery/signing, and providing regulated services; those are not automatically treated alike ([FinCEN virtual-currency guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [FCA registration perimeter](https://www.fca.org.uk/firms/cryptoassets/who-needs-register), [MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).

### Plain-English bottom line

- **Private software is not a legal shield:** Encryption, Tor, non-custody, decentralization, open source, free distribution, and a user-choice disclaimer must not be marketed as making prohibited conduct lawful. Classification must use what the actual people, company, code, infrastructure, and marketing do, rather than a label ([FinCEN guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [MiCA](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng), [MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).
- **Some territories are particularly restrictive:** Mainland China's notice treats specified virtual-currency exchange and related business activities as illegal financial activities; Dubai's VARA rules prohibit issuance and covered VA activities involving anonymity-enhanced cryptocurrencies in its defined Emirate scope ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html), [VARA regulations](https://rulebooks.vara.ae/entiresection/437)).
- **Some restrictions apply to providers, not every holder:** The EU AML Regulation's anonymity-related account restriction is directed at specified regulated institutions/CASPs and generally applies from 10 July 2027; it is not a blanket declaration that every individual holding a privacy coin or using a self-hosted wallet is committing a crime ([Regulation (EU) 2024/1624, Articles 79 and 90 and recital 160](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)).
- **United States obligations remain relevant:** Federal money-transmission analysis, Washington licensing, sanctions, encryption export classification, consumer-facing claims, and actual criminal conduct require distinct review; “we do not custody” is not a substitute for that work ([FinCEN guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [Washington RCW 19.230.030](https://app.leg.wa.gov/rcw/default.aspx?cite=19.230.030), [OFAC FAQ 560](https://ofac.treasury.gov/faqs/560), [EAR §742.15](https://www.bis.gov/regulations/ear/742)).
- **TGP's product response is not covert surveillance:** If a proposed service cannot lawfully be offered while preserving the binding privacy requirements, do not offer that service in that scope. Seek a lawful classification/authorization or remove the activity; do not secretly weaken encryption, add identity logging, or claim that a warning removes the obligation.

The country table below is intentionally limited to reviewed issues and source scope. Unlisted countries are unreviewed, not automatically permitted and not automatically illegal.

### Separate the actor and the activity

#### Classification worksheet

| Actor/activity | What counsel must determine | Product policy pending approval |
|---|---|---|
| Individual holding keys and paying with own funds | Applicable personal-use, sanctions, tax, asset, import/network and transaction restrictions | Give accurate limits; no universal legality assurance |
| Publishing neutral chat source/binaries | Software/encryption distribution, privacy, export, intellectual property, consumer and platform obligations | Signed distribution; no financial-service claim by implication |
| Operating message relay/rendezvous/directory | Network/content/service/privacy/security duties, local infrastructure rules and actual data held | Minimal documented retention; no financial instructions or settlement authority |
| Optional local wallet software | Whether exact functionality is software-only, custody, exchange, transfer, arranging or another regulated role | No custody; distinct platform/chain qualification and counsel review |
| Contact-payment request transport | Whether typed private messages plus wallet affordances alter service classification | No operator-readable payment graph; no automatic sign/broadcast |
| Swap offer/discovery/router UI | Whether matching, arranging, pricing, facilitation, brokering, liquidity, referral or promotions duties arise | No hosted TGP orderbook, liquidity, coordinator, percentage fee or mainnet default |
| CoinJoin/mixer coordinator or operator | Money transmission, AML, sanctions, anonymizing-service, prohibited-asset and criminal-law exposure | Not a TGP service; external tools require specific review, not assumed exemption |
| Watcher/refund signer | Actual key/control authority, operational duty, geography and protocol role | Exact least authority; no implied “only monitoring” if it can sign |
| Volunteer proxy / device VPN / nearby radio | Local telecom/network/software distribution and participation restrictions | Independently optional, explicit, disabled until qualified |
| Paid optional infrastructure / donations | Business records, tax, payments, consumer rights and entitlement joinability | No core-security paywall or messaging-identity link |
| Support and abuse reporting | Data-controller/processor role, lawful requests, retention and user disclosure | Only explicitly previewed selected data; no master decryption key |
| Marketing/app-store distribution | Targeted country, financial-promotion rules, app category and licensing representations | No country/asset/service promotion before applicable approval |

This worksheet is a required product control, not a legal conclusion that every row requires a license. Its purpose is to stop the company from relying on the most favorable description while performing a different activity.

#### Geography and entity worksheet

Document the developer's residence, entity formation and management location, employees/contractors, infrastructure, signers/watchers, customers and targeting, counterparties, app stores, marketing channels, payment/fee flow, and contract terms. A country selector, foreign company, server location, or “not intended for residents” sentence is not treated as a complete legal solution.

For every financial adapter, counsel must review whether TGP merely publishes software or also makes introductions, controls rules/fees, maintains necessary infrastructure, actively facilitates transactions, or has ongoing intervention power. Singapore explicitly includes actively facilitating DPT buying/selling without possession in its stated DPT service types, illustrating why custody alone is not a universal dividing line ([MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).

### Country and regional restrictions

#### United States federal and Washington

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Federal own-use wallet versus service | FinCEN's guidance distinguishes unhosted own-use wallet activity from money transmission and distinguishes providers of anonymizing software from an anonymizing service that accepts/retransmits value; actual business activity matters ([FinCEN 2019 guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf)). | Obtain a written analysis of each actual role. Keep local wallet/chat architecture separate; do not assume every swap/router/coordinator is exempt. |
| State licensing | Washington prohibits engaging in, advertising, soliciting, or holding oneself out as providing the business of money transmission without the stated license/delegate status or applicable statutory exclusion ([RCW 19.230.030](https://app.leg.wa.gov/rcw/default.aspx?cite=19.230.030)). | Review the Washington-based founder/entity and offered activities before launch; no “licensed” or “exempt” claim without basis. |
| Washington virtual currency | DFI's interpretive statement addresses virtual-currency transmission/exchange and how actual control/settlement/software roles affect analysis ([Washington DFI interpretive statement](https://dfi.wa.gov/sites/default/files/virtual-currency-money-transmission-laws.pdf)). | Federal analysis does not replace state analysis. If a license is necessary and incompatible with product invariants, do not perform the regulated activity. |
| Sanctions | OFAC states virtual- and fiat-currency obligations are the same for covered persons, including prohibited dealings, relevant blocked property, and sanctions evasion; compliance programs should be tailored to actual risk and role ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)). | Counsel designs the lawful role-specific approach. Local provenance tags and a user declaration are not presented as sanctions compliance. |
| Criminal conduct and intent | DOJ's Samourai sentencing announcement describes a criminal money-transmitting conspiracy involving operators and their conduct; it does not establish that every privacy-software author or every private user commits a crime ([DOJ Samourai announcement](https://www.justice.gov/usao-sdny/pr/founders-samourai-wallet-cryptocurrency-mixing-service-sentenced-five-and-four-years)). | Do not operate or knowingly support unlawful money laundering, sanctions evasion, or an unlawful transmission business; no “clean funds” or criminal-evasion marketing. |
| Enforcement policy is not immunity | DOJ's August 2025 remarks describe a stated charging policy for certain truly decentralized noncustodial peer-to-peer software situations, while preserving other possible criminal theories; an enforcement speech is not statutory immunity ([DOJ policy remarks](https://justice.gov/opa/speech/acting-assistant-attorney-general-matthew-r-galeotti-delivers-remarks-american)). | Do not rely on the speech as a permanent safe harbor. Counsel reviews statutes, cases, actual operations, and subsequent changes. |
| Tornado Cash | Treasury announced the removal of Tornado Cash economic sanctions in March 2025; that announcement is not a blanket clearance for every mixing service, transaction, operator, or criminal conduct ([Treasury announcement](https://home.treasury.gov/news/press-releases/sb0057)). | Do not display “Treasury approved mixers” or infer general legality from delisting. |

The baseline TGP scope excludes a fiat exchange, TGP liquidity provider, mixer coordinator, custodial wallet, pooled treasury, brokerage, and payment-percentage business. Those exclusions reduce product scope; only qualified counsel can determine their legal effect for the implemented facts.

Washington is especially relevant to the founder's stated location, but no survey of all US states is provided. Nationwide targeting requires an appropriately scoped state-by-state analysis rather than extrapolating from one state.

#### European Union and EEA targeting

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| MiCA software distinction | MiCA recital 83 distinguishes providers of hardware/software for non-custodial wallets from regulated custody; Article 59 sets the authorization rule for cryptoasset services in the Union ([MiCA](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng)). | Analyze exact services, not merely the app's name. No CASP/exemption claim without advice on the actual activity. |
| Decentralization | MiCA discusses services provided in a fully decentralized manner without an intermediary, but partially decentralized or controlled arrangements are not automatically outside scope ([MiCA recital 22](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng)). | A TGP-controlled interface, router, operation or intermediary role needs review; no blanket “DeFi exempt” language. |
| Anonymity-related accounts | AMLR Article 79 prohibits specified regulated institutions/CASPs from keeping anonymous accounts or accounts allowing anonymization/increased obfuscation of holders/transactions, including anonymity-enhancing coins; recital 160 distinguishes self-hosted hardware/software providers without access/control ([Regulation (EU) 2024/1624](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)). | Do not claim a blanket EU ban on private possession/self-hosted software; do not assume a regulated TGP service could ignore Article 79. |
| Date | The regulation generally applies from 10 July 2027 under Article 90, subject to its specified exceptions ([AMLR Article 90](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)). | Review the coming change before any service extending into that period; do not describe it as already universally operative in November 2026. |
| Privacy law | GDPR addresses territorial scope, data minimization, privacy by design/default, and security of processing in Articles 3, 5, 25 and 32 ([GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)). | Counsel maps roles for relays, notifications, support, billing, studies and incident handling; E2EE does not remove those business-data questions. |

Member-state implementation, other financial rules, consumer/tax law, and non-EU EEA treatment require specific review. “Available in Europe” is too broad to serve as a launch approval.

#### United Kingdom

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| In-scope UK business | FCA guidance addresses registration for in-scope cryptoasset exchange, arranging-exchange and custodian activity by way of business in the UK; it distinguishes overseas firms merely serving UK customers from actual UK business presence/activity ([FCA perimeter guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Review entity/presence/activity before operating a swap or exchange-adjacent service. Do not claim every overseas app automatically needs the same registration. |
| Promotions | The FCA separately states the cryptoasset financial-promotions regime can apply to firms marketing to UK consumers regardless of where the firm is based ([FCA guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Review store copy, website, tutorials, referral links, invitations, and asset/tool recommendations for promotion implications. |
| Changing regime | FCA guidance describes a transition to a new cryptoasset regime; requirements must be reviewed for the actual launch date rather than frozen from an older app policy ([FCA guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Legal approval has a review/expiry trigger; do not label the app “UK compliant” indefinitely. |

No claim is made here that all private wallet use or privacy coins are illegal in the UK. TGP must resolve the activity and promotion perimeter before offering financial tools in a UK-targeted distribution.

#### Mainland China

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Virtual-currency business | The 2021 official notice classifies specified fiat-to-virtual-currency, virtual-to-virtual-currency, central-counterparty, trading-information/pricing, token and derivative-related business activities as illegal financial activities ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html)). | Do not offer TGP exchange/swap/discovery/pricing service functionality targeting mainland residents without a qualified opinion establishing a lawful permitted scope. |
| Overseas service/support | The notice addresses overseas exchanges serving mainland residents and specified knowing support; it cannot be reduced to “our server is abroad” ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html)). | Analyze targeting and support/integration roles, not just entity/server location. No bypass guide or false-residency workflow. |
| Continuing policy | A 2025 PBOC interdepartmental meeting reaffirmed the restrictive approach to virtual-currency trading/speculation ([PBOC 2025 statement](https://www.pbc.gov.cn/en/3688110/3688172/5552468/2025121116132332435/index.html)). | Treat financial-service launch as blocked pending local counsel; do not imply an old notice is obsolete merely because software is decentralized. |

These materials do not establish a blanket rule that every private holder, every encrypted chat, or every line of wallet source code is illegal. Mainland encryption, app/network distribution, telecom and personal-use questions are not comprehensively reviewed here; Hong Kong and Macao are not cleared by this mainland analysis.

#### India

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| VDA provider scope | FIU-IND's registration material describes business activities for/on behalf of another including fiat/VDA exchange, VDA/VDA exchange, transfers, safekeeping/control and specified issuer-related financial services ([FIU-IND registration material, 15 September 2025](https://fiuindia.gov.in/pdfs/downloads/VDASP15092025.pdf)). | Classify each exact operation; no blanket claim that local wallet code alone is a registered service or that all noncustodial facilitation is exempt. |
| Registration/compliance | The material describes registration as a prerequisite for covered VDA service-provider activity and associated compliance processes ([FIU-IND material](https://fiuindia.gov.in/pdfs/downloads/VDASP15092025.pdf)). | Do not start an in-scope service without required approval/process. If obligations conflict with invariants, withhold the service rather than add covert KYC/logging. |
| Privacy tools: unresolved scope | An updated January 2026 guideline document was located, but the retrieved portion did not establish the substantive clauses concerning anonymity-enhancing coins and mixers ([FIU-IND January 2026 guidelines](https://fiuindia.gov.in/pdfs/downloads/VDA08012026.pdf)). | Specific India privacy-tool approval remains unresolved. Do not invent a blanket coin/mixer ban or a permission from a table of contents. |

India's financial launch decision therefore requires full current text and local advice, especially for transfer/arranging/privacy-tool features. This section does not say that every individual holding cryptocurrency is acting illegally.

#### Singapore

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Broad DPT activity scope | MAS lists buying/selling, exchange platforms, transmitting/arranging transmission, custody, and actively facilitating buying/selling without possession as DPT service types ([MAS service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)). | A no-custody label alone is insufficient; analyze exact interface, matching, routing and ongoing operation. |
| Payment licensing | MAS licensing FAQs explain licensing/exemption requirements for covered payment services and distinguish service types ([MAS licensing FAQs](https://www.mas.gov.sg/contact-us/faqs/payments-faqs/payments-service-licensing-faqs)). | No in-scope service without the applicable license/exemption and compatible operating controls. |
| Overseas-only customers | MAS states that from 30 June 2025, relevant Singapore-based digital-token service providers serving only overseas customers require a license and that MAS generally will not issue such licenses under the described regime ([MAS clarification](https://www.mas.gov.sg/news/media-releases/2025/mas-clarifies-regulatory-regime-for-digital-token-service-providers)). | Forming/operating there while excluding local users is not an assumed workaround. Review developer/entity/watchtower/coordinator location and activity. |

Do not infer that every Singapore user is prohibited from using a local wallet. The relevant question for TGP is whether its implemented activity is a regulated service and can be offered lawfully without violating the privacy contract.

#### Dubai / UAE: preserve the territorial distinction

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| VARA territory | The defined Emirate covers Dubai's specified zones/free zones but excludes the Dubai International Financial Centre ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Do not relabel a VARA rule as a complete all-UAE/DIFC legal opinion. |
| Anonymity-enhanced assets | VARA prohibits issuance of anonymity-enhanced cryptocurrencies and all covered VA activities related to them in the Emirate; the definition concerns assets preventing transaction/ownership tracing for which the VASP has no mitigating mechanism ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Block TGP provider activity involving that category in the relevant scope unless counsel establishes an actually lawful different classification. Do not weaken privacy to make an asset traceable. |
| Business licensing | VARA prohibits covered VA activity by way of business without authorization/license or a stated exception ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Obtain specific provider/activity advice; no “software, therefore exempt” assumption. |
| Marketing | VARA's marketing rules address virtual-asset/VA-activity marketing in or targeting the UAE and expressly restrict anonymity-enhanced-asset marketing in the stated Emirate scope ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Review websites, store descriptions, tutorials, influencer/referral content and educational materials in context; do not treat a “not advice” footer as approval. |

The retrieved rules do not establish a blanket prohibition on all private possession or use throughout the UAE. Other emirates, DIFC and federal frameworks remain separate unreviewed questions rather than automatically permitted alternatives.

#### All other jurisdictions

Financial-service launch remains unapproved until the actual target jurisdiction, entity, activity, asset, distribution and marketing scope is reviewed. That is a TGP conservative release policy, not a claim that every unreviewed country bans the software.

Encryption/telecom/network-use rules, asset restrictions, licensing, sanctions, privacy, consumer, tax and app-store treatment must be checked locally. Do not publish a global green/red map based only on these eight regional issue summaries.

### Sanctions and prohibited conduct

#### No evasion product positioning

Do not market TGP as a way to evade sanctions, launder proceeds, defeat court orders, hide criminal conduct, or make funds “clean.” OFAC explicitly addresses evasion and prohibited support as well as digital-currency dealings; an encrypted interface does not change those stated obligations for covered persons ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)).

This does not equate privacy with criminality. The product can minimize unnecessary surveillance while refusing to undertake an unlawful operator role; the implementation and marketing must maintain that distinction.

#### Role-specific compliance, not a universal surveillance switch

Counsel must determine whether TGP has any applicable blocking, reporting, screening, licensing or records obligation for each role and geography. OFAC recommends tailored risk-based programs and does not describe one single program as suitable for every circumstance ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)).

Do not pretend that a local “I am allowed” checkbox, no-fee model, source label, sanctioned-address list, country selector, or Tor routing is sufficient compliance. Conversely, do not implement a remote freeze or identity-logging mechanism into a noncustodial wallet without recognizing that it changes both the architecture and the privacy contract.

If a lawful required control cannot coexist with the contract, the affected operated service must not launch. Whether neutral source publication or a narrower software-only scope remains lawful is a separate counsel question, not a suggested workaround.

### Encryption export, software licenses, and app stores

#### Encryption and export classification

US encryption-export treatment is artifact- and activity-specific; EAR §742.15 addresses publicly available encryption source code under specified conditions and notification for source providing/performing non-standard cryptography ([EAR §742.15](https://www.bis.gov/regulations/ear/742)). Do not recycle outdated blanket claims that every open-source encryption release must make identical notifications, or that every encrypted app is automatically outside export controls.

Have counsel classify source, binaries, embedded libraries, public availability, non-standard cryptography, commercial/service activity, destinations/end users and any applicable restrictions. TGP cannot inherit another project's classification merely because it uses the same library.

Do not publish masked or guessed compliance email addresses. A release checklist must use the current official regulation and verified agency instructions at the time of filing.

#### Open-source and dependency obligations

libsignal's repository states AGPLv3 licensing and unsupported external use/API instability; SQLCipher's licensing material contains attribution/notice requirements ([libsignal](https://github.com/signalapp/libsignal), [SQLCipher licensing](https://www.zetetic.net/sqlcipher/license/)). Legal/release owners must review the actual dependency graph, linking/distribution/service model, notices, source-offer obligations where applicable, trademarks and maintenance plan.

Do not assume that putting only TGP's wrapper on GitHub satisfies every dependency obligation. Any required source or notices must correspond to the shipped artifacts and approved legal analysis.

#### Store distribution

Apple's crypto rules address wallet developer organization status, exchange licensing and other crypto-specific restrictions; the exact app functionality and targeted regions matter ([Apple App Review Guidelines, §3.1.5](https://developer.apple.com/app-store/review/guidelines/)). Google states that noncustodial wallets are outside its named crypto exchange/software-wallet policy requirements, while other financial declarations and applicable-law duties still need consideration ([Google Play policy](https://support.google.com/googleplay/android-developer/answer/16329703)).

Store approval is not a legal license, and a lawful app is not guaranteed store approval. Direct signed distribution also does not erase export, local law, platform, security-update or consumer obligations.

### Privacy, data protection, consumer claims, and lawful requests

#### Data map before policy writing

Document all actual data flows across relays, rendezvous, optional platform notices, stores, billing, support, researchers, hosting and release distribution. GDPR's minimization, privacy-by-design and security provisions are relevant where its scope applies; encrypted payloads do not eliminate the need to assess other personal data ([GDPR Articles 3, 5, 25 and 32](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)).

Create truthful notices for the actual build, not an aspirational “no data” policy. Retention claims must match host snapshots, dumps, support systems, logs and mandatory business records.

#### Lawful requests and user safety

The lawful-process policy must distinguish data not held, data held temporarily, user-selected support exports, and separate business records. Do not promise to decrypt content the infrastructure cannot decrypt, or promise that legal process can never affect a company or a device.

Counsel handles validity, jurisdiction, scope, preservation, challenge and disclosure obligations. This specification does not design a covert backdoor or instruct the team to destroy evidence or defeat lawful process.

#### Tax and records

Offer a deliberate local export of appropriate transaction records without contact labels by default. Obtain country-specific advice on tax/reporting/user-record requirements before describing obligations; this spec makes no universal tax-free or no-records claim.

Deleting a chat card, changing a label, moving funds, or using a privacy protocol must never be described as erasing legal, tax or accounting responsibilities. A user may need independently retained records even when chat details are minimized.

#### Consumer-facing financial limits

Publish chain-specific irreversible-action, fee, delay, reorg, recovery, hardware, provider and swap risks. No yield, investment return, guaranteed refund, future price, universal settlement time, anonymity, evidentiary immunity, or regulatory approval is promised.

Promotional copy must go through the same claims and legal gates as technical UI. “Atomic,” “decentralized,” “non-custodial,” “open source,” and “privacy-preserving” cannot replace precise disclosure.

### Legal capability manifest

#### Required decision record

```yaml
decision_id: unique-versioned-record
review_date: actual-date
review_expiry_or_trigger: counsel-defined
legal_entity: actual-entity-and-management-location
activity: exact-operation-not-just-wallet
capability:
  chain: exact-chain-and-network
  protocol: exact-engine-direction-version
  distribution: app-store-direct-source-service
  custody_and_control: exact-keys-signers-coordination-and-fees
jurisdictions:
  operator: reviewed-locations
  infrastructure: reviewed-locations
  targeted_users: reviewed-locations
  marketing: reviewed-channels-and-targeting
authority:
  statutes_rules_guidance: actual-urls-and-effective-dates
  counsel: named-qualified-reviewer
  written_opinion: controlled-document-reference
classification: software-only-or-exact-regulated-role-or-unresolved
requirements: exact-licenses-disclosures-controls-retention-and-exceptions
privacy_compatibility: approved-or-conflict-or-unresolved
new_operations: approved-or-blocked
existing_operation_recovery: exact-lawful-safe-plan
approvers: actual-named-owners
```

This is a schema example, not a completed legal approval. Placeholder strings in it must never be mistaken for a valid manifest or shipped in place of counsel's decision.

#### Capability decision process

1. Identify exact actors, keys/control, infrastructure, funds flow, fees, geography, targeting and marketing.
2. Obtain qualified advice using current primary materials and actual implementation facts.
3. Identify licenses, registrations, prohibited activities, disclosures, records and other required controls.
4. Compare those controls with every privacy invariant and eight-dimension baseline.
5. If compatible, implement and verify the approved narrow scope.
6. If incompatible or unresolved, block the new financial/service operation and document why.
7. Recheck after legal, entity, activity, asset, protocol, fee, infrastructure, marketing or targeting changes.

Local country selection can help show information, but does not establish residence, sanctions status, territorial targeting or legal compliance. Any necessary distribution or service restriction must be designed lawfully, tested, and transparent without covert data collection or advice to falsify location.

#### Existing-operation retirement

Do not remotely delete seeds, block necessary local export, remove an active swap's recovery journal, or strand a required refund action merely because an adapter is retired or a new-operation region policy changes. Counsel and security must define the exact lawful preservation/recovery path, including situations where a particular transaction itself cannot legally proceed.

The app must distinguish “new operations unavailable” from “recovery information retained.” It cannot promise a legal exception for every recovery payment or perform a prohibited transaction under the label of safety.

### Legal risk register

These are severity-oriented launch issues, not quantified predictions of enforcement. Likelihood and legal outcome depend on facts and qualified analysis not established here.

| Risk | Product severity | Required mitigation / release rule |
|---|---|---|
| Unlicensed financial service | Launch-blocking | Written role/country classification and required authorization or no service |
| Prohibited anonymity-enhanced-asset activity | Launch-blocking in applicable scope | Exact territory/asset/activity review; no weakening privacy to fit a prohibited provider model |
| Sanctions/prohibited support | Launch-blocking | Actual role-specific lawful controls; no evasion positioning |
| Incorrect “noncustodial exemption” | High | Control/arranging/facilitation analysis, not seed-possession test alone |
| Criminal-purpose marketing or knowing unlawful assistance | High | Refuse unlawful operator role; review promotions and support conduct |
| Financial-promotion breach | High | Targeted-channel/region review before publication |
| Export/encryption mistake | High | Artifact classification/current filing/destination analysis |
| Privacy/retention mismatch | High | Actual data map, deployment evidence, truthful notice and compatible duties |
| Unsupported audit/privacy/evidence claim | High | Claim-specific evidence; remove absolute language |
| App-store rejection | Material distribution risk | Exact regional policy review; no assumption approval substitutes for law |
| Dependency/license violation | High | Artifact-level dependency/notice/source review |
| User loss from misunderstood recovery/swap | High | Tested recovery, exact risk copy and no guarantee |
| Stale legal opinion | High | Versioned approval, expiry/triggers, new-operation disable policy |
| Overbroad geo/personal-data collection | High privacy risk | Minimum lawful transparent mechanism or do not offer service |

### Required launch checklist

- **Entity and geography:** Confirm actual entity, management/developer locations, infrastructure, target users and marketing channels.
- **Washington and federal US:** Obtain a written money-transmission/service, sanctions, export and operational assessment for the implemented role.
- **Each financial region:** Review provider scope, asset restrictions, promotions, required licenses/registrations and dates.
- **Each adapter:** Review the exact engine, direction, key/control authority, counterparties, fees, deadlines and ongoing operations.
- **Each distribution channel:** Review source/binary export, store category, developer entity and local availability.
- **Privacy and security:** Reconcile required legal/business records with the data map; no hidden expansion of collection.
- **Policies:** Publish accurate privacy, terms, lawful-process, security disclosure, abuse/support, financial-risk, retention, export and license materials.
- **User records:** Offer deliberate local transaction export and explain that card minimization does not remove legal obligations.
- **Research and support:** Separate consent, recipient and retention; no seeds or default contact/payment graph.
- **Incident and retirement:** Preserve lawful safe recovery without enabling prohibited new operations or covert remote control.
- **Approval:** Named qualified counsel, security, product, platform, operations and release owners sign the exact scope.

### Final legal launch rule

TGP must not claim worldwide legality, universal anonymity, financial-service exemption, or immunity from evidence or enforcement. Where current law, platform policy, or required controls conflict with the binding privacy contract, do not launch the conflicting capability in that scope; narrow the lawful activity, obtain the necessary approval where possible, or leave the feature unavailable.

This last section is a release gate, not a disclaimer that transfers all responsibility to the user. The financial tools remain optional, separately qualified, and unavailable wherever the actual legal and privacy requirements cannot both be met.
