# TGP Chat v0.6: Implementation, Verification, and Release Contract

This volume turns the design into accountable implementation and evidence work. It does not declare any gate passed; the supplied material contains no TGP source checkout, runnable build, packet capture, independent assessment, user-study result, or jurisdiction-specific counsel opinion.

## Release status and decision vocabulary

### What is selected and what is not

| Decision class | v0.6 status | Consequence |
|---|---|---|
| Product privacy invariants | Binding design requirements | Implementation cannot override them |
| Rust core / TypeScript presentation | Selected stack direction | Actual bridges/frameworks still qualify per platform |
| No registration / directory / contact upload | Selected product policy | Test first launch and every discovery path |
| Scope-local keys / explicit recipients | Selected authority requirement | Concrete library composition remains blocking |
| Protected broker / fail closed | Selected networking requirement | Actual sockets/resolution/platform exceptions need evidence |
| Two tabs before optional wallet | Selected navigation | Does not require wallet to ship |
| Keep history / no pre-join archive / no linked history by default | Selected privacy defaults | Every restore/sync path must preserve them |
| libsignal direct profile | Candidate, not approved integration | Licensing, scoped identity, PQ ratchet and metadata review |
| Hybrid OpenMLS | Candidate, production profile unresolved | No group production release before exact suite/interop review |
| Low-entropy hybrid invitation composition | Unresolved cryptographic decision | No homemade PAKE-plus-KEM production shortcut |
| Strict authority freshness | Requirement selected, mechanism unresolved | Membership/device-sensitive production sends blocked until resolved |
| Mobile wallet process isolation | Platform-specific unresolved decision | Separate installation or disabled financial module if necessary |
| Numeric performance/capacity targets | Proposed acceptance budgets | Lower supported limits after measurement; no claimed results |
| Large shared mailboxes / external blobs | Blocked baseline proposals | No production enablement through warnings |
| Public-chain contact spending | Blocked where privacy baseline is exceeded | Management is not automatic spend approval |
| Calls / swaps / financial adapters | Experimental, separate gates | No mainnet/live deployment approval in this document |
| Worldwide legal availability | Not established | Financial/service launch by jurisdiction only after approval |

The distinction matters because a comprehensive spec can deliberately identify unresolved engineering questions. Calling those questions “implemented,” “audited,” “production-ready,” or “privacy-preserving” without evidence would contradict the product's own requirements.

### Priority and dependency rules

P0 requirements are hard requirements for their own capability, not a promise that every capability ships in the first release. Wallet, groups, calls, and continuity may remain absent while an independently qualified direct-chat release ships.

No calendar date or staffing assumption is specified. Work estimates follow experiments, named owners, resource measurements, and the chosen platform scope.

## Architecture decision register

| ADR | Required decision and proposed direction | Evidence required to close | Owner role / blocked scope |
|---|---|---|---|
| ADR-IDENTITY | Scope-local exported identity with no reusable universal certificate | Credential wire examples; joinability review; compromise boundaries | Security + protocol / all relationship scopes |
| ADR-SESSION | Independent direct sessions for authorized endpoints | Chosen API; crash/rollback tests; prekey publication; state lifetime | Protocol / direct chat, devices |
| ADR-PQ | Exact mandatory direct hybrid handshake and continuing ratchet profile | Versioned profile; vectors; downgrade review; composition assessment | Security / direct release |
| ADR-INVITE | Complete reviewed high-/low-entropy invitation protocol and one-wrong-guess policy | Formal transcript/state machine; concurrency/race review; accessible ceremony | Security / invitations |
| ADR-PAIR | Both-device compared channel, no live-state copy | Canonical transcript; comparison test; scoped-grant tests | Protocol + UX / device linking |
| ADR-GROUP | Group application authority, ordering, coordinator succession | State transition model; fork/partition simulation; recovery plan | Protocol / private groups |
| ADR-GROUP-PQ | Actual interoperable maintained hybrid group suite | Suite/codepoint/version; dependency advisories; interoperability and review | Security / group production |
| ADR-FANOUT | Client recipient-specific wrapping initially | Single/colluding relay review; size/timing captures; capacity curves | Protocol + operations / group metadata |
| ADR-FRESH | Exact authority freshness and offline availability tradeoff | Defined adversary/partition model; stale-controller and revoked-device tests | Security / revocation and affected sends |
| ADR-ARCHIVE | History format separate from continuity authority | Hostile parser tests; no state clone; expiry/import rules | Storage / backup |
| ADR-RECOVER | Old/new controller conflicts, loss and reset | Conflicting-successor model; re-establishment UX; peer continuity rules | Security / migration and continuity |
| ADR-TOR | Per-platform maintained Tor/PT integration | Real-device sockets/lifecycle/kill-switch matrix | Platform + network / platform support |
| ADR-MEDIA | Tor-compatible media transport with no direct fallback | Latency/loss/load experiment; packet captures; parser containment | Media + network / calls |
| ADR-MEDIA-KEY | Call-only subgroup and sender authentication | Replay/outsider/rekey/handoff assessment | Security + media / calls |
| ADR-IOS | App-open default, optional platform notices and content-key policy | Push token lifecycle; suspension/reboot tests; disclosure comparison | iOS lead / iOS availability claims |
| ADR-DESKTOP | Renderer/native/process/storage/update architecture | OS sandbox and command allowlist tests; build verification | Desktop lead / desktop release |
| ADR-ATTACH | Reviewed container, staging, transfer, retention | Malformed media/container tests; memory/disk bounds; metadata fixtures | Media + storage / attachments |
| ADR-OPS | Queue bounds, quotas, eviction, maintenance and no-log deployment | Actual host swap/dump/snapshot review; load tests; restart captures | Operations / relays |
| ADR-FUND | Separate funding/entitlements and mandatory business retention | Data-flow/legal review; no identity join; wallet-free billing tests | Product + legal / any paid optional service |
| ADR-MEASURE | Reference devices, network conditions, sample and thresholds | Preregistered lab protocol; no-production-analytics proof | Research + security / performance claims |
| ADR-WALLET-ISO | OS-realized wallet boundary per target | Memory/IPC/renderer attack tests; privilege diagram | Wallet + platform / financial activation |
| ADR-WALLET-XMR | Maintained complete scanner/signer/recovery implementation | Exact implementation review; output/fee/reorg fixtures | Wallet / XMR |
| ADR-WALLET-BTC | Descriptor/filter/PSBT/hardware compatibility | Tor network adapter; filter/query analysis; device/firmware matrix | Wallet / BTC management |
| ADR-WALLET-ETH | Exact node/light verification and address-query policy | Checkpoint trust; RPC exposure; account isolation | Wallet / ETH management |
| ADR-PAYJOIN | Exact protocol/direction/transport and no-fallback policy | Negotiation/fee/contribution tests; residual-linkage/legal review | Wallet + security / Payjoin |
| ADR-SWAP | One exact engine/direction plus deadline/watcher authority | Maintained source; audit; full recovery matrix; coverage proof | Wallet + legal / each swap adapter |
| ADR-LEGAL | Entity/activity/country/distribution/service classification | Written advice on current law and operating facts | Qualified counsel / affected launch |
| ADR-INCIDENT | Capability containment without exfiltration or stranding recovery | Signed notice/runbook simulation; offline-client limitations | Security + release / operational response |

Every ADR includes alternatives, rejected shortcuts, key/authority/data flows, exact versions and licenses, failure semantics, metadata delta, owner, reviewers, evidence, migration/rollback, public-claim consequences, and reevaluation triggers. An unfilled ADR remains open rather than being “approved by default.”

### Authority freshness is a real availability decision

The system cannot assume that a disconnected endpoint instantly knows an unseen removal. v0.6 therefore requires a reviewed definition of acceptable freshness rather than promising both indefinite offline sending and immediate universal revocation.

Evaluate authenticated sequenced state with bounded leases/checkpoints, explicit coordinator dependencies, or another reviewed mechanism against malicious delay, collusion, partitions, compromised old controllers, rollback, and clock uncertainty. Do not choose a timeout election or wall-clock last-write-wins policy merely to keep the Send button working.

The ADR must state precisely which device can send, under what known state, after how much offline time, and which revocation claim can be made. Until that mechanism is approved, affected multi-device/group security claims and production operations remain blocked.

## Implementation contracts

### Command execution and optimistic UI

```text
Receive typed command
  -> validate schema/version/size
  -> locate currently authorized scope and key lease
  -> validate permission and expected revision
  -> prepare bounded operation
  -> persist operation plus cryptographic state transactionally
  -> return truthful local state
  -> perform permitted network/external effect
  -> record evidence-backed transition
  -> publish minimal typed UI event
```

The renderer never decides authority from a hidden button or a cached green icon. All important checks also run in Rust, including stale revision, locked scope, unsupported security profile, recipient expansion, signing handle, and export selection.

An optimistic bubble may mean Queued only after a safe local commit. It cannot mean relayed, received, admitted, verified, paid, or confirmed without the corresponding evidence.

### Transaction and idempotency requirements

| Operation | Stable identity | Atomic boundary | Retry/cancellation rule |
|---|---|---|---|
| Text/control send | Scoped event and operation IDs | Appropriate session advance + protected outbox | Never recreate from stale key state |
| Edit/reaction | Scoped target + author/revision/operation | Mutation eligibility + event persistence | Duplicate is not another edit/count |
| Invitation claim | Invite generation + transcript/attempt | Used/burned marker and accepted state | No second claimant after crash |
| Device grant | Pairing transcript + selected scope revision | Grant intent and independent admission state | Partial scopes remain distinguishable |
| Group transition | Authenticated parent state + transition ID | Validated state/epoch and derived secrets | Conflicts pause rather than arrival-order choice |
| Archive import | Archive integrity ID + import selection | Bounded transactional import batches | No duplicate resurrection/authority clone |
| Payment review | Wallet revision + request + intent digest | Immutable reviewed preparation | Any material change invalidates approval |
| Sign/broadcast | One-use authorization + chain transaction identity | Signed result and observed submission state | Reconcile unknown chain state before repeat |
| Swap | Engine-specific operation ID | Durable encrypted recovery journal | Cannot generic-cancel funded state |
| External export | Preview revision + destination + exact selection | Finalized approved package | Partial/failed state reported, no hidden extra fields |

Rollback resistance has limits on general-purpose endpoints. The implementation must detect/prohibit dangerous state reuse and document unrecoverable uncertainty; it cannot assume encrypted storage alone prevents snapshots restoring an old sender.

### Retention and storage matrix

The following are design policies, not assertions about deployed servers. Each row needs storage-location, key, delete/replay, restart, and snapshot evidence.

| Data | Default policy | Required deletion/recovery behavior |
|---|---|---|
| Local message history | Keep until explicit deletion or selected prospective expiry | Encrypted per scope; no forced seven-day deletion |
| Unsent draft | Encrypted local, bounded size | Clear on explicit discard; hide/purge active plaintext on lock |
| Sender retry source | Until acknowledged/expired/cancelled according to policy | Necessary retry cannot imply relay durability |
| Relay ciphertext queue | RAM-only with seven-day maximum TTL | Earlier eviction/restart possible; no swap/dumps/snapshots/log traces by design |
| Invitation | One use, proposed ten-minute expiry | Burned/used replay protection survives relevant crash window |
| Skipped/prekey/replay state | Exact bounded profile policy | Cannot erase too early for supported delivery or retain without bound |
| Group roster/policy | Protected current state plus bounded authenticated recovery | No plaintext central group history |
| Media staging | Protected temporary content, bounded quotas | Cancellation/expiry/lock workers handled explicitly |
| Received attachment | Protected local cache according to content policy | Expiry removes eligible keys/cache references; recipient copies remain |
| Search index | Per-scope protected local index | Locked scopes excluded from active results and memory |
| Pairing grants | Current scoped authority and necessary revoked-state evidence | No full universal endpoint directory on peer infrastructure |
| Chat payment card details | Proposed minimization after settlement + 24 hours | Keep required unresolved-operation/recovery data; no chain erasure claim |
| Wallet transaction history | User-controlled local record with chain requirements | Chat deletion does not destroy funds or mandatory recovery state |
| Scheduled unsigned intent | Until executed/expired/cancelled | Revalidate at due time; no automatic authorization |
| Swap recovery journal | Until protocol-safe final state and user recovery policy | Retiring adapter cannot delete intervention/refund material |
| Local diagnostics | Bounded rotating redacted evidence | Exact cap/TTL and opt-in export; no remote automatic upload |
| Support case export | Only explicit reviewed selected fields | Recipient and published retention defined before send |
| Billing records | Separate minimum necessary business/legal record | No messaging/queue/contact identifier join |
| Study data | Separate consented study retention | No production behavior feed or hidden enrollment |
| External backups | User-chosen destination | Local delete cannot erase externally retained archive |

Exact skipped-key limits, replay windows, diagnostic TTLs, and platform temporary-file behavior are profile/implementation decisions requiring review, not conveniently infinite defaults. Missing numerical/configuration evidence blocks the relevant implementation gate.

## Acceptance test catalog

All tests start as Not run. The evidence package records real device/OS/build, chosen crypto/transport profile, prerequisites, inputs, expected and actual observations, packet/storage captures, reviewer, findings, remediation, and rerun.

### Identity, protocol, and content

| Test | Given / when | Required result |
|---|---|---|
| TST-001 First launch | Fresh install; name skipped; all optional permissions denied | Local profile/chat available without registration, contacts, wallet, analytics |
| TST-002 Remote invite | Captured link without secret; wrong guess; reused/expired code | No connection; prescribed burn/expiry/replay behavior; no oracle bypass |
| TST-003 Invitation race | Two claimants and process death at each persistence point | At most intended valid accepted relationship; no invite reuse |
| TST-004 Comparison | Remote image, transferred record, stale fingerprint, actual in-person QR | Distinct provenance; no automatic false independent comparison |
| TST-005 Key change | Queued message exists; peer identity changes | Pause affected send; fresh review; no silent “new phone” trust |
| TST-006 Direct profile | Unsupported/downgrade/replayed handshake and first reply | Required profile or fail closed; no compatibility downgrade |
| TST-007 State crash | Crash/rollback/disk full around session advance and send | No nonce/key reuse; truthful retry or explicit blocked uncertainty |
| TST-008 Message algebra | Duplicate/reordered edits, reactions, replies, wrong-author event | Bounded deterministic result; no cross-scope mutation |
| TST-009 Receipt accuracy | Relay ACK, relay restart, one/multiple endpoint receipts | Correct queued/accepted/received/partial, never inferred read |
| TST-010 Expiry | Sender/receiver skew, long offline delay, import and duplicate | Prospective authenticated policy; no timer restart/resurrection |
| TST-011 Search lock | Query while unlocked, then relock/process background | Results/snippets/key leases cleared; locked scope excluded |
| TST-012 Link/parser | Malformed URL, QR, card, JSON, unknown security event | Bounded inert handling; no native authority or hidden fetch |

### Network, infrastructure, and metadata

| Test | Given / when | Required result |
|---|---|---|
| TST-013 Full egress | Every network feature; IPv4/IPv6/DNS/redirect/proxy exceptions | Only permitted broker/bootstrap/platform scope; no hidden clients |
| TST-014 Route outage | Kill Tor during send, node, update, rate, diagnostics, media | No direct fallback; protected local pending state |
| TST-015 Context separation | Unrelated chats, wallet accounts, diagnostics, updates | No unintended reusable external identifier/circuit-level context join |
| TST-016 Relay host | Swap/core dumps/snapshots/crash/maintenance simulated | Verified deployment controls; accepted queue loss labeled honestly |
| TST-017 Relay quota | Flood malformed/valid bearer capabilities and large messages | Bounded per-capability resources; no civil-identity verification shortcut |
| TST-018 Directory | Invalid/old/expired/compromised recommendation | Reject per policy; cannot change identity authority or security profile |
| TST-019 Metadata comparison | Equivalent v0.5/v0.6 journeys, single/colluding observers | Field/size/timing/retention delta; no unsupported equality conclusion |
| TST-020 Privacy Report | Offline, incomplete instrumentation, optional external test | Passed only for observed scope; Not tested/Inconclusive otherwise |

### Groups, devices, and recovery

| Test | Given / when | Required result |
|---|---|---|
| TST-021 Pairing comparison | Mismatch, replay, only one confirmed device | No grants or active linked scopes |
| TST-022 Selected grants | Empty defaults, locked chat, future chat, crafted wider command | Only eligible selected scopes; no wallet/admin/future-chat expansion |
| TST-023 History transfer | None/range/custom, expired media, interrupted archive | Selected eligible history only; no ratchet/leaf clone |
| TST-024 Partial admission | Some peers/groups offline or reject | Per-scope active/pending; no global linked success |
| TST-025 Revocation | Lost device offline; peer partition; stale sender | Current reviewed freshness behavior; no global erase claim |
| TST-026 Group consent | Invite accepted but commit absent; device lacks authorization | No content/access until valid admission |
| TST-027 Group role | Malicious member/admin/coordinator attempts extra powers | Distinct powers; invalid authority rejected |
| TST-028 Group conflict | Competing children, coordinator loss, fork/partition | Affected action paused; no timeout election or timestamp winner |
| TST-029 Group capacity | Declared people/endpoints; worst-case fanout and padding | Resource/metadata targets met or limit lowered; no server-fanout switch |
| TST-030 Controller recovery | Old controller alive, duplicate successor/archive, companion promotion | No automatic authority; conflict recovery preserves truthful limits |
| TST-031 Hostile backup | Corrupt/old/bomb archive, wrong secret, truncated chunk | Bounded authenticated parsing; no plaintext temp/live-state activation |
| TST-032 Recovery drill | Isolated archive/wallet drill completed/cancelled | No active sessions, fund movement, or retained temporary secrets |

### Platform, multimedia, and UX

| Test | Given / when | Required result |
|---|---|---|
| TST-033 Lock lifecycle | App/chat/OS lock, background, reboot, process death | Correct key leases/previews/capture cleanup; no late UI plaintext |
| TST-034 Storage | WAL/temp/cache/recents/OS backup/search/crash dump inspected | No unintended plaintext/secret capture in supported boundary |
| TST-035 Notification | Denied/delayed/revoked push/distributor, force-quit/suspension | Honest availability; no body/amount/key in push; no content-key weakening |
| TST-036 Attachment sanitize | EXIF/GPS/document author/malformed codecs/huge dimensions | Exact sanitization result; unsupported original warning; bounded worker |
| TST-037 Transfer/view-once | Missing/reordered chunk, duplicate view, expired capability | Integrity/replay enforced; no cloud fallback or copy-prevention claim |
| TST-038 Media consent | Pre-call/invite/lock/panic/handoff/failure | No pre-consent/post-cancel capture; actual roster/rekey; no direct/STUN |
| TST-039 Renderer attack | Injected content/compromised TypeScript invokes native bridge | No arbitrary sign/export/enroll/socket/shell authority |
| TST-040 Accessibility | Large text, screen reader, keyboard, reduced motion | All consequential controls and full comparison data usable |
| TST-041 Comprehension | Consented user reviews verification/grants/payment/deletion | No severe scope/authority misunderstanding; redesign/retest if observed |
| TST-042 Thirty-day paths | New user and interruption branches across catalog | Every enabled control matches record; disabled feature cannot deep-link around gate |

### Financial, operational, and release

| Test | Given / when | Required result |
|---|---|---|
| TST-043 Wallet removal | Build with financial crates/module absent | All declared core chat journeys pass |
| TST-044 Wallet isolation | Renderer/core compromise attempt and OS privilege inspection | Enforced claimed boundary or module unavailable; distinct keys/store/recovery |
| TST-045 Existing wallet | Hardware/watch-only Connect, mismatched network, unknown history | No seed; no provider upload; conservative labels; contact-spend gate |
| TST-046 Node privacy | BTC filter/XMR scan/ETH own and external node profiles | Exact documented requests; no view key/xpub/contact map leakage |
| TST-047 Spend authorization | Changed destination/amount/fee/source/request/nonce/revision | Stale review/authorization rejected; no replay signing |
| TST-048 Chain lifecycle | Unknown submit result, reorg, replacement/conflict, stale scan | Reconcile before repeat; chain-specific status; no generic finality |
| TST-049 Hardware return | Altered PSBT/intent/network/change/fee/sighash | Reject mismatched return; exact device/firmware supported matrix |
| TST-050 Scheduling | Clock jump/reboot/locked phone/expired request/fee change | No unauthorized automatic future sign; due requires revalidation |
| TST-051 Payjoin/receive | Malicious negotiation, indexer/gas metadata, unsupported adapter | No ordinary-payment fallback; no unlinkability certification |
| TST-052 Swap | Peer failure, deadlines, watcher failure, chain reorg, phone death | Exact engine recovery; no uncovered start; no guaranteed automatic refund |
| TST-053 Export/support | Package preview, redactions, destination failure | Exact selected fields; no hidden keys/labels; truthful external effect |
| TST-054 Release supply chain | Tampered/old manifest, dependency advisory, rebuild mismatch | Block/contain according to scoped policy; no blanket audit claim |
| TST-055 Incident | Signing compromise, crypto flaw, adapter retirement, offline clients | Safe containment; no remote key exfiltration/wipe; recovery retained |
| TST-056 Funding/research | Billing/study interactions, rejected optional permissions | No messaging-identity join; no production analytics; free chat retained |
| TST-057 Legal capability | Region unreviewed/restricted, policy update, active funded operation | No new prohibited service; lawful safe recovery; no hidden identity logs |
| TST-058 Claims | Every product/store/help/security statement compared with evidence | Unsupported absolute/scopeless claim removed before release |

## Capability release gates

| Gate | Applies to | Minimum exit evidence |
|---|---|---|
| REL-CORE | Direct text and local identity | INV-01–20 applicable; ADR-IDENTITY/SESSION/PQ/INVITE/TOR; TST-001–020,033–035,039–043,053–058 |
| REL-VAULT | App/chat lock, search, archives | Key/storage/restore review; TST-010–012,031–034,040–042 |
| REL-DEVICE | Scoped pairing/sync/revoke/migration | Freshness/authority review; TST-021–025,030–032; actual multi-endpoint tests |
| REL-GROUP | Small private groups | Exact approved hybrid profile, role/ordering/freshness, client-fanout metadata; TST-026–029 |
| REL-MEDIA | Images/documents/notes/video | Parser isolation, sanitized-copy fixture tests, protected transfer/limits; TST-036–037 |
| REL-PLATFORM | Each OS/background mode | Actual hardware/OS matrix; storage/permission/push/build/lock tests; no inherited approval |
| REL-WALLET-MANAGE | Each chain and platform | Isolation, key/recovery/node/provenance review, legal classification; TST-043–046,049 |
| REL-PAY-XMR | Eligible private payment scope | Exact retained XMR flow; typed bridge; review/sign/status/history; FIN-01–20 and TST-047–050 |
| REL-PAY-PUBLIC | BTC/ETH contact spending | No-regression equivalence first; currently blocked where public linkage exceeds baseline |
| REL-CALL | Each voice/video topology | Feasibility + privacy + capture/admission/rekey assessment; TST-038 and full real egress matrix |
| REL-ADAPTER | Each protocol/direction/version | Exact maintained engine, manifest, audit, legal, deadline/recovery evidence; TST-051–052 |
| REL-OPS | Each hosted role/deployment | Retention/abuse/cost/host/signing/incident evidence, not merely source configuration |
| REL-LEGAL | Each entity/activity/jurisdiction/channel | Written current legal classification and controls compatible with invariants |
| REL-CLAIMS | Every public capability statement | Claim ID, exact evidence, limitations, approvers, expiry/review trigger |

A user checking “I understand” is not exit evidence for REL-PAY-PUBLIC or any other blocked gate. The no-regression requirement remains stricter than accepting a disclosed risk.

### Per-platform qualification matrix

| Target | Starting mode | Required device/lifecycle coverage | Non-assumption |
|---|---|---|---|
| Android | Primary development target | Supported OS range, low-memory, OEM battery policies, lock/reboot, foreground service, picker/USB | A service is not automatically an isolated security process |
| iOS | App-open delivery baseline | Supported devices, suspension/force-quit, key accessibility, notifications, background task limits | No arbitrary long-running child wallet process or guaranteed background swap watcher |
| macOS | Installed companion | App sandbox/entitlements, keychain behavior, screen lock, update/signing, external picker | Tauri logical isolation is not OS sandbox proof |
| Windows | Installed companion | Credential/storage behavior, OS lock, installer/signature/update, renderer constraints | Packaging alone does not prove process containment |
| Linux | Installed companion | Supported distro/display/keyring/package matrix, sandbox availability, permissions | Do not imply universal distro/hardware compatibility |

Each row needs the exact Rust, TypeScript, framework, native-bridge and transport versions. “Cross-platform” means independently tested capability variants, not one test run copied across five checkboxes.

## Claims register and evidence package

### Initial claims disposition

| Claim | Status before implementation | Required revision/evidence |
|---|---|---|
| “No phone number required” | Design intent | First-launch and optional-flow proof; no hidden dependency |
| “TGP cannot read messages” | Design intent for declared infrastructure boundary | Key/data-flow audit, server capture, operational exceptions and client limitations |
| “Post-quantum secure” | Not approved as blanket phrase | Exact protocol component/version/threat scope and limitations |
| “Deniable / not evidence” | Not approved as universal/legal claim | Protocol-specific qualified wording only; no legal guarantee |
| “Untraceable payments” | Prohibited | No such claim |
| “Unblockable anywhere” | Prohibited | Censorship-resilient attempts with explicit shutdown limits |
| “Audited” | Not approved for TGP | Actual assessor/build/scope/findings/remediation/public report |
| “No logs” | Not approved as absolute | Enumerate operational data and retention; actual deployment evidence |
| “Reproducible builds” | Target | Independent rebuild result for exact artifact/platform |
| “Instant” | Not approved as universal | Local-feedback target separated from route/delivery/confirmation |
| “Non-custodial” | Intended technical scope, not legal exemption | Exact role/control/key review plus counsel classification |
| “Free private chat” | Binding product model, unimplemented | Wallet-free/entitlement-free actual release and sustainable quota policy |
| “Works in country X” | Not approved globally | Current distribution/network/legal/capability evidence |

An evidence record includes artifact hashes, source commit/lockfile, supported platforms, approved ADRs, threat model, disclosure deltas, executed tests, captures with sensitive-data handling, review/finding closure, accessibility/comprehension results, capacity/cost, legal decision, owner signatures, and incident/rollback plans. A signature, green CI run, or this specification is not a substitute for those materials.

## Delivery work packages and accountability

### Implementation backlog

| Package | Deliverable | Dependency and stop condition |
|---|---|---|
| WP-FOUNDATION | Types, local stores, key leases, broker, dependency/provenance CI | Named owners and threat model; no hidden socket clients |
| WP-IDENTITY | Scoped credentials, compared invitation prototype | Close identity/PQ/invitation composition; block production otherwise |
| WP-DIRECT | Protected outbox, event algebra, receipts, search/vault | Crash/failure/locked-state tests before polished success UI |
| WP-INFRA | Minimal independent relay/rendezvous/directory roles | RAM/log/host/abuse metadata evidence; sustainable quotas |
| WP-DEVICE | Pairing, selection, per-scope admission/history, revoke | Exact freshness/migration rules; no universal trust |
| WP-GROUP | Hybrid engine integration and application authority | Profile/fork/partition/fanout review; no classical fallback |
| WP-MEDIA | Protected staging, sanitization, codec sandbox, transfer | No external blob service without no-regression result |
| WP-PLATFORM | Native key/permission/lifecycle integration per OS | Actual device matrix; degrade availability honestly |
| WP-DESIGN | Tokens/components, catalog, accessible ceremonies | Every control/negative state traced; severe misunderstanding blocks |
| WP-WALLET | Isolated optional chain adapters and recovery | Disable/separate module if OS containment unmet |
| WP-PAYMENT | Typed requests, exact review, separate signing, status | Source/privacy/legal eligibility; no public-chain override |
| WP-EXPERIMENT | Calls/Payjoin/stealth/swaps/nearby/continuity prototypes | Sandbox/testnet first; no mainnet launch assumed |
| WP-RELEASE | Independent assessment, reproducibility, claim/legal gates | Scoped approval; smaller supported release if necessary |

### Accountable roles

Bradley is the product owner named in the supplied specification. Security, protocol, platform, wallet, media, operations, release, design/accessibility, research, support and qualified legal-counsel owners must be named before execution; this document does not invent staff or approvals.

One person may hold multiple roles, but every release decision needs a named accountable owner and an independent reviewer where required. Missing an owner is a planning blocker, not implicit product-owner consent to the unresolved risk.

## Specification change control

Any change to an invariant, recipient set, authority, transport, key lifecycle, retention, dependency/parser, external destination, recovery, jurisdiction, or public claim requires an explicit before/after delta and updated tests. Feature flags, remote configuration, deep links, adapters, translations, OS integrations, and “temporary” operational logging follow the same process.

Record a change as Preserve by design, Candidate improvement, Conditional, Blocked, Deferred, or Validated for exact scope. Never summarize a tradeoff as “99% private” or average away a regression in one dimension with a benefit in another.
