# TGP Chat v0.6: Goal State and Complete Feature Catalog

This volume defines the product contract, binding security constraints, and cumulative feature inventory for TGP Chat v0.6. It is a normative design proposal, not a claim that an implementation exists, has passed tests, or has received an independent security audit.

| Field | Specification |
|---|---|
| Version | 0.6, detailed product and engineering baseline |
| Date | 5 November 2026 |
| Product owner | Bradley |
| Application stack | Rust application/security core and services; TypeScript presentation |
| Platforms | Android first; separately qualified iOS, macOS, Windows, Linux |
| Baseline | Supplied TGP Chat Product Specification v0.5, dated 3 November 2026 |
| Document status | Proposed specification; all implementation evidence initially absent |
| Normative vocabulary | MUST is mandatory; SHOULD needs a recorded exception; MAY is optional |
| Intended readers | Product, design, client, protocol, wallet, security, operations, release, legal, accessibility |
| Precedence | Privacy invariants, then explicit requirements, then selected policies, then candidates, then targets |
| Approval rule | A smaller supported release is preferable to a privacy regression |

## Goal state explanation

### Product owner's goal, reproduced verbatim

> We want to produce an app that allows for near-instant connection to anyone, anywhere, without being identified or blocked ever. We want to allow crypto currency exchange direct via contacts without this connecting identities inherently (must be strong enough to avoid being irrefutable evidence, at least). We want this app to be easy to use, free for chatting, and have world class UI. It will serve as the counterparty to the surveillance states and financial entrapment of the USA platforms!

### Engineering interpretation and limits

The quotation is the owner's aspiration, not approved customer-facing security language. v0.6 MUST NOT turn “ever,” “anywhere,” or the proposed evidence threshold into guarantees that the architecture cannot establish.

| Goal phrase | Testable product interpretation | Boundary that remains |
|---|---|---|
| Near-instant connection | Immediate local feedback, background key generation/transport bootstrap, short connection ceremony | First network contact requires a working route and an available peer or queued delivery |
| Anyone, anywhere | No required phone, email, country-specific registration, or provider account | Distribution, network access, devices, censorship, and law can restrict availability |
| Without being identified | No mandatory real-world identity; scope-local public keys and presentation; no address-book upload | Contacts can recognize each other; endpoints, platforms, public ledgers, and traffic may identify activity |
| Without being blocked ever | Multiple maintained transport options, self-hosting, signed distribution, honest offline queues | Total shutdown and sufficiently capable blocking remain possible |
| Direct exchange via contacts | Locally authorized non-custodial payment tools, E2EE request transport, no TGP custody | Payment peers and relevant protocols necessarily learn some payment information |
| Without connecting identities inherently | No shared messaging/wallet identifier, no TGP-readable contact/payment database, minimal typed bridge | Existing blockchain history, endpoints, counterparties, amount/timing, exports, and RPC queries may associate activity |
| Not irrefutable evidence | Avoid unnecessary third-party-verifiable application signatures on payment chat messages | No messaging or payment product can guarantee how evidence will be interpreted |
| Free for chatting | No payment, token, wallet, subscription, or financial identity required for core chat | Resource quotas and measured capacity still apply |
| World-class UI | Short safe pathways, accessible controls, truthful state, progressive disclosure | Verification, granting access, spending, recovery, and destructive actions retain deliberate friction |
| Counterparty to surveillance | Minimize collection and control; publish source, protocols, limits, and evidence | Open source and decentralization are not immunity from compromise, traffic analysis, or legal process |

Signal's PQXDH specification describes qualified offline deniability rather than a universal evidence guarantee, and a published analysis identifies deniability differences from X3DH ([PQXDH specification](https://signal.org/docs/specifications/pqxdh/), [PoPETs deniability analysis](https://petsymposium.org/popets/2024/popets-2024-0148.pdf)). MLS explicitly does not claim deniability and leaves application authentication and delivery choices to the deployment ([MLS architecture, RFC 9750](https://www.rfc-editor.org/rfc/rfc9750.html)).

### Safe public product statement

Proposed wording: “Private conversations without phone-number registration. You control which people and devices receive your messages, and TGP infrastructure does not hold the keys to read them. Optional wallets remain separate from your chat identity. Public-chain payments, recipients, platforms, and compromised devices have limits we explain before you use them.”

This wording is still conditional on implementation evidence. The claims register in the verification volume determines which clauses a particular release may publish.

## Privacy constitution and no-regression rule

### Ranked tenets retained

- **Data minimization:** Do not collect information that the service does not need.
- **Safe default:** Do not make users discover switches to obtain the baseline protections.
- **Device-held keys:** TGP infrastructure never receives content-decryption keys or wallet spending secrets.
- **No custody:** TGP does not custody, pool, mix, settle, or take a percentage of user payments.
- **Reviewed cryptography:** Do not invent primitives, combiners, key exchange, consensus, or recovery constructions.
- **Truthful boundaries:** Describe what is protected, what is visible, and what remains unproven.
- **Usable security:** Make routine safe actions simple and consequential authority changes explicit.

### Binding invariants

| ID | Binding requirement | Concrete failure that blocks release |
|---|---|---|
| INV-01 | No mandatory registration identity or TGP account | First launch requires phone, email, social login, or wallet |
| INV-02 | No public people directory, contact upload, or provider-readable roster | Service can enumerate a person's contacts or organization |
| INV-03 | Adding a person, endpoint, or history recipient requires explicit approval | Pairing silently shares every chat |
| INV-04 | App-managed online traffic uses the approved protected transport or fails closed | A library opens direct DNS/HTTP/STUN after Tor failure |
| INV-05 | Independent endpoints never share live ratchets, MLS leaves, or database keys | Backup clones a running session onto a second active device |
| INV-06 | Device enrollment grants only selected scopes | New device receives future chats automatically |
| INV-07 | Local deletion, requested deletion, expiry, and future revocation stay distinct | “Erase everywhere” is displayed without such authority |
| INV-08 | Messaging enrollment never grants wallet spending authority | Linked desktop can sign with the phone's wallet |
| INV-09 | Encryption, comparison, membership, route, and device health remain separate states | One green shield implies all protections |
| INV-10 | Platform services and exports have explicit boundaries | Push or external opening silently discloses content |
| INV-11 | Core security is not paywalled or joined to billing identity | Paid entitlement becomes a reusable messaging identity |
| INV-12 | Important claims name configuration and evidence | “Audited” without build, scope, findings, and exclusions |
| INV-13 | No optional feature can waive an existing privacy invariant | A warning is used to justify a direct-network fallback |
| INV-14 | Financial and messaging keys, storage, identifiers, and authorization are separate | Chat root derives wallet seed or wallet logs include chat ID |
| INV-15 | A chain transformation does not certify identity unlinkability | Swap or CoinJoin changes a wallet label to “anonymous” |
| INV-16 | Untrusted content cannot grant authority | QR, message, attachment, or URI auto-signs, enrolls, exports, or broadcasts |
| INV-17 | No provider-controlled content recovery or security bypass | TGP password reset decrypts chats or funds |
| INV-18 | Unknown/unsupported security state stops the affected action | Client chooses weaker profile to preserve availability |
| INV-19 | Secret deletion and crash consistency are explicit security properties | Rollback reuses nonce or restores an erased send key |
| INV-20 | No production social graph is collected for analytics or support | Engagement dashboard needs per-profile contact relationships |

### What “not even 1%” means operationally

Privacy is not reduced to a fabricated percentage. Each proposed change must be compared with the applicable v0.5 capability under the same threat model, platform, operating conditions, data retention, and adversary access.

For each dimension record the baseline, proposed behavior, observer, data field, destination, retention, joinability, evidence, and verdict. A new observer, newly accessible plaintext, new stable identifier, broader recipient set, longer retention, weaker recovery authority, extra uncontained parser, or failure-mode downgrade is a blocking regression until the design is changed or equivalence is established.

“Unmeasured” is not “equal.” An optional feature may be designed and documented without qualifying for production. User consent is necessary for deliberate disclosure but cannot prove that the no-regression rule has been met.

| Verdict | Meaning | Release action |
|---|---|---|
| Preserves by design, unverified | Intended boundary is unchanged | Implement and test; no public assurance yet |
| Candidate improvement, unverified | Design removes an exposure but composition remains untested | Require comparative evidence |
| Conditional | Named evidence or containment decision is missing | Disabled in release until condition closes |
| Blocked | Known new exposure conflicts with binding rule | Do not ship affected capability |
| Deferred | Product does not commit implementation | Keep inventory and reevaluation criteria |
| Validated for scope | Exact tested build/configuration has acceptable evidence | Only scoped claim may ship |

No feature in this specification is marked Validated. The security volume is an architecture-level pre-implementation review, not an independent audit.

### Critical disposition of the eight upgrades

| Upgrade | v0.6 disposition |
|---|---|
| Faster onboarding | Retain all checks; parallelize safe local work; target shorter setup, not weaker verification |
| Messaging UX | Add local-first events with bounded schemas and unchanged recipients |
| Large communities | Client-fanout private groups first; shared-mailbox scaling blocked pending metadata equivalence |
| Multimedia | Local sanitization and bounded endpoint transfer first; external blob storage separately gated |
| Native Bitcoin | Isolated optional wallet management specified; contact spending blocked where public-ledger disclosure violates baseline |
| Decentralized infrastructure | Open federated relays, BYO endpoints, independent operation, signed non-authoritative directory |
| Financial interoperability | Typed adapters and export boundaries; no TGP-operated swap/mixing service; no unlinkability certification |
| Wallet usability/recovery | Hardware/watch-only connection, separate backups/drills; no shared seed or automatic social recovery |

The earlier phrase “Move funds privately” is not retained as a production promise. v0.6 uses “Review external privacy tools,” explains residual linkage, and never declares that prior wallet history has been removed.

## Product requirements in plain English

### Classification and priority

Core means required for a useful chat release, not “all features ship at once.” Optional means removable without harming chat; Advanced means hidden from the routine UI; Experimental means not production-enabled without separate approval; Deferred means no current implementation commitment.

P0 is necessary for the affected capability to ship, P1 is a planned enhancement once its dependencies close, and P2 is optional exploration. A P0 wallet requirement does not force the wallet into the first messaging release.

### Identity, onboarding, and contact features

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX screen family |
|---|---|---|---|---|
| F-001 Local profile | Start without a phone, email, provider account, or payment | Core P0 | T-01 | O |
| F-002 Display name | Choose an optional name stored locally; no global username search | Core P0 | T-01 | O, C |
| F-003 Per-contact presentation | Use a different name/avatar for each relationship | Core P1 | T-01 | C |
| F-004 Fast setup | Prepare keys and protected connection while entering basic information | Core P0 | T-01, T-04 | O, N |
| F-005 Build verification | Inspect release version, signed digest, and independent build status | Advanced P0 | T-15 | H |
| F-006 QR connection | Scan an in-person one-use invitation and bind the session to its keys | Core P0 | T-02 | C |
| F-007 Separate-secret invite | Connect remotely using a link and separately conveyed secret | Core P0 | T-02 | C |
| F-008 Invite lifecycle | See expiry, cancel, rotate, and reject reused invitations | Core P0 | T-02 | C |
| F-009 Identity comparison | Compare canonical safety data and record how it was compared | Core P0 | T-02 | C |
| F-010 Key-change review | Pause affected sends when previously compared keys change | Core P0 | T-02 | R |
| F-011 Local contact labels | Rename or annotate contacts without transmitting private labels | Core P1 | T-01 | C |
| F-012 Contact cards | Share explicitly chosen signed fields only after export warning | Advanced P2 | T-02 | C |
| F-013 Reusable contact link | Optional revocable discovery capability, never a public account | Experimental P2 | T-02 | C |
| F-014 Block contact | Stop local receipt/fanout and revoke relevant delivery capabilities | Core P0 | T-03 | C |
| F-015 Contextual tutorial | Dismissible local hints and a three-task checklist, not a slideshow | Core P1 | T-16 | O, H |

### Messaging features

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-016 Direct messages | E2EE private text with independent endpoint sessions | Core P0 | T-03 | M |
| F-017 Truthful delivery | Distinguish queued, relay accepted, endpoint received, partial, failed, expired | Core P0 | T-03 | M |
| F-018 Offline queue | Read eligible local history and queue text without pretending it arrived | Core P0 | T-03 | M, N |
| F-019 Drafts | Retain an encrypted local draft; no draft synchronization by default | Core P1 | T-03 | M |
| F-020 Reply | Reply to a scoped event without leaking a locked/deleted quote | Core P1 | T-03 | M |
| F-021 Reactions | Add/remove idempotent E2EE reactions | Core P1 | T-03 | M |
| F-022 Edits | Show edited messages; bound edit authority and conflict behavior | Core P1 | T-03 | M |
| F-023 Pins/archive/mute | Organize conversations locally without server labels | Core P1 | T-03 | M |
| F-024 Search | Search unlocked local content and local contact labels only | Core P0 | T-03, T-05 | M |
| F-025 Disappearing messages | Optional authenticated prospective expiry; no remote-erasure promise | Core P0 | T-03 | S |
| F-026 Delete controls | Separate delete here and requests to others | Core P0 | T-03 | M, S |
| F-027 Receipts/typing | Read receipts, typing, last-online off; proposed activation separately reviewed | Advanced P2 | T-03 | S |
| F-028 URL safety | No automatic remote previews; explicit external-opening boundary | Core P0 | T-06 | M |
| F-029 Compatibility | Reject unsupported security profiles without silent downgrade | Core P0 | T-03 | R |
| F-030 Scoped security events | Changes to recipients and authority are not ordinary settings | Core P0 | T-03 | R |

### Media, groups, and communities

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-031 Image sharing | Normalize and strip supported metadata from a send copy | Collaboration P1 | T-06 | A |
| F-032 Documents | Warn when metadata cannot be safely removed; explicit original export | Collaboration P1 | T-06 | A |
| F-033 Voice notes | User-initiated recording, local codec, protected transfer | Collaboration P1 | T-06 | A |
| F-034 Video files | Bounded local re-encode and preview; no remote transcoding | Collaboration P1 | T-06 | A |
| F-035 View-once | Compliant-client view restriction with copying limitation | Collaboration P2 | T-06 | A |
| F-036 Attachment storage | Optional ciphertext blobs with separate retention and metadata review | Experimental P2 | T-06 | A |
| F-037 Private groups | Invite contacts, accept, approve endpoints, and admit cryptographically | Collaboration P0 | T-07 | G |
| F-038 Group roles | Explicit administrator/member/coordinator powers, no master reader | Collaboration P0 | T-07 | G |
| F-039 Group privacy | Encrypted roster/policy and recipient-specific delivery wrapping | Collaboration P0 | T-07 | G |
| F-040 Group removal | Remove people or devices with visible rekey progress | Collaboration P0 | T-07 | G, R |
| F-041 Group conflicts | Pause on contradictory authenticated state; no timestamp election | Collaboration P0 | T-07 | R |
| F-042 Large groups | Raise tested fanout capacity without new server-visible group identifiers | Experimental P2 | T-07 | G |
| F-043 Communities | Invite-only collection of separately protected groups | Experimental P2 | T-07 | G |
| F-044 Group history | No pre-join history by default; explicit authorized transfer | Collaboration P0 | T-07, T-08 | G, D |
| F-045 Voice calls | Tor-only feasibility-gated one-to-one voice | Experimental P1 | T-09 | L |
| F-046 Group voice/video | Four-person voice, then one-to-one video after separate gates | Experimental P2 | T-09 | L |
| F-047 Call admission | Only actual admitted call endpoints receive media secrets | Experimental P0 | T-09 | L |
| F-048 Call handoff | Explicit target admission and old capture retirement | Experimental P2 | T-09 | L |
| F-049 Recording/transcription | No TGP cloud transcript or default recording | Core restriction P0 | T-06, T-09 | A, L |

### Devices, transport, and local security

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-050 Scoped device linking | Link only selected chats, with fresh independent endpoint keys | Collaboration P0 | T-08 | D |
| F-051 History range | Separately choose none, 24 hours, seven days, or custom eligible history | Collaboration P0 | T-08 | D |
| F-052 Device inventory | Show grants and locally observed last-seen information | Collaboration P0 | T-08 | D |
| F-053 Revoke device | Stop new fanout locally and propagate scoped removal/rekey | Collaboration P0 | T-08 | R |
| F-054 Controller migration | Transfer scoped authority without cloning sessions | Advanced P0 | T-08 | R |
| F-055 Controller loss | Explain what survives and how to re-establish trust | Core P0 | T-08, T-12 | R |
| F-056 Automatic protected route | Connect via maintained Tor/pluggable transports | Core P0 | T-04 | N |
| F-057 Fail-closed broker | Libraries cannot bypass routing when connection fails | Core P0 | T-04 | N |
| F-058 BYO infrastructure | Independently configure relays, chain nodes, and bridges | Advanced P1 | T-04, T-10 | N, W |
| F-059 Federated relays | Open implementation, signed directory, operation independent of TGP | Core P0 | T-04 | N |
| F-060 Privacy report | Local scoped checks, not an anonymity score | Advanced P1 | T-14 | H |
| F-061 Cover traffic | Measured experimental padding/timing profile, no global-observer guarantee | Experimental P2 | T-04 | N |
| F-062 Snowflake contribution | Separate optional volunteer proxy with battery/network warning | Experimental P2 | T-04 | N |
| F-063 Device-wide VPN | Separate Android permission and exact tested traffic scope | Experimental P2 | T-04 | N |
| F-064 Local radio/mesh | Explicit proximity mode, never automatic online fallback | Experimental P2 | T-13 | N |
| F-065 App lock | Entry lock with device protection and configurable inactivity | Core P0 | T-05 | S |
| F-066 Per-chat vault | Independent keys/passphrase and locked-search exclusion | Core P0 | T-05 | S |
| F-067 Panic lock | Immediate local lock/capture stop with no remote trigger | Core P0 | T-05 | S |
| F-068 Decoy/disguise | Best-effort local presentation, never forensic-deniability claim | Experimental P2 | T-05 | S |
| F-069 Destructive wipe | Separate high-friction local configuration, not ordinary panic | Experimental P2 | T-05 | S |
| F-070 Dead-man behavior | Auto-lock only by default; auto-wipe deferred/experimental | Advanced P2 | T-05 | S |
| F-071 Clipboard/screenshot | Reduce supported capture paths; no absolute prevention promise | Core P0 | T-05 | S, W |
| F-072 Platform notifications | Minimal content; iOS platform path only after explicit choice | Optional P0 | T-11 | H |
| F-073 Desktop | Installed multipane companion with strict rendering/native boundary | Collaboration P0 | T-11 | D, H |

### Wallets, payments, recovery, and operations

| Feature | Plain-English requirement | Class / priority | Technical sheet | UX family |
|---|---|---|---|---|
| F-074 Wallet activation | No wallet tab or seed ceremony during chat onboarding | Optional P0 | T-10 | W |
| F-075 Native XMR | Local scan, separate keys, subaddresses, own/remote node over protected route | Optional P0 | T-10 | W |
| F-076 Native BTC | Descriptor wallet, local filter matching, PSBT/hardware workflows | Optional P0 | T-10 | W |
| F-077 Native ETH | Account isolation, own node preference, verified responses where supported | Optional P0 | T-10 | W |
| F-078 Connect existing funds | Watch-only or hardware first, no seed requested merely to connect | Optional P0 | T-10 | W |
| F-079 Imported-wallet quarantine | Preserve provenance and block contact payment where identity link remains | Optional P0 | T-10 | W |
| F-080 Source labels | Local conservative labels prevent accidental merging, not an anonymity score | Advanced P0 | T-10 | W |
| F-081 Contact requests | Typed E2EE one-to-one requests; no signing from chat payload | Optional P0 | T-10 | P |
| F-082 Review/sign/send | Exact network, recipient, amount, fees, source, and separate authorization | Optional P0 | T-10 | P |
| F-083 Delay/schedule | Explicit not-broadcast hold, cancellation limits, fresh review rules | Advanced P1 | T-10 | P |
| F-084 Spend guardrails | Local limits/large-send delay without coercion-resistance claim | Advanced P1 | T-10 | P |
| F-085 Transaction history | Chain-specific status; reveal TXIDs/proofs only deliberately | Optional P0 | T-10 | P |
| F-086 Fiat estimates | Off by default; manual or protected identifier-free cached rate | Advanced P2 | T-10 | W |
| F-087 Payjoin | Protocol-reviewed negotiation; never silently fall back to a plain payment | Experimental P1 | T-10 | P |
| F-088 Silent/stealth receive | Experimental scanning/gas/recovery review, no unlinkability promise | Experimental P2 | T-10 | W |
| F-089 Contact swaps | One-to-one negotiation, reviewed engine, proven deadline coverage | Experimental P2 | T-10 | X |
| F-090 External financial tools | Manifest and explicit export/import, no custody or TGP coordinator | Advanced P2 | T-10 | X |
| F-091 CoinJoin/mixer tools | No built-in automated route; user-chosen external boundary and legal review | Deferred P2 | T-10 | X |
| F-092 Wallet backup/drill | Chain-specific separate recovery and no-spend restore drill | Optional P0 | T-12 | B |
| F-093 Chat backup/restore | Selected encrypted archive, no seeds or live protocol state | Core P0 | T-12 | B |
| F-094 Continuity archive | Separately protected, high-consequence authority recovery | Experimental P2 | T-12 | R, B |
| F-095 Multisig/social recovery | Bitcoin descriptor study; no generic split-seed/contact recovery launch | Deferred P2 | T-12 | B |
| F-096 Cold/offline transfer | Typed bounded QR/file unsigned/signed transaction transfer | Advanced P1 | T-13 | W, P |
| F-097 Local diagnostics | Redacted bounded local evidence with preview before export | Advanced P0 | T-14 | H |
| F-098 Abuse controls | Capability quotas, local block, explicit selected-content report | Core P0 | T-04, T-14 | C, H |
| F-099 Distribution/updates | Signed manifests, provenance, reproducibility, rollback defenses | Core P0 | T-15 | H |
| F-100 Funding/support | No ads, graph monetization, chat fee, payment skim, or secret recovery | Core policy P0 | T-14 | H |
| F-101 Accessibility | Large text, screen readers, keyboard, reduced motion, accessible ceremonies | Core P0 | T-16 | All |
| F-102 Privacy-preserving research | Lab/cohort measurement without production behavior tracking | Core policy P0 | T-16 | H |
| F-103 Account deletion equivalent | Delete local profile/keys, explain retained external copies and wallets | Core P0 | T-05 | S |
| F-104 Security incident response | Capability-specific containment, signed fixes, scoped public claims | Core P0 | T-15 | H |

### Explicit non-goals and rejected shortcuts

- **Public social layer:** No public feed, public handle search, global organization listing, address-book matching, or public community discovery.
- **Provider recovery:** No master decryption key, admin escrow, support seed handling, account password reset, or cloud-readable archive.
- **Network shortcuts:** No direct-media fallback, hidden DNS, automatic external thumbnails, direct RPC fallback, or background third-party analytics.
- **Financial service:** No fiat on-ramp, brokerage, TGP liquidity maker, hosted swap coordinator, pooled treasury, percentage fee, or hosted mixing infrastructure.
- **Universal privacy badge:** No “untraceable,” “unblockable,” “anonymous wallet,” “zero clustering,” “not evidence,” or percentage security score.
- **Scope expansion by convenience:** No all-chat pairing, silent history sharing, automatic administrator promotion, or wallet replication through message sync.
- **Unreviewed recovery:** No custom Shamir splitting, automatic contact-held seed shares, or treating a copied archive as proof that the original controller is gone.
- **Unqualified media:** No automatic cloud transcription, default call recording, bot ecosystem, external AI reading messages, or initial screen sharing.

## Users, outcomes, and product acceptance

### Working user stories

- **New private-chat user:** As a person connecting to one intended contact, I want a short setup without registration so I can begin without creating a provider account.
- **Small-team member:** As an invited participant, I want to understand who and which devices can read future messages so I can make an informed admission choice.
- **Controller owner:** As someone adding a laptop, I want to select exactly which chats and history it receives so unrelated relationships remain outside its access.
- **Existing-wallet owner:** As someone who already holds BTC or ETH, I want to inspect/manage funds without exporting seeds or disclosing chat identity to a provider.
- **Payment recipient:** As someone receiving a request, I want to distinguish a request from a transaction and a peer claim from locally observed settlement.
- **Lost-device user:** As someone who lost a phone, I want an honest recovery path that does not imply unavailable remote erasure or recovery powers.
- **Accessibility user:** As someone using a screen reader or large text, I want the same comparison, grant, and spending decisions without bypassing security.
- **Hostile-network user:** As someone with intermittent or blocked internet, I want clear queued states and safe route recovery without silent weaker connections.

### Success targets, not reported results

| Outcome | Proposed target | Measurement and guardrail |
|---|---|---|
| Setup to first queued message | Median below 45 seconds in defined guided lab condition | Report invite, route, typing, and verification separately |
| Local interaction feedback | 95th percentile under 100 ms on declared reference devices | Never synthesize delivery or admission success |
| Warm chat opening | 95th percentile under 300 ms for unlocked local history | Locked-chat keys must not be kept solely to improve speed |
| Safe task completion | At least 90% unassisted completion in a consented formative cohort | Cohort size/protocol set before evaluation; no production tracking |
| Critical comprehension | No observed severe misunderstanding of recipient/spend authority in release study | Any severe error triggers redesign/retest, not averaging away |
| Egress policy | Zero prohibited direct flows in the adversarial matrix | One unexplained packet blocks the affected build |
| Crypto/authority failures | Zero known unresolved critical/high exploitable findings | Evidence must identify assessor, build, scope, and remediation |
| Wallet removal | All core chat tests pass in a wallet-free build | No financial dependency in onboarding or chat transport |
| Capacity | Supported limits come from measured worst-case workloads | Published limits may be lower than design targets |

The 45-second target is a new design ambition, not a measured improvement over v0.5. No comparative performance percentage is asserted.

### Definition of a complete v0.6 specification

Every catalog feature must map to a technical owner, a concrete state/authority model, a disclosure comparison, screen pathways, and release evidence. Experimental and deferred features are complete as decisions only when the blocking question, safe disabled UI behavior, and reevaluation criteria are explicit.

Implementation tickets may subdivide requirements but may not silently remove them. Any conflict between a convenient product action and an invariant blocks the affected action and requires an ADR, not a discretionary UI warning.
