# TGP Chat v0.6: Feature and Baseline Traceability

This matrix maps all 104 product features to technical sheets, concrete screen records, eight-dimension reviews, owner roles, and release tests. It records intended coverage, not proof that code exists or a requirement has passed.

The screen catalog's family trace rows describe the broader surface; the per-feature screen assignments here are the more precise navigation mapping. Owner roles require actual named assignees before execution.

## Feature-to-evidence matrix

| Feature | Classification | Technical / owner role | Screen IDs | Eight-dimension review | Required tests / gate |
|---|---|---|---|---|---|
| F-001 Local profile | Core P0 | T-01; Identity/platform | O-02, O-03, O-04 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-002 Display name | Core P0 | T-01; Identity/platform | O-03, C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-003 Per-contact presentation | Core P1 | T-01; Identity/platform | C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-004 Fast setup | Core P0 | T-01, T-04; Identity/platform, Network/operations | O-04, O-05 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-005 Build verification | Advanced P0 | T-15; Release/security | O-01, H-08 | AUD-03 | TST-054,058; REL-CLAIMS / REL-PLATFORM |
| F-006 QR connection | Core P0 | T-02; Protocol/security | C-01, C-02, C-03, C-06 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-007 Separate-secret invite | Core P0 | T-02; Protocol/security | C-04, C-05, C-06 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-008 Invite lifecycle | Core P0 | T-02; Protocol/security | C-02, C-04, C-05 | AUD-02 | TST-001–005,012,039–042; REL-CORE |
| F-009 Identity comparison | Core P0 | T-02; Protocol/security | C-06, C-07 | AUD-03 | TST-001–005,012,039–042; REL-CORE |
| F-010 Key-change review | Core P0 | T-02; Protocol/security | R-01, C-07 | AUD-03 | TST-001–005,012,039–042; REL-CORE |
| F-011 Local contact labels | Core P1 | T-01; Identity/platform | C-08, C-09 | AUD-01 | TST-001–005,012,039–042; REL-CORE |
| F-012 Contact cards | Advanced P2 | T-02; Protocol/security | C-10 | AUD-03 | TST-004,012,019,053; REL-CORE / REL-CLAIMS |
| F-013 Reusable contact link | Experimental P2 | T-02; Protocol/security | C-10 | AUD-03 | TST-002–003,012,017,019; REL-CORE / REL-OPS |
| F-014 Block contact | Core P0 | T-03; Messaging | C-11 | AUD-25 | TST-012,014,017,019; REL-CORE / REL-OPS |
| F-015 Contextual tutorial | Core P1 | T-16; Design/accessibility/research | O-06, O-07, H-07 | AUD-01 | TST-001,040–042,056; REL-CORE |
| F-016 Direct messages | Core P0 | T-03; Messaging | M-01 | AUD-04 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-017 Truthful delivery | Core P0 | T-03; Messaging | M-01, M-06 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-018 Offline queue | Core P0 | T-03; Messaging | M-01, M-06, N-01 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-019 Drafts | Core P1 | T-03; Messaging | M-01, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-020 Reply | Core P1 | T-03; Messaging | M-03, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-021 Reactions | Core P1 | T-03; Messaging | M-03, M-05 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-022 Edits | Core P1 | T-03; Messaging | M-03, M-04 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-023 Pins/archive/mute | Core P1 | T-03; Messaging | M-02, M-08 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-024 Search | Core P0 | T-03, T-05; Messaging, Storage/security | M-02, M-07 | AUD-06 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-025 Disappearing messages | Core P0 | T-03; Messaging | S-06 | AUD-06 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-026 Delete controls | Core P0 | T-03; Messaging | M-09, S-09 | AUD-05 | TST-006–012,033–034,039–042; REL-CORE / REL-VAULT |
| F-027 Receipts/typing | Advanced P2 | T-03; Messaging | S-10 | AUD-25 | TST-013–014,019,042; REL-CORE |
| F-028 URL safety | Core P0 | T-06; Media/storage | M-10 | AUD-25 | TST-012–014,039; REL-CORE |
| F-029 Compatibility | Core P0 | T-03; Messaging | M-11 | AUD-04 | TST-006,012,054; REL-CORE |
| F-030 Scoped security events | Core P0 | T-03; Messaging | M-01, R-01, R-02, R-06 | AUD-04 | TST-005,025–030,039–042; REL-CORE / REL-DEVICE / REL-GROUP |
| F-031 Image sharing | Collaboration P1 | T-06; Media/storage | A-01, A-02, A-05, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-032 Documents | Collaboration P1 | T-06; Media/storage | A-01, A-03, A-05 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-033 Voice notes | Collaboration P1 | T-06; Media/storage | A-04, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-034 Video files | Collaboration P1 | T-06; Media/storage | A-06, A-07 | AUD-11 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-035 View-once | Collaboration P2 | T-06; Media/storage | A-02, A-05 | AUD-06 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-036 Attachment storage | Experimental P2 | T-06; Media/storage | A-08 | AUD-12 | TST-014,034,036–037,040–042; REL-MEDIA |
| F-037 Private groups | Collaboration P0 | T-07; Group protocol | G-01, G-02, G-03, G-04, G-05 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-038 Group roles | Collaboration P0 | T-07; Group protocol | G-06, G-07, G-08 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-039 Group privacy | Collaboration P0 | T-07; Group protocol | G-02, G-06, G-07 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-040 Group removal | Collaboration P0 | T-07; Group protocol | G-09, G-10 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-041 Group conflicts | Collaboration P0 | T-07; Group protocol | G-08, R-06 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-042 Large groups | Experimental P2 | T-07; Group protocol | G-11 | AUD-10 | TST-019,025–029,040–042; REL-GROUP |
| F-043 Communities | Experimental P2 | T-07; Group protocol | G-11 | AUD-10 | TST-019,025–029,040–042; REL-GROUP |
| F-044 Group history | Collaboration P0 | T-07, T-08; Group protocol, Device/authority | G-02, G-12, D-05 | AUD-09 | TST-019,025–029,040–042; REL-GROUP |
| F-045 Voice calls | Experimental P1 | T-09; Media/security | L-01, L-02, L-03, L-04 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-046 Group voice/video | Experimental P2 | T-09; Media/security | L-01, L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-047 Call admission | Experimental P0 | T-09; Media/security | L-01, L-02, L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-048 Call handoff | Experimental P2 | T-09; Media/security | L-03 | AUD-18 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-049 Recording/transcription | Core restriction P0 | T-06, T-09; Media/storage, Media/security | A-04, L-03, L-04 | AUD-11 | TST-013–014,033,038,040–042; REL-CALL / REL-MEDIA |
| F-050 Scoped device linking | Collaboration P0 | T-08; Device/authority | D-01, D-02, D-03, D-04, D-06 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-051 History range | Collaboration P0 | T-08; Device/authority | D-05, D-06 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-052 Device inventory | Collaboration P0 | T-08; Device/authority | D-01 | AUD-13 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-053 Revoke device | Collaboration P0 | T-08; Device/authority | R-03 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-054 Controller migration | Advanced P0 | T-08; Device/authority | R-04 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-055 Controller loss | Core P0 | T-08, T-12; Device/authority, Recovery/security | R-05 | AUD-14 | TST-021–025,030–032,040–042; REL-DEVICE |
| F-056 Automatic protected route | Core P0 | T-04; Network/operations | O-05, N-01, N-02, N-03 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-057 Fail-closed broker | Core P0 | T-04; Network/operations | N-01, N-02, N-05 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-058 BYO infrastructure | Advanced P1 | T-04, T-10; Network/operations, Wallet/security/legal | N-03, N-04, N-05, W-07 | AUD-07 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-059 Federated relays | Core P0 | T-04; Network/operations | N-04, N-05 | AUD-08 | TST-013–020,033,057; REL-CORE / REL-OPS / REL-PLATFORM |
| F-060 Privacy report | Advanced P1 | T-14; Operations/support | H-03 | AUD-26 | TST-020,053; REL-CORE / REL-CLAIMS |
| F-061 Cover traffic | Experimental P2 | T-04; Network/operations | N-06 | AUD-27 | TST-013–015,019; REL-CORE / REL-PLATFORM |
| F-062 Snowflake contribution | Experimental P2 | T-04; Network/operations | N-07 | AUD-27 | TST-013–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-063 Device-wide VPN | Experimental P2 | T-04; Network/operations | N-07 | AUD-27 | TST-013–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-064 Local radio/mesh | Experimental P2 | T-13; Platform/wallet | N-08 | AUD-27 | TST-012–014,019,033,035,057; REL-PLATFORM / REL-LEGAL |
| F-065 App lock | Core P0 | T-05; Storage/security | S-01, S-02, S-03 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-066 Per-chat vault | Core P0 | T-05; Storage/security | S-04, S-05 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-067 Panic lock | Core P0 | T-05; Storage/security | S-02 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-068 Decoy/disguise | Experimental P2 | T-05; Storage/security | S-08 | AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-069 Destructive wipe | Experimental P2 | T-05; Storage/security | S-08 | AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-070 Dead-man behavior | Advanced P2 | T-05; Storage/security | S-03, S-08 | AUD-15, AUD-16 | TST-011,030–034,039–042; REL-VAULT |
| F-071 Clipboard/screenshot | Core P0 | T-05; Storage/security | S-07, W-10, B-09 | AUD-15 | TST-011,030–034,039–042; REL-VAULT |
| F-072 Platform notifications | Optional P0 | T-11; Platform | H-02 | AUD-17 | TST-013–014,033–035,039–042,054; REL-PLATFORM |
| F-073 Desktop | Collaboration P0 | T-11; Platform | D-07, H-08, H-09 | AUD-17 | TST-013–014,033–035,039–042,054; REL-PLATFORM |
| F-074 Wallet activation | Optional P0 | T-10; Wallet/security/legal | W-01, W-02 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-075 Native XMR | Optional P0 | T-10; Wallet/security/legal | W-07, W-08, W-09, W-10, W-11 | AUD-20 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-076 Native BTC | Optional P0 | T-10; Wallet/security/legal | W-03, W-04, W-05, W-07, W-14 | AUD-21 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-077 Native ETH | Optional P0 | T-10; Wallet/security/legal | W-07, W-08, W-09 | AUD-21 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-078 Connect existing funds | Optional P0 | T-10; Wallet/security/legal | W-03, W-04, W-05 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-079 Imported-wallet quarantine | Optional P0 | T-10; Wallet/security/legal | W-06 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-080 Source labels | Advanced P0 | T-10; Wallet/security/legal | W-06, W-13 | AUD-19 | TST-043–046,049,057; REL-WALLET-MANAGE |
| F-081 Contact requests | Optional P0 | T-10; Wallet/security/legal | P-01, P-02 | AUD-20, AUD-21, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-082 Review/sign/send | Optional P0 | T-10; Wallet/security/legal | P-03, P-04, P-05, P-06, P-07 | AUD-20, AUD-21, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-083 Delay/schedule | Advanced P1 | T-10; Wallet/security/legal | P-10 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-084 Spend guardrails | Advanced P1 | T-10; Wallet/security/legal | P-11 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-085 Transaction history | Optional P0 | T-10; Wallet/security/legal | P-08, P-09 | AUD-20, AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-086 Fiat estimates | Advanced P2 | T-10; Wallet/security/legal | W-15 | AUD-22 | FIN-01–20; TST-047–050,057; REL-PAY-XMR / REL-PAY-PUBLIC |
| F-087 Payjoin | Experimental P1 | T-10; Wallet/security/legal | P-12 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-088 Silent/stealth receive | Experimental P2 | T-10; Wallet/security/legal | W-16 | AUD-21, AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-089 Contact swaps | Experimental P2 | T-10; Wallet/security/legal | X-03, X-04, X-05 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-090 External financial tools | Advanced P2 | T-10; Wallet/security/legal | X-01, X-02, X-06 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-091 CoinJoin/mixer tools | Deferred P2 | T-10; Wallet/security/legal | X-01, X-02, X-06 | AUD-23 | TST-019,044,051–052,057; REL-ADAPTER; REL-PAY-PUBLIC where applicable |
| F-092 Wallet backup/drill | Optional P0 | T-12; Recovery/security | B-09, B-10, W-12 | AUD-24 | TST-030–032,044,049,057; REL-VAULT / REL-WALLET-MANAGE |
| F-093 Chat backup/restore | Core P0 | T-12; Recovery/security | B-01, B-02, B-03, B-04, B-05, B-06, B-07, B-08 | AUD-24 | TST-030–032,044,049,057; REL-VAULT / REL-WALLET-MANAGE |
| F-094 Continuity archive | Experimental P2 | T-12; Recovery/security | R-07 | AUD-14, AUD-24 | TST-025,030–032; REL-DEVICE / REL-VAULT |
| F-095 Multisig/social recovery | Deferred P2 | T-12; Recovery/security | B-11 | AUD-24 | TST-030–032,044,049,057; REL-ADAPTER; deferred, not approved |
| F-096 Cold/offline transfer | Advanced P1 | T-13; Platform/wallet | W-14, P-06 | AUD-24 | TST-044,047,049; REL-WALLET-MANAGE / REL-ADAPTER |
| F-097 Local diagnostics | Advanced P0 | T-14; Operations/support | H-03, H-05, H-06 | AUD-24 | TST-017,020,053,056; REL-CORE / REL-OPS |
| F-098 Abuse controls | Core P0 | T-04, T-14; Network/operations, Operations/support | C-11, H-05, N-04 | AUD-08, AUD-24 | TST-017,020,053,056; REL-CORE / REL-OPS |
| F-099 Distribution/updates | Core P0 | T-15; Release/security | O-01, H-08, H-09 | AUD-24 | TST-054–055,058; REL-CLAIMS / REL-PLATFORM |
| F-100 Funding/support | Core policy P0 | T-14; Operations/support | H-04, H-12 | AUD-24 | TST-043,053,056–058; REL-CLAIMS / REL-LEGAL |
| F-101 Accessibility | Core P0 | T-16; Design/accessibility/research | O-08, C-07, D-03, H-07 | AUD-24 | TST-040–042; Every enabled capability |
| F-102 Privacy-preserving research | Core policy P0 | T-16; Design/accessibility/research | H-13 | AUD-24 | TST-041,056; REL-CLAIMS / REL-LEGAL |
| F-103 Account deletion equivalent | Core P0 | T-05; Storage/security | S-09 | AUD-15 | TST-030–034,043–044; REL-VAULT / REL-WALLET-MANAGE |
| F-104 Security incident response | Core P0 | T-15; Release/security | H-14, H-09 | AUD-24 | TST-054–055,057–058; REL-CLAIMS / REL-OPS |

## v0.5 requirement-family disposition

These IDs are extracted from the supplied v0.5 baseline and retained as provenance identifiers. The crosswalk states where their intent is carried or tightened; it does not overwrite an inherited privacy requirement with a convenient weaker implementation.

| Baseline IDs present | v0.6 feature coverage | Disposition / technical and release home |
|---|---|---|
| INV-01, INV-02, INV-03, INV-04, INV-05, INV-06, INV-07, INV-08, INV-09, INV-10, INV-11, INV-12 | INV-01–12 retained and extended by INV-13–20 | All volumes / all release gates |
| ID-01, ID-02, ID-03, ID-04 | F-001–004,006–008,011–013 | T-01/T-02; O/C; REL-CORE |
| VER-01, VER-02, VER-03, VER-04, VER-05 | F-005,009–010,030,052 | T-02/T-15; C/R/H; REL-CORE/REL-CLAIMS |
| MSG-01, MSG-02, MSG-03, MSG-04, MSG-05, MSG-06, MSG-07 | F-016–030 | T-03; M/S; REL-CORE/REL-VAULT |
| V3-01, V3-02, V3-03, V3-04, V3-05, V3-06 | F-024,060,065,085–086,097 | T-03/T-05/T-10/T-14; M/S/W/P/H |
| NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07 | F-056–064 | T-04; N; REL-CORE/REL-OPS/REL-PLATFORM |
| DEV-01, DEV-02, DEV-03, DEV-04, DEV-05, DEV-06, DEV-07, DEV-08 | F-050–055 | T-08; D/R; REL-DEVICE |
| SYN-01, SYN-02, SYN-03, SYN-04, SYN-05, SYN-06 | F-017–024,044,050–055,093–094 | T-03/T-07/T-08/T-12; M/G/D/R/B |
| GRP-01, GRP-02, GRP-03, GRP-04, GRP-05, GRP-06, GRP-07, GRP-08, GRP-09, GRP-10 | F-037–044 | T-07; G/R; REL-GROUP |
| CALL-01, CALL-02, CALL-03, CALL-04, CALL-05, CALL-06, CALL-07, CALL-08, CALL-09 | F-045–049 | T-09; L; REL-CALL |
| AND-01, AND-02, AND-03, AND-04 | F-056–057,065–067,071–072 | T-04/T-05/T-11; Android independently qualified |
| IOS-01, IOS-02, IOS-03, IOS-04, IOS-05, IOS-06 | F-056–057,065–067,071–072 | T-04/T-05/T-11; app-open default; REL-PLATFORM |
| DESK-01, DESK-02, DESK-03, DESK-04, DESK-05 | F-050–057,065–067,071–073 | T-08/T-11/T-15; D-07; REL-PLATFORM |
| SEC-01, SEC-02, SEC-03, SEC-04, SEC-05, SEC-06, SEC-07 | F-065–071,103 | T-05; S; destructive options remain experimental |
| BKP-01, BKP-02, BKP-03, BKP-04, BKP-05, BKP-06, BKP-07 | F-092–096 | T-12; B/R/W; history/continuity/wallet separate |
| WAL-01, WAL-02, WAL-03, WAL-04, WAL-05, WAL-06, WAL-07, WAL-08 | F-074–080,088,092,095–096 | T-10/T-12; W/B; optional isolation and chain gates |
| PAY-01, PAY-02, PAY-03, PAY-04, PAY-05, PAY-06, PAY-07 | F-081–087,089–091 | T-10; P/X; typed 1:1 only and separate auth |
| MED-01, MED-02, MED-03, MED-04 | F-031–036,049,071 | T-06; A; no implicit persistent cloud storage |
| OFF-01, OFF-02, OFF-03, OFF-04 | F-018,064,093,096 | T-03/T-13; M/N/W; no offline chain-settlement guarantee |
| UX-01, UX-02, UX-03, UX-04, UX-05 | F-015,101 and all screen pathways | T-16; UI system/catalog; original aesthetic retained, no new mockup approval claimed |
| ARCH-01, ARCH-02, ARCH-03, ARCH-04 | INV-01–20 and F-016,037,050,057,074,081 | Component/bridge/data boundary contracts; all capabilities |
| OPS-01, OPS-02, OPS-03, OPS-04, OPS-05, OPS-06 | F-017–018,059,097–100,104 | T-04/T-14/T-15; REL-OPS |
| DIST-01, DIST-02, DIST-03, DIST-04 | F-005,099,104 | T-15; H-08/H-09/H-14; REL-CLAIMS |
| FUND-01, FUND-02 | F-100 | T-14; H-12; no identity-linked billing/security paywall |
| SUP-01 | F-097–098,100 | T-14; H-04/H-05/H-06; selected export only |
| LEGAL-01 | All optional financial and operated services | Final legal volume; REL-LEGAL |
| MET-01, MET-02, MET-03, MET-04 | F-101–102 and success targets | T-16; consented cohorts/lab only, no production graph |
| GATE-01 | All feature evidence/release records | Verification volume; not a claim gates passed |
| NOT-01 | F-072 | T-11; H-02; platform-specific explicit modes |

## Explicit v0.5-to-v0.6 changes

| Change | Disposition | Privacy consequence / required evidence |
|---|---|---|
| Eight upgrade proposals | Consolidated into feature IDs and gates | No blanket approval of the earlier brainstorm |
| Local-first usability | More explicit taps, controls, empty/error/partial states | No authority check removed for speed |
| Crypto/library choices | Current candidate profiles and licensing/advisory notes | Actual composition remains open, no invented suite |
| Groups | 32-person/128-endpoint envelope retained as target; larger tiers experimental | Shared-mailbox/server-fanout scaling blocked without metadata equivalence |
| Media | Detailed local preparation and endpoint transfer | External persistent blob service not silently inherited |
| BTC/ETH | Native isolated management architecture added | Contact spending blocked where public metadata exceeds baseline |
| Existing funds | Hardware/watch-only first, conservative provenance | No seed on Connect or anonymous/clean label |
| Financial tools | Per-adapter manifests, explicit external boundary and legal gates | No automatic recommended mixer/swap route or guaranteed unlinkability |
| Scheduling/swaps | Explicit authorization and deadline/recovery contracts | No phone-background guarantee or generic automatic refund |
| Recovery | No-spend drills and history/continuity/wallet separation | No live-state clone or automatic social recovery |
| Security review | Feature-linked eight-dimension comparisons | Architecture review, not independent audit |
| First thirty days | Full declared product-owned screen/state catalog | External/OS/engine annexes remain release dependencies |
| Legality | Country/activity/actor restrictions at the end | No worldwide legality guarantee or covert compliance surveillance |

## Evidence status

All feature implementation/test statuses are Not implemented / Not tested for purposes of this document because no executable TGP implementation or results were supplied. Upstream references are background, and the authoring checks on this specification validate only document structure and coverage.

A future implementation must replace these initial statuses with traceable issue, commit, test, review, legal and release records. It must not interpret this matrix as security certification or authorization to deploy a financial service.
