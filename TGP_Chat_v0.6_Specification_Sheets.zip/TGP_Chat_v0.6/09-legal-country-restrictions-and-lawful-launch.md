# TGP Chat v0.6: Legal, Country Restrictions, and Lawful Launch

This section intentionally comes last in the master specification. It is a preliminary issue-spotting and launch-control framework dated 5 November 2026, not a legal opinion, a worldwide country clearance, a promise of legality, or advice to evade restrictions.

Some financial services, privacy-asset activities, marketing, sanctions dealings, and unlicensed operations are prohibited in particular jurisdictions. The legal analysis must distinguish an individual's own use, publishing software, operating a relay, arranging transactions, supplying liquidity, controlling recovery/signing, and providing regulated services; those are not automatically treated alike ([FinCEN virtual-currency guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [FCA registration perimeter](https://www.fca.org.uk/firms/cryptoassets/who-needs-register), [MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).

## Plain-English bottom line

- **Private software is not a legal shield:** Encryption, Tor, non-custody, decentralization, open source, free distribution, and a user-choice disclaimer must not be marketed as making prohibited conduct lawful. Classification must use what the actual people, company, code, infrastructure, and marketing do, rather than a label ([FinCEN guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [MiCA](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng), [MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).
- **Some territories are particularly restrictive:** Mainland China's notice treats specified virtual-currency exchange and related business activities as illegal financial activities; Dubai's VARA rules prohibit issuance and covered VA activities involving anonymity-enhanced cryptocurrencies in its defined Emirate scope ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html), [VARA regulations](https://rulebooks.vara.ae/entiresection/437)).
- **Some restrictions apply to providers, not every holder:** The EU AML Regulation's anonymity-related account restriction is directed at specified regulated institutions/CASPs and generally applies from 10 July 2027; it is not a blanket declaration that every individual holding a privacy coin or using a self-hosted wallet is committing a crime ([Regulation (EU) 2024/1624, Articles 79 and 90 and recital 160](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)).
- **United States obligations remain relevant:** Federal money-transmission analysis, Washington licensing, sanctions, encryption export classification, consumer-facing claims, and actual criminal conduct require distinct review; “we do not custody” is not a substitute for that work ([FinCEN guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf), [Washington RCW 19.230.030](https://app.leg.wa.gov/rcw/default.aspx?cite=19.230.030), [OFAC FAQ 560](https://ofac.treasury.gov/faqs/560), [EAR §742.15](https://www.bis.gov/regulations/ear/742)).
- **TGP's product response is not covert surveillance:** If a proposed service cannot lawfully be offered while preserving the binding privacy requirements, do not offer that service in that scope. Seek a lawful classification/authorization or remove the activity; do not secretly weaken encryption, add identity logging, or claim that a warning removes the obligation.

The country table below is intentionally limited to reviewed issues and source scope. Unlisted countries are unreviewed, not automatically permitted and not automatically illegal.

## Separate the actor and the activity

### Classification worksheet

| Actor/activity | What counsel must determine | Product policy pending approval |
|---|---|---|
| Individual holding keys and paying with own funds | Applicable personal-use, sanctions, tax, asset, import/network and transaction restrictions | Give accurate limits; no universal legality assurance |
| Publishing neutral chat source/binaries | Software/encryption distribution, privacy, export, intellectual property, consumer and platform obligations | Signed distribution; no financial-service claim by implication |
| Operating message relay/rendezvous/directory | Network/content/service/privacy/security duties, local infrastructure rules and actual data held | Minimal documented retention; no financial instructions or settlement authority |
| Optional local wallet software | Whether exact functionality is software-only, custody, exchange, transfer, arranging or another regulated role | No custody; distinct platform/chain qualification and counsel review |
| Contact-payment request transport | Whether typed private messages plus wallet affordances alter service classification | No operator-readable payment graph; no automatic sign/broadcast |
| Swap offer/discovery/router UI | Whether matching, arranging, pricing, facilitation, brokering, liquidity, referral or promotions duties arise | No hosted TGP orderbook, liquidity, coordinator, percentage fee or mainnet default |
| CoinJoin/mixer coordinator or operator | Money transmission, AML, sanctions, anonymizing-service, prohibited-asset and criminal-law exposure | Not a TGP service; external tools require specific review, not assumed exemption |
| Watcher/refund signer | Actual key/control authority, operational duty, geography and protocol role | Exact least authority; no implied “only monitoring” if it can sign |
| Volunteer proxy / device VPN / nearby radio | Local telecom/network/software distribution and participation restrictions | Independently optional, explicit, disabled until qualified |
| Paid optional infrastructure / donations | Business records, tax, payments, consumer rights and entitlement joinability | No core-security paywall or messaging-identity link |
| Support and abuse reporting | Data-controller/processor role, lawful requests, retention and user disclosure | Only explicitly previewed selected data; no master decryption key |
| Marketing/app-store distribution | Targeted country, financial-promotion rules, app category and licensing representations | No country/asset/service promotion before applicable approval |

This worksheet is a required product control, not a legal conclusion that every row requires a license. Its purpose is to stop the company from relying on the most favorable description while performing a different activity.

### Geography and entity worksheet

Document the developer's residence, entity formation and management location, employees/contractors, infrastructure, signers/watchers, customers and targeting, counterparties, app stores, marketing channels, payment/fee flow, and contract terms. A country selector, foreign company, server location, or “not intended for residents” sentence is not treated as a complete legal solution.

For every financial adapter, counsel must review whether TGP merely publishes software or also makes introductions, controls rules/fees, maintains necessary infrastructure, actively facilitates transactions, or has ongoing intervention power. Singapore explicitly includes actively facilitating DPT buying/selling without possession in its stated DPT service types, illustrating why custody alone is not a universal dividing line ([MAS payment-service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)).

## Country and regional restrictions

### United States federal and Washington

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Federal own-use wallet versus service | FinCEN's guidance distinguishes unhosted own-use wallet activity from money transmission and distinguishes providers of anonymizing software from an anonymizing service that accepts/retransmits value; actual business activity matters ([FinCEN 2019 guidance](https://www.fincen.gov/system/files/2019-05/FinCEN%20Guidance%20CVC%20FINAL%20508.pdf)). | Obtain a written analysis of each actual role. Keep local wallet/chat architecture separate; do not assume every swap/router/coordinator is exempt. |
| State licensing | Washington prohibits engaging in, advertising, soliciting, or holding oneself out as providing the business of money transmission without the stated license/delegate status or applicable statutory exclusion ([RCW 19.230.030](https://app.leg.wa.gov/rcw/default.aspx?cite=19.230.030)). | Review the Washington-based founder/entity and offered activities before launch; no “licensed” or “exempt” claim without basis. |
| Washington virtual currency | DFI's interpretive statement addresses virtual-currency transmission/exchange and how actual control/settlement/software roles affect analysis ([Washington DFI interpretive statement](https://dfi.wa.gov/sites/default/files/virtual-currency-money-transmission-laws.pdf)). | Federal analysis does not replace state analysis. If a license is necessary and incompatible with product invariants, do not perform the regulated activity. |
| Sanctions | OFAC states virtual- and fiat-currency obligations are the same for covered persons, including prohibited dealings, relevant blocked property, and sanctions evasion; compliance programs should be tailored to actual risk and role ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)). | Counsel designs the lawful role-specific approach. Local provenance tags and a user declaration are not presented as sanctions compliance. |
| Criminal conduct and intent | DOJ's Samourai sentencing announcement describes a criminal money-transmitting conspiracy involving operators and their conduct; it does not establish that every privacy-software author or every private user commits a crime ([DOJ Samourai announcement](https://www.justice.gov/usao-sdny/pr/founders-samourai-wallet-cryptocurrency-mixing-service-sentenced-five-and-four-years)). | Do not operate or knowingly support unlawful money laundering, sanctions evasion, or an unlawful transmission business; no “clean funds” or criminal-evasion marketing. |
| Enforcement policy is not immunity | DOJ's August 2025 remarks describe a stated charging policy for certain truly decentralized noncustodial peer-to-peer software situations, while preserving other possible criminal theories; an enforcement speech is not statutory immunity ([DOJ policy remarks](https://justice.gov/opa/speech/acting-assistant-attorney-general-matthew-r-galeotti-delivers-remarks-american)). | Do not rely on the speech as a permanent safe harbor. Counsel reviews statutes, cases, actual operations, and subsequent changes. |
| Tornado Cash | Treasury announced the removal of Tornado Cash economic sanctions in March 2025; that announcement is not a blanket clearance for every mixing service, transaction, operator, or criminal conduct ([Treasury announcement](https://home.treasury.gov/news/press-releases/sb0057)). | Do not display “Treasury approved mixers” or infer general legality from delisting. |

The baseline TGP scope excludes a fiat exchange, TGP liquidity provider, mixer coordinator, custodial wallet, pooled treasury, brokerage, and payment-percentage business. Those exclusions reduce product scope; only qualified counsel can determine their legal effect for the implemented facts.

Washington is especially relevant to the founder's stated location, but no survey of all US states is provided. Nationwide targeting requires an appropriately scoped state-by-state analysis rather than extrapolating from one state.

### European Union and EEA targeting

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| MiCA software distinction | MiCA recital 83 distinguishes providers of hardware/software for non-custodial wallets from regulated custody; Article 59 sets the authorization rule for cryptoasset services in the Union ([MiCA](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng)). | Analyze exact services, not merely the app's name. No CASP/exemption claim without advice on the actual activity. |
| Decentralization | MiCA discusses services provided in a fully decentralized manner without an intermediary, but partially decentralized or controlled arrangements are not automatically outside scope ([MiCA recital 22](https://eur-lex.europa.eu/eli/reg/2023/1114/oj/eng)). | A TGP-controlled interface, router, operation or intermediary role needs review; no blanket “DeFi exempt” language. |
| Anonymity-related accounts | AMLR Article 79 prohibits specified regulated institutions/CASPs from keeping anonymous accounts or accounts allowing anonymization/increased obfuscation of holders/transactions, including anonymity-enhancing coins; recital 160 distinguishes self-hosted hardware/software providers without access/control ([Regulation (EU) 2024/1624](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)). | Do not claim a blanket EU ban on private possession/self-hosted software; do not assume a regulated TGP service could ignore Article 79. |
| Date | The regulation generally applies from 10 July 2027 under Article 90, subject to its specified exceptions ([AMLR Article 90](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng)). | Review the coming change before any service extending into that period; do not describe it as already universally operative in November 2026. |
| Privacy law | GDPR addresses territorial scope, data minimization, privacy by design/default, and security of processing in Articles 3, 5, 25 and 32 ([GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)). | Counsel maps roles for relays, notifications, support, billing, studies and incident handling; E2EE does not remove those business-data questions. |

Member-state implementation, other financial rules, consumer/tax law, and non-EU EEA treatment require specific review. “Available in Europe” is too broad to serve as a launch approval.

### United Kingdom

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| In-scope UK business | FCA guidance addresses registration for in-scope cryptoasset exchange, arranging-exchange and custodian activity by way of business in the UK; it distinguishes overseas firms merely serving UK customers from actual UK business presence/activity ([FCA perimeter guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Review entity/presence/activity before operating a swap or exchange-adjacent service. Do not claim every overseas app automatically needs the same registration. |
| Promotions | The FCA separately states the cryptoasset financial-promotions regime can apply to firms marketing to UK consumers regardless of where the firm is based ([FCA guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Review store copy, website, tutorials, referral links, invitations, and asset/tool recommendations for promotion implications. |
| Changing regime | FCA guidance describes a transition to a new cryptoasset regime; requirements must be reviewed for the actual launch date rather than frozen from an older app policy ([FCA guidance](https://www.fca.org.uk/firms/cryptoassets/who-needs-register)). | Legal approval has a review/expiry trigger; do not label the app “UK compliant” indefinitely. |

No claim is made here that all private wallet use or privacy coins are illegal in the UK. TGP must resolve the activity and promotion perimeter before offering financial tools in a UK-targeted distribution.

### Mainland China

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Virtual-currency business | The 2021 official notice classifies specified fiat-to-virtual-currency, virtual-to-virtual-currency, central-counterparty, trading-information/pricing, token and derivative-related business activities as illegal financial activities ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html)). | Do not offer TGP exchange/swap/discovery/pricing service functionality targeting mainland residents without a qualified opinion establishing a lawful permitted scope. |
| Overseas service/support | The notice addresses overseas exchanges serving mainland residents and specified knowing support; it cannot be reduced to “our server is abroad” ([PBOC notice](http://www.pbc.gov.cn/en/3688253/3689012/4353814/index.html)). | Analyze targeting and support/integration roles, not just entity/server location. No bypass guide or false-residency workflow. |
| Continuing policy | A 2025 PBOC interdepartmental meeting reaffirmed the restrictive approach to virtual-currency trading/speculation ([PBOC 2025 statement](https://www.pbc.gov.cn/en/3688110/3688172/5552468/2025121116132332435/index.html)). | Treat financial-service launch as blocked pending local counsel; do not imply an old notice is obsolete merely because software is decentralized. |

These materials do not establish a blanket rule that every private holder, every encrypted chat, or every line of wallet source code is illegal. Mainland encryption, app/network distribution, telecom and personal-use questions are not comprehensively reviewed here; Hong Kong and Macao are not cleared by this mainland analysis.

### India

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| VDA provider scope | FIU-IND's registration material describes business activities for/on behalf of another including fiat/VDA exchange, VDA/VDA exchange, transfers, safekeeping/control and specified issuer-related financial services ([FIU-IND registration material, 15 September 2025](https://fiuindia.gov.in/pdfs/downloads/VDASP15092025.pdf)). | Classify each exact operation; no blanket claim that local wallet code alone is a registered service or that all noncustodial facilitation is exempt. |
| Registration/compliance | The material describes registration as a prerequisite for covered VDA service-provider activity and associated compliance processes ([FIU-IND material](https://fiuindia.gov.in/pdfs/downloads/VDASP15092025.pdf)). | Do not start an in-scope service without required approval/process. If obligations conflict with invariants, withhold the service rather than add covert KYC/logging. |
| Privacy tools: unresolved scope | An updated January 2026 guideline document was located, but the retrieved portion did not establish the substantive clauses concerning anonymity-enhancing coins and mixers ([FIU-IND January 2026 guidelines](https://fiuindia.gov.in/pdfs/downloads/VDA08012026.pdf)). | Specific India privacy-tool approval remains unresolved. Do not invent a blanket coin/mixer ban or a permission from a table of contents. |

India's financial launch decision therefore requires full current text and local advice, especially for transfer/arranging/privacy-tool features. This section does not say that every individual holding cryptocurrency is acting illegally.

### Singapore

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| Broad DPT activity scope | MAS lists buying/selling, exchange platforms, transmitting/arranging transmission, custody, and actively facilitating buying/selling without possession as DPT service types ([MAS service types](https://www.mas.gov.sg/regulation/payments/licensing-for-payment-service-providers/types-of-payment-services)). | A no-custody label alone is insufficient; analyze exact interface, matching, routing and ongoing operation. |
| Payment licensing | MAS licensing FAQs explain licensing/exemption requirements for covered payment services and distinguish service types ([MAS licensing FAQs](https://www.mas.gov.sg/contact-us/faqs/payments-faqs/payments-service-licensing-faqs)). | No in-scope service without the applicable license/exemption and compatible operating controls. |
| Overseas-only customers | MAS states that from 30 June 2025, relevant Singapore-based digital-token service providers serving only overseas customers require a license and that MAS generally will not issue such licenses under the described regime ([MAS clarification](https://www.mas.gov.sg/news/media-releases/2025/mas-clarifies-regulatory-regime-for-digital-token-service-providers)). | Forming/operating there while excluding local users is not an assumed workaround. Review developer/entity/watchtower/coordinator location and activity. |

Do not infer that every Singapore user is prohibited from using a local wallet. The relevant question for TGP is whether its implemented activity is a regulated service and can be offered lawfully without violating the privacy contract.

### Dubai / UAE: preserve the territorial distinction

| Topic | Verified legal issue | TGP handling |
|---|---|---|
| VARA territory | The defined Emirate covers Dubai's specified zones/free zones but excludes the Dubai International Financial Centre ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Do not relabel a VARA rule as a complete all-UAE/DIFC legal opinion. |
| Anonymity-enhanced assets | VARA prohibits issuance of anonymity-enhanced cryptocurrencies and all covered VA activities related to them in the Emirate; the definition concerns assets preventing transaction/ownership tracing for which the VASP has no mitigating mechanism ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Block TGP provider activity involving that category in the relevant scope unless counsel establishes an actually lawful different classification. Do not weaken privacy to make an asset traceable. |
| Business licensing | VARA prohibits covered VA activity by way of business without authorization/license or a stated exception ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Obtain specific provider/activity advice; no “software, therefore exempt” assumption. |
| Marketing | VARA's marketing rules address virtual-asset/VA-activity marketing in or targeting the UAE and expressly restrict anonymity-enhanced-asset marketing in the stated Emirate scope ([VARA regulations](https://rulebooks.vara.ae/entiresection/437)). | Review websites, store descriptions, tutorials, influencer/referral content and educational materials in context; do not treat a “not advice” footer as approval. |

The retrieved rules do not establish a blanket prohibition on all private possession or use throughout the UAE. Other emirates, DIFC and federal frameworks remain separate unreviewed questions rather than automatically permitted alternatives.

### All other jurisdictions

Financial-service launch remains unapproved until the actual target jurisdiction, entity, activity, asset, distribution and marketing scope is reviewed. That is a TGP conservative release policy, not a claim that every unreviewed country bans the software.

Encryption/telecom/network-use rules, asset restrictions, licensing, sanctions, privacy, consumer, tax and app-store treatment must be checked locally. Do not publish a global green/red map based only on these eight regional issue summaries.

## Sanctions and prohibited conduct

### No evasion product positioning

Do not market TGP as a way to evade sanctions, launder proceeds, defeat court orders, hide criminal conduct, or make funds “clean.” OFAC explicitly addresses evasion and prohibited support as well as digital-currency dealings; an encrypted interface does not change those stated obligations for covered persons ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)).

This does not equate privacy with criminality. The product can minimize unnecessary surveillance while refusing to undertake an unlawful operator role; the implementation and marketing must maintain that distinction.

### Role-specific compliance, not a universal surveillance switch

Counsel must determine whether TGP has any applicable blocking, reporting, screening, licensing or records obligation for each role and geography. OFAC recommends tailored risk-based programs and does not describe one single program as suitable for every circumstance ([OFAC FAQ 560](https://ofac.treasury.gov/faqs/560)).

Do not pretend that a local “I am allowed” checkbox, no-fee model, source label, sanctioned-address list, country selector, or Tor routing is sufficient compliance. Conversely, do not implement a remote freeze or identity-logging mechanism into a noncustodial wallet without recognizing that it changes both the architecture and the privacy contract.

If a lawful required control cannot coexist with the contract, the affected operated service must not launch. Whether neutral source publication or a narrower software-only scope remains lawful is a separate counsel question, not a suggested workaround.

## Encryption export, software licenses, and app stores

### Encryption and export classification

US encryption-export treatment is artifact- and activity-specific; EAR §742.15 addresses publicly available encryption source code under specified conditions and notification for source providing/performing non-standard cryptography ([EAR §742.15](https://www.bis.gov/regulations/ear/742)). Do not recycle outdated blanket claims that every open-source encryption release must make identical notifications, or that every encrypted app is automatically outside export controls.

Have counsel classify source, binaries, embedded libraries, public availability, non-standard cryptography, commercial/service activity, destinations/end users and any applicable restrictions. TGP cannot inherit another project's classification merely because it uses the same library.

Do not publish masked or guessed compliance email addresses. A release checklist must use the current official regulation and verified agency instructions at the time of filing.

### Open-source and dependency obligations

libsignal's repository states AGPLv3 licensing and unsupported external use/API instability; SQLCipher's licensing material contains attribution/notice requirements ([libsignal](https://github.com/signalapp/libsignal), [SQLCipher licensing](https://www.zetetic.net/sqlcipher/license/)). Legal/release owners must review the actual dependency graph, linking/distribution/service model, notices, source-offer obligations where applicable, trademarks and maintenance plan.

Do not assume that putting only TGP's wrapper on GitHub satisfies every dependency obligation. Any required source or notices must correspond to the shipped artifacts and approved legal analysis.

### Store distribution

Apple's crypto rules address wallet developer organization status, exchange licensing and other crypto-specific restrictions; the exact app functionality and targeted regions matter ([Apple App Review Guidelines, §3.1.5](https://developer.apple.com/app-store/review/guidelines/)). Google states that noncustodial wallets are outside its named crypto exchange/software-wallet policy requirements, while other financial declarations and applicable-law duties still need consideration ([Google Play policy](https://support.google.com/googleplay/android-developer/answer/16329703)).

Store approval is not a legal license, and a lawful app is not guaranteed store approval. Direct signed distribution also does not erase export, local law, platform, security-update or consumer obligations.

## Privacy, data protection, consumer claims, and lawful requests

### Data map before policy writing

Document all actual data flows across relays, rendezvous, optional platform notices, stores, billing, support, researchers, hosting and release distribution. GDPR's minimization, privacy-by-design and security provisions are relevant where its scope applies; encrypted payloads do not eliminate the need to assess other personal data ([GDPR Articles 3, 5, 25 and 32](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)).

Create truthful notices for the actual build, not an aspirational “no data” policy. Retention claims must match host snapshots, dumps, support systems, logs and mandatory business records.

### Lawful requests and user safety

The lawful-process policy must distinguish data not held, data held temporarily, user-selected support exports, and separate business records. Do not promise to decrypt content the infrastructure cannot decrypt, or promise that legal process can never affect a company or a device.

Counsel handles validity, jurisdiction, scope, preservation, challenge and disclosure obligations. This specification does not design a covert backdoor or instruct the team to destroy evidence or defeat lawful process.

### Tax and records

Offer a deliberate local export of appropriate transaction records without contact labels by default. Obtain country-specific advice on tax/reporting/user-record requirements before describing obligations; this spec makes no universal tax-free or no-records claim.

Deleting a chat card, changing a label, moving funds, or using a privacy protocol must never be described as erasing legal, tax or accounting responsibilities. A user may need independently retained records even when chat details are minimized.

### Consumer-facing financial limits

Publish chain-specific irreversible-action, fee, delay, reorg, recovery, hardware, provider and swap risks. No yield, investment return, guaranteed refund, future price, universal settlement time, anonymity, evidentiary immunity, or regulatory approval is promised.

Promotional copy must go through the same claims and legal gates as technical UI. “Atomic,” “decentralized,” “non-custodial,” “open source,” and “privacy-preserving” cannot replace precise disclosure.

## Legal capability manifest

### Required decision record

```yaml
decision_id: unique-versioned-record
review_date: actual-date
review_expiry_or_trigger: counsel-defined
legal_entity: actual-entity-and-management-location
activity: exact-operation-not-just-wallet
capability:
  chain: exact-chain-and-network
  protocol: exact-engine-direction-version
  distribution: app-store-direct-source-service
  custody_and_control: exact-keys-signers-coordination-and-fees
jurisdictions:
  operator: reviewed-locations
  infrastructure: reviewed-locations
  targeted_users: reviewed-locations
  marketing: reviewed-channels-and-targeting
authority:
  statutes_rules_guidance: actual-urls-and-effective-dates
  counsel: named-qualified-reviewer
  written_opinion: controlled-document-reference
classification: software-only-or-exact-regulated-role-or-unresolved
requirements: exact-licenses-disclosures-controls-retention-and-exceptions
privacy_compatibility: approved-or-conflict-or-unresolved
new_operations: approved-or-blocked
existing_operation_recovery: exact-lawful-safe-plan
approvers: actual-named-owners
```

This is a schema example, not a completed legal approval. Placeholder strings in it must never be mistaken for a valid manifest or shipped in place of counsel's decision.

### Capability decision process

1. Identify exact actors, keys/control, infrastructure, funds flow, fees, geography, targeting and marketing.
2. Obtain qualified advice using current primary materials and actual implementation facts.
3. Identify licenses, registrations, prohibited activities, disclosures, records and other required controls.
4. Compare those controls with every privacy invariant and eight-dimension baseline.
5. If compatible, implement and verify the approved narrow scope.
6. If incompatible or unresolved, block the new financial/service operation and document why.
7. Recheck after legal, entity, activity, asset, protocol, fee, infrastructure, marketing or targeting changes.

Local country selection can help show information, but does not establish residence, sanctions status, territorial targeting or legal compliance. Any necessary distribution or service restriction must be designed lawfully, tested, and transparent without covert data collection or advice to falsify location.

### Existing-operation retirement

Do not remotely delete seeds, block necessary local export, remove an active swap's recovery journal, or strand a required refund action merely because an adapter is retired or a new-operation region policy changes. Counsel and security must define the exact lawful preservation/recovery path, including situations where a particular transaction itself cannot legally proceed.

The app must distinguish “new operations unavailable” from “recovery information retained.” It cannot promise a legal exception for every recovery payment or perform a prohibited transaction under the label of safety.

## Legal risk register

These are severity-oriented launch issues, not quantified predictions of enforcement. Likelihood and legal outcome depend on facts and qualified analysis not established here.

| Risk | Product severity | Required mitigation / release rule |
|---|---|---|
| Unlicensed financial service | Launch-blocking | Written role/country classification and required authorization or no service |
| Prohibited anonymity-enhanced-asset activity | Launch-blocking in applicable scope | Exact territory/asset/activity review; no weakening privacy to fit a prohibited provider model |
| Sanctions/prohibited support | Launch-blocking | Actual role-specific lawful controls; no evasion positioning |
| Incorrect “noncustodial exemption” | High | Control/arranging/facilitation analysis, not seed-possession test alone |
| Criminal-purpose marketing or knowing unlawful assistance | High | Refuse unlawful operator role; review promotions and support conduct |
| Financial-promotion breach | High | Targeted-channel/region review before publication |
| Export/encryption mistake | High | Artifact classification/current filing/destination analysis |
| Privacy/retention mismatch | High | Actual data map, deployment evidence, truthful notice and compatible duties |
| Unsupported audit/privacy/evidence claim | High | Claim-specific evidence; remove absolute language |
| App-store rejection | Material distribution risk | Exact regional policy review; no assumption approval substitutes for law |
| Dependency/license violation | High | Artifact-level dependency/notice/source review |
| User loss from misunderstood recovery/swap | High | Tested recovery, exact risk copy and no guarantee |
| Stale legal opinion | High | Versioned approval, expiry/triggers, new-operation disable policy |
| Overbroad geo/personal-data collection | High privacy risk | Minimum lawful transparent mechanism or do not offer service |

## Required launch checklist

- **Entity and geography:** Confirm actual entity, management/developer locations, infrastructure, target users and marketing channels.
- **Washington and federal US:** Obtain a written money-transmission/service, sanctions, export and operational assessment for the implemented role.
- **Each financial region:** Review provider scope, asset restrictions, promotions, required licenses/registrations and dates.
- **Each adapter:** Review the exact engine, direction, key/control authority, counterparties, fees, deadlines and ongoing operations.
- **Each distribution channel:** Review source/binary export, store category, developer entity and local availability.
- **Privacy and security:** Reconcile required legal/business records with the data map; no hidden expansion of collection.
- **Policies:** Publish accurate privacy, terms, lawful-process, security disclosure, abuse/support, financial-risk, retention, export and license materials.
- **User records:** Offer deliberate local transaction export and explain that card minimization does not remove legal obligations.
- **Research and support:** Separate consent, recipient and retention; no seeds or default contact/payment graph.
- **Incident and retirement:** Preserve lawful safe recovery without enabling prohibited new operations or covert remote control.
- **Approval:** Named qualified counsel, security, product, platform, operations and release owners sign the exact scope.

## Final legal launch rule

TGP must not claim worldwide legality, universal anonymity, financial-service exemption, or immunity from evidence or enforcement. Where current law, platform policy, or required controls conflict with the binding privacy contract, do not launch the conflicting capability in that scope; narrow the lawful activity, obtain the necessary approval where possible, or leave the feature unavailable.

This last section is a release gate, not a disclaimer that transfers all responsibility to the user. The financial tools remain optional, separately qualified, and unavailable wherever the actual legal and privacy requirements cannot both be met.
