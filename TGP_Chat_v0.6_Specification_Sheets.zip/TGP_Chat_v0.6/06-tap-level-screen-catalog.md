# TGP Chat v0.6: Tap-Level Screen Catalog

This catalog defines the product-owned screens, sheets, controls, and negative states for the first thirty days, including optional and advanced branches. It is a design contract rather than implemented UI; disabled experimental records do not imply those features are available.

Every record inherits the universal state, interruption, accessibility, and transport rules in the UI-system volume. Back, Close, outside-tap, system Back, Escape, keyboard equivalents, and swipe behavior are explicitly constrained below; additional implementation controls require a catalog update.

## Catalog conventions

- **Activation:** Every named control has its specified effect; no other effect is implied. Text entry is local until the explicit submit action.
- **Back and gestures:** Back/Close/Escape returns without granting authority; sensitive review sheets do not dismiss on outside tap. A safe draft may be kept/discarded explicitly. Swipes never sign, spend, export, enroll, or destroy.
- **States:** Each record lists its distinctive states; all also implement empty/loading/offline/locked/error/partial/unsupported/cancelled according to the shared contract.
- **Accessibility:** All records require large text without clipped warnings, labeled controls, visible focus, keyboard/screen-reader parity, non-color status, reduced motion, and accessible alternatives to camera-only ceremonies.
- **Exact copy:** Quoted strings are normative English direction; localization must preserve certainty, scope, and authority. Dynamic names/amounts are escaped, not interpreted as markup.
- **Tests:** Each listed negative criterion supplements the shared Given/When/Then screen tests; no screen is validated merely because its record exists.

## Screen index

| ID | Screen | Availability |
|---|---|---|
| O-01 | Download and installation boundary | Core |
| O-02 | Welcome and concise limits | Core |
| O-03 | Optional display name | Core |
| O-04 | Local protection setup | Core |
| O-05 | Preparing protected connection | Core |
| O-06 | Empty Chats | Core |
| O-07 | Three things to try tutorial | Core |
| O-08 | Contextual permission rationale | Core |
| C-01 | Connect chooser | Core unless marked |
| C-02 | Show one-use contact QR | Core unless marked |
| C-03 | Typed QR scanner and import preview | Core unless marked |
| C-04 | Create remote invitation | Core unless marked |
| C-05 | Enter link and secret | Core unless marked |
| C-06 | Contact/session confirmation | Core unless marked |
| C-07 | Canonical identity comparison | Core unless marked |
| C-08 | Contact details | Core unless marked |
| C-09 | Local label and per-contact presentation | Core unless marked |
| C-10 | Advanced contact link and card | Core unless marked |
| C-11 | Block contact confirmation | Core unless marked |
| M-01 | Conversation timeline and composer | Core |
| M-02 | Chats list and filters | Core |
| M-03 | Message action sheet | Core |
| M-04 | Edit or reply draft | Core |
| M-05 | Reaction picker | Core |
| M-06 | Delivery and event details | Core |
| M-07 | Local search | Core |
| M-08 | Local organization actions | Core |
| M-09 | Delete and requested deletion | Core |
| M-10 | External URL boundary | Core |
| M-11 | Unsupported message or security profile | Core |
| A-01 | Attachment chooser | Collaboration, gated |
| A-02 | Sanitized image preview | Collaboration, gated |
| A-03 | Document/original-file disclosure | Collaboration, gated |
| A-04 | Voice note recording and preview | Collaboration, gated |
| A-05 | Received media viewer and shared media | Collaboration, gated |
| A-06 | Video preparation and preview | Collaboration, gated |
| A-07 | Attachment transfer status | Collaboration, gated |
| A-08 | External blob storage unavailable | Collaboration, gated |
| G-01 | Select group contacts | Collaboration, gated |
| G-02 | Review group and policy | Collaboration, gated |
| G-03 | Invitation and admission progress | Collaboration, gated |
| G-04 | Incoming group invitation review | Collaboration, gated |
| G-05 | Joining group | Collaboration, gated |
| G-06 | Group details | Collaboration, gated |
| G-07 | Members and endpoints | Collaboration, gated |
| G-08 | Group policy and role review | Collaboration, gated |
| G-09 | Remove person or device | Collaboration, gated |
| G-10 | Leave group | Collaboration, gated |
| G-11 | Large group/community unavailable | Collaboration, gated |
| G-12 | Share selected earlier group history | Collaboration, gated |
| D-01 | Device inventory | Collaboration, gated |
| D-02 | Link-device ceremony start | Collaboration, gated |
| D-03 | Compare both devices | Collaboration, gated |
| D-04 | Select conversation grants | Collaboration, gated |
| D-05 | Choose history and review access | Collaboration, gated |
| D-06 | Linking and history transfer progress | Collaboration, gated |
| D-07 | Desktop companion workspace | Collaboration, gated |
| S-01 | Security and Vault hub | Core unless marked |
| S-02 | App locked / panic result | Core unless marked |
| S-03 | App passphrase and inactivity policy | Core unless marked |
| S-04 | Create/change per-chat vault | Core unless marked |
| S-05 | Unlock one chat | Core unless marked |
| S-06 | Disappearing message policy | Core unless marked |
| S-07 | Capture and clipboard controls | Core unless marked |
| S-08 | Advanced local concealment and destructive controls | Core unless marked |
| S-09 | Delete local profile review | Core unless marked |
| S-10 | Read, typing, and availability signals | Core unless marked |
| B-01 | Backup and Restore hub | Core/optional by archive type |
| B-02 | Select chat archive content | Core/optional by archive type |
| B-03 | Archive passphrase and review | Core/optional by archive type |
| B-04 | Choose encrypted archive destination | Core/optional by archive type |
| B-05 | Archive export result | Core/optional by archive type |
| B-06 | Select and unlock chat archive | Core/optional by archive type |
| B-07 | Review archive restore | Core/optional by archive type |
| B-08 | Non-authoritative chat recovery drill | Core/optional by archive type |
| B-09 | Separate wallet backup | Core/optional by archive type |
| B-10 | Wallet no-spend recovery drill | Core/optional by archive type |
| B-11 | Multisig and social recovery study | Core/optional by archive type |
| N-01 | Connection status | Core/Advanced |
| N-02 | Connection assistance | Core/Advanced |
| N-03 | Bridge configuration import | Core/Advanced |
| N-04 | Message relay directory and BYO | Core/Advanced |
| N-05 | Endpoint review and test | Core/Advanced |
| N-06 | Advanced traffic profile | Core/Advanced |
| N-07 | Volunteer proxy and device VPN experiments | Core/Advanced |
| N-08 | Nearby/offline radio experiment | Core/Advanced |
| H-01 | You hub | Core/Advanced |
| H-02 | Notification availability choice | Core/Advanced |
| H-03 | Local Privacy Report | Core/Advanced |
| H-04 | Help and troubleshooting | Core/Advanced |
| H-05 | Diagnostic/report preview | Core/Advanced |
| H-06 | Support export/handoff result | Core/Advanced |
| H-07 | Tutorial and local hints settings | Core/Advanced |
| H-08 | About, licenses, and build evidence | Core/Advanced |
| H-09 | Update review and rollback protection | Core/Advanced |
| H-10 | Advanced hub | Core/Advanced |
| H-11 | Legal availability and user obligations | Core/Advanced |
| H-12 | Funding without chat identity | Core/Advanced |
| H-13 | Consented research and feedback | Core/Advanced |
| H-14 | Security incident notice | Core/Advanced |
| W-01 | Activate optional wallet | Optional, platform/chain gated |
| W-02 | Choose create, connect, or restore | Optional, platform/chain gated |
| W-03 | Existing wallet connection method | Optional, platform/chain gated |
| W-04 | Hardware connection and policy review | Optional, platform/chain gated |
| W-05 | Watch-only import preview | Optional, platform/chain gated |
| W-06 | Provenance and management-only quarantine | Optional, platform/chain gated |
| W-07 | Chain node and privacy profile | Optional, platform/chain gated |
| W-08 | Wallet synchronization | Optional, platform/chain gated |
| W-09 | Wallet home | Optional, platform/chain gated |
| W-10 | Receive address and request context | Optional, platform/chain gated |
| W-11 | Create new wallet and recovery preparation | Optional, platform/chain gated |
| W-12 | Restore wallet recovery | Optional, platform/chain gated |
| W-13 | Wallet settings and source labels | Optional, platform/chain gated |
| W-14 | Offline signing transfer | Optional, platform/chain gated |
| W-15 | Optional fiat estimates | Optional, platform/chain gated |
| W-16 | Silent and stealth receiving experiments | Optional, platform/chain gated |
| P-01 | Create one-to-one payment request | Optional, eligibility gated |
| P-02 | Incoming request card and details | Optional, eligibility gated |
| P-03 | Select payer wallet and amount | Optional, eligibility gated |
| P-04 | Exact payment review | Optional, eligibility gated |
| P-05 | Separate wallet authorization | Optional, eligibility gated |
| P-06 | Hardware or air-gapped signature return | Optional, eligibility gated |
| P-07 | Signed/ready/broadcast decision | Optional, eligibility gated |
| P-08 | Payment progress and chain observation | Optional, eligibility gated |
| P-09 | History and transaction detail | Optional, eligibility gated |
| P-10 | Delay or schedule payment | Optional, eligibility gated |
| P-11 | Spend guardrails | Optional, eligibility gated |
| P-12 | Payjoin negotiation review | Optional, eligibility gated |
| X-01 | Financial tools catalog | Experimental/deferred; mainnet disabled |
| X-02 | Adapter manifest review | Experimental/deferred; mainnet disabled |
| X-03 | Contact swap offer | Experimental/deferred; mainnet disabled |
| X-04 | Swap financial and deadline review | Experimental/deferred; mainnet disabled |
| X-05 | Active swap and recovery | Experimental/deferred; mainnet disabled |
| X-06 | External tool export/import | Experimental/deferred; mainnet disabled |
| R-01 | Contact key changed | Core/Advanced |
| R-02 | New endpoint approval | Core/Advanced |
| R-03 | Revoke lost device | Core/Advanced |
| R-04 | Controller migration | Core/Advanced |
| R-05 | Controller lost | Core/Advanced |
| R-06 | Group or authority conflict | Core/Advanced |
| R-07 | Continuity archive experiment | Core/Advanced |
| L-01 | Pre-call or unavailable call | Experimental; disabled until qualified |
| L-02 | Incoming call and endpoint selection | Experimental; disabled until qualified |
| L-03 | Live call, rekey, and handoff | Experimental; disabled until qualified |
| L-04 | Call ended or failed | Experimental; disabled until qualified |

## Day 0: onboarding

### O-01: Download and installation boundary

| Record field | Required behavior |
|---|---|
| Entry points | Official distribution page/store before first launch. |
| Layout and elements | Supported platforms; signed artifact/version; verify instructions; store and direct download choices. |
| Every control activation | Platform → show matching artifact; Download → chosen supported distribution; Verify → H-08 instructions; Help → H-04. |
| Distinctive states | Unavailable platform: no fake download; interrupted download: platform retry; not yet installed: no local identity. |
| Exact copy | “Install a supported signed build. A matching hash does not prove your device is uncompromised.” |
| Data read / written | No profile exists. Distribution may expose platform/store account, IP and download activity. |
| Network calls | Distribution is browser/store-controlled, not claimed to pass through the app broker. |
| Cryptographic operations | Artifact signature/digest verified by platform or independent instructions; no messaging keys. |
| Disclosure-ledger effect | Store/website sees distribution metadata; no registration or contact graph. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wrong-platform artifact cannot be presented as supported; verification instructions name exact version/digest. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-02: Welcome and concise limits

| Record field | Required behavior |
|---|---|
| Entry points | First launch after install or confirmed local reset. |
| Layout and elements | Product promise; three concise boundaries; Start; Restore; About. |
| Every control activation | Start → O-03; Restore → B-06; About → H-08; limits row → expanded local explanation. |
| Distinctive states | No permissions requested; offline: all copy works; restored draft setup: Resume label; unsupported OS: block before key creation. |
| Exact copy | “Private conversations without phone-number registration. Recipients can still copy what you send.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: First-launch capture has no account, analytics, contact, wallet, or price request. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-03: Optional display name

| Record field | Required behavior |
|---|---|
| Entry points | O-02 Start. |
| Layout and elements | Optional name field; local-avatar placeholder; Continue; Skip; explanatory label. |
| Every control activation | Name field → local keyboard; Continue → validate bounds then O-04; Skip → empty optional name then O-04; avatar → local picker preview, no automatic upload. |
| Distinctive states | Empty accepted; overlength/control-character input gets field error; offline unchanged; interrupted setup keeps protected draft. |
| Exact copy | “This is a display name, not a public username. You can use a different name with each contact.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate and empty names work without remote availability lookup; Unicode bounds do not corrupt layout. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-04: Local protection setup

| Record field | Required behavior |
|---|---|
| Entry points | O-03 Continue/Skip. |
| Layout and elements | Device-protection availability; app-lock choice; passphrase option; Continue; details. |
| Every control activation | Use device protection → native protected setup; Add app passphrase → S-03; Continue → O-05 only after required protection; Details → local capability explanation. |
| Distinctive states | No hardware feature: honest capability message; no device lock: explain approved alternative; cancellation returns without half-created identity. |
| Exact copy | “App lock protects entry to TGP. Chat vaults and wallet authorization are separate.” |
| Data read / written | Write local protection configuration and wrapped keys only after successful setup. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Biometric cancellation cannot mark setup successful; no silent insecure-key fallback. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-05: Preparing protected connection

| Record field | Required behavior |
|---|---|
| Entry points | Protection succeeds; may overlap safe setup work. |
| Layout and elements | Separate Key preparation and Protected connection progress; Continue locally; Connection help. |
| Every control activation | Continue locally → O-06 with offline banner; Help → N-02; Cancel route attempt → local mode, not identity deletion. |
| Distinctive states | Key failure blocks contact creation; Tor failure permits local UI; progress is stage-based, not fabricated countdown. |
| Exact copy | “Preparing your device and protected connection. Nothing will be sent directly if the route fails.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | Explicit approved Tor/bootstrap/PT activity only; no external IP test. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Keygen and route status remain separate; route loss never shows green from Wi-Fi connectivity. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-06: Empty Chats

| Record field | Required behavior |
|---|---|
| Entry points | Setup complete; no conversations. |
| Layout and elements | Chats/You tabs; Search; +; Connect call-to-action; optional three-task checklist. |
| Every control activation | Connect or + → C-01; Search → M-07 empty state; You → H-01; Try checklist → O-07; dismiss hint → local preference. |
| Distinctive states | Offline: Connect explains queued ceremony limits; locked app: S-02; no fake sample chats or unread counts. |
| Exact copy | “Connect with your first contact. No address-book access is needed.” |
| Data read / written | Local profile/settings store; no provider account. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet tab is absent before activation and checklist dismissal creates no network request. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-07: Three things to try tutorial

| Record field | Required behavior |
|---|---|
| Entry points | Empty Chats hint or H-07. |
| Layout and elements | Connect a contact; Compare identity; Send a message; progress; dismiss/reset. |
| Every control activation | Task → matching safe screen; Dismiss → prior screen and local hide; Reset → local unchecked state; Close → prior screen. |
| Distinctive states | Incomplete stays local; offline tasks can explain next step; no forced slideshow; security warning always above hints. |
| Exact copy | “These tips stay on this device. You can skip them.” |
| Data read / written | Only local checklist completion/hide state; no behavior event upload. |
| Network calls | No network unless a control explicitly starts approved Tor bootstrap. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tutorial cannot mark comparison complete or bypass any identity ceremony. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |

### O-08: Contextual permission rationale

| Record field | Required behavior |
|---|---|
| Entry points | First camera/microphone/photo/notification action. |
| Layout and elements | One permission purpose; Allow; Not now; alternative path. |
| Every control activation | Allow → OS permission dialog; Not now → parent unchanged; Enter manually → typed invite where applicable; Open settings only after explicit tap. |
| Distinctive states | Denied/permanently denied/revoked are distinct; app resume rechecks permission; no repeating prompt loop. |
| Exact copy | “Use the camera to scan this code. You can enter an invitation manually instead.” |
| Data read / written | Permission state only; no permission grants inferred from previous attempt. |
| Network calls | No network solely for permission rationale. |
| Cryptographic operations | OS entropy and protected key creation only after prerequisites; no wallet keys. |
| Disclosure-ledger effect | No registration identity, public lookup, contacts access, or analytics. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Deny camera and complete a manual invite path; mic denial leaves text available. |
| Traceability / release scope | T-01; AUD-01; feature coverage F-001,F-002,F-004,F-015; Core. Required evidence absent initially. |


## Contacts and verification

### C-01: Connect chooser

| Record field | Required behavior |
|---|---|
| Entry points | Chats + → Connect, or empty Chats. |
| Layout and elements | Scan QR; Show my QR; Remote invite; Back. |
| Every control activation | Scan → C-03; Show mine → C-02; Remote invite → C-04; Back → Chats. |
| Distinctive states | Offline: show what can be prepared locally; current invite active: show resume/replace; locked profile: unlock first. |
| Exact copy | “Choose how to connect. Remote links are not an independent identity comparison.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Scanner route is typed and cannot turn a wallet QR into an enrollment grant. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-02: Show one-use contact QR

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Show mine. |
| Layout and elements | QR, expiry, one-use label, Regenerate, Cancel invite, remote alternative. |
| Every control activation | Regenerate → invalidate old then new QR; Cancel invite → burn local state and close; Remote alternative → C-04; received claim → C-06 review. |
| Distinctive states | Expired/burned/claimed: QR unavailable; offline: no claim of discoverability; parallel claimant: review conflict. |
| Exact copy | “One use. Expires in 10 minutes. Show this in person only if you intend to compare this key.” |
| Data read / written | Ephemeral invite, nonce/expiry and persistent used/burned marker; no global name record. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Old QR, replay, simultaneous claim and crash cannot create a second relationship. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-03: Typed QR scanner and import preview

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Scan or authorized pairing/financial scanner. |
| Layout and elements | Camera frame, torch if supported, Enter manually, selected import type, Cancel. |
| Every control activation | Torch → local camera setting; Manual → C-05; scan → typed preview only; Confirm contact QR → C-06; wrong QR type → explanatory route chooser, no action. |
| Distinctive states | Permission denied → O-08/manual; malformed/oversize → reject; camera interruption stops capture; no automatic URL launch. |
| Exact copy | “Review this code before continuing. Scanning does not authorize a payment or device.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receive-address, transaction, config and pairing QR cannot be accepted as a contact invitation. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-04: Create remote invitation

| Record field | Required behavior |
|---|---|
| Entry points | C-01 Remote invite. |
| Layout and elements | Link panel, separate secret panel, expiry, Create, Copy link, Reveal secret, Cancel. |
| Every control activation | Create → reviewed one-use ceremony material; Copy link → copy only link with warning; Reveal secret → protected display; Cancel → burn; Done → wait state. |
| Distinctive states | Do not expose both pieces through one default share action; expired/wrong attempt needs fresh invite; locked hides secret. |
| Exact copy | “Send the link and secret through separate trusted channels. This does not independently compare identity.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Chosen external channel may retain link/secret; TGP never assumes that channel is private. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: One wrong eligible guess burns attempt locally; copy/share excludes the separate secret. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-05: Enter link and secret

| Record field | Required behavior |
|---|---|
| Entry points | C-03 Manual or typed/deep-link preview. |
| Layout and elements | Link field; secret field with visibility toggle; Connect; Cancel. |
| Every control activation | Paste → validate type/length locally; Show secret → temporary reveal; Connect → C-06 after reviewed ceremony; Cancel → clear transient secret. |
| Distinctive states | Missing/malformed input: inline error; expired/used/burned: no retry with same invite; route unavailable: no direct fallback. |
| Exact copy | “A link alone is not enough. Ask the inviter for the separate secret.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Deep link cannot auto-submit, leak secret to clipboard/logs, or accept unknown protocol version. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-06: Contact/session confirmation

| Record field | Required behavior |
|---|---|
| Entry points | Valid QR or remote ceremony candidate. |
| Layout and elements | Peer presentation, comparison provenance, selected security profile, Accept, Decline, details. |
| Every control activation | Accept → persist scoped relationship/session then M-01; Decline → terminal invite cancellation; Details → C-07; in-person checkbox → provenance only after explicit physical-source confirmation. |
| Distinctive states | Changed transcript/profile/mismatch: stop; pending peer: show waiting; offline: no completed contact claim. |
| Exact copy | “Encrypted. Identity not independently compared.” / “Compared from this QR in person.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: A remote QR image cannot be marked in-person compared automatically. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-07: Canonical identity comparison

| Record field | Required behavior |
|---|---|
| Entry points | Contact details → Compare, or establishment review. |
| Layout and elements | Canonical numeric/word/QR representation; provenance; Match; Does not match; accessible text. |
| Every control activation | Show QR → canonical comparison QR; Match → explicit method confirmation then local record; Mismatch → pause scope and R-01; Close → no comparison upgrade. |
| Distinctive states | Key change invalidates old view; locked hides comparison data; transferred record labeled; no truncated short fingerprint. |
| Exact copy | “Compare through an independent trusted channel. Only confirm if the complete representation matches.” |
| Data read / written | Fingerprint, scope, comparison method/date and optional local note. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Stale comparison view cannot verify a new key; screen-reader path exposes full canonical data. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-08: Contact details

| Record field | Required behavior |
|---|---|
| Entry points | M-01 header. |
| Layout and elements | Local label, shared profile, trust provenance, Compare, devices, media, timer, lock, Pay/Request if eligible, Block, Delete. |
| Every control activation | Compare → C-07; Devices → R-02 scoped list; Media → A-05; Timer → S-06; Lock → S-04; Pay/Request → P-03/P-01; Block → C-11; Delete → M-09; Edit label → C-09. |
| Distinctive states | Locked: no private detail; incompatible/pending endpoints visible; financial actions absent/blocked by policy. |
| Exact copy | “These details apply to this relationship, not every device or conversation.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No full profile device inventory or wallet address is fetched merely by opening contact details. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-09: Local label and per-contact presentation

| Record field | Required behavior |
|---|---|
| Entry points | C-08 Edit or You profile. |
| Layout and elements | Private nickname/note; shared-with-this-contact name/avatar; separate labels; Save/Cancel. |
| Every control activation | Edit private fields → local draft; Change shared avatar → local picker preview; Save → local fields plus explicit scoped profile event if shared fields changed; Cancel → discard. |
| Distinctive states | Offline shared change queued; locked unavailable; overlength/unsafe avatar rejected; no global propagation. |
| Exact copy | “Private labels stay here. Shared fields are sent only to this contact.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Local nickname never enters profile event, node request, contact card, or diagnostic export by default. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-10: Advanced contact link and card

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Contact tools. |
| Layout and elements | Separate reusable-link and signed-card sections; disabled status; explicit field preview; revoke/export. |
| Every control activation | Reusable link → disabled-gate explanation until approved; Card fields → opt-in selection; Export → boundary review if qualified; Revoke link → capability invalidation, not recipient erasure. |
| Distinctive states | Unqualified capability has no Create button; signature evidence warning before export; old cards may survive revocation. |
| Exact copy | “A signed card can be kept and shown to others. It is not used as your payment identity.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Portable signatures/reusable capabilities may link contexts; no default activation. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet fields/private labels excluded; signed-card export cannot silently enable a reusable link. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |

### C-11: Block contact confirmation

| Record field | Required behavior |
|---|---|
| Entry points | C-08 Block or unsolicited request review. |
| Layout and elements | Affected relationship, stop-receipt explanation, optional delete-here choice unchecked, Block/Cancel. |
| Every control activation | Block → stop local fanout/subscriptions and rotate/revoke applicable capabilities; Delete here → separate M-09 review; Cancel → no effect. |
| Distinctive states | Offline: applied here/pending remote capability update; existing peer copies retained; repeated block idempotent. |
| Exact copy | “This stops this relationship here. It does not erase messages stored by the other person.” |
| Data read / written | Scope-local contact/invite/comparison records; private nickname stays local. |
| Network calls | Invitation/session traffic only through broker; no public people search. |
| Cryptographic operations | Reviewed invitation/session adapter; canonical comparison; no custom crypto. |
| Disclosure-ledger effect | Intended peer learns deliberately shared fields; rendezvous sees bounded activity, not a directory. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Block cannot delete wallet funds, revoke unrelated contacts, or claim a global identity ban. |
| Traceability / release scope | T-02; AUD-02/AUD-03; feature coverage F-003,F-006–F-014; Core unless marked. Required evidence absent initially. |


## Everyday messaging

### M-01: Conversation timeline and composer

| Record field | Required behavior |
|---|---|
| Entry points | Chats row or completed connection. |
| Layout and elements | Trust/route header; timeline; composer; attachment; voice; Send; details; optional qualified call. |
| Every control activation | Header → C-08/G-06; Text → local draft; Send → core validation/outbox; Attachment → A-01; Voice → A-04; long press → M-03; status → M-06; Call → L-01 only if qualified. |
| Distinctive states | Empty prompts first message; offline labels queued; locked → S-05; pending authority/key change blocks send; partial receipt explicit. |
| Exact copy | “Queued on this device.” / “Accepted by relay.” / “Received by an authorized endpoint.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Double Send, crash after commit, route loss, locked target, and late callback do not duplicate or leak content. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-02: Chats list and filters

| Record field | Required behavior |
|---|---|
| Entry points | Chats tab. |
| Layout and elements | Search, All/Compared/Needs review/Locked filters, rows, +, multi-select local organization. |
| Every control activation | Row → M-01 or S-05; Search → M-07; filter → local query; + → safe action menu; swipe → M-08 reversible options; long press row → local selection. |
| Distinctive states | No matches shows filter reset; locked rows no preview; offline keeps eligible local history; security-event count not read receipt. |
| Exact copy | “Locked chats stay out of message search until you unlock them.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Filters never confuse app lock, comparison, route, decoy, and group admission. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-03: Message action sheet

| Record field | Required behavior |
|---|---|
| Entry points | Long press or accessible message menu. |
| Layout and elements | Reply, reactions, Edit if author/eligible, Copy, Delete here/request, Details; no secret unsafe actions. |
| Every control activation | Reply → composer reference; reaction → scoped add/remove; Edit → M-04; Copy → clipboard warning/policy; Delete → M-09; Details → M-06; Close → unchanged. |
| Distinctive states | Expired/unsupported target limits actions; locked dismisses; edits unavailable for security/payment/control events. |
| Exact copy | “Copying leaves TGP's protected storage and may remain in clipboard history.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Other-author edit/cross-scope reply cannot be invoked by crafted frontend command. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-04: Edit or reply draft

| Record field | Required behavior |
|---|---|
| Entry points | M-03 Reply/Edit. |
| Layout and elements | Visible Replying to/Editing label; original availability; text; Save/Send; Cancel. |
| Every control activation | Save edit → authenticated revision event; Send reply → scoped content event; Cancel → restore ordinary draft; quoted source → only if currently authorized. |
| Distinctive states | Original expired/deleted/locked → unavailable placeholder; edit window closed → block; conflicting revision → visible review. |
| Exact copy | “Edited” / “Original message unavailable.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: A quote cannot recover expired/locked plaintext; edit replay cannot change authority state. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-05: Reaction picker

| Record field | Required behavior |
|---|---|
| Entry points | M-03 reaction action or selected existing reaction. |
| Layout and elements | Bounded reaction set; current selection; Remove; Close. |
| Every control activation | Choose → idempotent scoped reaction; selected reaction → remove; Close → unchanged; accessible More menu has same actions. |
| Distinctive states | Offline queues event; expired/unknown target reject; locked dismisses; no typing/online signal. |
| Exact copy | “Reaction queued” when offline; do not imply recipient read. |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate add/remove and reordering converge without extra counts or cross-scope mutation. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-06: Delivery and event details

| Record field | Required behavior |
|---|---|
| Entry points | Message status or Details. |
| Layout and elements | Local queued time; relay receipt; known authorized endpoint receipts; expiry/failure; Retry/Cancel if eligible. |
| Every control activation | Retry → revalidate current state and resend safely; Cancel queued → stop pending local effect if possible; receipt row → scoped evidence explanation; Close → timeline. |
| Distinctive states | Relay restart may lose accepted queue; partial endpoint receipt not everyone; unknown → unconfirmed. |
| Exact copy | “Relay acceptance is not proof that a person received or read this message.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No receipt is synthesized from an animation, HTTP success, or local bubble. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-07: Local search

| Record field | Required behavior |
|---|---|
| Entry points | Chats Search or conversation search. |
| Layout and elements | Query field; current scope/filter; unlocked results; Clear query/history; Cancel. |
| Every control activation | Type → bounded local query; result → authorized message context; Clear → local clear; scope → local filter; Cancel → purge active result model. |
| Distinctive states | No results explicit; locked scope excluded; relock purges results/snippets; indexing progress cancellable; offline unaffected. |
| Exact copy | “Search runs on this device. Locked chats are excluded.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | None. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Relock during query clears snippets and navigation targets; no query in network/analytics logs. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-08: Local organization actions

| Record field | Required behavior |
|---|---|
| Entry points | Chat swipe or row action menu. |
| Layout and elements | Pin/unpin; mute duration; archive/unarchive; local-only label; Close. |
| Every control activation | Pin → local list preference; Mute → local notification policy; Archive → hide from main list with Undo; Unarchive → restore; Close → unchanged. |
| Distinctive states | Offline fully works; locked rows keep generic label; Undo never reverses an already requested remote effect because none occurs. |
| Exact copy | “These organization changes stay on this device unless you separately enable eligible own-device sync.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Local mute/archive cannot emit read receipt, membership change, or wallet event. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-09: Delete and requested deletion

| Record field | Required behavior |
|---|---|
| Entry points | Message/contact action. |
| Layout and elements | Delete here; request deletion on linked devices/participants where supported; exact scope; Cancel. |
| Every control activation | Delete here → local eligible deletion; Request → authenticated bounded request with acknowledgment progress; Cancel → unchanged; scope help → limits. |
| Distinctive states | Unconfirmed/offline recipient remains unconfirmed; locked content deletion obeys key/store policy; wallet records unaffected. |
| Exact copy | “Others may have copied, exported, or photographed this content.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No global erased success; delayed content/import cannot silently resurrect within defined replay/expiry policy. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-10: External URL boundary

| Record field | Required behavior |
|---|---|
| Entry points | Tapped message link. |
| Layout and elements | Readable scheme/host; tracking/external-app warning; Open externally; Copy; Cancel. |
| Every control activation | Open → OS/browser handoff after consent; Copy → clipboard boundary; Cancel → no fetch; suspicious scheme → unsupported, no handler launch. |
| Distinctive states | Offline no automatic retry; locked dismisses; URL parsing bounded; no preview fetch on rendering. |
| Exact copy | “Opening leaves TGP. The destination and your browser may observe this visit.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | No app fetch for preview; external browser behavior is outside app transport guarantee. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: javascript/file/custom-command schemes and redirect tricks cannot invoke native authority. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |

### M-11: Unsupported message or security profile

| Record field | Required behavior |
|---|---|
| Entry points | Unknown event/version or incompatible endpoint. |
| Layout and elements | Safe placeholder; reason; update guidance; export-safe diagnostics; no raw unsafe rendering. |
| Every control activation | Update → H-09; Details → reason without secret payload; Diagnostics → H-05; Back → timeline; unsupported security state blocks affected send. |
| Distinctive states | Unknown ordinary content can be placeholder; unknown authority-bearing version fails closed; no weaker profile option. |
| Exact copy | “This version cannot use the required security profile.” |
| Data read / written | Unlocked scope content, encrypted local draft/index/outbox; no global plaintext index. |
| Network calls | Only approved E2EE delivery/receipts through broker; local controls do not phone home. |
| Cryptographic operations | Selected direct/group profile; core validates event scope, author, replay, and revision. |
| Disclosure-ledger effect | Existing authorized recipients only; local organization/search is not uploaded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unsupported event never becomes a generic settings update or authority grant. |
| Traceability / release scope | T-03; AUD-04/AUD-05/AUD-06; feature coverage F-016–F-030; Core. Required evidence absent initially. |


## Attachments and voice notes

### A-01: Attachment chooser

| Record field | Required behavior |
|---|---|
| Entry points | Composer attachment. |
| Layout and elements | Photos, camera if qualified, document, Cancel; current limits. |
| Every control activation | Photos/document → narrow OS picker; Camera → O-08 then capture; chosen file → A-02/A-03/A-06; Cancel → composer unchanged. |
| Distinctive states | Permission denied offers supported picker/manual alternative; oversize detected before decode; no auto-send on OS return. |
| Exact copy | “Choose a file, then review the send copy before sending.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Drag/drop/share extension stages review only; unknown type rejected safely. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-02: Sanitized image preview

| Record field | Required behavior |
|---|---|
| Entry points | Selected supported image. |
| Layout and elements | Send-copy preview; metadata result; resize; view-once choice; Send; Cancel. |
| Every control activation | Resize → local bounded re-encode; view-once → explicit limits; Send → descriptor/body queue; Cancel → protected staging cleanup; metadata row → exact removed/remaining fields. |
| Distinctive states | Sanitizing progress; failure not labeled cleaned; offline queued transfer; lock cancels plaintext preview. |
| Exact copy | “Metadata removed from this send copy. Your original is unchanged. Recipients can still copy the image.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: EXIF/GPS/orientation fixtures, decompression bombs, relock and worker crash stay bounded. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-03: Document/original-file disclosure

| Record field | Required behavior |
|---|---|
| Entry points | Selected document or unsanitizable format. |
| Layout and elements | Filename/type/size; metadata limitation; Send original; Cancel; unsupported-type explanation. |
| Every control activation | Send original → explicit disclosure confirmation then approved transfer; Cancel → remove staging; safe preview → bounded worker only if supported. |
| Distinctive states | Unsupported parser: no unsafe preview; offline queue explicit; locked hides file contents; no remote conversion. |
| Exact copy | “TGP cannot safely remove all metadata from this file. Sending the original may reveal author or editing information.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No false sanitize success; external viewer not launched automatically. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-04: Voice note recording and preview

| Record field | Required behavior |
|---|---|
| Entry points | Composer Voice. |
| Layout and elements | Record/Stop, duration, waveform, Play, Delete, Send, Cancel; visible microphone state. |
| Every control activation | Record → permission then capture; Stop → encrypted draft preview; Play → local playback; Delete/Cancel → stop/delete; Send → approved protected transfer. |
| Distinctive states | Lock/background stops capture under policy; duration cap enforced; denied mic leaves text; failed call never enters this screen automatically. |
| Exact copy | “Recording on this device. Nothing is sent until you choose Send.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No pre-consent or post-cancel capture; interrupted unsent audio does not upload. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-05: Received media viewer and shared media

| Record field | Required behavior |
|---|---|
| Entry points | Attachment bubble or Contact/Group shared media. |
| Layout and elements | Authorized media list/view, Download if needed, Save externally, view-once limits, Close. |
| Every control activation | Download → protected approved transfer; Open → bounded local viewer; Save → explicit OS export boundary; Close → purge transient preview; view-once open → consume under replay policy. |
| Distinctive states | Expired/unavailable/missing chunks explicit; no cloud fallback; locked denies body; partial download resumable only with valid capability. |
| Exact copy | “Saving outside TGP creates a copy controlled by the destination.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Duplicate view-once delivery cannot reopen; external export excludes unrelated files/keys. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-06: Video preparation and preview

| Record field | Required behavior |
|---|---|
| Entry points | Selected supported video. |
| Layout and elements | Local processing progress; duration/dimension cap; preview; audio toggle; Send; Cancel. |
| Every control activation | Trim/resize if supported → local work; Play → local preview; Send → reviewed prepared copy; Cancel → worker cancellation and cleanup. |
| Distinctive states | Over cap offers smaller local copy or cancel; no remote transcoder; disk-full leaves no plaintext temp; lock clears preview. |
| Exact copy | “Preparing video on this device. Larger transfers are not available in this build.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Codec time/memory caps, malformed frames, interruption and denied permissions handled without leaks. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-07: Attachment transfer status

| Record field | Required behavior |
|---|---|
| Entry points | Attachment progress indicator. |
| Layout and elements | Queued/preparing/transferring/partial/received/expired states; bytes bucket; Retry; Cancel. |
| Every control activation | Retry → validate manifest/capability/expiry; Cancel → stop uncompleted local transfer; Details → limits; Close → timeline with actual progress. |
| Distinctive states | Sender offline may prevent body fetch; no durable-store claim; token consumed/expired produces honest unavailable state. |
| Exact copy | “The message arrived, but this attachment is not available yet.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | Approved endpoint transfer only; external blob service disabled until separate gate. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Message receipt never implies attachment receipt; reordered/truncated chunks cannot render unverified body. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |

### A-08: External blob storage unavailable

| Record field | Required behavior |
|---|---|
| Entry points | Advanced attachment options or oversized offline transfer. |
| Layout and elements | Disabled capability explanation; current endpoint-transfer limits; Back. |
| Every control activation | Read why → privacy/persistence explanation; Back → safe transfer flow; no Enable bypass. |
| Distinctive states | Always disabled until storage gate closes; outage does not switch to public file host. |
| Exact copy | “External attachment storage is not enabled because its added metadata and retention have not met the privacy requirement.” |
| Data read / written | Protected staging/cache and bounded descriptors; originals unchanged. |
| Network calls | None. |
| Cryptographic operations | Reviewed authenticated chunk/container encryption; keys inside E2EE descriptor. |
| Disclosure-ledger effect | Recipients receive send copy; external opening/export is a separate disclosure. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No storage endpoint contacted and no upload token created from disabled UI. |
| Traceability / release scope | T-06; AUD-11/AUD-12; feature coverage F-031–F-036,F-049; Collaboration, gated. Required evidence absent initially. |


## Groups and community experiments

### G-01: Select group contacts

| Record field | Required behavior |
|---|---|
| Entry points | Chats + → New group. |
| Layout and elements | Existing authenticated contacts; none selected; search local labels; Continue; Cancel. |
| Every control activation | Select person → local draft roster; Continue → G-02; search → local filter; Cancel → discard draft; unqualified group build → G-11. |
| Distinctive states | No contacts offers Connect; incompatible/pending contact explained; no public invite entry or phone lookup. |
| Exact copy | “Choose people you already connected with. Nobody receives messages until they accept and are admitted.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Selection alone cannot send invite or create member leaf. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-02: Review group and policy

| Record field | Required behavior |
|---|---|
| Entry points | G-01 Continue. |
| Layout and elements | Title/avatar; selected people; administrator/coordinator explanation; history none; Keep default; Invite/Back. |
| Every control activation | Edit roster → G-01; policy rows → G-08; avatar → local sanitize; Invite → encrypted invitations and G-03; Back → preserved draft. |
| Distinctive states | Policy changes revalidate preview; offline invitations queued; all recipients shown; no automatic pre-join history. |
| Exact copy | “New members receive new messages after admission. Earlier history is not shared by default.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No hidden endpoint, public mailbox, or wallet/treasury created by group creation. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-03: Invitation and admission progress

| Record field | Required behavior |
|---|---|
| Entry points | G-02 Invite. |
| Layout and elements | Per-person Invited/Accepted/Joining/Member; expiry; Cancel pending; Open group. |
| Every control activation | Person row → current evidence; Cancel pending → revoke unused invite; Open group → G-06/M-01 with pending banner; Retry → current-state validation. |
| Distinctive states | Partial success explicit; peer offline stays pending; expired invite needs fresh review; not all green until committed. |
| Exact copy | “Accepted is not yet admitted. Pending people cannot read group content.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No group ciphertext delivered to merely invited or accepted endpoints. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-04: Incoming group invitation review

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated one-to-one group invitation. |
| Layout and elements | Inviter comparison; roster; policy; history boundary; Accept; Decline. |
| Every control activation | Accept → consent/key-package step and G-05; Decline → bounded reply and no membership; roster/policy → readable local detail. |
| Distinctive states | Expired/revoked/materially changed invite → renew review; unsupported hybrid profile blocks join; no auto-download archive. |
| Exact copy | “Accepting asks to join this group. Admission still needs to complete.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Forwarded invite cannot delegate admission to an unrelated relationship. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-05: Joining group

| Record field | Required behavior |
|---|---|
| Entry points | G-04 Accept. |
| Layout and elements | Consent accepted; cryptographic admission progress; Cancel before admission; Open when ready. |
| Every control activation | Cancel → withdraw pending consent if not committed; Open → conversation only after valid persisted state; Details → per-endpoint admission. |
| Distinctive states | Missing commit/partition → joining; conflicting state → R-06; process death resumes safely; no live-state copy. |
| Exact copy | “Finishing protected admission. You are not a recipient until this completes.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Optimistic UI cannot enable sends or content decryption before valid admission. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-06: Group details

| Record field | Required behavior |
|---|---|
| Entry points | Group conversation header. |
| Layout and elements | Title; actual member count; pending count; Members; Policy; Media; role actions; Leave; Pay privately. |
| Every control activation | Members → G-07; Policy → G-08; Media → A-05; Add → G-01 scoped add flow; Leave → G-10; Pay privately → select member then 1:1 P-03. |
| Distinctive states | Locked hides content; stale group pauses affected controls; unauthorized role actions not offered; no group payment event. |
| Exact copy | “Members and their admitted devices can receive new group messages.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Pay privately emits no group request/address/TXID/completion badge. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-07: Members and endpoints

| Record field | Required behavior |
|---|---|
| Entry points | G-06 Members. |
| Layout and elements | People, scoped authorized endpoints, role, pending devices, remove/promote controls by role. |
| Every control activation | Person → its group endpoints; pending → R-02; Remove → G-09; role change → G-08 reviewed policy transition; Back → details. |
| Distinctive states | Not a global device inventory; offline status is locally observed, not global last-online; pending not active. |
| Exact copy | “These are devices admitted to this group, not all devices a person owns.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Companion/controller role cannot inherit group administration silently. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-08: Group policy and role review

| Record field | Required behavior |
|---|---|
| Entry points | G-02/G-06/G-07. |
| Layout and elements | Admission rules; roles/coordinator; history/expiry; explicit changed-fields diff; Apply/Cancel. |
| Every control activation | Change field → draft only; Apply → authority/consent/parent-state check and valid transition; Cancel → no change; transfer coordinator → separate confirmed transition. |
| Distinctive states | Coordinator offline: admin waits; unsupported broadening blocks; conflicting parent → R-06; no last-write-wins security policy. |
| Exact copy | “This changes who can admit recipients or what future messages follow. Review before applying.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Invalid admin signature, replayed policy, concurrent child states and silent timer changes rejected. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-09: Remove person or device

| Record field | Required behavior |
|---|---|
| Entry points | G-07 authorized Remove. |
| Layout and elements | Exact person/all endpoints or one endpoint; retained-copy warning; Remove; Cancel; progress. |
| Every control activation | Remove → local stop plus authorized group transition; progress → per-state applied/pending; Cancel before commit → no promise after published effect. |
| Distinctive states | Offline coordinator/peers pending; old content not erased; removed endpoint cannot receive new epoch secrets after valid transition. |
| Exact copy | “Removal blocks future access as the group updates. Stored copies remain.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Remove person covers every represented endpoint; stale client cannot fabricate completed global revocation. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-10: Leave group

| Record field | Required behavior |
|---|---|
| Entry points | G-06 Leave. |
| Layout and elements | Local departure versus cryptographic removal; keep/delete local history choices; Leave/Cancel. |
| Every control activation | Leave → stop local participation and authenticated leave request; Delete here → separate M-09; Cancel → unchanged. |
| Distinctive states | Last administrator/coordinator requires reviewed transfer or successor-group warning; offline removal may remain pending. |
| Exact copy | “You stop participating here now. Completing group rekey may require another authorized participant.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Leave cannot delete everyone else's history or silently transfer administrator authority. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-11: Large group/community unavailable

| Record field | Required behavior |
|---|---|
| Entry points | Capacity limit or You → Advanced → Communities. |
| Layout and elements | Measured current limit; experimental tier explanation; Create separate private group; Back. |
| Every control activation | Create private group → G-01 only if qualified; Details → metadata/capacity gate; Back → prior; no shared-mailbox override. |
| Distinctive states | Unsupported capacity is honest; no auto-sharding that changes recipient set; no public discovery. |
| Exact copy | “Larger communities are not enabled until their metadata, authority, and capacity requirements pass.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | None until a separately reviewed private-group action. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crossing capacity cannot silently switch to server fanout or classical encryption. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |

### G-12: Share selected earlier group history

| Record field | Required behavior |
|---|---|
| Entry points | Authorized group details → History transfer. |
| Layout and elements | Recipient endpoint; prior authorization; range none by default; eligible content; forwardable disclosure; Share/Cancel. |
| Every control activation | Select range → eligible manifest; locked source → S-05; Share → reviewed participant-authorized archive flow; Cancel → no history. |
| Distinctive states | Role/consent/profile changes invalidate; expired/deleted excluded; new group membership alone grants no old history. |
| Exact copy | “This creates another stored copy of the selected earlier history.” |
| Data read / written | Encrypted group roster/policy, consent and pending state; no plaintext server roster. |
| Network calls | Protected pairwise invitations and recipient-specific group fanout. |
| Cryptographic operations | Approved hybrid MLS profile and independent leaf per endpoint; application authority checks. |
| Disclosure-ledger effect | Admitted members know roster; invited/pending people are not yet recipients. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Administrator cannot export another member's unavailable/locked content or silently share all old history. |
| Traceability / release scope | T-07; AUD-09/AUD-10; feature coverage F-037–F-044; Collaboration, gated. Required evidence absent initially. |


## Devices and selected history

### D-01: Device inventory

| Record field | Required behavior |
|---|---|
| Entry points | You → Devices. |
| Layout and elements | Controller/companion role; local names; selected grants; last seen by this device; Link; device rows. |
| Every control activation | Link → D-02; device → grant detail and R-03 revoke; migration → R-04; lost controller help → R-05. |
| Distinctive states | Empty companions explicit; pending scopes separate; no authoritative global online time; wallet state never listed. |
| Exact copy | “Linked devices receive only the chats you approve. Wallets are separate.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Companion cannot enroll/promote itself or inspect unrelated profile grant inventory. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-02: Link-device ceremony start

| Record field | Required behavior |
|---|---|
| Entry points | Controller D-01 Link or new desktop companion setup. |
| Layout and elements | Role explanation; reauthenticate controller; scan/show pairing QR; Cancel; expiry. |
| Every control activation | Controller reauth → scanner; new device Show QR → fresh one-use invite; Scan → D-03; Cancel → destroy pending pairing. |
| Distinctive states | Companion role denied; expired/reused code terminal; offline no completed grant; permission alternative accessible. |
| Exact copy | “The new device will become another recipient only in the chats you choose.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Contact invitation and payment QR cannot be treated as pairing invitation. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-03: Compare both devices

| Record field | Required behavior |
|---|---|
| Entry points | Valid pairing candidate. |
| Layout and elements | Full transcript comparison on both devices; Matches; Does not match; destination local name. |
| Every control activation | Matches → local confirmation waits for both then D-04; Mismatch → invalidate attempt; name → local device label; Close → no grants. |
| Distinctive states | One-sided confirmation pending; transcript changes resets approval; interruption cannot create universal trust. |
| Exact copy | “Compare both screens. Confirm on both devices only if they match.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Replayed transcript or single-device confirmation cannot activate scopes. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-04: Select conversation grants

| Record field | Required behavior |
|---|---|
| Entry points | Both-device comparison succeeds. |
| Layout and elements | None selected; eligible chats; locked scopes need unlock; new-message permission; Continue. |
| Every control activation | Select → draft grant; locked scope → S-05; Continue → D-05; Select all not default and requires explicit action if offered; Back → no grant. |
| Distinctive states | Unavailable/incompatible scopes explained; no future-chat toggle; no wallet/admin permission. |
| Exact copy | “Only selected conversations will be offered to this device. Other and future chats stay excluded.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crafted selection cannot grant wallet, enrollment, future chats, or locked plaintext. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-05: Choose history and review access

| Record field | Required behavior |
|---|---|
| Entry points | D-04 Continue. |
| Layout and elements | Per-scope history None/24h/7d/custom; approximate size; attachments on request; single combined review; Link selected. |
| Every control activation | Range → eligible local manifest; custom → bounded dates; Link selected → D-06 and peer/group admissions; Back → preserved draft no effect. |
| Distinctive states | Expired/deleted excluded; locked scope needs separate unlock; disk/network estimate not certainty; no history default. |
| Exact copy | “Selected history will be stored on this device. No live session state or wallet is copied.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Import/transfer cannot restart expiry or clone running ratchets/leaves. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-06: Linking and history transfer progress

| Record field | Required behavior |
|---|---|
| Entry points | D-05 authorized Link. |
| Layout and elements | Per-scope active/awaiting peer/awaiting group/transferring; pause/cancel eligible work; Done. |
| Every control activation | Scope → reason/evidence; Pause archive → stop history only; Cancel pending scope → bounded cancellation; Done → D-01. |
| Distinctive states | Partial admission explicit; no content before scope active; archive resumable only with valid current grant; crash idempotent. |
| Exact copy | “4 chats active. 1 awaiting approval.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Cancelling archive does not revoke unrelated active scopes or leave a universal partially trusted endpoint. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |

### D-07: Desktop companion workspace

| Record field | Required behavior |
|---|---|
| Entry points | Qualified installed desktop after pairing. |
| Layout and elements | Rail, chat list, main conversation, detail pane, lock control, local notification preference. |
| Every control activation | Rail tabs → same mobile destinations; chat → M-01; details → scoped pane; Lock → S-02; close window → explicit tray/exit preference, not assumed lock. |
| Distinctive states | OS session lock purges plaintext; wallet absent/not configured; permission denial limits feature; no browser remote content. |
| Exact copy | “This installation has only its selected chat grants. No wallet was linked.” |
| Data read / written | Scoped local grants, compared pairing transcript and eligible-history manifest. |
| Network calls | Protected pairing/admission/archive transfer; no global device directory. |
| Cryptographic operations | Fresh new-device secrets; reviewed compared channel; never copy live ratchets/leaves. |
| Disclosure-ledger effect | Only explicitly selected scopes/history go to the new endpoint; wallet excluded. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Keyboard-only pairing/chat/lock works; webview injection cannot call sign/export/enroll APIs. |
| Traceability / release scope | T-08/T-11; AUD-13/AUD-17; feature coverage F-050–F-052,F-073; Collaboration, gated. Required evidence absent initially. |


## Security, locks, and deletion

### S-01: Security and Vault hub

| Record field | Required behavior |
|---|---|
| Entry points | You → Security & Vault. |
| Layout and elements | App lock; chat vaults; inactivity; Lock now; clipboard/capture limits; Advanced local controls. |
| Every control activation | App lock → S-03; chat vaults → select S-04; inactivity → local policy review; Lock now → S-02; Advanced → S-08. |
| Distinctive states | Hardware capability honest; locked app must unlock before settings; no global all-secure badge. |
| Exact copy | “App entry, chat vaults, and wallet signing use separate authorization.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Changing app-lock preference cannot unlock every chat or wallet. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-02: App locked / panic result

| Record field | Required behavior |
|---|---|
| Entry points | Manual lock, panic accelerator, inactivity, screen-off policy. |
| Layout and elements | Generic app title; unlock; recovery limits; no chat names, previews, balances, or camera capture. |
| Every control activation | Unlock → appropriate native/passphrase flow; help → local no-reset explanation; panic action while open → stop capture and lock immediately. |
| Distinctive states | Bad attempt rate-limited; process death/reboot remains locked; biometric unavailable offers approved alternative not bypass. |
| Exact copy | “Unlock TGP. TGP cannot reset a forgotten local secret.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | No unlock analytics; only permitted background ciphertext handling. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Panic clears views/search/capture and does not silently wipe, spend, or send remote commands. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-03: App passphrase and inactivity policy

| Record field | Required behavior |
|---|---|
| Entry points | O-04 or S-01 App lock. |
| Layout and elements | Passphrase/confirm; visibility; device protection; lock timing; Save/Cancel. |
| Every control activation | Visibility → temporary local reveal; Save → derive/wrap under approved profile and persist policy; Cancel → discard; timing row → explicit future local policy. |
| Distinctive states | Weak/unequal fields error; memory/KDF unsupported blocks, no silent cheaper derivation; biometric convenience separately explained. |
| Exact copy | “Use a strong local secret. Losing it may make protected local data unavailable.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Passphrase never enters logs/clipboard/diagnostics; parameter change cannot silently downgrade KDF. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-04: Create/change per-chat vault

| Record field | Required behavior |
|---|---|
| Entry points | Contact details Lock or S-01 selected chat. |
| Layout and elements | Exact chat; passphrase/confirm; independent-key explanation; optional biometric re-unlock; Save. |
| Every control activation | Save → rewrap/create distinct vault key and relock/reindex safely; biometric choice → explicit convenience scope; Cancel → no protection change. |
| Distinctive states | Existing vault requires unlock; failed migration leaves old valid protection or fail-closed recovery; no global DB-only hiding. |
| Exact copy | “This chat has a separate vault key. Unlocking another chat does not unlock it.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Memory/storage dump while different chat open cannot obtain this locked vault key through ordinary app access. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-05: Unlock one chat

| Record field | Required behavior |
|---|---|
| Entry points | Locked chat row, search target, or selected grant. |
| Layout and elements | Generic protected-chat label where necessary; passphrase/biometric; unlock duration; Cancel. |
| Every control activation | Unlock → bounded scope key lease then intended screen; Cancel → no preview; show secret → temporary; wrong attempt → rate-limited. |
| Distinctive states | Relock cancels dependent search/media/export; no transfer or sync bypass; device key unavailable means blocked. |
| Exact copy | “Unlock this chat only. Your other locked chats stay locked.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Late callbacks after cancel/relock cannot repopulate message previews. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-06: Disappearing message policy

| Record field | Required behavior |
|---|---|
| Entry points | Contact/group details Timer. |
| Layout and elements | Keep default; timer options; prospective anchor/clock explanation; Apply; Cancel. |
| Every control activation | Select → draft; Apply → authenticated current-scope policy change; existing-content delete → separate M-09; Cancel → unchanged. |
| Distinctive states | Offline change pending; conflicting group state blocks; imported/read content never restarts timer; recipients can copy. |
| Exact copy | “This applies to new messages. Expiry is not proof that every copy is destroyed.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Clock skew, offline-before-receipt, timer conflict and archive restore follow defined bounds. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-07: Capture and clipboard controls

| Record field | Required behavior |
|---|---|
| Entry points | S-01 or sensitive copy action. |
| Layout and elements | Supported screenshot/recents controls; clipboard preference/clear; limitations; Save. |
| Every control activation | Toggle supported protection → local policy; Clear clipboard → best-effort platform action; Save → local; Back → no unapproved change. |
| Distinctive states | Unsupported OS says unavailable; external cameras/OS histories cannot be ruled out; secrets never auto-copied. |
| Exact copy | “These controls reduce supported capture paths. Other devices or a compromised OS may still capture content.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No claim that FLAG_SECURE or clipboard clearing defeats all recording/history. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-08: Advanced local concealment and destructive controls

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Local controls. |
| Layout and elements | Separate Decoy/disguise, Panic lock, Inactivity lock, Destructive wipe experiments; disabled labels. |
| Every control activation | Panic → S-02; inactivity → S-03; decoy/disguise/wipe → unavailable risk explanation unless separately qualified; no remote trigger. |
| Distinctive states | Experimental defaults off; no ambiguous duress PIN; auto-lock available, auto-wipe unavailable by default. |
| Exact copy | “Concealment is best effort. It does not guarantee plausible deniability or forensic invisibility.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No destructive action can be activated by ordinary unlock, peer message, timeout clock glitch, or support command. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-09: Delete local profile review

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Delete local profile. |
| Layout and elements | Local chats/keys/settings affected; external-copy warning; separate wallet warning; Export backup; Delete profile; Cancel. |
| Every control activation | Backup → B-02; Delete → reauth and explicit final local confirmation; existing wallet → separate recovery/removal review, no implicit destruction; Cancel → unchanged. |
| Distinctive states | Failed deletion reports exact partial local state; public chain/recipient/export copies remain; no server account to reset. |
| Exact copy | “Delete from this device. This does not erase recipient copies, external backups, or blockchain records.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Chat reset cannot silently destroy funds or claim all external data erased. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |

### S-10: Read, typing, and availability signals

| Record field | Required behavior |
|---|---|
| Entry points | Security/privacy settings → Activity signals. |
| Layout and elements | Read receipts, typing, last-online off; metadata explanation; individual capability status. |
| Every control activation | Signal row → disclosure/no-regression review; unqualified Enable → unavailable explanation, not toggle; Back → no change. |
| Distinctive states | Default off; one-to-one versus group separately scoped; no inherited enablement through pairing or restore. |
| Exact copy | “These signals reveal activity. They remain off unless their privacy requirement is separately met.” |
| Data read / written | Local lock/vault policy and protected key leases; no remote recovery channel. |
| Network calls | Local-only unless an explicit authenticated expiry/deletion request is sent. |
| Cryptographic operations | Reviewed per-vault wrapping and Argon2id profile; OS protection where supported. |
| Disclosure-ledger effect | Lock states do not claim remote erasure, forensic invisibility, or protection from compromised OS. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening or reading messages emits no read/typing/last-online event under default policy. |
| Traceability / release scope | T-03/T-05; AUD-05/AUD-15/AUD-16; feature coverage F-025,F-027,F-065–F-071,F-103; Core unless marked. Required evidence absent initially. |


## Backup, restore, and drills

### B-01: Backup and Restore hub

| Record field | Required behavior |
|---|---|
| Entry points | You → Backup & Restore. |
| Layout and elements | Export chat archive; Restore chat archive; Recovery drill; Wallet recovery separate; continuity experiment. |
| Every control activation | Export → B-02; Restore → B-06; Drill → B-08; Wallet → B-09; Continuity → R-07 unavailable unless approved. |
| Distinctive states | No cloud account/connect; locked scope needs unlock; no “recover account” generic button. |
| Exact copy | “History, identity continuity, and wallet recovery are different operations.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Choosing chat restore never prompts for wallet seed or activates old session. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-02: Select chat archive content

| Record field | Required behavior |
|---|---|
| Entry points | B-01 Export. |
| Layout and elements | Chats none/explicit selection; date range; local metadata options; attachment choice; exclusions; Continue. |
| Every control activation | Select/range → eligible manifest; metadata → explicit opt-in; Continue → B-03; locked scope → S-05; Cancel → discard plan. |
| Distinctive states | Expired/deleted excluded; approximate size; disk capacity checked; live sessions/authority/wallet excluded. |
| Exact copy | “This archive contains selected history, not active sessions, group leaves, or wallet recovery.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Manifest exactly matches eligible selected scope/range and exclusions. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-03: Archive passphrase and review

| Record field | Required behavior |
|---|---|
| Entry points | B-02 Continue. |
| Layout and elements | Strong passphrase/confirm; no-reset warning; manifest summary; Continue; Cancel. |
| Every control activation | Continue → validated KDF/profile and B-04; reveal → temporary; Back → plan; Cancel → clear transient secret. |
| Distinctive states | Weak/mismatch error; unsupported KDF blocks; no remembered secret or provider recovery. |
| Exact copy | “Keep this passphrase separately. TGP cannot recover it.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No plaintext export before authenticated container setup; KDF minimum enforced. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-04: Choose encrypted archive destination

| Record field | Required behavior |
|---|---|
| Entry points | B-03. |
| Layout and elements | Encrypted file type/name without contact labels; destination boundary; Save; Cancel. |
| Every control activation | Save → OS picker then authenticated protected streaming export; Cancel → clean partial protected state; external cloud chosen → metadata warning remains. |
| Distinctive states | Disk full/cancel/OS failure never creates plaintext temp; partial file invalid and reported; local archive can be retained only explicitly. |
| Exact copy | “The destination may retain this encrypted file, its size, and upload time.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Destination sees no plaintext; contact names excluded from default filename. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-05: Archive export result

| Record field | Required behavior |
|---|---|
| Entry points | Completed/failed export. |
| Layout and elements | Exact selected archive result, destination label, integrity status, Drill, Done; partial/error branch. |
| Every control activation | Drill → B-08; Done → B-01; Retry → fresh validated export; reveal file → OS boundary. |
| Distinctive states | Only successful finalized container shows success; cancellation/partial export distinguished; no remote durable promise. |
| Exact copy | “Encrypted archive saved. This does not back up wallet funds or reactivate identity on another device.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Success requires completed authentication/finalization and destination write evidence. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-06: Select and unlock chat archive

| Record field | Required behavior |
|---|---|
| Entry points | Welcome Restore or B-01. |
| Layout and elements | OS file selection; type/version; passphrase; Inspect; Cancel. |
| Every control activation | Choose → bounded header parse; Inspect → authenticate/decrypt manifest then B-07; Cancel → clear temp/secret; unsupported file → reject. |
| Distinctive states | Wrong secret/corrupt/oversize/incompatible handled safely; no plaintext preview before integrity; no wallet format guessing. |
| Exact copy | “Restoring history does not restore a running session or prove an old controller is gone.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Hostile nesting, huge declared size, truncated tags and wrong type cannot exhaust resources or bypass auth. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-07: Review archive restore

| Record field | Required behavior |
|---|---|
| Entry points | B-06 valid manifest. |
| Layout and elements | Eligible content/ranges/provenance; excluded expired items; fresh-endpoint explanation; Import selected; Cancel. |
| Every control activation | Select → local import plan; Import → transactional protected import; Cancel → no data; continuity request → separate R-07. |
| Distinctive states | Partial import exact count/error; no duplicate resurrection; incompatible active-state fields rejected; locked destination policy maintained. |
| Exact copy | “Imported messages are history. Contacts and groups may need fresh connection or admission.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No ratchet/group leaf/controller/wallet authority activated from ordinary archive. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-08: Non-authoritative chat recovery drill

| Record field | Required behavior |
|---|---|
| Entry points | B-01/B-05. |
| Layout and elements | Choose archive; temporary isolated context; verify sample eligible content; Finish; Cancel. |
| Every control activation | Choose/unlock → same bounded parser; Verify → local sample integrity; Finish/Cancel → destroy temporary context; no Send control. |
| Distinctive states | Offline fully possible; wrong passphrase fail safe; drill cannot join groups or create duplicate active endpoint. |
| Exact copy | “This checks recovery without reactivating old message sessions.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No outbound message/session enrollment and no temporary plaintext residue after drill. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-09: Separate wallet backup

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings or B-01 wallet recovery. |
| Layout and elements | Selected chain/wallet; supported recovery format; hardware versus local; protected reveal; descriptor/height requirements; Confirm. |
| Every control activation | Reveal → separate wallet reauth and protected native view; Confirm understanding → local backup status; Export supported public policy → explicit boundary; Cancel → hide. |
| Distinctive states | No screenshots/clipboard default; hardware seed never requested; format-specific prerequisites; no generic seed splitting. |
| Exact copy | “This recovers funds, not chats. A watch-only export is not a spending backup.” |
| Data read / written | Wallet-only recovery metadata; no chat archive insertion. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Seed/view-key material never crosses chat bridge or general support export. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-10: Wallet no-spend recovery drill

| Record field | Required behavior |
|---|---|
| Entry points | Wallet backup result/settings. |
| Layout and elements | Chain-specific temporary restore; verify derived address/policy/height; no-spend label; Finish. |
| Every control activation | Start → separate local protected input; Verify → derive/check without broadcast; Finish → destroy temp secrets; Cancel → cleanup. |
| Distinctive states | Wrong format/network/passphrase explicit; hardware follows exact matrix; no funds moved, no provider lookup required unless separately reviewed sync. |
| Exact copy | “This drill does not send a transaction or link a wallet to another chat device.” |
| Data read / written | Isolated temporary wallet context; no contact mapping. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No signing/broadcast and no automatic source-label promotion from successful restore. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |

### B-11: Multisig and social recovery study

| Record field | Required behavior |
|---|---|
| Entry points | Backup hub → Advanced recovery. |
| Layout and elements | Bitcoin descriptor multisig study; generic social recovery unavailable; exact signer/loss/timelock requirements; Back. |
| Every control activation | Study row → non-actionable design status; Back → backup hub; no split-seed, contact-share, or contract-deploy control. |
| Distinctive states | All deferred paths remain disabled; no assurance contacts can recover funds; no chat identity used as on-chain recovery authority. |
| Exact copy | “Do not split or send a recovery phrase through contacts. This recovery feature is not available.” |
| Data read / written | Selected manifest and encrypted archive or separate wallet recovery material. |
| Network calls | No TGP backup service; OS destination boundary shown before export. |
| Cryptographic operations | Reviewed authenticated streaming container and KDF; no live-state clone. |
| Disclosure-ledger effect | Chosen destination can retain ciphertext/metadata; chat archive excludes wallet secrets. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Contact/group members cannot enroll themselves as recovery signers or receive secret shares. |
| Traceability / release scope | T-12; AUD-24; feature coverage F-092–F-095; Core/optional by archive type. Required evidence absent initially. |


## Network and infrastructure

### N-01: Connection status

| Record field | Required behavior |
|---|---|
| Entry points | Header route badge or You → Privacy & Network. |
| Layout and elements | Connecting/Tor/PT/offline/degraded; last local check; Retry; Assistance; Advanced endpoints. |
| Every control activation | Retry → approved broker attempt; Assistance → N-02; endpoints → N-04; report → H-03; Close → prior. |
| Distinctive states | Wi-Fi not Tor; no universal green privacy score; stale status timestamp; offline queues remain local. |
| Exact copy | “Protected connection unavailable. Nothing was sent directly.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Status never derives security from hop count or internet connectivity alone. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-02: Connection assistance

| Record field | Required behavior |
|---|---|
| Entry points | N-01 Help or O-05. |
| Layout and elements | Supported transport choices/automatic retry; manual bridge; concise network limits; Cancel. |
| Every control activation | Try supported method → broker/PT attempt; Manual bridge → N-03; Cancel → local offline mode; details → local explanation. |
| Distinctive states | Unsupported PT unavailable by platform; repeated failure bounded backoff; no TGP-branded secret bridge guarantee. |
| Exact copy | “Some networks block all available routes. TGP cannot guarantee access during a shutdown.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Failed PT never opens direct message/node/update request. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-03: Bridge configuration import

| Record field | Required behavior |
|---|---|
| Entry points | N-02 manual or Advanced bridges. |
| Layout and elements | Typed bridge/PT fields; operator/address preview; Save/Test; Cancel; remove. |
| Every control activation | Paste/scan → parse preview only; Test → approved transport bootstrap; Save → reviewed config; Remove → revert to safe automatic profile; Cancel → unchanged. |
| Distinctive states | Malformed/unsupported type rejected; QR cannot replace config silently; no content sends during config test. |
| Exact copy | “This changes transport setup, not your message relay or wallet node.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Bridge, relay, chain node and payment QR types remain distinct. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-04: Message relay directory and BYO

| Record field | Required behavior |
|---|---|
| Entry points | Privacy & Network → Relays. |
| Layout and elements | Signed manifest status; declared operators; selected roles; Add own; inspect; Save. |
| Every control activation | Relay → N-05; Add → typed onion/protocol preview; Save → compatibility/operator rule check; refresh → broker fetch without client identity. |
| Distinctive states | Expired manifest warns/blocks unsafe use; same declared operator not silently accepted; BYO not proof trusted. |
| Exact copy | “Different declared operators reduce concentration. They do not prove non-collusion.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Directory update cannot change person identity, add recipients, or enable weaker profile. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-05: Endpoint review and test

| Record field | Required behavior |
|---|---|
| Entry points | Relay/node/config selection. |
| Layout and elements | Endpoint type, onion/host, operator, transport, data exposure, Test/Save/Cancel. |
| Every control activation | Test → role-specific reachability only; Save → current typed endpoint profile; Cancel → no change; disclosure → exact observer fields. |
| Distinctive states | Redirect/host/protocol mismatch rejected; timeout local error; no wallet secret in health query. |
| Exact copy | “Reachable means this endpoint answered this test. It is not a privacy endorsement.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Node test cannot upload descriptor/view key or contact label. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-06: Advanced traffic profile

| Record field | Required behavior |
|---|---|
| Entry points | You → Advanced → Network experiments. |
| Layout and elements | Cover-traffic measurement status; padding profile; cost/latency; disabled production toggle until approved. |
| Every control activation | Read results → local evidence; qualified profile selection → explicit resource/disclosure review; Back → unchanged; no magic-anonymity switch. |
| Distinctive states | Unqualified stays off; battery/data costs visible; app suspension limits explained. |
| Exact copy | “Cover traffic does not guarantee protection against a global observer.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Profile change cannot lower baseline padding or bypass route on battery pressure. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-07: Volunteer proxy and device VPN experiments

| Record field | Required behavior |
|---|---|
| Entry points | Advanced network. |
| Layout and elements | Separate volunteer Snowflake proxy and device-wide VPN cards; disabled/current capability; stop control if qualified. |
| Every control activation | Proxy details → role/battery/network disclosure; VPN details → exact traffic scope/OS permission; Stop → immediate local stop; no default activation. |
| Distinctive states | Unsupported/platform conflict remains off; proxy contribution not own route privacy; VPN other-app effects explicit. |
| Exact copy | “Contributing a proxy is different from using Snowflake to connect.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No claim all-device kill switch without scope tests; no rewards or anonymity gain implied. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |

### N-08: Nearby/offline radio experiment

| Record field | Required behavior |
|---|---|
| Entry points | Advanced → Nearby transfer. |
| Layout and elements | Disabled prototype status; proximity/radio identifiers; authenticated peer requirement; Back. |
| Every control activation | Read limits → local; qualified explicit start only after separate consent; Stop → radio discovery ends; Back → no automatic Tor bypass. |
| Distinctive states | No wallet sync/settlement promise; no multi-hop internet claim; denied radio permission normal. |
| Exact copy | “Nearby transfers can reveal proximity and radio activity. This is not an automatic fallback.” |
| Data read / written | Protected route/configuration and bounded local health state. |
| Network calls | Broker-managed approved Tor/bootstrap/PT paths; no direct application fallback. |
| Cryptographic operations | Signed infrastructure manifest validation; endpoint configuration is not identity verification. |
| Disclosure-ledger effect | Transport infrastructure observes its role; no universal anonymity claim. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No Bluetooth/Wi-Fi discovery before explicit action and qualified platform gate. |
| Traceability / release scope | T-04; AUD-07/AUD-08; feature coverage F-056–F-064; Core/Advanced. Required evidence absent initially. |


## You, help, notifications, and build

### H-01: You hub

| Record field | Required behavior |
|---|---|
| Entry points | You tab. |
| Layout and elements | Local profile; Devices; Privacy & Network; Security & Vault; Backup & Restore; Notifications; Help; Privacy Report; About; Advanced; Lock. |
| Every control activation | Profile → C-09; Devices → D-01; Network → N-01; Security → S-01; Backup → B-01; Notifications → H-02; Help → H-04; Report → H-03; About → H-08; Advanced → H-10; Lock → S-02. |
| Distinctive states | Wallet activation entry available without active tab; locked state reveals no settings secrets; no account/billing identity display required. |
| Exact copy | “Your profile is local. There is no TGP account password to reset.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening You triggers no wallet, rate, support, update, or engagement network request. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-02: Notification availability choice

| Record field | Required behavior |
|---|---|
| Entry points | You Notifications or contextual request. |
| Layout and elements | Platform-specific app-open/foreground/reviewed distributor/platform notice choices; minimal payload; Save; Disable. |
| Every control activation | Select → local draft plus exposure explanation; Save → OS permission and reviewed registration only if approved; Disable → mapping removal/expiry and generic availability update. |
| Distinctive states | iOS default app-open; denied/delayed/force-quit explicit; no sender/body/amount preview default; no content-key accessibility downgrade. |
| Exact copy | “Optional platform notices expose notification metadata. Message content still uses the protected route.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | Only explicit approved platform/distributor registration, separately disclosed from broker content transport. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Push cannot decrypt vault, activate capture, authorize device, or sign funds. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-03: Local Privacy Report

| Record field | Required behavior |
|---|---|
| Entry points | You Privacy Report or N-01. |
| Layout and elements | Scope/date; route/fail-closed/resolver checks; Passed/Issue/Not tested/Inconclusive; Run; clear; external-test opt-in. |
| Every control activation | Run → bounded local checks; check → evidence details; external test → separate observer consent; Clear → local history deletion; Export → H-05. |
| Distinctive states | No universal score; offline local checks still run; unavailable instrumentation inconclusive not passed. |
| Exact copy | “These results apply only to the tested path and time. They are not an anonymity guarantee.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No external IP/DNS request before consent; results cite local test scope/configuration. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-04: Help and troubleshooting

| Record field | Required behavior |
|---|---|
| Entry points | You Help or inline error. |
| Layout and elements | Local FAQ, error code, tutorial, recovery limits, support export, legal availability. |
| Every control activation | FAQ → bundled local content; tutorial → H-07; support → H-05; legal → H-11; external article → explicit M-10 boundary. |
| Distinctive states | Offline help available; support cannot inspect chats/reset seeds; no automatic log upload. |
| Exact copy | “Support will never ask for your recovery phrase or private keys.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Help article links cannot silently fetch tracking pixels or prefill secrets. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-05: Diagnostic/report preview

| Record field | Required behavior |
|---|---|
| Entry points | Help support or Privacy Report Export. |
| Layout and elements | Exact fields/content selected; redactions; recipient/retention; Remove field; Export/Cancel. |
| Every control activation | Field → readable value; Remove → exclude; Export → H-06 after final explicit boundary; Cancel → no disclosure; content report → explicitly selected content only. |
| Distinctive states | No seed/key/address-contact map default; locked content unavailable; missing retention policy blocks submission. |
| Exact copy | “Review exactly what you will share. Exporting leaves private local storage.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Redaction at source, bounded package, no hidden fields or automatic complete history. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-06: Support export/handoff result

| Record field | Required behavior |
|---|---|
| Entry points | H-05 Export. |
| Layout and elements | Chosen destination/service, file preview summary, submission state, Done/Cancel. |
| Every control activation | Choose destination → OS share/file boundary; Submit where supported → explicit authorized send; Done → help; Cancel before send → no submission. |
| Distinctive states | Partial/failed submission honest; already sent cannot be recalled by Cancel; no support data directory joined to messaging. |
| Exact copy | “The selected support destination controls its copy under the stated retention policy.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Final package matches preview byte-for-field and excludes unrelated secrets. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-07: Tutorial and local hints settings

| Record field | Required behavior |
|---|---|
| Entry points | You Help Tutorial. |
| Layout and elements | Three-task checklist; hint examples; reset; dismiss all; no analytics. |
| Every control activation | Task → O-07 matching safe path; Reset → local reset; Dismiss all → local preference; Back → help. |
| Distinctive states | Offline works; no remotely targeted experiments; never covers active security warning. |
| Exact copy | “Tutorial progress stays on this device.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tutorial state contains no messages, wallet data, contact names, or behavior upload. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-08: About, licenses, and build evidence

| Record field | Required behavior |
|---|---|
| Entry points | You About or pre-setup About. |
| Layout and elements | Version/platform/source commit; artifact/signature status; independent rebuild status; audit scope; licenses; Check updates. |
| Every control activation | Build details → exact evidence; licenses → bundled notices; audit → scope/findings not blanket badge; Check → H-09 only after opt-in. |
| Distinctive states | Cannot inspect installed package: says so; missing independent rebuild not mislabeled reproducible; offline cached evidence timestamped. |
| Exact copy | “A signed matching artifact does not prove runtime device integrity.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: AGPL/SQLCipher/other notices visible; upstream audit never represented as TGP audit. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-09: Update review and rollback protection

| Record field | Required behavior |
|---|---|
| Entry points | H-08 explicit Check or permitted stored preference. |
| Layout and elements | Signed version/profile/compatibility; security notes; download/install; Later; evidence. |
| Every control activation | Check/download → broker; Install → platform signed artifact flow; Later → unchanged unless unsafe capability blocked under policy; evidence → exact build scope. |
| Distinctive states | Invalid/expired/rollback signature rejects; offline no direct fallback; no remote JS injection; pending swap recovery not stranded. |
| Exact copy | “Review the supported security profile and known issues for this build.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Tampered manifest/artifact, old signed version and compromised UI cannot bypass release checks. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-10: Advanced hub

| Record field | Required behavior |
|---|---|
| Entry points | You Advanced. |
| Layout and elements | Separated Network, Financial tools, Offline signing, Continuity, local experiments, Delete profile; explanations. |
| Every control activation | Network → N-04/N-06; Financial → X-01; Offline signing → W-14; Continuity → R-07; Local controls → S-08; Delete → S-09. |
| Distinctive states | Disabled experiments visible as explanations only; no tap sequence bypass; normal features remain outside. |
| Exact copy | “Advanced controls do not relax the privacy requirements.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Feature flags/hidden deep links cannot turn blocked capability on. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-11: Legal availability and user obligations

| Record field | Required behavior |
|---|---|
| Entry points | You Help Legal or financial eligibility notice. |
| Layout and elements | Selected distribution region; policy date; software/use/service distinctions; country restrictions; no legal guarantee; counsel contact. |
| Every control activation | Region info → local signed policy display; financial restriction → exact capability explanation; external law → M-10 boundary; Back → no action. |
| Distinctive states | Unknown/unreviewed jurisdiction: no financial service start; no silent IP/GPS collection; changing region not presented as bypass. |
| Exact copy | “Privacy tools do not make unlawful transactions lawful. This is not legal advice.” |
| Data read / written | Minimum local policy selection, not mandatory identity/country telemetry. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Legal block does not erase keys, disable safe recovery, or add hidden identity collection. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-12: Funding without chat identity

| Record field | Required behavior |
|---|---|
| Entry points | You About → Support development. |
| Layout and elements | Free-chat policy; voluntary options; separate billing boundary; no rewards/token/percentage; Back. |
| Every control activation | Read model → local; voluntary contribution → explicit external/payment boundary and eligible policy; paid optional service → separate unlinked entitlement review if ever approved. |
| Distinctive states | No donation required; external processor may retain business records; no donor badge attached to profile. |
| Exact copy | “Core private chat and security do not require payment.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No chat/contact/queue ID in invoice, donation payload, analytics, or entitlement claim. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-13: Consented research and feedback

| Record field | Required behavior |
|---|---|
| Entry points | Help → Research, only if project offers a separate study. |
| Layout and elements | Optional protocol, collected fields, researcher, retention, consent, withdraw; no production tracking toggle. |
| Every control activation | Read protocol → exact study; Consent → separate approved recruitment boundary; Withdraw → stated process; feedback → H-05 selected content. |
| Distinctive states | No active study says none; refusal leaves features unchanged; no silent random assignment or behavioral SDK. |
| Exact copy | “Using TGP does not enroll you in research.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No experimental group identifier, keystrokes, contact behavior, or wallet activity transmitted in normal app use. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |

### H-14: Security incident notice

| Record field | Required behavior |
|---|---|
| Entry points | Verified signed release/capability notice or local detected unsafe state. |
| Layout and elements | Exact affected build/capability; uncertainty; stop-new-operation scope; safe update/recovery; evidence. |
| Every control activation | Update → H-09; active financial recovery → X-05/W-14 as applicable; evidence → exact signed notice; Dismiss → cannot bypass local mandatory safety block. |
| Distinctive states | Offline clients may not receive notice; invalid notice cannot execute commands; content keys never uploaded; active recovery not wiped. |
| Exact copy | “This notice affects the named capability. It does not prove that all devices or past copies are safe.” |
| Data read / written | Local settings, evidence results, tutorial state and previewed diagnostic fields. |
| Network calls | No hidden analytics; explicit external/platform/check actions only. |
| Cryptographic operations | No content or wallet keys to support/push; signed release validation when requested. |
| Disclosure-ledger effect | Platform, external help, and support boundaries are explicitly reviewed. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Incident channel cannot erase keys, enroll device, change recipient, extract secrets, or strand funded operations. |
| Traceability / release scope | T-11/T-14/T-15/T-16; AUD-17/AUD-24; feature coverage F-005,F-060,F-072,F-097–F-102,F-104; Core/Advanced. Required evidence absent initially. |


## Wallet activation and connection

### W-01: Activate optional wallet

| Record field | Required behavior |
|---|---|
| Entry points | You Wallet or eligible payment action. |
| Layout and elements | Separate recovery/isolation explanation; Activate; Not now; no default chain/account. |
| Every control activation | Activate → platform qualification check then W-02; Not now → chat unchanged; limits → local privacy explanation. |
| Distinctive states | Unqualified platform → management/export explanation only; no seed creation before choice; incoming request still viewable. |
| Exact copy | “Wallets are optional and separate from chat. Linking chats does not link funds.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Decline activation and all core chat journeys remain available. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-02: Choose create, connect, or restore

| Record field | Required behavior |
|---|---|
| Entry points | W-01. |
| Layout and elements | Create new wallet; Connect existing hardware/watch-only; Restore recovery; chain choice. |
| Every control activation | Create → W-11; Connect → W-03; Restore → W-12; chain → supported exact network only; Back → inactive/previous wallet. |
| Distinctive states | Unsupported chain disabled; no generic all-chain seed; chat name never passed to chain adapter. |
| Exact copy | “Connect does not require your seed. Restore introduces spending secrets into this device.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Normal Connect path contains no seed field. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-03: Existing wallet connection method

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Connect. |
| Layout and elements | Hardware first; watch-only descriptor/address; requested data preview; compatibility matrix. |
| Every control activation | Hardware → W-04; Watch-only → W-05; matrix → exact model/format/platform; Back → no imported authority. |
| Distinctive states | Unsupported hardware truthful; no account-based hosted wallet login; chain/network mismatch rejected. |
| Exact copy | “Connecting does not remove links in this wallet's earlier history.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No wallet provider registration, seed prompt, or TGP wallet account created. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-04: Hardware connection and policy review

| Record field | Required behavior |
|---|---|
| Entry points | W-03 Hardware. |
| Layout and elements | Device/firmware/chain app; transport permission; public policy requested; Connect/Cancel. |
| Every control activation | Connect → permitted local device session; approve public descriptor/address on hardware → W-06; Cancel → close session; unsupported → no speculative support. |
| Distinctive states | Disconnect/reconnect revalidates device/policy; no vendor analytics request; signer seed stays on hardware. |
| Exact copy | “Review the device and public wallet policy. No seed is requested.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | No vendor cloud request; only reviewed local hardware transport and later approved sync. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Different returned policy, substituted device, denied USB/Bluetooth and firmware mismatch block safely. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-05: Watch-only import preview

| Record field | Required behavior |
|---|---|
| Entry points | W-03 Watch-only. |
| Layout and elements | Typed descriptor/xpub/address import; network/derivation/policy preview; sensitive-data warning; Import/Cancel. |
| Every control activation | Paste/scan/file → bounded preview; Import → W-06 management-only record; Cancel → clear transient material; reveal → local deliberate. |
| Distinctive states | Wrong checksum/network/unsupported derivation rejected; no network validation upload; large QR/file bounded. |
| Exact copy | “Public wallet data can reveal your portfolio. TGP checks it locally and does not upload it to a public wallet service.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | None during import validation. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Imported descriptor cannot trigger remote URL, wallet derivation bomb, or signing authority. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-06: Provenance and management-only quarantine

| Record field | Required behavior |
|---|---|
| Entry points | Existing-wallet import/connection. |
| Layout and elements | Externally linked/history unknown choice; conservative explanation; management-only label; Continue; source details. |
| Every control activation | User provenance choice → local conservative tag; Continue → W-07; details → W-13; Pay contact → blocked explanation, no warning-only override. |
| Distinctive states | Unknown history stays conservative; fresh address/swap output does not auto-upgrade; no anonymous/clean badge. |
| Exact copy | “This wallet can be managed here. Contact payments remain unavailable while identity-linkage requirements are unmet.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Any external transformation preserves ancestry label and cannot unlock baseline-blocked spend automatically. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-07: Chain node and privacy profile

| Record field | Required behavior |
|---|---|
| Entry points | Wallet setup or settings. |
| Layout and elements | Own node/protected peer mode; chain-specific third-party exposure; endpoint type; Test/Save. |
| Every control activation | Own endpoint → N-05 typed test; approved BTC filter mode → local peer config; ETH RPC → explicit query exposure; Save → W-08 if qualified. |
| Distinctive states | No endpoint/no qualifying mode: wallet remains unsynced/limited; no default direct provider; XMR view-key service unavailable. |
| Exact copy | “Tor hides network origin from the endpoint, not the address or query you send it.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No batched unrelated ETH accounts, BTC xpub upload, or XMR private view-key export. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-08: Wallet synchronization

| Record field | Required behavior |
|---|---|
| Entry points | Approved node profile. |
| Layout and elements | Chain/profile, last locally verified state, headers/scan progress, pause, details. |
| Every control activation | Pause → stop optional sync safely; Details → exact node/query exposures; Done → W-09; node change → W-07 reviewed. |
| Distinctive states | Stale/partial/offline explicit; balance not final before required scan; provider proof/checkpoint failure blocks trusted claims. |
| Exact copy | “Synchronization is incomplete. Displayed funds or history may be incomplete.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Malicious provider, stale checkpoint, reorg and process death cannot show false complete/spendable state. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-09: Wallet home

| Record field | Required behavior |
|---|---|
| Entry points | Activated wallet tab. |
| Layout and elements | Selected wallet/network; hidden-by-default sensitive balance; sync/provenance; Receive/Pay/Request; History; add/settings. |
| Every control activation | Reveal balance → separate local wallet policy; Receive → W-10; Pay → P-03 eligible or block; Request → P-01; History → P-09; Add → W-02; Settings → W-13. |
| Distinctive states | Watch-only no signing; management-only contact Pay blocked; stale balance warning; chat device linkage never populates funds. |
| Exact copy | “Management-only” / “Watch-only” / “Sync incomplete” shown independently. |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening Wallet cannot expose contact roster or trigger hidden rates/token/NFT services. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-10: Receive address and request context

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Receive. |
| Layout and elements | Chain/network, fresh address/subaddress, optional amount, reveal/copy/QR; local label; external-share warning. |
| Every control activation | Reveal → protected display; Copy → deliberate clipboard boundary; QR → typed receive code; Request contact → P-01 eligible 1:1; Done → home. |
| Distinctive states | Fresh address not privacy guarantee; unsupported stealth/silent receive disabled; no reuse by default; stale scan caveat. |
| Exact copy | “This address can be shared. Public-chain receipts and funding history may still be linkable.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receive QR cannot be misparsed as contact/pairing or contain private key/contact label by default. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-11: Create new wallet and recovery preparation

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Create. |
| Layout and elements | Exact chain/recovery format; local creation; backup requirement; no inherited messaging root; Create/Cancel. |
| Every control activation | Create → independent wallet entropy and protected store; Backup → B-09; Continue → W-07 only under reviewed policy; Cancel → safe unactivated cleanup. |
| Distinctive states | Entropy/key protection failure blocks; new wallet not labeled anonymous; receive/spend readiness depends backup/capability rules. |
| Exact copy | “New keys do not make later funding anonymous. Back up this wallet separately.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | OS entropy and maintained chain wallet derivation in isolated wallet runtime; no messaging-key derivation. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Two wallet roots and messaging roots independent; backup acknowledgement does not certify written backup. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-12: Restore wallet recovery

| Record field | Required behavior |
|---|---|
| Entry points | W-02 Restore. |
| Layout and elements | Exact chain/format; protected seed/passphrase input; XMR restore height/BTC descriptor needs; restore review. |
| Every control activation | Choose format → supported parser; input visibility → deliberate; Restore → wallet-only derivation and W-06/W-07; Cancel → clear transient secrets. |
| Distinctive states | Wrong format/network/passphrase uncertainty truthful; no seed guessing/upload; no chat or current membership recovery. |
| Exact copy | “Only enter recovery material on a trusted device. This operation can grant spending access.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Seed never enters JS/general diagnostics/clipboard; restore cannot silently become chat continuity. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-13: Wallet settings and source labels

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings/provenance detail. |
| Layout and elements | Node profile; local provenance/source tags; backup; hardware; guardrails; rates; disconnect/remove; advanced. |
| Every control activation | Node → W-07; source → local conservative view; Backup → B-09; Guardrails → P-11; Rates → W-15; Remove → separate backup/removal review; Advanced → X-01. |
| Distinctive states | No anonymity score; mixed-source selection blocked automatically; local label changes cannot change verified history facts. |
| Exact copy | “Source labels are local safety notes, not proof of ownership, legality, or unlinkability.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Disconnect removes local association only; no funds destroyed without separate explicit removal ceremony. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-14: Offline signing transfer

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Advanced → Offline signing. |
| Layout and elements | Typed unsigned transaction/PSBT, exact review summary, QR/file export, signed-return import; Cancel. |
| Every control activation | Export → explicit destination review; Import signed → bounded parse and intent comparison then P-07; Cancel → no broadcast; unknown type → reject. |
| Distinctive states | No private-key export; copied unsigned/public policy still sensitive; corrupt/mismatched returned payload blocked. |
| Exact copy | “Review destination, amount, network, change, and fee on the signing device.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Cross-network, sighash, fee, change and recipient substitution cannot pass return validation. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-15: Optional fiat estimates

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings Rates. |
| Layout and elements | Off default; manual rate; approved remote identifier-free source; cached time/staleness; Save. |
| Every control activation | Manual → local input; remote opt-in → exposure preview and broker fetch; Refresh → explicit request; Off → no future fetch. |
| Distinctive states | Stale/missing rate does not block exact-coin review; no wallet/contact ID in request; no direct fallback. |
| Exact copy | “Approximate value only. Not an executable exchange price.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wallet opening has zero rate traffic until enabled; failure leaves exact amounts usable. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |

### W-16: Silent and stealth receiving experiments

| Record field | Required behavior |
|---|---|
| Entry points | Wallet Advanced → Receiving protocols. |
| Layout and elements | Bitcoin silent receive and Ethereum stealth/gas profiles separately listed; scanning/recovery/infrastructure evidence; unavailable. |
| Every control activation | Profile → exact limitations; recovery → required scan metadata; Back → ordinary deliberate receive only; no automatically enabled announcement scan. |
| Distinctive states | No production activation until all gates; ETH gas source can associate addresses; unsupported hardware honest. |
| Exact copy | “A different receiving address does not remove funding, scanning, gas, or endpoint linkage.” |
| Data read / written | Separate wallet store, provenance and node profile; no chat roster in adapter. |
| Network calls | Wallet-specific broker context; no xpub/address upload in approved BTC mode; ETH query exposure disclosed. |
| Cryptographic operations | Independent chain keys or watch-only data; Connect never requests seed. |
| Disclosure-ledger effect | Existing history remains linkable; no TGP-readable contact/payment ledger. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No external indexer, announcement service, or gas relayer contacted on catalog view. |
| Traceability / release scope | T-10; AUD-19/AUD-20/AUD-21; feature coverage F-074–F-080,F-086,F-088,F-096; Optional, platform/chain gated. Required evidence absent initially. |


## Payment requests and spending

### P-01: Create one-to-one payment request

| Record field | Required behavior |
|---|---|
| Entry points | Qualified Wallet Request or contact details. |
| Layout and elements | Intended direct peer, comparison, chain, fresh address, optional integer amount/memo, expiry, Review. |
| Every control activation | Select peer → existing 1:1 only; amount/memo → bounded input; Review → P-02; Cancel → no request; group path → select person and open direct scope. |
| Distinctive states | No wallet still can view incoming request; unsupported/public-chain eligibility blocks creation; no group event. |
| Exact copy | “A request does not move funds.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No plaintext address/amount/contact map to TGP service and no hidden peer signature credential. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-02: Incoming request card and details

| Record field | Required behavior |
|---|---|
| Entry points | Typed E2EE direct request. |
| Layout and elements | Sender comparison; exact chain/address/amount/expiry; claimed versus observed status; Pay/Decline; details. |
| Every control activation | Pay → P-03 eligibility and wallet review; Decline → bounded local/optional scoped response; Details → safe fields; expired → no approval; activate wallet → W-01. |
| Distinctive states | Wrong network/address/replay/unknown version rejected; peer “paid” claim not settlement; locked hides sensitive detail. |
| Exact copy | “No funds have moved. Review in your wallet before authorizing.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Crafted card cannot sign/broadcast or force wallet activation. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-03: Select payer wallet and amount

| Record field | Required behavior |
|---|---|
| Entry points | Pay contact or incoming request. |
| Layout and elements | Eligible wallet list, source policy, exact amount, request expiry, Continue. |
| Every control activation | Wallet → capability/provenance check; amount → integer validation; Continue → P-04; management-only → W-06 blocked explanation; Back → no effect. |
| Distinctive states | Insufficient funds/stale sync/unknown history blocks; no merge of different source tags; no public-chain warning override. |
| Exact copy | “Choose an eligible wallet. Connecting a wallet does not make contact payments private.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Changing wallet/source/amount invalidates any earlier review handle. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-04: Exact payment review

| Record field | Required behavior |
|---|---|
| Entry points | P-03 valid preparation. |
| Layout and elements | Recipient/key state; network; amount; fee/cap; source; destination; delay; worst relevant exposure; Authorize/Back. |
| Every control activation | Authorize → P-05 with current revision; source/fee/schedule edit → recompute review; destination reveal → deliberate; Back → no sign. |
| Distinctive states | Key/request/fee/source/chain change invalidates review; offline quote stale; no floating-point rounding ambiguity. |
| Exact copy | “Review the exact amount, network, destination, and fee before authorizing.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Substitution between review and authorization causes conflict, never silent sign. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-05: Separate wallet authorization

| Record field | Required behavior |
|---|---|
| Entry points | P-04 Authorize. |
| Layout and elements | Exact action summary; local native reauth/hardware choice; Confirm/Cancel; no chat-unlock reuse as sole authority. |
| Every control activation | Confirm → one-use authorization for reviewed revision; hardware → P-06; local sign → P-07; Cancel → no signature. |
| Distinctive states | Failed auth/rate limit/locked wallet blocks; process restart loses unconsumed UI authorization; no background auto-sign. |
| Exact copy | “Authorize this payment only. Chat access does not grant spending access.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Untrusted frontend cannot reuse handle for different recipient/amount or repeated spend. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-06: Hardware or air-gapped signature return

| Record field | Required behavior |
|---|---|
| Entry points | P-05 supported signer. |
| Layout and elements | Transaction review handoff; connection/export; waiting; import; Cancel. |
| Every control activation | Send to signer/export → reviewed typed payload; Import/return → exact intent validation; Cancel → no broadcast; changed payload → reject. |
| Distinctive states | Device disconnect, unsupported policy, partial QR, stale authorization safe; no seed prompt. |
| Exact copy | “A returned signature is checked against your reviewed transaction before broadcast.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Wrong change/fee/network/sighash/recipient or extra transaction cannot sneak through. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-07: Signed/ready/broadcast decision

| Record field | Required behavior |
|---|---|
| Entry points | Valid local/hardware signing result. |
| Layout and elements | Signed status, broadcast policy, copied-signature warning, Broadcast if separate step, Cancel local hold. |
| Every control activation | Broadcast → broker submission under current valid policy; Hold → explicit signed-held advanced flow; Cancel → stop local submission, warn copied signature may escape. |
| Distinctive states | Unsigned schedule instead → P-10; route down stays not broadcast; unknown result reconciles chain before retry. |
| Exact copy | “Signed is not broadcast. A copied signed transaction may be broadcast elsewhere.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No automatic double broadcast/sign on timeout; cancel never claims chain reversal. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-08: Payment progress and chain observation

| Record field | Required behavior |
|---|---|
| Entry points | Broadcast submission or request status. |
| Layout and elements | Submitted/pending/confirming/chain-specific finality/spendability; local evidence; details; no chat delivery equivalence. |
| Every control activation | Details → P-09; Refresh → approved wallet observation; return chat → minimal card; error → safe chain-specific action not generic repeat. |
| Distinctive states | Reorg/conflict/replacement/expired request distinct; pending does not imply irreversible finality; peer claim labeled. |
| Exact copy | “This status comes from your wallet's current chain view, not a chat receipt.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Reorg can move state backward without duplicate payment or false terminal success. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-09: History and transaction detail

| Record field | Required behavior |
|---|---|
| Entry points | Wallet History or payment progress. |
| Layout and elements | Local sent/received/pending filters; chain status; local labels; reveal TXID/proof; export; mapping retention. |
| Every control activation | Row → exact transaction; Reveal TXID/proof → disclosure warning; Export → chosen minimal fields/destination; remove local mapping → separate confirmation; filter → local. |
| Distinctive states | Locked wallet hides; stale/reorg state visible; card minimization not public-chain erasure; no explorer auto-open. |
| Exact copy | “Sharing identifiers or proofs can reveal more about this payment.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Default history export excludes contact labels/mapping unless explicitly selected. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-10: Delay or schedule payment

| Record field | Required behavior |
|---|---|
| Entry points | P-04 schedule or Advanced. |
| Layout and elements | Unsigned intent default; chosen time; fee cap/expiry; lock/background limits; signed-held advanced warning; Save/Cancel. |
| Every control activation | Save → protected unsigned scheduled intent; due → revalidate and ask authorization; Cancel pending → remove local intent; signed-held → separate explicit qualified mode. |
| Distinctive states | App asleep/locked says awaiting authorization; spent inputs/nonce/expired request/changed fee requires new review; jitter distinct. |
| Exact copy | “Scheduling does not guarantee broadcast or hide timing. You may need to authorize again.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Clock change, reboot, request expiry and conflicting spend cannot trigger unauthorized late payment. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-11: Spend guardrails

| Record field | Required behavior |
|---|---|
| Entry points | Wallet settings Guardrails. |
| Layout and elements | Local daily threshold, large-send extra review/delay, reset timezone, remaining limit, Save. |
| Every control activation | Edit → local policy draft; Save → separate wallet auth if broadening; reset rule → explicit explanation; Back → unchanged. |
| Distinctive states | Not coercion-proof; cloned wallet/other signer may bypass local limits; no server enforcement; clock ambiguity conservative. |
| Exact copy | “These are local guardrails, not a guarantee against theft or coercion.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Limit broadening cannot be caused by contact payload, settings sync, or clock rollback. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |

### P-12: Payjoin negotiation review

| Record field | Required behavior |
|---|---|
| Entry points | Qualified BTC wallet Advanced → Payjoin. |
| Layout and elements | Protocol/version/direction; receiver/coordinator transport; exact extra-input/fee policy; review; no-fallback choice. |
| Every control activation | Start only if qualified → isolated negotiation; review changed transaction → P-04; cancel/failure → no plain-payment fallback; Back → no broadcast. |
| Distinctive states | Default experimental/off; rejected proposal not ordinary BTC send; timeout/replay/contribution mismatch stops. |
| Exact copy | “Payjoin is not a guarantee against transaction analysis. A failed negotiation will not send a plain payment.” |
| Data read / written | Typed local request/review handles and separate wallet transaction state. |
| Network calls | E2EE 1:1 request transport and separately authorized chain broadcast through broker. |
| Cryptographic operations | Revision-bound separate local signing authorization; chat payload cannot sign. |
| Disclosure-ledger effect | Intended peer sees request; public-chain/provider limits remain; no group financial event. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Receiver cannot add unauthorized outputs/fees or swap destination; no on-chain contact-spend eligibility bypass. |
| Traceability / release scope | T-10; AUD-20/AUD-21/AUD-22; feature coverage F-081–F-087; Optional, eligibility gated. Required evidence absent initially. |


## External tools and swaps

### X-01: Financial tools catalog

| Record field | Required behavior |
|---|---|
| Entry points | You Advanced or wallet Advanced. |
| Layout and elements | Per-adapter status, protocol/version, legal region, audit/deadline evidence; no ranked liquidity offers by default. |
| Every control activation | Adapter → X-02; Swap → X-03 disabled/qualified path; export tools → X-06; Back → no discovery traffic. |
| Distinctive states | Research-only stays disabled; missing manifest/review blocks; no auto-install or TGP hosted orderbook. |
| Exact copy | “Independent tools have different privacy, financial, and legal risks. None guarantees unlinkability.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Opening catalog performs no counterparty/coordinator discovery or address upload. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

### X-02: Adapter manifest review

| Record field | Required behavior |
|---|---|
| Entry points | X-01 adapter. |
| Layout and elements | Exact destinations/data, custody/control, fees/penalties, recovery deadlines, evidence, region decision, Enable only if qualified. |
| Every control activation | Destination/data row → detailed field list; evidence → exact review; Enable → all-gates check plus explicit consent; disabled reason → no override. |
| Distinctive states | Unknown commit/license/audit/legal/retention blocks; updated manifest requires re-review; no broad destination wildcard. |
| Exact copy | “A non-custodial label does not prove safety or exemption from regulation.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Manifest cannot broaden destinations, secret authority or mainnet scope through unsigned runtime config. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

### X-03: Contact swap offer

| Record field | Required behavior |
|---|---|
| Entry points | Qualified 1:1 swap action; otherwise disabled explanation. |
| Layout and elements | Peer, direction/assets/network, protocol engine, amounts/expiry; create/accept review; no group offer. |
| Every control activation | Create/accept → local bounded offer and X-04 only if eligible; Decline → no commitment; expired → new offer; Back → no funding. |
| Distinctive states | Mainnet default disabled; unsupported direction rejected; no generic BTC↔XMR/ETH↔XMR promise. |
| Exact copy | “An offer is not funding. Atomic does not mean risk-free.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Group route cannot emit offer; stale quote/direction/protocol mismatch rejected. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

### X-04: Swap financial and deadline review

| Record field | Required behavior |
|---|---|
| Entry points | Valid qualified offer. |
| Layout and elements | Amounts, all fees/deposit/penalty, chain waits, exact engine worst case, watcher/signer authority, deadline coverage; Start. |
| Every control activation | Coverage details → evidence/role; Start → only if protocol/financial/legal/security gates pass; no coverage → blocked; Back → no funding. |
| Distinctive states | Phone-only background assumption fails; watcher offline/insufficient fees blocks; change in quote/coverage invalidates. |
| Exact copy | “This setup cannot safely cover the required deadlines.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Missing/forged watcher coverage cannot begin irreversible funding. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

### X-05: Active swap and recovery

| Record field | Required behavior |
|---|---|
| Entry points | Only after separately qualified engine funding. |
| Layout and elements | Protocol-specific actual state, deadlines, required action, safe recovery export, no generic cancel/refund guarantee. |
| Every control activation | Required action → engine-authorized review; recovery export → explicit sensitive boundary; status → chain evidence; Stop UI → no false protocol cancellation. |
| Distinctive states | Offline/reorg/fee spike/reboot/peer refusal show exact unresolved state; journal retained; adapter retirement preserves recovery. |
| Exact copy | “Follow this protocol's recovery instructions. Do not assume closing the app cancels a funded swap.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Every engine terminal/refund/intervention path tested; no deletion of recovery secrets before safe completion. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |

### X-06: External tool export/import

| Record field | Required behavior |
|---|---|
| Entry points | Qualified external adapter or offline financial export. |
| Layout and elements | Tool/version/accepted format; exact fields; destination; residual exposure; Export/Import/Cancel. |
| Every control activation | Export → explicit OS/application boundary; Import → bounded network/intent/format validation; Cancel → no handoff; unsupported PSBT/tool pair → unavailable. |
| Distinctive states | No default CoinJoin/mixer coordinator; no automatically prescribed transformation route; return cannot mark funds anonymous. |
| Exact copy | “The external tool controls its own behavior. This does not remove prior wallet history.” |
| Data read / written | Adapter manifest and isolated encrypted operation/recovery journal. |
| Network calls | None while disabled; approved adapter destinations only after all gates. |
| Cryptographic operations | Maintained reviewed engine only; protocol-specific authority and deadline coverage. |
| Disclosure-ledger effect | External actors/exports add observations; no tool certifies unlinkability. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unsupported interoperability cannot be shown as working; no seed/contact graph in default export. |
| Traceability / release scope | T-10; AUD-23; feature coverage F-087–F-091; Experimental/deferred; mainnet disabled. Required evidence absent initially. |


## Trust changes and recovery

### R-01: Contact key changed

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated replacement or detected identity mismatch. |
| Layout and elements | Prior/new fingerprints, known evidence not guessed cause, paused sends, Compare, local history, Cancel pending. |
| Every control activation | Compare → C-07 fresh representation; history → local previous records; cancel queue → scoped action; close → warning persists and unsafe sends stay blocked. |
| Distinctive states | Offline/missing evidence not auto-accepted; “new phone” only if authenticated evidence supports; no inherited green badge. |
| Exact copy | “This contact's key changed. Review before sending new content.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Reinstall claim cannot silently preserve verification or release queued messages. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-02: New endpoint approval

| Record field | Required behavior |
|---|---|
| Entry points | Contact/group scoped device proposal. |
| Layout and elements | Exact relationship/group, new scoped endpoint, authority/provenance, content effect, Approve/Reject. |
| Every control activation | Approve → current authority/consent/profile validation and admission; Reject → no recipient expansion; details → scoped provenance; group policy → G-08. |
| Distinctive states | Controller transfer record not independent person comparison; offline group transition pending; no global device model/name required. |
| Exact copy | “Approving makes this endpoint another recipient for this scope.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Approval cannot add future chats, old history, wallet authority, or unrelated group role. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-03: Revoke lost device

| Record field | Required behavior |
|---|---|
| Entry points | D-01 selected device. |
| Layout and elements | Selected grants; retained-copy warning; reauthenticate; Revoke; per-scope progress. |
| Every control activation | Revoke → immediate local fanout stop plus authenticated updates/rekeys; scope → pending/applied evidence; Done → inventory; Cancel before effect → unchanged. |
| Distinctive states | Offline peers pending; old copies remain; repeated revoke idempotent; no “erase everywhere”. |
| Exact copy | “This blocks future access as updates take effect. It does not erase stored copies.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Unconfirmed remote update never shown as globally revoked; wallet access not inferred from chat revocation. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-04: Controller migration

| Record field | Required behavior |
|---|---|
| Entry points | Controller Devices → Migrate. |
| Layout and elements | Both-device reauth/comparison; selected continuity authority; fresh endpoint; successor review; Start/Cancel. |
| Every control activation | Compare → reviewed pairing ceremony; select → explicit scopes; Start → authenticated staged migration; progress → applied/pending; wallet migration → separate unavailable/path. |
| Distinctive states | Duplicate successors → R-06; interruption follows reviewed completion/rollback; no ratchet clone; old enrollment retired only under protocol. |
| Exact copy | “Migration transfers authority. It does not prove that every old copy has disappeared.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Old and new controller concurrent, interruption and conflicting successors cannot silently both enroll. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-05: Controller lost

| Record field | Required behavior |
|---|---|
| Entry points | Help recovery or surviving companion. |
| Layout and elements | What this device retains; no automatic promotion; archive/identity/wallet options; re-establish contact. |
| Every control activation | History → available local/ B-06; New identity → explicit fresh setup; wallet recovery → B-09/W-12 separate; continuity → R-07 if approved; Back → no authority. |
| Distinctive states | No approved continuity means honest loss/reset; companion cannot become controller by timeout; old device may remain active. |
| Exact copy | “A surviving companion keeps only its existing grants. It does not automatically gain controller power.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Recovery help cannot trigger silent trust promotion or server password reset. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-06: Group or authority conflict

| Record field | Required behavior |
|---|---|
| Entry points | Contradictory authenticated state, successors, or stale required transition. |
| Layout and elements | Affected scope, bounded local evidence, paused actions, authenticated recovery, support-safe export. |
| Every control activation | Recover → reviewed missing-state/fresh-admission path; Export diagnostics → H-05 bounded; successor group → explicit new group if required; Back → paused state remains. |
| Distinctive states | No wall-clock/arrival winner; no untrusted server rejoin; ordinary unrelated scopes may remain usable. |
| Exact copy | “This scope needs security review. Sending is paused rather than choosing an uncertain authority state.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Fork, partition, stale restore and malicious coordinator cannot force weaker accepted view. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |

### R-07: Continuity archive experiment

| Record field | Required behavior |
|---|---|
| Entry points | Backup hub or recovery help. |
| Layout and elements | Disabled high-consequence status; exact authority versus history distinction; old-controller risk; Back. |
| Every control activation | Read design → local explanation; approved future restore → separately gated ceremony only; Back → no authority; no Enable from normal backup. |
| Distinctive states | Default unavailable; copied archive cannot prove predecessor absence; wallet unrelated. |
| Exact copy | “Continuity recovery can create competing authority if an old copy still exists.” |
| Data read / written | Scoped authority/comparison history and pending transition status. |
| Network calls | Authenticated per-scope changes through broker; no global erase request. |
| Cryptographic operations | Fresh successor state and reviewed continuity; no copied active session. |
| Disclosure-ledger effect | Previously received copies remain; offline peers may not know changes yet. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Ordinary archive contains no continuity authority; deep link cannot enable experimental restore. |
| Traceability / release scope | T-02/T-08/T-12; AUD-14; feature coverage F-010,F-030,F-053–F-055,F-094; Core/Advanced. Required evidence absent initially. |


## Experimental calls

### L-01: Pre-call or unavailable call

| Record field | Required behavior |
|---|---|
| Entry points | Qualified conversation call action. |
| Layout and elements | Intended people/endpoints; route; trust warnings; audio default; Start; limits. |
| Every control activation | Start → only qualified profile then signaling; unsupported → local unavailable explanation; video preview → permission/local preview only; Cancel → no capture. |
| Distinctive states | Key/group/route issue blocks; no direct fallback; no mic/camera from merely opening pre-call. |
| Exact copy | “Setting up encrypted media is separate from sending a call invitation.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: No microphone/camera before consent and no call key to nonparticipants. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

### L-02: Incoming call and endpoint selection

| Record field | Required behavior |
|---|---|
| Entry points | Authenticated qualified call invite. |
| Layout and elements | Generic locked-safe caller state; Answer on this device; Decline; trust/unlock requirement. |
| Every control activation | Answer → local permission/unlock and call admission; Decline → no media; other device answered → no capture; locked → required unlock. |
| Distinctive states | Ringing not live; timeout honest; push cannot release keys; duplicate answers arbitrate one endpoint. |
| Exact copy | “Answering admits this device to the protected call after setup completes.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Multiple-device answer race leaves at most one active media endpoint per person by default. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

### L-03: Live call, rekey, and handoff

| Record field | Required behavior |
|---|---|
| Entry points | Qualified protected media active. |
| Layout and elements | Actual admitted roster; mic mute; camera off default; route; End; handoff; explicit state. |
| Every control activation | Mute → local capture/transmit control; Camera → preview/consent; Handoff → target admit/fresh state/old retire; End → stop capture/erase session state. |
| Distinctive states | Reconnecting/security update pauses media; unsafe rekey ends/pauses; app lock/panic applies capture policy; no automatic recording. |
| Exact copy | “TGP does not record this call. Participants or their devices may still record it.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Sender spoof/replay, outsider decrypt, route failure, lock and handoff interruption safe. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

### L-04: Call ended or failed

| Record field | Required behavior |
|---|---|
| Entry points | User end, timeout, route/security failure. |
| Layout and elements | Actual end reason; no capture; separate voice-note option; retry pre-call; Done. |
| Every control activation | Voice note → A-04 fresh user action; Retry → L-01 full current-state review; Done → chat; no auto-record/upload. |
| Distinctive states | Failed route remains protected-only; no queued speech secretly retained; unsupported state explicit. |
| Exact copy | “The protected call ended. You can choose to record a separate voice message.” |
| Data read / written | Call-specific roster/state; bounded buffers; no recordings/transcripts. |
| Network calls | No media while disabled; otherwise approved Tor-only protected route, no STUN/direct fallback. |
| Cryptographic operations | Independent call-only admission/secrets and reviewed frame protection. |
| Disclosure-ledger effect | Media infrastructure may observe duration/association; chat membership is not call admission. |
| Failure and recovery | Do not commit an unapproved effect. Revalidate current revision on retry; no weaker fallback. |
| Back / gestures / interruption | Back/Close/Escape grants nothing; no outside-dismiss of consequential review. Apply shared lock/capture cleanup and current-revision revalidation. External effects already sent are not undone by navigation. |
| Accessibility | Shared large-text/screen-reader/keyboard/reduced-motion contract; read exact warnings, provenance and pending state before primary action. No gesture-only control. |
| Acceptance criteria | Given this entry and state, when each named control is activated, then only its listed effect occurs. Negative criterion: Call failure does not activate microphone, direct media, or asynchronous attachment automatically. |
| Traceability / release scope | T-09; AUD-18; feature coverage F-045–F-048; Experimental; disabled until qualified. Required evidence absent initially. |

## Screen change control

The catalog is closed for the declared scope, not a claim to know every future third-party interface. OS/store pickers and permission dialogs, hardware firmware, external tools, and exact protocol-specific swap recovery branches need versioned annexes before release.

A new button, menu item, automatic effect, external destination, permission, recipient, retained record, or authority transition must update this catalog, its disclosure comparison, and acceptance tests. A feature flag or deep link cannot bypass a disabled record's release gate.
