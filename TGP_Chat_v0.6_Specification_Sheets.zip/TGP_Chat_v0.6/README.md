# TGP Chat v0.6: Specification Sheet Pack

This pack contains the comprehensive master specification and nine individually readable Markdown sheets. The master follows the requested order and ends with legal/country restrictions.

Inventory: 104 features; 145 fourteen-field product-owned screens; 27 eight-dimension review groups; 58 shared adversarial test scenarios and 20 financial scenarios. These are specification records, not executed tests or certification.

## Files

- `TGP_Chat_Product_Spec_v0.6.md`: complete master document.
- `01-goal-and-feature-catalog.md`: Goal State and Complete Feature Catalog.
- `02-rust-typescript-technical-specification.md`: Rust and TypeScript Technical Specification.
- `03-wallets-payments-and-financial-tools.md`: Wallets, Payments, and Financial Tools.
- `04-security-review-and-disclosure-ledger.md`: Eight-Dimension Security Review and Disclosure Ledger.
- `05-first-thirty-days-and-ui-system.md`: First Thirty Days and UI System.
- `06-tap-level-screen-catalog.md`: Tap-Level Screen Catalog.
- `07-verification-implementation-and-release-contract.md`: Implementation, Verification, and Release Contract.
- `08-feature-and-baseline-traceability.md`: Feature and Baseline Traceability.
- `09-legal-country-restrictions-and-lawful-launch.md`: Legal, Country Restrictions, and Lawful Launch.

## Status

Proposed design baseline dated 5 November 2026. Crypto composition, freshness, platform wallet isolation, some advanced capabilities, implementation, independent assessment and jurisdiction-specific legal approvals remain explicit release dependencies.

The financial tools do not promise anonymity, lawful use everywhere, automatic refund, or legal non-evidence. No user consent or warning overrides the no-regression privacy requirement.
